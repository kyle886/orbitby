import React from 'react';
import { useSearchParams } from 'react-router-dom';
import DevCasePage from './DevCase';

export default function DevCaseDetails() {
  return <DevCasePage />;
}