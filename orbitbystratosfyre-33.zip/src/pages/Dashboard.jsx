import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";

export default function Dashboard() {
  const navigate = useNavigate();

  useEffect(() => {
    const redirectToDashboard = async () => {
      try {
        const user = await User.me();
        
        if (user.user_type === 'stratosfyre_admin') {
          navigate(createPageUrl("AdminDashboard"), { replace: true });
        } else if (user.user_type === 'client') {
          navigate(createPageUrl("ClientDashboard"), { replace: true });
        } else if (user.user_type === 'agent_landlord') {
          navigate(createPageUrl("SubmitListing"), { replace: true });
        } else {
          navigate(createPageUrl("UpdateUserType"), { replace: true });
        }
      } catch (error) {
        navigate(createPageUrl("UpdateUserType"), { replace: true });
      }
    };

    redirectToDashboard();
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <div className="orbit-card p-8 bg-gray-800">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-400 mx-auto"></div>
        <p className="text-gray-300 text-center mt-4">Redirecting to dashboard...</p>
      </div>
    </div>
  );
}