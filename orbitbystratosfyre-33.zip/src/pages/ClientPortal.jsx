
import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { Document } from "@/api/entities";
import { InspectionItinerary } from "@/api/entities";
import { InspectionFeedback } from "@/api/entities";
import { ClientUpdate } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  MapPin, 
  MessageSquare, 
  Star, 
  Clock,
  Download,
  Calendar,
  Bell
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function ClientPortal() {
  const { engagementId } = useParams();
  const [feedItems, setFeedItems] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [inspections, setInspections] = useState([]);
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [feedbackModal, setFeedbackModal] = useState({ open: false, inspection: null });
  const [feedbackForm, setFeedbackForm] = useState({ rating: 0, notes: '' });
  const { toast } = useToast();

  const refresh = useCallback(async () => {
    try {
      const [docsData, inspectionsData, updatesData] = await Promise.all([
        Document.filter({ 
          client_id: engagementId, 
          is_client_visible: true 
        }, '-created_date', 50),
        InspectionItinerary.filter({ 
          client_id: engagementId 
        }, '-created_date', 20),
        ClientUpdate.filter({ 
          client_id: engagementId,
          is_client_visible: true 
        }, '-created_date', 20)
      ]);

      setDocuments(docsData || []);
      setInspections(inspectionsData || []);
      setUpdates(updatesData || []);

      // Create unified feed
      const items = [
        ...(docsData || []).map(d => ({
          type: 'document',
          id: d.id,
          title: d.document_name,
          description: d.description,
          url: d.file_url,
          created_date: d.created_date,
          icon: FileText
        })),
        ...(inspectionsData || []).map(i => ({
          type: 'inspection',
          id: i.id,
          title: `Inspection: ${i.itinerary_name}`,
          description: `${(i.properties || []).length} properties`,
          inspection_date: i.inspection_date,
          created_date: i.created_date,
          icon: MapPin,
          data: i
        })),
        ...(updatesData || []).map(u => ({
          type: 'update',
          id: u.id,
          title: u.title,
          description: u.message,
          created_date: u.created_date,
          icon: Bell
        }))
      ].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

      setFeedItems(items);
    } catch (error) {
      console.error('Error refreshing portal:', error);
      toast({
        variant: "destructive",
        title: "Refresh failed",
        description: "Could not load latest updates"
      });
    } finally {
      setLoading(false);
    }
  }, [engagementId, toast, setDocuments, setInspections, setUpdates, setFeedItems, setLoading]); // Add all dependencies

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, [refresh]); // Depend on memoized refresh function

  const submitFeedback = async () => {
    if (!feedbackModal.inspection || feedbackForm.rating === 0) {
      toast({
        variant: "destructive",
        title: "Please provide a rating"
      });
      return;
    }

    try {
      await InspectionFeedback.create({
        itinerary_id: feedbackModal.inspection.id,
        property_submission_id: feedbackModal.inspection.properties?.[0]?.property_submission_id,
        attendee_name: 'Client Portal User',
        attendee_email: 'portal@client.com', // Would get from user context
        criteria_ratings: {
          overall: feedbackForm.rating
        },
        overall_rating: feedbackForm.rating,
        notes: feedbackForm.notes
      });

      toast({ title: "Feedback submitted successfully" });
      setFeedbackModal({ open: false, inspection: null });
      setFeedbackForm({ rating: 0, notes: '' });
    } catch (error) {
      console.error('Feedback submission failed:', error);
      toast({
        variant: "destructive",
        title: "Failed to submit feedback"
      });
    }
  };

  const formatDate = (dateString) => {
    try {
      return new Date(dateString).toLocaleString('en-AU', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dateString || '';
    }
  };

  if (loading) {
    return (
      <div className="space-y-4 max-w-[1100px] mx-auto px-3">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-800 rounded w-1/3"></div>
          <div className="grid gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 bg-gray-800 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-[1100px] mx-auto px-3">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-white">Client Portal</h1>
        <p className="text-gray-300">Live updates, documents, and feedback for your property search</p>
      </div>

      {/* Live Activity Feed */}
      <Card className="shadow-elevated">
        <CardHeader>
          <div className="flex items-center justify-between">
            {/* Fix: CardTitle should be closed before the enclosing div */}
            <CardTitle className="text-white flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Recent Activity
            </CardTitle>
            <Button variant="outline" size="sm" onClick={refresh}>
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {feedItems.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <Bell className="w-12 h-12 mx-auto mb-3 text-gray-600" />
              <p>No recent activity</p>
            </div>
          ) : (
            feedItems.map(item => {
              const Icon = item.icon;
              return (
                <div key={`${item.type}-${item.id}`} className="flex items-start gap-4 p-4 rounded-lg border border-white/10 hover:bg-white/5 transition-colors">
                  <div className="p-2 rounded-lg bg-orange-500/20">
                    <Icon className="w-4 h-4 text-orange-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-white truncate">{item.title}</h4>
                      <Badge variant="outline" className="text-xs">
                        {item.type}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-300 mb-2">{item.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">
                        {formatDate(item.created_date)}
                      </span>
                      {item.type === 'document' && item.url && (
                        <Button variant="ghost" size="sm" asChild>
                          <a href={item.url} target="_blank" rel="noreferrer">
                            <Download className="w-3 h-3 mr-1" />
                            Download
                          </a>
                        </Button>
                      )}
                      {item.type === 'inspection' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setFeedbackModal({ open: true, inspection: item.data });
                            setFeedbackForm({ rating: 0, notes: '' });
                          }}
                        >
                          <MessageSquare className="w-3 h-3 mr-1" />
                          Feedback
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="shadow-elevated">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-lg bg-blue-500/20">
                <FileText className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{documents.length}</div>
                <div className="text-sm text-gray-400">Documents Shared</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-elevated">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-lg bg-green-500/20">
                <MapPin className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{inspections.length}</div>
                <div className="text-sm text-gray-400">Inspections Scheduled</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Fix: Removed extraneous closing div tag here */}

        <Card className="shadow-elevated">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-lg bg-purple-500/20">
                <Bell className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{updates.length}</div>
                <div className="text-sm text-gray-400">Project Updates</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Feedback Modal */}
      {feedbackModal.open && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-white">Property Feedback</CardTitle>
              <p className="text-sm text-gray-400">
                {feedbackModal.inspection?.itinerary_name}
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-300 mb-2 block">
                  Overall Rating
                </label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map(rating => (
                    <Button
                      key={rating}
                      variant={feedbackForm.rating >= rating ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFeedbackForm({
                        ...feedbackForm,
                        rating
                      })}
                    >
                      <Star className="w-4 h-4" />
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-300 mb-2 block">
                  Additional Notes (optional)
                </label>
                <Textarea
                  value={feedbackForm.notes}
                  onChange={(e) => setFeedbackForm({
                    ...feedbackForm,
                    notes: e.target.value
                  })}
                  placeholder="Share your thoughts about the property..."
                  className="min-h-[100px]"
                />
              </div>

              <div className="flex gap-2 justify-end">
                <Button
                  variant="outline"
                  onClick={() => setFeedbackModal({ open: false, inspection: null })}
                >
                  Cancel
                </Button>
                <Button onClick={submitFeedback}>
                  Submit Feedback
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
