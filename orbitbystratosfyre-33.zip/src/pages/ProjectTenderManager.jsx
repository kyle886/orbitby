import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { TenantRequirement } from '@/api/entities';
import { BuildTenderPackage } from '@/api/entities';
import { BuildBid } from '@/api/entities';
import { BuildRFI } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Hammer, 
  FileQuestion, 
  DollarSign, 
  Clock, 
  Award,
  AlertCircle,
  Plus,
  Send,
  Eye,
  Building
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export default function ProjectTenderManager() {
  const [searchParams] = useSearchParams();
  const projectId = searchParams.get('projectId');
  const { toast } = useToast();

  const [project, setProject] = useState(null);
  const [packages, setPackages] = useState([]);
  const [activePackage, setActivePackage] = useState(null);
  const [bids, setBids] = useState([]);
  const [rfis, setRfis] = useState([]);
  const [loading, setLoading] = useState(true);

  // Create new package form
  const [showCreatePackage, setShowCreatePackage] = useState(false);
  const [newPackageData, setNewPackageData] = useState({
    name: '',
    dueAt: '',
    workScope: '',
    contractForm: 'ABIC',
    estimatedValue: ''
  });

  // RFI form
  const [showRfiForm, setShowRfiForm] = useState(false);
  const [newRfi, setNewRfi] = useState({
    question: '',
    category: 'Design'
  });

  const loadData = useCallback(async () => {
    if (!projectId) return;
    
    setLoading(true);
    try {
      // Load the project
      const projectData = await TenantRequirement.get(projectId);
      setProject(projectData);

      // Load all packages for this project
      const packagesData = await BuildTenderPackage.filter({ projectId });
      setPackages(packagesData || []);
      
      // Set the most recent package as active
      if (packagesData && packagesData.length > 0) {
        const latestPackage = packagesData.sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
        setActivePackage(latestPackage);

        // Load data for the active package
        const [bidsData, rfisData] = await Promise.all([
          BuildBid.filter({ packageId: latestPackage.id }),
          BuildRFI.filter({ packageId: latestPackage.id })
        ]);

        setBids(bidsData || []);
        setRfis(rfisData || []);
      }
    } catch (error) {
      console.error('Error loading project tender data:', error);
      toast({
        variant: 'destructive',
        title: 'Failed to load tender data',
        description: error.message
      });
    } finally {
      setLoading(false);
    }
  }, [projectId, toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleCreatePackage = async () => {
    try {
      const packageData = {
        projectId,
        name: newPackageData.name,
        status: 'OPEN',
        dueAt: new Date(newPackageData.dueAt).toISOString(),
        workScope: newPackageData.workScope,
        contractForm: newPackageData.contractForm,
        estimatedValue: parseFloat(newPackageData.estimatedValue) || null,
        createdBy: 'current_user' // This would come from auth context
      };

      const newPackage = await BuildTenderPackage.create(packageData);
      setPackages(prev => [newPackage, ...prev]);
      setActivePackage(newPackage);
      setShowCreatePackage(false);
      setNewPackageData({ name: '', dueAt: '', workScope: '', contractForm: 'ABIC', estimatedValue: '' });
      
      toast({
        title: 'Tender Package Created',
        description: `${newPackageData.name} has been created and is now open for bids.`
      });
    } catch (error) {
      console.error('Error creating package:', error);
      toast({
        variant: 'destructive',
        title: 'Failed to create package',
        description: error.message
      });
    }
  };

  const handleSubmitRfi = async () => {
    if (!activePackage || !newRfi.question.trim()) return;

    try {
      const rfiData = {
        packageId: activePackage.id,
        rfiNumber: `RFI-${String(rfis.length + 1).padStart(3, '0')}`,
        question: newRfi.question,
        category: newRfi.category,
        askedBy: 'current_user', // This would come from auth context
        createdAt: new Date().toISOString()
      };

      const newRfiRecord = await BuildRFI.create(rfiData);
      setRfis(prev => [newRfiRecord, ...prev]);
      setNewRfi({ question: '', category: 'Design' });
      setShowRfiForm(false);

      toast({
        title: 'RFI Submitted',
        description: `${rfiData.rfiNumber} has been submitted for review.`
      });
    } catch (error) {
      console.error('Error submitting RFI:', error);
      toast({
        variant: 'destructive',
        title: 'Failed to submit RFI',
        description: error.message
      });
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      'OPEN': 'bg-green-500/20 text-green-300 border-green-700',
      'CLARIFICATIONS': 'bg-yellow-500/20 text-yellow-300 border-yellow-700',
      'CLOSED': 'bg-gray-500/20 text-gray-300 border-gray-700',
      'AWARDED': 'bg-purple-500/20 text-purple-300 border-purple-700',
      'DRAFT': 'bg-blue-500/20 text-blue-300 border-blue-700',
      'SUBMITTED': 'bg-orange-500/20 text-orange-300 border-orange-700',
      'UNDER_REVIEW': 'bg-yellow-500/20 text-yellow-300 border-yellow-700',
      'SHORTLISTED': 'bg-indigo-500/20 text-indigo-300 border-indigo-700',
      'REJECTED': 'bg-red-500/20 text-red-300 border-red-700'
    };
    return colors[status] || colors['DRAFT'];
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-8 h-8 rounded-full animate-pulse bg-white/10"></div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="p-8">
        <Card className="orbit-card max-w-lg mx-auto text-center">
          <CardHeader>
            <CardTitle className="text-red-400">Project Not Found</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300">The requested project could not be found.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Project Tender Manager</h1>
            <p className="text-gray-300">{project.company_name} - Fitout Project</p>
            <div className="flex items-center gap-2 mt-2">
              <Building className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">
                Construction & Fitout Works
              </span>
            </div>
          </div>
          <Button 
            onClick={() => setShowCreatePackage(true)}
            className="bg-orange-500 hover:bg-orange-600 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Tender Package
          </Button>
        </div>
      </div>

      {/* Packages Selection */}
      {packages.length > 0 && (
        <div className="mb-6">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {packages.map((pkg) => (
              <Button
                key={pkg.id}
                variant={activePackage?.id === pkg.id ? "default" : "outline"}
                onClick={() => setActivePackage(pkg)}
                className="flex-shrink-0"
              >
                {pkg.name}
                <Badge className={`ml-2 ${getStatusColor(pkg.status)}`} size="sm">
                  {pkg.status}
                </Badge>
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Create Package Form */}
      {showCreatePackage && (
        <Card className="orbit-card mb-6">
          <CardHeader>
            <CardTitle>Create New Tender Package</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Package Name</Label>
                <Input
                  value={newPackageData.name}
                  onChange={(e) => setNewPackageData(prev => ({...prev, name: e.target.value}))}
                  placeholder="e.g., Base Build, Fitout Works"
                  className="orbit-input"
                />
              </div>
              <div>
                <Label>Bid Deadline</Label>
                <Input
                  type="datetime-local"
                  value={newPackageData.dueAt}
                  onChange={(e) => setNewPackageData(prev => ({...prev, dueAt: e.target.value}))}
                  className="orbit-input"
                />
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Contract Form</Label>
                <Select 
                  value={newPackageData.contractForm} 
                  onValueChange={(value) => setNewPackageData(prev => ({...prev, contractForm: value}))}
                >
                  <SelectTrigger className="orbit-input">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ABIC">ABIC</SelectItem>
                    <SelectItem value="AS2124">AS2124</SelectItem>
                    <SelectItem value="AS4000">AS4000</SelectItem>
                    <SelectItem value="Custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Estimated Value (AUD)</Label>
                <Input
                  type="number"
                  value={newPackageData.estimatedValue}
                  onChange={(e) => setNewPackageData(prev => ({...prev, estimatedValue: e.target.value}))}
                  placeholder="500000"
                  className="orbit-input"
                />
              </div>
            </div>
            <div>
              <Label>Work Scope</Label>
              <Textarea
                value={newPackageData.workScope}
                onChange={(e) => setNewPackageData(prev => ({...prev, workScope: e.target.value}))}
                placeholder="Describe the scope of work to be tendered..."
                className="orbit-input h-24"
              />
            </div>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setShowCreatePackage(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreatePackage} className="bg-orange-500 hover:bg-orange-600">
                Create Package
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content */}
      {activePackage ? (
        <Tabs defaultValue="bids" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="bids" className="flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Bids ({bids.length})
            </TabsTrigger>
            <TabsTrigger value="rfis" className="flex items-center gap-2">
              <FileQuestion className="w-4 h-4" />
              RFIs ({rfis.length})
            </TabsTrigger>
            <TabsTrigger value="evaluation" className="flex items-center gap-2">
              <Award className="w-4 h-4" />
              Evaluation
            </TabsTrigger>
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Overview
            </TabsTrigger>
          </TabsList>

          <TabsContent value="bids">
            <div className="grid gap-4">
              {bids.length === 0 ? (
                <Card className="orbit-card">
                  <CardContent className="text-center py-12">
                    <Hammer className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">No Bids Yet</h3>
                    <p className="text-gray-400">Contractor bids will appear here once submitted.</p>
                  </CardContent>
                </Card>
              ) : (
                bids.map((bid) => (
                  <Card key={bid.id} className="orbit-card">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-white">Contractor #{bid.contractorOrgId}</CardTitle>
                          <p className="text-sm text-gray-400 mt-1">
                            Submitted {bid.submittedAt ? new Date(bid.submittedAt).toLocaleDateString() : 'Draft'}
                          </p>
                        </div>
                        <Badge className={getStatusColor(bid.status)}>
                          {bid.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-gray-400">Contract Sum</span>
                          <p className="text-white font-semibold">A${bid.contractSum?.toLocaleString()}</p>
                        </div>
                        <div>
                          <span className="text-gray-400">Programme</span>
                          <p className="text-white font-semibold">{bid.programmeWeeks} weeks</p>
                        </div>
                        <div>
                          <span className="text-gray-400">Base Build</span>
                          <p className="text-white font-semibold">A${bid.baseBuild?.toLocaleString()}</p>
                        </div>
                        <div>
                          <span className="text-gray-400">Evaluation</span>
                          <p className="text-white font-semibold">
                            {bid.evaluationScore ? `${bid.evaluationScore}/100` : 'Pending'}
                          </p>
                        </div>
                      </div>
                      {bid.exclusions && bid.exclusions.length > 0 && (
                        <div className="mt-4">
                          <span className="text-gray-400 text-xs">Exclusions:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {bid.exclusions.slice(0, 3).map((exclusion, idx) => (
                              <span key={idx} className="bg-gray-700 text-gray-300 px-2 py-1 rounded text-xs">
                                {exclusion}
                              </span>
                            ))}
                            {bid.exclusions.length > 3 && (
                              <span className="bg-gray-700 text-gray-300 px-2 py-1 rounded text-xs">
                                +{bid.exclusions.length - 3} more
                              </span>
                            )}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="rfis">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Requests for Information</h3>
                <Button 
                  onClick={() => setShowRfiForm(true)}
                  size="sm"
                  className="bg-orange-500 hover:bg-orange-600"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Submit RFI
                </Button>
              </div>

              {showRfiForm && (
                <Card className="orbit-card">
                  <CardHeader>
                    <CardTitle>Submit RFI</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Category</Label>
                      <Select 
                        value={newRfi.category} 
                        onValueChange={(value) => setNewRfi(prev => ({...prev, category: value}))}
                      >
                        <SelectTrigger className="orbit-input">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Design">Design</SelectItem>
                          <SelectItem value="Specification">Specification</SelectItem>
                          <SelectItem value="Program">Program</SelectItem>
                          <SelectItem value="Commercial">Commercial</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Question</Label>
                      <Textarea
                        value={newRfi.question}
                        onChange={(e) => setNewRfi(prev => ({...prev, question: e.target.value}))}
                        placeholder="Enter your technical question..."
                        className="orbit-input h-24"
                      />
                    </div>
                    <div className="flex gap-3 justify-end">
                      <Button variant="outline" onClick={() => setShowRfiForm(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleSubmitRfi}>
                        <Send className="w-4 h-4 mr-2" />
                        Submit RFI
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {rfis.length === 0 ? (
                <Card className="orbit-card">
                  <CardContent className="text-center py-12">
                    <FileQuestion className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">No RFIs Yet</h3>
                    <p className="text-gray-400">RFIs and responses will appear here.</p>
                  </CardContent>
                </Card>
              ) : (
                rfis.map((rfi) => (
                  <Card key={rfi.id} className="orbit-card">
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <FileQuestion className="w-4 h-4 text-blue-400" />
                            <span className="text-sm text-blue-400">{rfi.rfiNumber}</span>
                            <Badge variant="outline" size="sm">{rfi.category}</Badge>
                            <span className="text-xs text-gray-500 ml-auto">
                              {new Date(rfi.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-white">{rfi.question}</p>
                        </div>
                        
                        {rfi.response && (
                          <div className="border-t border-gray-700 pt-4">
                            <div className="flex items-center gap-2 mb-2">
                              <AlertCircle className="w-4 h-4 text-green-400" />
                              <span className="text-sm text-green-400">Response</span>
                              {rfi.respondedAt && (
                                <span className="text-xs text-gray-500">
                                  {new Date(rfi.respondedAt).toLocaleDateString()}
                                </span>
                              )}
                            </div>
                            <p className="text-gray-300">{rfi.response}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="evaluation">
            <Card className="orbit-card">
              <CardContent className="text-center py-12">
                <Award className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Evaluation in Progress</h3>
                <p className="text-gray-400">Bid evaluation matrix will appear here.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="overview">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="orbit-card">
                <CardHeader>
                  <CardTitle>Package Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Status</span>
                    <Badge className={getStatusColor(activePackage.status)}>
                      {activePackage.status}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Due Date</span>
                    <span className="text-white">
                      {new Date(activePackage.dueAt).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Contract Form</span>
                    <span className="text-white">{activePackage.contractForm}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Est. Value</span>
                    <span className="text-white">
                      A${activePackage.estimatedValue?.toLocaleString() || 'TBD'}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="orbit-card">
                <CardHeader>
                  <CardTitle>Bid Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {['SUBMITTED', 'DRAFT', 'UNDER_REVIEW', 'SHORTLISTED'].map(status => {
                      const count = bids.filter(b => b.status === status).length;
                      if (count === 0) return null;
                      return (
                        <div key={status} className="flex justify-between">
                          <span className="text-gray-400">{status.toLowerCase().replace('_', ' ')}</span>
                          <span className="text-white">{count}</span>
                        </div>
                      );
                    })}
                    <div className="pt-3 border-t border-gray-700">
                      <div className="flex justify-between">
                        <span className="text-gray-400">RFIs</span>
                        <span className="text-white">{rfis.length}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      ) : (
        <Card className="orbit-card">
          <CardContent className="text-center py-12">
            <Hammer className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No Tender Packages</h3>
            <p className="text-gray-400 mb-6">Create your first tender package to start the construction procurement process.</p>
            <Button 
              onClick={() => setShowCreatePackage(true)}
              className="bg-orange-500 hover:bg-orange-600 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create First Package
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}