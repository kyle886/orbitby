import Layout from "./Layout.jsx";

import SubmitListing from "./SubmitListing";

import Listings from "./Listings";

import Requirements from "./Requirements";

import ClientDashboard from "./ClientDashboard";

import AdminDashboard from "./AdminDashboard";

import ClientProperties from "./ClientProperties";

import DocumentManagement from "./DocumentManagement";

import ClientDocuments from "./ClientDocuments";

import ClientUpdates from "./ClientUpdates";

import AgentSubmission from "./AgentSubmission";

import CreateBrief from "./CreateBrief";

import BriefDetails from "./BriefDetails";

import ClientBriefApproval from "./ClientBriefApproval";

import JourneySummary from "./JourneySummary";

import Analytics from "./Analytics";

import ClientManagement from "./ClientManagement";

import SubmissionManagement from "./SubmissionManagement";

import SeedData from "./SeedData";

import InspectionPack from "./InspectionPack";

import MobileInspection from "./MobileInspection";

import ClientDetails from "./ClientDetails";

import InspectionInsights from "./InspectionInsights";

import UserManagement from "./UserManagement";

import AgentSubmissions from "./AgentSubmissions";

import UpdateUserType from "./UpdateUserType";

import BuildingDatabase from "./BuildingDatabase";

import UserSignup from "./UserSignup";

import AgentManagement from "./AgentManagement";

import MarketIntelligence from "./MarketIntelligence";

import AgentConfiguration from "./AgentConfiguration";

import BuildingDetails from "./BuildingDetails";

import SubmissionDetails from "./SubmissionDetails";

import RequestFinancialProposals from "./RequestFinancialProposals";

import RFPApproval from "./RFPApproval";

import AgentRFPResponse from "./AgentRFPResponse";

import RFPReview from "./RFPReview";

import RFPResponseDetails from "./RFPResponseDetails";

import AIPropertyReviews from "./AIPropertyReviews";

import ClientCommunications from "./ClientCommunications";

import TeamPerformance from "./TeamPerformance";

import TeamMemberPerformance from "./TeamMemberPerformance";

import Dashboard from "./Dashboard";

import BusinessDevelopmentDashboard from "./BusinessDevelopmentDashboard";

import TargetsWizard from "./TargetsWizard";

import TargetDetails from "./TargetDetails";

import EventsMan from "./EventsMan";

import PitchMaster from "./PitchMaster";

import DataIngestion from "./DataIngestion";

import AutomationsManager from "./AutomationsManager";

import BDKPIPage from "./BDKPIPage";

import EventBriefPrintable from "./EventBriefPrintable";

import PitchDossierPrintable from "./PitchDossierPrintable";

import BDAdminConsole from "./BDAdminConsole";

import LeaseHygiene from "./LeaseHygiene";

import InboundGenie from "./InboundGenie";

import DuplicateReview from "./DuplicateReview";

import LegacyDashboard from "./LegacyDashboard";

import CommandCentre from "./CommandCentre";

import AITestHarness from "./AITestHarness";

import PBLDConsole from "./PBLDConsole";

import DueDiligenceDashboard from "./DueDiligenceDashboard";

import OptionDetails from "./OptionDetails";

import DevelopmentFeasibility from "./DevelopmentFeasibility";

import DevCaseDetails from "./DevCaseDetails";

import FinanceDashboard from "./FinanceDashboard";

import EngagementDetails from "./EngagementDetails";

import AcceptanceTests from "./AcceptanceTests";

import CreateCapitalOpportunity from "./CreateCapitalOpportunity";

import CreateDebtFacility from "./CreateDebtFacility";

import DevCase from "./DevCase";

import ClientPortal from "./ClientPortal";

import JobControlCenter from "./JobControlCenter";

import PortfolioDashboard from "./PortfolioDashboard";

import FitoutProject from "./FitoutProject";

import TenderManager from "./TenderManager";

import PunchlistApp from "./PunchlistApp";

import ProjectDelivery from "./ProjectDelivery";

import ProjectInitiation from "./ProjectInitiation";

import RfpManager from "./RfpManager";

import ProjectTenderManager from "./ProjectTenderManager";

import LeasedPropertiesLog from "./LeasedPropertiesLog";

import TenantDashboard from "./TenantDashboard";

import DevFeasibilityModule from "./DevFeasibilityModule";

import BoardPackWizard from "./BoardPackWizard";

import PackCenter from "./PackCenter";

import ReportsCenter from "./ReportsCenter";

import RepoInventory from "./RepoInventory";

import SystemReports from "./SystemReports";

import SystemOperations from "./SystemOperations";

import InspectionSetup from "./InspectionSetup";

import InspectionShared from "./InspectionShared";

import ListingsExplore from "./ListingsExplore";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    SubmitListing: SubmitListing,
    
    Listings: Listings,
    
    Requirements: Requirements,
    
    ClientDashboard: ClientDashboard,
    
    AdminDashboard: AdminDashboard,
    
    ClientProperties: ClientProperties,
    
    DocumentManagement: DocumentManagement,
    
    ClientDocuments: ClientDocuments,
    
    ClientUpdates: ClientUpdates,
    
    AgentSubmission: AgentSubmission,
    
    CreateBrief: CreateBrief,
    
    BriefDetails: BriefDetails,
    
    ClientBriefApproval: ClientBriefApproval,
    
    JourneySummary: JourneySummary,
    
    Analytics: Analytics,
    
    ClientManagement: ClientManagement,
    
    SubmissionManagement: SubmissionManagement,
    
    SeedData: SeedData,
    
    InspectionPack: InspectionPack,
    
    MobileInspection: MobileInspection,
    
    ClientDetails: ClientDetails,
    
    InspectionInsights: InspectionInsights,
    
    UserManagement: UserManagement,
    
    AgentSubmissions: AgentSubmissions,
    
    UpdateUserType: UpdateUserType,
    
    BuildingDatabase: BuildingDatabase,
    
    UserSignup: UserSignup,
    
    AgentManagement: AgentManagement,
    
    MarketIntelligence: MarketIntelligence,
    
    AgentConfiguration: AgentConfiguration,
    
    BuildingDetails: BuildingDetails,
    
    SubmissionDetails: SubmissionDetails,
    
    RequestFinancialProposals: RequestFinancialProposals,
    
    RFPApproval: RFPApproval,
    
    AgentRFPResponse: AgentRFPResponse,
    
    RFPReview: RFPReview,
    
    RFPResponseDetails: RFPResponseDetails,
    
    AIPropertyReviews: AIPropertyReviews,
    
    ClientCommunications: ClientCommunications,
    
    TeamPerformance: TeamPerformance,
    
    TeamMemberPerformance: TeamMemberPerformance,
    
    Dashboard: Dashboard,
    
    BusinessDevelopmentDashboard: BusinessDevelopmentDashboard,
    
    TargetsWizard: TargetsWizard,
    
    TargetDetails: TargetDetails,
    
    EventsMan: EventsMan,
    
    PitchMaster: PitchMaster,
    
    DataIngestion: DataIngestion,
    
    AutomationsManager: AutomationsManager,
    
    BDKPIPage: BDKPIPage,
    
    EventBriefPrintable: EventBriefPrintable,
    
    PitchDossierPrintable: PitchDossierPrintable,
    
    BDAdminConsole: BDAdminConsole,
    
    LeaseHygiene: LeaseHygiene,
    
    InboundGenie: InboundGenie,
    
    DuplicateReview: DuplicateReview,
    
    LegacyDashboard: LegacyDashboard,
    
    CommandCentre: CommandCentre,
    
    AITestHarness: AITestHarness,
    
    PBLDConsole: PBLDConsole,
    
    DueDiligenceDashboard: DueDiligenceDashboard,
    
    OptionDetails: OptionDetails,
    
    DevelopmentFeasibility: DevelopmentFeasibility,
    
    DevCaseDetails: DevCaseDetails,
    
    FinanceDashboard: FinanceDashboard,
    
    EngagementDetails: EngagementDetails,
    
    AcceptanceTests: AcceptanceTests,
    
    CreateCapitalOpportunity: CreateCapitalOpportunity,
    
    CreateDebtFacility: CreateDebtFacility,
    
    DevCase: DevCase,
    
    ClientPortal: ClientPortal,
    
    JobControlCenter: JobControlCenter,
    
    PortfolioDashboard: PortfolioDashboard,
    
    FitoutProject: FitoutProject,
    
    TenderManager: TenderManager,
    
    PunchlistApp: PunchlistApp,
    
    ProjectDelivery: ProjectDelivery,
    
    ProjectInitiation: ProjectInitiation,
    
    RfpManager: RfpManager,
    
    ProjectTenderManager: ProjectTenderManager,
    
    LeasedPropertiesLog: LeasedPropertiesLog,
    
    TenantDashboard: TenantDashboard,
    
    DevFeasibilityModule: DevFeasibilityModule,
    
    BoardPackWizard: BoardPackWizard,
    
    PackCenter: PackCenter,
    
    ReportsCenter: ReportsCenter,
    
    RepoInventory: RepoInventory,
    
    SystemReports: SystemReports,
    
    SystemOperations: SystemOperations,
    
    InspectionSetup: InspectionSetup,
    
    InspectionShared: InspectionShared,
    
    ListingsExplore: ListingsExplore,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<SubmitListing />} />
                
                
                <Route path="/SubmitListing" element={<SubmitListing />} />
                
                <Route path="/Listings" element={<Listings />} />
                
                <Route path="/Requirements" element={<Requirements />} />
                
                <Route path="/ClientDashboard" element={<ClientDashboard />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/ClientProperties" element={<ClientProperties />} />
                
                <Route path="/DocumentManagement" element={<DocumentManagement />} />
                
                <Route path="/ClientDocuments" element={<ClientDocuments />} />
                
                <Route path="/ClientUpdates" element={<ClientUpdates />} />
                
                <Route path="/AgentSubmission" element={<AgentSubmission />} />
                
                <Route path="/CreateBrief" element={<CreateBrief />} />
                
                <Route path="/BriefDetails" element={<BriefDetails />} />
                
                <Route path="/ClientBriefApproval" element={<ClientBriefApproval />} />
                
                <Route path="/JourneySummary" element={<JourneySummary />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/ClientManagement" element={<ClientManagement />} />
                
                <Route path="/SubmissionManagement" element={<SubmissionManagement />} />
                
                <Route path="/SeedData" element={<SeedData />} />
                
                <Route path="/InspectionPack" element={<InspectionPack />} />
                
                <Route path="/MobileInspection" element={<MobileInspection />} />
                
                <Route path="/ClientDetails" element={<ClientDetails />} />
                
                <Route path="/InspectionInsights" element={<InspectionInsights />} />
                
                <Route path="/UserManagement" element={<UserManagement />} />
                
                <Route path="/AgentSubmissions" element={<AgentSubmissions />} />
                
                <Route path="/UpdateUserType" element={<UpdateUserType />} />
                
                <Route path="/BuildingDatabase" element={<BuildingDatabase />} />
                
                <Route path="/UserSignup" element={<UserSignup />} />
                
                <Route path="/AgentManagement" element={<AgentManagement />} />
                
                <Route path="/MarketIntelligence" element={<MarketIntelligence />} />
                
                <Route path="/AgentConfiguration" element={<AgentConfiguration />} />
                
                <Route path="/BuildingDetails" element={<BuildingDetails />} />
                
                <Route path="/SubmissionDetails" element={<SubmissionDetails />} />
                
                <Route path="/RequestFinancialProposals" element={<RequestFinancialProposals />} />
                
                <Route path="/RFPApproval" element={<RFPApproval />} />
                
                <Route path="/AgentRFPResponse" element={<AgentRFPResponse />} />
                
                <Route path="/RFPReview" element={<RFPReview />} />
                
                <Route path="/RFPResponseDetails" element={<RFPResponseDetails />} />
                
                <Route path="/AIPropertyReviews" element={<AIPropertyReviews />} />
                
                <Route path="/ClientCommunications" element={<ClientCommunications />} />
                
                <Route path="/TeamPerformance" element={<TeamPerformance />} />
                
                <Route path="/TeamMemberPerformance" element={<TeamMemberPerformance />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/BusinessDevelopmentDashboard" element={<BusinessDevelopmentDashboard />} />
                
                <Route path="/TargetsWizard" element={<TargetsWizard />} />
                
                <Route path="/TargetDetails" element={<TargetDetails />} />
                
                <Route path="/EventsMan" element={<EventsMan />} />
                
                <Route path="/PitchMaster" element={<PitchMaster />} />
                
                <Route path="/DataIngestion" element={<DataIngestion />} />
                
                <Route path="/AutomationsManager" element={<AutomationsManager />} />
                
                <Route path="/BDKPIPage" element={<BDKPIPage />} />
                
                <Route path="/EventBriefPrintable" element={<EventBriefPrintable />} />
                
                <Route path="/PitchDossierPrintable" element={<PitchDossierPrintable />} />
                
                <Route path="/BDAdminConsole" element={<BDAdminConsole />} />
                
                <Route path="/LeaseHygiene" element={<LeaseHygiene />} />
                
                <Route path="/InboundGenie" element={<InboundGenie />} />
                
                <Route path="/DuplicateReview" element={<DuplicateReview />} />
                
                <Route path="/LegacyDashboard" element={<LegacyDashboard />} />
                
                <Route path="/CommandCentre" element={<CommandCentre />} />
                
                <Route path="/AITestHarness" element={<AITestHarness />} />
                
                <Route path="/PBLDConsole" element={<PBLDConsole />} />
                
                <Route path="/DueDiligenceDashboard" element={<DueDiligenceDashboard />} />
                
                <Route path="/OptionDetails" element={<OptionDetails />} />
                
                <Route path="/DevelopmentFeasibility" element={<DevelopmentFeasibility />} />
                
                <Route path="/DevCaseDetails" element={<DevCaseDetails />} />
                
                <Route path="/FinanceDashboard" element={<FinanceDashboard />} />
                
                <Route path="/EngagementDetails" element={<EngagementDetails />} />
                
                <Route path="/AcceptanceTests" element={<AcceptanceTests />} />
                
                <Route path="/CreateCapitalOpportunity" element={<CreateCapitalOpportunity />} />
                
                <Route path="/CreateDebtFacility" element={<CreateDebtFacility />} />
                
                <Route path="/DevCase" element={<DevCase />} />
                
                <Route path="/ClientPortal" element={<ClientPortal />} />
                
                <Route path="/JobControlCenter" element={<JobControlCenter />} />
                
                <Route path="/PortfolioDashboard" element={<PortfolioDashboard />} />
                
                <Route path="/FitoutProject" element={<FitoutProject />} />
                
                <Route path="/TenderManager" element={<TenderManager />} />
                
                <Route path="/PunchlistApp" element={<PunchlistApp />} />
                
                <Route path="/ProjectDelivery" element={<ProjectDelivery />} />
                
                <Route path="/ProjectInitiation" element={<ProjectInitiation />} />
                
                <Route path="/RfpManager" element={<RfpManager />} />
                
                <Route path="/ProjectTenderManager" element={<ProjectTenderManager />} />
                
                <Route path="/LeasedPropertiesLog" element={<LeasedPropertiesLog />} />
                
                <Route path="/TenantDashboard" element={<TenantDashboard />} />
                
                <Route path="/DevFeasibilityModule" element={<DevFeasibilityModule />} />
                
                <Route path="/BoardPackWizard" element={<BoardPackWizard />} />
                
                <Route path="/PackCenter" element={<PackCenter />} />
                
                <Route path="/ReportsCenter" element={<ReportsCenter />} />
                
                <Route path="/RepoInventory" element={<RepoInventory />} />
                
                <Route path="/SystemReports" element={<SystemReports />} />
                
                <Route path="/SystemOperations" element={<SystemOperations />} />
                
                <Route path="/InspectionSetup" element={<InspectionSetup />} />
                
                <Route path="/InspectionShared" element={<InspectionShared />} />
                
                <Route path="/ListingsExplore" element={<ListingsExplore />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}