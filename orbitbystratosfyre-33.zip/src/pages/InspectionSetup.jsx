
import React, { useState, useEffect, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { InspectionPackContext } from "@/components/state/InspectionPackContext";
import StopsBuilder from "@/components/inspection/StopsBuilder";
import MapLite from "@/components/inspection/MapLite";
import { getLegDurations } from "@/components/utils/osrm";
import { toast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { nanoid } from "nanoid";
import { PropertySubmission } from '@/api/entities';
import { Loader2 } from 'lucide-react';


export default function InspectionSetup() {
  const nav = useNavigate();
  const { draft, setStops, setStartISO } = useContext(InspectionPackContext);
  
  const [available, setAvailable] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [startTime, setStartTime] = useState("09:30");

  useEffect(() => {
    async function loadAvailableListings() {
      setLoading(true);
      try {
        const submissions = await PropertySubmission.filter({ status: "shortlisted" });
        const listings = submissions.map(p => ({
          id: p.id,
          title: p.property_title,
          address: p.address,
          lat: p.latitude,
          lng: p.longitude,
        })).filter(p => p.lat && p.lng);
        setAvailable(listings);
      } catch (e) {
        toast({ variant: "destructive", title: "Failed to load listings" });
      } finally {
        setLoading(false);
      }
    }
    loadAvailableListings();
  }, []);

  const addProperty = (p) => {
    const s = { id: nanoid(), type: "property", title: p.title, propertyId: p.id, lat: p.lat, lng: p.lng, dwellMin: 20 };
    setStops([...(draft.stops || []), s]);
  };

  const addBreak = () => setStops([...(draft.stops || []), { id: nanoid(), type: "break", title: "Coffee Break", dwellMin: 15 }]);

  async function computeSchedule() {
    const day = new Date();
    const [hh, mm] = startTime.split(":").map(Number);
    day.setHours(hh || 9, mm || 30, 0, 0);
    setStartISO(day.toISOString());
    const ordered = draft.stops;
    const propPoints = ordered.filter(s => s.type === "property").map((s) => ({ lat: s.lat, lng: s.lng }));
    
    let legs = [];
    if (propPoints.length > 1) {
      try {
        const { legs: arr } = await getLegDurations(propPoints);
        let i = 0;
        for (let k = 0; k < ordered.length - 1; k++) {
          const a = ordered[k], b = ordered[k + 1];
          legs[k] = (a.type === "property" && b.type === "property") ? (arr[i++] || 0) : 0;
        }
      } catch (e) {
        toast({ variant: "destructive", title: "Routing Error", description: "Could not calculate travel times. Schedule will assume zero travel time."});
        legs = ordered.map(() => 0);
      }
    }
    
    let cursor = new Date(day);
    const schedule = ordered.map((s, idx) => {
      const travelSec = idx === 0 ? 0 : (legs[idx - 1] || 0);
      cursor = new Date(cursor.getTime() + travelSec * 1000);
      const arrival = new Date(cursor);
      cursor = new Date(cursor.getTime() + (s.dwellMin || 0) * 60000);
      const depart = new Date(cursor);
      return { ...s, travelSecFromPrev: travelSec, arrival: arrival.toISOString(), depart: depart.toISOString() };
    });
    return schedule;
  }

  async function handleSubmit() {
    setIsSubmitting(true);
    try {
      if (draft.stops.length === 0) {
        throw new Error("Add at least one property to the inspection.");
      }
      const schedule = await computeSchedule();
      const { data: r } = await window.base44.functions.saveInspectionPack({
        title: draft.title, startISO: draft.startISO, stops: schedule,
        attendees: draft.attendees, criteria: draft.criteria, status: "Pending Confirmation"
      });
      toast({ title: "Inspection Pack saved", description: `ID: ${r.id}` });
      nav(`/inspection/pack/${r.id}`);
    } catch (e) {
      toast({ variant: "destructive", title: "Error", description: e.message || String(e) });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <h2 className="text-xl font-semibold text-white">Inspection Setup</h2>
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-4 space-y-4">
          <div>
            <Label className="text-sm text-gray-300">Start Time</Label>
            <Input className="orbit-input" type="time" value={startTime} onChange={e => setStartTime(e.target.value)} />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="orbit-button" onClick={addBreak}>+ Coffee Break</Button>
          </div>
          <StopsBuilder items={draft.stops} setItems={setStops} />
          <div className="flex gap-2 justify-end">
            <Button className="orbit-button-primary" onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="animate-spin mr-2"/> : null}
              Generate Pack
            </Button>
          </div>
        </Card>
        <Card className="p-4 space-y-3">
          <Label className="text-sm text-gray-300">Available Shortlisted Listings</Label>
          <div className="space-y-2 max-h-[460px] overflow-auto pr-2">
            {loading ? <Loader2 className="animate-spin text-white mx-auto"/> : 
            available.length > 0 ? available.map(p => (
              <div key={p.id} className="flex items-center justify-between p-2 rounded bg-white/5 border border-white/10">
                <div className="text-sm text-white">{p.title}</div>
                <Button size="sm" variant="secondary" onClick={() => addProperty(p)}>Add</Button>
              </div>
            )) : <p className="text-sm text-gray-400 text-center py-4">No shortlisted properties found.</p>}
          </div>
          <MapLite points={draft.stops.filter(s => s.type === "property").map(s => ({ lat: s.lat, lng: s.lng, label: s.title }))} />
        </Card>
      </div>
    </div>
  );
}
