import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { PunchItem } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { enqueue, flush } from "@/components/utils/offline/queue";

export default function PunchlistApp(){
  const { projectId } = useParams();
  const [rows, setRows] = useState([]);
  const [title, setTitle] = useState(''); 
  const [loc, setLoc] = useState('');
  const [file, setFile] = useState(null);
  const { toast } = useToast();

  useEffect(()=>{ (async()=> {
    try {
      const data = await PunchItem.filter({ project_id: projectId });
      setRows(data || []);
    } catch (error) {
      console.error('Failed to load punch items:', error);
      setRows([]);
    }
  })(); }, [projectId]);

  const add = async () => {
    const payload = { 
      project_id: projectId, 
      title, 
      location: loc, 
      status: 'Open', 
      created_at: new Date().toISOString() 
    };
    
    try {
      let photo_url = null;
      if (file) { 
        const response = await UploadFile({ file });
        photo_url = response.file_url;
      }
      
      const row = await PunchItem.create({ ...payload, photo_url });
      setRows([row, ...rows]); 
      setTitle(''); 
      setLoc(''); 
      setFile(null); 
      toast({ title: 'Item added' });
    } catch(error) {
      // Offline fallback
      enqueue('punch_add', { 
        ...payload, 
        file_b64: file ? await toB64(file) : null 
      });
      toast({ 
        title: 'Queued offline', 
        description: 'Will sync when online' 
      });
    }
  };

  const complete = async (id) => {
    try { 
      await PunchItem.update(id, { 
        status: 'Done', 
        closed_at: new Date().toISOString() 
      });
      setRows(rows.map(r => r.id === id ? {...r, status: 'Done'} : r));
    } catch(error) { 
      enqueue('punch_complete', { id }); 
      toast({ 
        title: 'Queued offline', 
        description: 'Will sync when online' 
      });
    }
  };

  useEffect(() => { 
    // Try flush on load
    flush(async ({kind, payload}) => {
      if (kind === 'punch_add') {
        const f = payload.file_b64 ? b64toBlob(payload.file_b64) : null;
        let photo_url = null;
        
        if (f) {
          const response = await UploadFile({ file: f });
          photo_url = response.file_url;
        }
        
        await PunchItem.create({ ...payload, photo_url });
      }
      if (kind === 'punch_complete') { 
        await PunchItem.update(payload.id, { 
          status: 'Done', 
          closed_at: new Date().toISOString() 
        }); 
      }
    });
  }, []);

  return (
    <div className="p-3 space-y-3 max-w-[720px] mx-auto">
      <div className="rounded-2xl border border-white/10 p-3 bg-white/5">
        <div className="text-sm font-semibold mb-2">New snag</div>
        <div className="grid grid-cols-2 gap-2">
          <Input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Issue title" />
          <Input value={loc} onChange={e=>setLoc(e.target.value)} placeholder="Location (grid/room)" />
          <input 
            type="file" 
            accept="image/*" 
            capture="environment" 
            onChange={e=>setFile(e.target.files?.[0]||null)} 
            className="col-span-2 text-xs" 
          />
          <Textarea className="col-span-2" placeholder="Notes (optional)" />
          <Button className="col-span-2" onClick={add}>Add</Button>
        </div>
      </div>

      {rows.map(r=>(
        <div key={r.id} className="rounded-2xl border border-white/10 p-3 bg-white/5">
          <div className="text-sm font-semibold">{r.title}</div>
          <div className="text-xs text-gray-400">{r.location||'—'} · {r.status}</div>
          {r.photo_url && <img src={r.photo_url} alt="" className="w-full rounded-md mt-2" />}
          {r.status !== 'Done' && (
            <div className="mt-2">
              <Button size="sm" onClick={() => complete(r.id)}>Mark Done</Button>
            </div>
          )}
        </div>
      ))}
      {rows.length === 0 && <div className="text-sm text-gray-400">No punch items yet.</div>}
    </div>
  );
}

async function toB64(file) { 
  return new Promise(res => { 
    const fr = new FileReader(); 
    fr.onload = () => res(String(fr.result)); 
    fr.readAsDataURL(file); 
  }); 
}

function b64toBlob(b64) { 
  const arr = b64.split(','), 
        mime = arr[0].match(/:(.*?);/)[1]; 
  const bstr = atob(arr[1]); 
  let n = bstr.length; 
  const u8 = new Uint8Array(n); 
  while(n--) u8[n] = bstr.charCodeAt(n); 
  return new Blob([u8], {type: mime}); 
}