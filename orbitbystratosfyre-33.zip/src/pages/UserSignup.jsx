
import React, { useState, useEffect, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import { User } from "@/api/entities";
import { UserInvitation } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, XCircle, Users, Building, Briefcase, Upload, Loader2 } from "lucide-react";

export default function UserSignup() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  
  const [invitation, setInvitation] = useState(null);
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    title: '',
    company: '',
    mobile: '',
    landline: ''
  });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [error, setError] = useState('');

  const validateToken = useCallback(async () => {
    try {
      const invitations = await UserInvitation.filter({ invitation_token: token });
      const invitation = invitations?.[0];

      if (!invitation) {
        setError('Invalid invitation token');
        return;
      }

      if (invitation.status === 'accepted') {
        setError('This invitation has already been used');
        return;
      }

      if (invitation.status === 'expired' || new Date(invitation.expires_at) < new Date()) {
        setError('This invitation has expired');
        return;
      }

      setInvitation(invitation);
    } catch (error) {
      console.error('Error validating token:', error);
      setError('Failed to validate invitation');
    } finally {
      setLoading(false);
    }
  }, [token]); // token is used inside validateToken, so it's a dependency for useCallback

  useEffect(() => {
    if (token) {
      validateToken();
    } else {
      setError('No invitation token provided');
      setLoading(false);
    }
  }, [token, validateToken]); // validateToken is now a dependency

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.first_name || !formData.last_name || !formData.company) {
      alert('Please fill in all required fields');
      return;
    }

    setSubmitting(true);

    try {
      // Create the user account
      const userData = {
        email: invitation.invited_email,
        first_name: formData.first_name,
        last_name: formData.last_name,
        title: formData.title,
        company: formData.company,
        mobile: formData.mobile,
        landline: formData.landline,
        user_type: invitation.user_type,
        permission_level: invitation.permission_level || 'user',
        invitation_token: token,
        invited_by: invitation.invited_by,
        invitation_sent_date: invitation.created_date,
        signup_completed: true,
        is_active: true
      };

      await User.create(userData);

      // Update invitation status
      await UserInvitation.update(invitation.id, { status: 'accepted' });

      setCompleted(true);
    } catch (error) {
      console.error('Error completing signup:', error);
      alert('Failed to complete signup. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const getUserTypeInfo = (userType) => {
    switch (userType) {
      case 'stratosfyre_admin':
        return {
          title: 'Stratosfyre Team Member',
          description: 'Full access to all platform features including client management, analytics, and system administration.',
          icon: Briefcase,
          color: 'from-orange-500 to-amber-500'
        };
      case 'client':
        return {
          title: 'Client/Occupier',
          description: 'Access to view your property search progress, documents, and provide feedback on shortlisted properties.',
          icon: Building,
          color: 'from-blue-500 to-blue-600'
        };
      case 'agent_landlord':
        return {
          title: 'Agent/Landlord',
          description: 'Submit property listings and manage your property submissions through the platform.',
          icon: Upload,
          color: 'from-green-500 to-green-600'
        };
      default:
        return {
          title: 'User',
          description: 'Platform access',
          icon: Users,
          color: 'from-gray-500 to-gray-600'
        };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-orange-400" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="orbit-card p-8 max-w-md w-full text-center">
          <XCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">Invalid Invitation</h2>
          <p className="text-gray-400 mb-6">{error}</p>
          <Button 
            onClick={() => window.location.href = '/'}
            className="bg-gradient-to-r from-orange-500 to-amber-500 text-white"
          >
            Return to Login
          </Button>
        </div>
      </div>
    );
  }

  if (completed) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="orbit-card p-8 max-w-md w-full text-center">
          <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">Welcome to ORBIT!</h2>
          <p className="text-gray-400 mb-6">Your account has been created successfully. You can now sign in to access the platform.</p>
          <Button 
            onClick={() => User.login()}
            className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold py-3 px-6 rounded-xl"
          >
            Sign In to ORBIT
          </Button>
        </div>
      </div>
    );
  }

  const userTypeInfo = getUserTypeInfo(invitation?.user_type);
  const Icon = userTypeInfo.icon;

  return (
    <div className="min-h-screen bg-gray-900 p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <div className="orbit-card p-8">
          <div className="text-center mb-8">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/688244252a7b37f0b4a1bcf9/9234d12f9_image.png" 
              alt="ORBIT by Stratosfyre" 
              className="w-48 mx-auto mb-6"
            />
            <div className={`bg-gradient-to-br ${userTypeInfo.color} p-4 rounded-full w-16 h-16 mx-auto mb-4`}>
              <Icon className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Complete Your Registration</h1>
            <p className="text-gray-400 mb-4">You've been invited as: <span className="text-white font-medium">{userTypeInfo.title}</span></p>
            <p className="text-gray-500 text-sm">{userTypeInfo.description}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label className="text-gray-300 mb-2 block">Email Address</Label>
              <Input
                value={invitation?.invited_email || ''}
                disabled
                className="orbit-input text-gray-400 bg-gray-800"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">First Name *</Label>
                <Input
                  value={formData.first_name}
                  onChange={(e) => setFormData(prev => ({...prev, first_name: e.target.value}))}
                  className="orbit-input text-white"
                  required
                />
              </div>
              <div>
                <Label className="text-gray-300">Last Name *</Label>
                <Input
                  value={formData.last_name}
                  onChange={(e) => setFormData(prev => ({...prev, last_name: e.target.value}))}
                  className="orbit-input text-white"
                  required
                />
              </div>
            </div>

            <div>
              <Label className="text-gray-300">Job Title</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData(prev => ({...prev, title: e.target.value}))}
                className="orbit-input text-white"
                placeholder="e.g., Director, Agent, Consultant"
              />
            </div>

            <div>
              <Label className="text-gray-300">Company *</Label>
              <Input
                value={formData.company}
                onChange={(e) => setFormData(prev => ({...prev, company: e.target.value}))}
                className="orbit-input text-white"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">
                  Mobile Phone {(invitation?.user_type === 'agent_landlord') ? '*' : ''}
                </Label>
                <Input
                  value={formData.mobile}
                  onChange={(e) => setFormData(prev => ({...prev, mobile: e.target.value}))}
                  className="orbit-input text-white"
                  placeholder="+61 4XX XXX XXX"
                  required={invitation?.user_type === 'agent_landlord'}
                />
              </div>
              
              {(invitation?.user_type === 'agent_landlord') && (
                <div>
                  <Label className="text-gray-300">Landline (Optional)</Label>
                  <Input
                    value={formData.landline}
                    onChange={(e) => setFormData(prev => ({...prev, landline: e.target.value}))}
                    className="orbit-input text-white"
                    placeholder="+61 2 XXXX XXXX"
                  />
                </div>
              )}
            </div>

            {invitation?.personal_message && (
              <div className="p-4 bg-gray-800 rounded-xl">
                <Label className="text-gray-300 mb-2 block">Message from {invitation.invited_by}:</Label>
                <p className="text-gray-400 italic">"{invitation.personal_message}"</p>
              </div>
            )}

            <Button 
              type="submit" 
              disabled={submitting}
              className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold py-3 px-6 rounded-xl hover:from-orange-400 hover:to-amber-400 transition-all duration-200"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating Account...
                </>
              ) : (
                'Complete Registration'
              )}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
