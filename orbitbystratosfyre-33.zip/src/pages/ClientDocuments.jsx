
import React, { useState, useEffect } from "react";
import { Document } from "@/api/entities";
import { User } from "@/api/entities";
import { Client } from "@/api/entities";
import { Loader2, FileText, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge"; // Added for the new UI

export default function ClientDocuments() {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [client, setClient] = useState(null);

  useEffect(() => {
    loadData();
  }, []); // Empty dependency array means this runs once on mount

  const loadData = async () => {
    setLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const clients = await Client.list();
      const currentClient = clients.find(c => c.primary_contact_email === currentUser.email);
      setClient(currentClient);

      if (currentClient) {
        const documentData = await Document.filter({ client_id: currentClient.id, is_client_visible: true }, "-created_date");
        setDocuments(documentData);
      }
    } catch (error) {
      console.error("Error loading documents:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="p-8 text-center"><Loader2 className="h-12 w-12 animate-spin text-orange-400 mx-auto" /></div>;

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Your Documents</h1>
          <p className="text-gray-300">Access all shared documents related to your property search.</p>
        </div>

        <div className="orbit-card p-2 sm:p-6">
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-[300px]">Document</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Date Uploaded</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {documents.map((doc) => (
                            <TableRow key={doc.id}>
                                <TableCell className="font-medium text-white">{doc.document_name}</TableCell>
                                <TableCell>
                                    <Badge variant="outline">{doc.document_type.replace('_', ' ')}</Badge> {/* Added Badge, kept replace for formatting */}
                                </TableCell>
                                <TableCell>{new Date(doc.created_date).toLocaleDateString()}</TableCell>
                                <TableCell className="text-right">
                                    <Button asChild variant="ghost" size="icon">
                                        <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                                            <Download className="h-4 w-4" />
                                        </a>
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
          {documents.length === 0 && (
            <div className="text-center py-16">
                <FileText className="w-12 h-12 mx-auto text-gray-500 mb-4" />
                <h3 className="text-lg font-medium text-white">No documents available</h3>
                <p className="text-gray-400 mt-1">Your consultant has not shared any documents with you yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
