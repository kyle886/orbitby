
import React, { useState, useEffect } from "react";
import { PropertySubmission } from "@/api/entities";
import { User } from "@/api/entities";
import { Client } from "@/api/entities";
import { Loader2, Building2, MapPin, Square, DollarSign, BedDouble, CheckCircle, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useUnits } from '@/components/utils/units';

export default function ClientProperties() {
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [client, setClient] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const clients = await Client.list();
      const currentClient = clients.find(c => c.primary_contact_email === currentUser.email);
      setClient(currentClient);

      if (currentClient) {
        const submissionData = await PropertySubmission.filter({ client_id: currentClient.id, status: "shortlisted" }, "-created_date");
        setSubmissions(submissionData || []);
      }
    } catch (error) {
      console.error("Error loading data:", error);
      setSubmissions([]);
    } finally {
      setLoading(false);
    }
  };

  const handleFeedbackChange = (submissionId, feedback) => {
    setSubmissions(prev => prev.map(s => s.id === submissionId ? { ...s, client_feedback: feedback } : s));
  };

  const submitFeedback = async (submissionId, feedback) => {
    try {
      const submissionToUpdate = submissions.find(s => s.id === submissionId);
      if (!submissionToUpdate) {
        alert("Error: Could not find the submission to update.");
        return;
      }
      
      const payload = { ...submissionToUpdate, client_feedback: feedback };
      if (!payload.street_address && payload.address) {
        payload.street_address = payload.address;
      }

      await PropertySubmission.update(submissionId, payload);
      alert("Feedback submitted successfully!");
    } catch (error) {
      console.error("Error submitting feedback:", error);
      alert("Failed to submit feedback.");
    }
  };

  const PropertyCard = ({ sub }) => {
    const { convertEconomics } = useUnits();
    const economics = convertEconomics({
      area_m2: sub.floor_area_sqm,
      rent_aud_per_m2_pa: sub.rental_rate_sqm,
    });
    
    return (
    <div className="orbit-card overflow-hidden">
      {sub.images && sub.images.length > 0 && (
        <img src={sub.images[0]} alt={sub.property_title} className="w-full h-32 sm:h-48 object-cover" />
      )}
      <div className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start gap-2 mb-3">
          <h3 className="text-lg sm:text-xl font-bold text-white">{sub.property_title}</h3>
          <div className={`flex items-center gap-2 px-2 sm:px-3 py-1 rounded-full text-xs font-medium flex-shrink-0 ${
            sub.brief_match_status === 'on_brief' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'
          }`}>
            {sub.brief_match_status === 'on_brief' ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
            <span className="hidden sm:inline">{sub.brief_match_status?.replace('_', ' ').toUpperCase()}</span>
          </div>
        </div>
        <div className="flex items-start gap-2 text-gray-400 mb-4">
          <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <span className="text-sm">{sub.address}</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 text-sm mb-4 text-gray-300">
          <div className="flex items-center gap-2">
            <Square className="w-4 h-4 text-orange-400 flex-shrink-0" />
            <span>{economics.area?.value} {economics.area?.unit}</span>
          </div>
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-orange-400 flex-shrink-0" />
            <span>{economics.rent ? `$${economics.rent.value}` : 'N/A'} <span className="text-gray-400 text-xs">{economics.rent?.unit}</span></span>
          </div>
          <div className="flex items-center gap-2 sm:col-span-2">
            <BedDouble className="w-4 h-4 text-orange-400 flex-shrink-0" />
            <span>{sub.fitout_status || 'N/A'}</span>
          </div>
        </div>
        <p className="text-sm text-gray-400 italic mb-4 line-clamp-3">"{sub.amplifyre_notes}"</p>
        
        <div className="space-y-3">
            <label className="text-sm font-medium text-white">Your Feedback:</label>
            <Textarea 
                placeholder="Let us know your thoughts on this property..."
                value={sub.client_feedback || ""}
                onChange={(e) => handleFeedbackChange(sub.id, e.target.value)}
                className="orbit-input text-white min-h-[80px] resize-none"
                rows={3}
            />
            <Button onClick={() => submitFeedback(sub.id, sub.client_feedback)} className="w-full orbit-button bg-orange-500 hover:bg-orange-600 text-white min-h-[44px]">
                Submit Feedback
            </Button>
        </div>
      </div>
    </div>
  )};

  if (loading) return <div className="p-8 text-center"><Loader2 className="h-12 w-12 animate-spin text-orange-400 mx-auto" /></div>;

  return (
    <div className="p-4 sm:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">Your Property Options</h1>
          <p className="text-sm sm:text-base text-gray-300">Here are the properties we've shortlisted for your consideration.</p>
        </div>
        
        {submissions.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6">
            {submissions.map(sub => <PropertyCard key={sub.id} sub={sub} />)}
          </div>
        ) : (
          <div className="orbit-card p-8 sm:p-12 text-center">
            <Building2 className="w-12 sm:w-16 h-12 sm:h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-lg sm:text-xl font-medium text-white mb-2">No properties shortlisted yet</h3>
            <p className="text-sm sm:text-base text-gray-400">As we find properties that match your brief, they will appear here.</p>
          </div>
        )}
      </div>
    </div>
  );
}
