
import React, { useState, useEffect } from "react";
import { PropertySubmission } from "@/api/entities";
import { Building } from "@/api/entities";
import { Tenancy } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2, CheckCircle, Loader2 } from "lucide-react";

export default function AgentSubmission() {
  const [formData, setFormData] = useState({
    brief_reference_code: "",
    property_title: "", // New field
    address: "",
    latitude: null, // New field
    longitude: null, // New field
    suite_floor: "",
    submarket: "",
    size_sqm: "", // Remains as size_sqm in form, mapped to floor_area_sqm
    net_face_rent_sqm: "", // Remains as net_face_rent_sqm, mapped to rental_rate_sqm
    outgoings_sqm: "",
    fitout_status: "",
    availability_date: "",
    status: "available", // New field for availability_status
    parking_info: "", // Mapped to parking_spaces
    building_nabers: "",
    landlord_owner: "",
    building_grade: "", // New field
    agent_name: "",
    agent_company: "", // New field
    agent_email: "", // New field
    agent_phone: "", // New field
    co_agent_name: "",
    comments: "" // Mapped to amplifyre_notes
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const briefRef = urlParams.get('briefRef');
    if (briefRef) {
      setFormData(prev => ({ ...prev, brief_reference_code: briefRef }));
    }
  }, []);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAddressChange = async (address) => {
    setFormData(prev => ({ ...prev, address }));

    // Automatically geocode the address if it's long enough (likely a full address)
    if (address && address.length > 10) {
      try {
        const geoData = await InvokeLLM({
          prompt: `Get the latitude and longitude for this address: ${address}. Only return coordinates if you're confident this is a valid address.`,
          add_context_from_internet: true,
          response_json_schema: {
            type: "object",
            properties: {
              latitude: { type: "number" },
              longitude: { type: "number" },
              confidence: { type: "string", enum: ["high", "medium", "low"] }
            },
            required: ["latitude", "longitude", "confidence"],
          },
        });
        
        if (geoData.confidence === "high" && geoData.latitude && geoData.longitude) {
          setFormData(prev => ({ 
            ...prev, 
            latitude: geoData.latitude, 
            longitude: geoData.longitude 
          }));
        }
      } catch (geoError) {
        console.log("Geocoding failed, continuing without coordinates:", geoError);
        // Don't show error to user, just continue without coordinates
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // If we don't have coordinates yet from live typing, try one final geocoding attempt
      let finalData = { ...formData };
      if (!finalData.latitude && !finalData.longitude && finalData.address) {
        try {
          const geoData = await InvokeLLM({
            prompt: `Get the latitude and longitude for this address: ${finalData.address}`,
            add_context_from_internet: true,
            response_json_schema: {
              type: "object",
              properties: {
                latitude: { type: "number" },
                longitude: { type: "number" },
              },
              required: ["latitude", "longitude"],
            },
          });
          if (geoData.latitude !== undefined && geoData.longitude !== undefined) {
            finalData.latitude = geoData.latitude;
            finalData.longitude = geoData.longitude;
          }
        } catch (geoError) {
          console.log("Final geocoding attempt failed, submitting without coordinates:", geoError);
        }
      }

      // This page is for submitting property *options* for a specific brief.
      // It creates a PropertySubmission record.
      // The old logic also tried to put it in the building DB, which is now handled
      // by the dedicated "Submit Listing" page. This keeps AgentSubmission focused.
      const submissionData = {
        brief_reference_code: finalData.brief_reference_code,
        property_title: finalData.property_title || finalData.address,
        address: finalData.address,
        latitude: finalData.latitude,
        longitude: finalData.longitude,
        suite_floor: finalData.suite_floor,
        submarket: finalData.submarket,
        floor_area_sqm: parseFloat(finalData.size_sqm),
        rental_rate_sqm: parseFloat(finalData.net_face_rent_sqm),
        outgoings_sqm: parseFloat(finalData.outgoings_sqm || 0),
        parking_spaces: parseInt(finalData.parking_info?.split(' ')[0] || "0"),
        availability_date: finalData.availability_date,
        availability_status: finalData.status || 'available',
        building_grade: finalData.building_grade,
        agent_name: finalData.agent_name,
        agent_company: finalData.agent_company,
        agent_email: finalData.agent_email,
        agent_phone: finalData.agent_phone,
        brief_match_status: "off_brief",
        status: "submitted",
        amplifyre_notes: finalData.comments
      };
      
      await PropertySubmission.create(submissionData);
      
      setSubmissionSuccess(true);

      // Reset form
      setFormData({
        brief_reference_code: "",
        property_title: "",
        address: "",
        latitude: null,
        longitude: null,
        suite_floor: "",
        submarket: "",
        size_sqm: "",
        net_face_rent_sqm: "",
        outgoings_sqm: "",
        fitout_status: "",
        availability_date: "",
        status: "available",
        parking_info: "",
        building_nabers: "",
        landlord_owner: "",
        building_grade: "",
        agent_name: "",
        agent_company: "",
        agent_email: "",
        agent_phone: "",
        co_agent_name: "",
        comments: ""
      });

    } catch (error) {
      console.error("Error submitting property:", error);
      alert("Failed to submit property. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Removed processSubmissionForBuildingDatabase as this page should only create PropertySubmissions.
  // The "Submit Listing" page is now responsible for populating the Building/Tenancy DB.

  if (submissionSuccess) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="orbit-card w-full max-w-lg text-center p-6 sm:p-8">
           <div className="mx-auto bg-green-900/50 border border-green-700 rounded-full p-3 w-fit">
             <CheckCircle className="w-8 sm:w-10 h-8 sm:h-10 text-green-400" />
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white mt-6 mb-2">Submission Received</h2>
          <p className="text-sm sm:text-base text-gray-300 mb-6">
            Thank you for providing the property details. The Stratosfyre team will review the information.
          </p>
          <Button onClick={() => window.location.reload()} className="orbit-button bg-amber-500 hover:bg-amber-600 text-white w-full sm:w-auto min-h-[44px]">Submit Another Property</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 p-4 sm:p-6 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-6 sm:mb-8">
          <div className="bg-gradient-to-br from-orange-500 to-amber-500 p-3 rounded-lg">
            <Building2 className="w-6 sm:w-8 h-6 sm:h-8 text-white" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-white">Agent Property Submission</h1>
            <p className="text-sm sm:text-base text-gray-400 mt-1">Please provide details for the property to be considered by Stratosfyre.</p>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="orbit-card p-4 sm:p-6 md:p-8 space-y-6">
            
            {formData.brief_reference_code && (
              <div className="bg-gray-800 border-l-4 border-amber-500 p-4 rounded-r-lg">
                <p className="text-sm text-gray-300">Submitting options for Brief:</p>
                <p className="font-semibold text-white">{formData.brief_reference_code}</p>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
              <div className="space-y-2">
                <Label htmlFor="address" className="text-sm sm:text-base text-gray-300">1. Address *</Label>
                <Input 
                  id="address" 
                  value={formData.address} 
                  onChange={(e) => handleAddressChange(e.target.value)}
                  required 
                  className="orbit-input"
                  placeholder="e.g., 123 Collins Street, Melbourne VIC 3000"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="suite_floor" className="text-sm sm:text-base text-gray-300">2. Suite/Floor</Label>
                <Input id="suite_floor" value={formData.suite_floor} onChange={(e) => handleInputChange('suite_floor', e.target.value)} className="orbit-input"/>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
               <div className="space-y-2">
                <Label htmlFor="submarket" className="text-sm sm:text-base text-gray-300">3. Submarket *</Label>
                <Select value={formData.submarket} onValueChange={(value) => handleInputChange('submarket', value)} required>
                  <SelectTrigger id="submarket" className="orbit-input">
                    <SelectValue placeholder="Select a submarket" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="City Core">City Core</SelectItem>
                    <SelectItem value="Western Corridor">Western Corridor</SelectItem>
                    <SelectItem value="Midtown">Midtown</SelectItem>
                    <SelectItem value="Southern CBD">Southern CBD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
               <div className="space-y-2">
                <Label htmlFor="size_sqm" className="text-sm sm:text-base text-gray-300">4. Size (sqm) *</Label>
                <Input id="size_sqm" type="number" value={formData.size_sqm} onChange={(e) => handleInputChange('size_sqm', e.target.value)} required className="orbit-input"/>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
              <div className="space-y-2">
                <Label htmlFor="net_face_rent_sqm" className="text-sm sm:text-base text-gray-300">5. Net Face Rent ($/sqm) *</Label>
                <Input id="net_face_rent_sqm" type="number" value={formData.net_face_rent_sqm} onChange={(e) => handleInputChange('net_face_rent_sqm', e.target.value)} required className="orbit-input"/>
              </div>
              <div className="space-y-2">
                <Label htmlFor="outgoings_sqm" className="text-sm sm:text-base text-gray-300">6. Outgoings ($/sqm)</Label>
                <Input id="outgoings_sqm" type="number" value={formData.outgoings_sqm} onChange={(e) => handleInputChange('outgoings_sqm', e.target.value)} className="orbit-input"/>
              </div>
            </div>

             <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                 <div className="space-y-2">
                  <Label htmlFor="fitout_status" className="text-sm sm:text-base text-gray-300">7. Fitout Status</Label>
                  <Input id="fitout_status" value={formData.fitout_status} onChange={(e) => handleInputChange('fitout_status', e.target.value)} placeholder="e.g., Fully fitted" className="orbit-input"/>
                </div>
                 <div className="space-y-2">
                  <Label htmlFor="availability_date" className="text-sm sm:text-base text-gray-300">8. Availability Date *</Label>
                  <Input id="availability_date" type="date" value={formData.availability_date} onChange={(e) => handleInputChange('availability_date', e.target.value)} required className="orbit-input"/>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                <div className="space-y-2">
                  <Label htmlFor="parking_info" className="text-sm sm:text-base text-gray-300">9. Parking Info</Label>
                  <Input id="parking_info" value={formData.parking_info} onChange={(e) => handleInputChange('parking_info', e.target.value)} placeholder="e.g., 2 spaces available" className="orbit-input"/>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="building_nabers" className="text-sm sm:text-base text-gray-300">10. Building NABERS Rating</Label>
                  <Input id="building_nabers" value={formData.building_nabers} onChange={(e) => handleInputChange('building_nabers', e.target.value)} placeholder="e.g., 4.5 Stars" className="orbit-input"/>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                <div className="space-y-2">
                  <Label htmlFor="landlord_owner" className="text-sm sm:text-base text-gray-300">11. Landlord/Owner</Label>
                  <Input id="landlord_owner" value={formData.landlord_owner} onChange={(e) => handleInputChange('landlord_owner', e.target.value)} className="orbit-input"/>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="agent_name" className="text-sm sm:text-base text-gray-300">12. Agent Name *</Label>
                  <Input id="agent_name" value={formData.agent_name} onChange={(e) => handleInputChange('agent_name', e.target.value)} required className="orbit-input"/>
                </div>
              </div>

              {/* New fields for Agent Company, Email, Phone */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                <div className="space-y-2">
                  <Label htmlFor="agent_company" className="text-sm sm:text-base text-gray-300">13. Agent Company</Label>
                  <Input id="agent_company" value={formData.agent_company} onChange={(e) => handleInputChange('agent_company', e.target.value)} className="orbit-input"/>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="agent_email" className="text-sm sm:text-base text-gray-300">14. Agent Email</Label>
                  <Input id="agent_email" type="email" value={formData.agent_email} onChange={(e) => handleInputChange('agent_email', e.target.value)} className="orbit-input"/>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                <div className="space-y-2">
                  <Label htmlFor="agent_phone" className="text-sm sm:text-base text-gray-300">15. Agent Phone</Label>
                  <Input id="agent_phone" type="tel" value={formData.agent_phone} onChange={(e) => handleInputChange('agent_phone', e.target.value)} className="orbit-input"/>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="building_grade" className="text-sm sm:text-base text-gray-300">16. Building Grade</Label>
                  <Input id="building_grade" value={formData.building_grade} onChange={(e) => handleInputChange('building_grade', e.target.value)} placeholder="e.g., A, B, Premium" className="orbit-input"/>
                </div>
              </div>


              {/* Original Co-Agent Name, moved down due to new fields */}
              <div className="space-y-2">
                <Label htmlFor="co_agent_name" className="text-sm sm:text-base text-gray-300">17. Co-Agent Name</Label>
                <Input id="co_agent_name" value={formData.co_agent_name} onChange={(e) => handleInputChange('co_agent_name', e.target.value)} className="orbit-input"/>
              </div>

              {/* Property Title field - new, but no specific number in outline, placing it here for completeness */}
              <div className="space-y-2">
                <Label htmlFor="property_title" className="text-sm sm:text-base text-gray-300">18. Property Title</Label>
                <Input id="property_title" value={formData.property_title} onChange={(e) => handleInputChange('property_title', e.target.value)} placeholder="e.g., Office Space at Level 5" className="orbit-input"/>
              </div>

              <div className="space-y-2">
                <Label htmlFor="comments" className="text-sm sm:text-base text-gray-300">19. Comments</Label>
                <Textarea id="comments" value={formData.comments} onChange={(e) => handleInputChange('comments', e.target.value)} rows={4} className="orbit-input"/>
              </div>

            <div className="flex flex-col sm:flex-row justify-end gap-3 pt-4">
               <Button type="submit" disabled={isSubmitting} size="lg" className="orbit-button bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-lg w-full sm:w-auto min-h-[44px]">
                {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting...</> : "Submit Property"}
              </Button>
            </div>

          </div>
        </form>
      </div>
    </div>
  );
}
