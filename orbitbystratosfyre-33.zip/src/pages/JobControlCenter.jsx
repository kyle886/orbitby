
import React, { useState, useEffect, useCallback } from 'react';
import { JobRun } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Activity,
  PlayCircle,
  AlertTriangle,
  CheckCircle,
  Clock,
  RefreshCw,
  TrendingUp,
  Database,
  Zap,
  Brain,
  Calendar,
  Loader2
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { triggerJob } from '@/components/utils/runJob';

const JOB_CATEGORIES = {
  'Data Ingestion': {
    icon: Database,
    color: 'text-blue-400',
    jobs: ['Ingest Data Job', 'Building Data Import', 'Contact Import']
  },
  'Intelligence Agents': {
    icon: Brain,
    color: 'text-purple-400',
    jobs: ['Funding News Agent', 'ASX Announcements Agent', 'Market Intelligence Scan']
  },
  'Automation Jobs': {
    icon: Zap,
    color: 'text-yellow-400',
    jobs: ['Duplicate Scanner', 'Naming Unifier', 'Data Quality Check']
  },
  'Marketing': {
    icon: TrendingUp,
    color: 'text-green-400',
    jobs: ['Inbound Generation Job', 'Content Recommendations']
  },
  'Events & Scheduling': {
    icon: Calendar,
    color: 'text-orange-400',
    jobs: ['Events Agent', 'BD Event Scan']
  }
};

const JobStatusBadge = ({ status }) => {
  const configs = {
    'success': { color: 'bg-green-900/50 text-green-300 border-green-700', icon: CheckCircle },
    'partial': { color: 'bg-yellow-900/50 text-yellow-300 border-yellow-700', icon: AlertTriangle },
    'failed': { color: 'bg-red-900/50 text-red-300 border-red-700', icon: AlertTriangle },
    'queued': { color: 'bg-blue-900/50 text-blue-300 border-blue-700', icon: Clock }
  };

  const config = configs[status] || configs.queued;
  const Icon = config.icon;

  return (
    <Badge className={`${config.color} border px-2 py-1 flex items-center gap-1`}>
      <Icon className="w-3 h-3" />
      {status}
    </Badge>
  );
};

const JobCategoryCard = ({ category, config, jobs, onRunJob, runningJobs }) => {
  const Icon = config.icon;
  const recentJobs = jobs.slice(0, 3);

  const successRate = jobs.length > 0
    ? Math.round((jobs.filter(j => j.status === 'success').length / jobs.length) * 100)
    : 0;

  const lastRun = jobs[0]?.started_at ? new Date(jobs[0].started_at).toLocaleString() : null;
  const isRunning = config.jobs.some(jobName => runningJobs.includes(jobName));

  return (
    <Card className="orbit-card">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Icon className={`w-5 h-5 ${config.color}`} />
            <span className="text-white">{category}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-400">{successRate}% success</span>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onRunJob(category, config.jobs)}
              disabled={isRunning}
              className="text-orange-400 hover:text-orange-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isRunning ? <Loader2 className="w-4 h-4 animate-spin" /> : <PlayCircle className="w-4 h-4" />}
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="text-xs text-gray-400">
            Last run: {lastRun || 'Never'}
          </div>

          <div className="space-y-2">
            {recentJobs.length > 0 ? (
              recentJobs.map(job => (
                <div key={job.id} className="flex items-center justify-between py-2 border-b border-gray-700/50 last:border-0">
                  <div className="flex-1">
                    <p className="text-sm text-white truncate">{job.job_name}</p>
                    <p className="text-xs text-gray-400">
                      {new Date(job.started_at).toLocaleString()}
                    </p>
                  </div>
                  <JobStatusBadge status={job.status} />
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-500 italic">No recent jobs</p>
            )}
          </div>

          {jobs.length > 3 && (
            <Button variant="outline" size="sm" className="w-full mt-3">
              View All ({jobs.length})
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

const SystemHealthCard = ({ jobs }) => {
  const last24h = jobs.filter(j =>
    new Date(j.started_at) > new Date(Date.now() - 24 * 60 * 60 * 1000)
  );

  const metrics = {
    totalJobs: last24h.length,
    successfulJobs: last24h.filter(j => j.status === 'success').length,
    failedJobs: last24h.filter(j => j.status === 'failed').length,
    avgDuration: last24h.length > 0
      ? Math.round(last24h.reduce((acc, j) => {
          if (j.finished_at) {
            return acc + (new Date(j.finished_at) - new Date(j.started_at));
          }
          return acc;
        }, 0) / last24h.length / 1000)
      : 0
  };

  const healthScore = metrics.totalJobs > 0
    ? Math.round((metrics.successfulJobs / metrics.totalJobs) * 100)
    : 100;

  const healthColor = healthScore >= 90 ? 'text-green-400' :
                     healthScore >= 70 ? 'text-yellow-400' : 'text-red-400';

  return (
    <Card className="orbit-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-white">
          <Activity className={`w-5 h-5 ${healthColor}`} />
          System Health
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-white">{healthScore}%</p>
            <p className="text-sm text-gray-400">Health Score</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-white">{metrics.totalJobs}</p>
            <p className="text-sm text-gray-400">Jobs (24h)</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-green-400">{metrics.successfulJobs}</p>
            <p className="text-sm text-gray-400">Successful</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-red-400">{metrics.failedJobs}</p>
            <p className="text-sm text-gray-400">Failed</p>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-gray-700/50">
          <p className="text-sm text-gray-400">
            Avg Duration: <span className="text-white">{metrics.avgDuration}s</span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default function JobControlCenter() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [runningJobs, setRunningJobs] = useState([]);
  const { toast } = useToast();

  const loadJobs = useCallback(async () => {
    setLoading(true);
    try {
      const jobRuns = await JobRun.list('-started_at', 100);
      setJobs(jobRuns || []);
    } catch (error) {
      console.error("Failed to load jobs:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadJobs();
    const interval = setInterval(loadJobs, 30000);
    return () => clearInterval(interval);
  }, [loadJobs]);

  const handleRunJob = async (category, jobNames) => {
    toast({
      title: `Triggering ${category} Jobs`,
      description: `Starting ${jobNames.length} job(s)...`,
    });

    setRunningJobs(prev => [...new Set([...prev, ...jobNames])]);

    const results = await Promise.allSettled(
      jobNames.map(async (jobName) => {
        try {
          const functionNameMap = {
            'Ingest Data Job': 'ingestData', // Specific mapping as per earlier logic
            'Building Data Import': 'buildingDataImport',
            'Contact Import': 'contactImport',
            'Funding News Agent': 'fundingNewsAgent',
            'ASX Announcements Agent': 'asxAnnouncementsAgent',
            'Events Agent': 'eventsAgent',
            'NSW DA Agent': 'nswDAAgent', // Example if this was a new one
            'Duplicate Scanner': 'duplicateScanner',
            'Naming Unifier': 'namingUnifier',
            'Data Quality Check': 'dataQualityCheck',
            'Inbound Generation Job': 'inboundGenerationJob',
            'Market Intelligence Scan': 'marketIntelligenceScan',
            'Content Recommendations': 'contentRecommendations' // Assuming a function name for this
          };

          // Use mapped name or convert display name to a camelCase function name
          const functionName = functionNameMap[jobName] || jobName
            .toLowerCase()
            .replace(/(^|[^a-zA-Z0-9]+)([a-zA-Z0-9])/g, (match, sep, char) => char.toUpperCase())
            .replace(/[^a-zA-Z0-9]/g, '');

          return await triggerJob(functionName, { category });
        } catch (error) {
          console.error(`Failed to trigger ${jobName}:`, error);
          throw { jobName, error }; // Re-throw with jobName for better error reporting
        }
      })
    );

    let successCount = 0;
    results.forEach(result => {
      if (result.status === 'fulfilled') {
        successCount++;
      } else {
        const failedJobName = result.reason?.jobName || 'unknown job';
        console.error(`Failed to trigger job ${failedJobName}:`, result.reason?.error || result.reason);
      }
    });

    toast({
      title: 'Jobs Triggered',
      description: `${successCount} of ${jobNames.length} jobs were successfully started. They will now run in the background.`,
      variant: successCount < jobNames.length ? 'destructive' : 'default',
    });

    // Refresh jobs after a delay to allow them to appear
    setTimeout(() => {
      loadJobs();
      setRunningJobs(prev => prev.filter(j => !jobNames.includes(j)));
    }, 3000); // Changed delay to 3 seconds
  };

  const categorizedJobs = Object.entries(JOB_CATEGORIES).map(([category, config]) => ({
    category,
    config,
    jobs: jobs.filter(job =>
      config.jobs.some(jobType => job.job_name.includes(jobType))
    )
  }));

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full min-h-screen">
        <div className="w-8 h-8 rounded-full animate-pulse" style={{ background: 'rgba(255,255,255,0.1)' }}></div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Job Control Center</h1>
            <p className="text-gray-300">Monitor and manage all automated system processes</p>
          </div>
          <Button onClick={loadJobs} disabled={loading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          <SystemHealthCard jobs={jobs} />
          <div className="lg:col-span-3 grid md:grid-cols-2 xl:grid-cols-3 gap-4">
            {categorizedJobs.map(({ category, config, jobs: categoryJobs }) => (
              <JobCategoryCard
                key={category}
                category={category}
                config={config}
                jobs={categoryJobs}
                onRunJob={handleRunJob}
                runningJobs={runningJobs}
              />
            ))}
          </div>
        </div>

        {/* Recent Activity Timeline */}
        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-white">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {jobs.slice(0, 10).map(job => (
                <div key={job.id} className="flex items-start gap-4 p-4 border border-gray-700/50 rounded-lg">
                  <div className="text-gray-400 text-sm">
                    {new Date(job.started_at).toLocaleString()}
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-medium">{job.job_name}</p>
                    {job.notes && (
                      <p className="text-sm text-gray-400 mt-1">{job.notes.substring(0, 100)}...</p>
                    )}
                  </div>
                  <JobStatusBadge status={job.status} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
