
import React, { useState, useEffect } from 'react';
import { Company } from '@/api/entities';
import { Signal } from '@/api/entities';
import { Contact } from '@/api/entities';
import { Pitch } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, ArrowRight, ArrowLeft, Check, Sparkles, Download, CalendarPlus, AlertTriangle } from 'lucide-react';
import { Combobox } from '@/components/ui/combobox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { runJob } from '@/components/utils/runJob'; // Updated import
import { calculatePitchReadiness } from '@/components/utils/scoringCalculations';
import { createPageUrl } from '@/utils';

const StepIndicator = ({ current, total }) => (
    <div className="flex justify-center items-center space-x-2 mb-8">
        {[...Array(total)].map((_, i) => (
            <div key={i} className={`h-2 w-12 rounded-full ${i < current ? 'bg-orange-500' : 'bg-gray-700'}`}></div>
        ))}
    </div>
);

export default function PitchMaster() {
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        company_id: null,
        company_name: '',
        attendees_input: '',
        project_brief: '',
        meeting_dt: '',
        signals: [],
        contacts: [],
        decision_makers: [], // This is a placeholder for selected decision makers
        messaging_hypothesis: '',
        sample_projects: '',
    });
    const [companies, setCompanies] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [createdPitch, setCreatedPitch] = useState(null); // State to store the created pitch object
    const { toast } = useToast();

    const [readinessScore, setReadinessScore] = useState(0);
    const [showOverrideDialog, setShowOverrideDialog] = useState(false);
    const [overrideReason, setOverrideReason] = useState("");

    // Calculate readiness score using the utility function
    useEffect(() => {
        // formData contains all the necessary data for readiness calculation
        const { readiness_score } = calculatePitchReadiness(formData);
        setReadinessScore(readiness_score);
    }, [formData]);


    useEffect(() => {
        async function fetchCompanies() {
            try {
                const companyData = await Company.list();
                setCompanies((companyData || []).map(c => ({ label: c.name, value: c.id })));
            } catch (error) {
                toast({ variant: 'destructive', title: 'Error', description: 'Failed to load companies.' });
            }
        }
        fetchCompanies();
    }, [toast]);

    const handleNext = async () => {
        if (step === 1) {
            if (!formData.company_id) {
                toast({ variant: 'destructive', title: 'Company Required', description: 'Please select a company to proceed.' });
                return;
            }
            if (!formData.meeting_dt) {
                toast({ variant: 'destructive', title: 'Meeting Date Required', description: 'Please set a meeting date and time.' });
                return;
            }
        }

        if (step === 2) { // After dossier step, fetch signals and contacts
            setIsLoading(true);
            try {
                const signalsData = await Signal.filter({ company_id: formData.company_id }, '-date', 50);
                const contactsData = await Contact.filter({ company_id: formData.company_id });
                
                const cutoffDate = new Date();
                cutoffDate.setDate(cutoffDate.getDate() - 180);
                
                setFormData(prev => ({
                    ...prev,
                    signals: (signalsData || []).filter(s => new Date(s.date) >= cutoffDate),
                    contacts: contactsData || [],
                }));
            } catch (error) {
                toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch dossier information.' });
            } finally {
                setIsLoading(false);
            }
        }
        setStep(prev => prev + 1);
    };

    const handleBack = () => {
        // If we are on the final success screen (step 4 with createdPitch), going back should clear the pitch
        // and return to the review screen (step 4, but without createdPitch)
        if (step === 4 && createdPitch) {
            setCreatedPitch(null);
        }
        setStep(prev => prev - 1);
    };
    
    const handleIssuePitch = async () => {
        setIsLoading(true); // Set isLoading to true immediately

        if (readinessScore < 70 && !overrideReason) {
            setShowOverrideDialog(true);
            setIsLoading(false); // Reset isLoading since we are not proceeding with the job immediately
            return;
        }

        try {
            await runJob(
                `Issue Pitch: ${formData.project_brief}`,
                async () => {
                    const newPitchData = {
                        company_id: formData.company_id,
                        pitch_name: `Pitch for ${formData.company_name} - ${new Date(formData.meeting_dt).toLocaleDateString()}`,
                        attendees_input: formData.attendees_input,
                        project_brief: formData.project_brief,
                        meeting_dt: formData.meeting_dt,
                        status: 'issued', // Changed from 'Preparation' to 'issued'
                        messaging_hypothesis: formData.messaging_hypothesis,
                        // In a real scenario, you'd generate and upload a PDF, then store its URL
                        pack_url: 'https://example.com/placeholder.pdf',
                        readiness_score: readinessScore,
                        override_reason: overrideReason // Add override reason if provided
                    };
                    
                    const newPitch = await Pitch.create(newPitchData);
                    setCreatedPitch(newPitch); // Store the created pitch object
                    
                    toast({
                        title: 'Pitch Issued',
                        description: `A new pitch record (#${newPitch.id}) has been created and issued. You can now download the dossier and create an invite.`
                    });
                    
                    // Clear override reason and close dialog
                    setOverrideReason("");
                    setShowOverrideDialog(false);

                    return { rows_affected: 1, notes: `Pitch ${newPitch.id} created and issued.` };
                },
                { ...formData, readiness_score: readinessScore, override_reason: overrideReason } // Context data for runJob
            );
            // The mock PDF generation and calendar invite download logic is now moved to specific buttons
            // on the final step (case 4 when createdPitch is true).
            // Do NOT reset step to 1 here, remain on step 4 to show the final success card.
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to issue pitch record.' });
        } finally {
            setIsLoading(false);
        }
    };

    const handleGenerateCalendarInvite = () => {
        if (!createdPitch || !formData.meeting_dt || !formData.company_name || !formData.project_brief || !formData.attendees_input) {
            toast({ variant: 'destructive', title: 'Missing Information', description: 'Cannot generate calendar invite due to missing pitch or meeting details.' });
            return;
        }

        const calContent = [
            'BEGIN:VCALENDAR', 'VERSION:2.0', 'BEGIN:VEVENT',
            `URL:${document.URL}`,
            `DTSTART:${new Date(formData.meeting_dt).toISOString().replace(/-|:|\.\d+/g, "")}`,
            `DTEND:${new Date(new Date(formData.meeting_dt).getTime() + 60*60*1000).toISOString().replace(/-|:|\.\d+/g, "")}`, // Default to 1-hour meeting
            `SUMMARY:Pitch Meeting with ${formData.company_name}`,
            `DESCRIPTION:${formData.project_brief.replace(/\n/g, '\\n')}`,
            `LOCATION:${formData.attendees_input}`, // Assuming address is in attendees
            'END:VEVENT', 'END:VCALENDAR'
        ].join('\n');
        const calBlob = new Blob([calContent], { type: 'text/calendar;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(calBlob);
        link.download = `pitch-meeting-${formData.company_name}.ics`;
        document.body.appendChild(link); // Append to body to ensure click works
        link.click();
        document.body.removeChild(link); // Clean up
        toast({ title: 'Calendar Invite Generated', description: 'ICS file downloaded.' });
    };

    const handleStartNewPitch = () => {
        setStep(1);
        setCreatedPitch(null);
        setFormData({
            company_id: null,
            company_name: '',
            attendees_input: '',
            project_brief: '',
            meeting_dt: '',
            signals: [],
            contacts: [],
            decision_makers: [],
            messaging_hypothesis: '',
            sample_projects: '',
        });
        setReadinessScore(0);
        setOverrideReason("");
    };

    const renderStep = () => {
        switch(step) {
            case 1:
                return (
                    <div className="space-y-4">
                        <h2 className="text-xl font-semibold text-white">Step 1: Basic Information</h2>
                        <div>
                            <Label className="text-gray-300">Company *</Label>
                             <Combobox
                                options={companies}
                                value={formData.company_id}
                                onSelect={(value, label) => setFormData(prev => ({ ...prev, company_id: value, company_name: label }))}
                                placeholder="Search for a company..."
                            />
                        </div>
                        <div>
                            <Label className="text-gray-300">Meeting Date & Time *</Label>
                            <Input type="datetime-local" value={formData.meeting_dt} onChange={e => setFormData(prev => ({...prev, meeting_dt: e.target.value}))} className="orbit-input"/>
                        </div>
                        <div>
                            <Label className="text-gray-300">Attendees & Address</Label>
                            <Textarea value={formData.attendees_input} onChange={e => setFormData(prev => ({...prev, attendees_input: e.target.value}))} className="orbit-input" placeholder="e.g., Jane Doe (CEO), John Smith (COO) at 123 Main St, Sydney"/>
                        </div>
                        <div>
                            <Label className="text-gray-300">Project Details</Label>
                            <Textarea value={formData.project_brief} onChange={e => setFormData(prev => ({...prev, project_brief: e.target.value}))} className="orbit-input" placeholder="Initial understanding of the project or opportunity..."/>
                        </div>
                    </div>
                );
            case 2:
                return (
                    <div className="space-y-6">
                        <h2 className="text-xl font-semibold text-white">Step 2: Dossier Compilation</h2>
                        {isLoading ? <Loader2 className="animate-spin mx-auto"/> :
                            <>
                                <div>
                                    <h3 className="font-semibold text-orange-400 mb-2">Recent Signals (Last 180d)</h3>
                                    <div className="space-y-2 max-h-40 overflow-y-auto p-2 bg-gray-800/50 rounded-md">
                                        {formData.signals.length > 0 ? formData.signals.map(s => <p key={s.id} className="text-sm text-gray-300 border-b border-gray-700 pb-1"><strong>{s.type}:</strong> {s.title}</p>) : <p className="text-gray-500">No recent signals found.</p>}
                                    </div>
                                </div>
                                <div>
                                    <h3 className="font-semibold text-orange-400 mb-2">Identify Decision Makers</h3>
                                    <div className="space-y-2 max-h-40 overflow-y-auto p-2 bg-gray-800/50 rounded-md">
                                         {formData.contacts.length > 0 ? formData.contacts.map(c => (
                                            <div key={c.id} className="flex items-center space-x-2">
                                                <Checkbox id={`contact-${c.id}`} />
                                                <Label htmlFor={`contact-${c.id}`} className="text-sm text-gray-300">{c.name} ({c.role})</Label>
                                            </div>
                                         )) : <p className="text-gray-500">No contacts found for this company.</p>}
                                    </div>
                                </div>
                            </>
                        }
                    </div>
                );
            case 3:
                return (
                    <div className="space-y-4">
                        <h2 className="text-xl font-semibold text-white">Step 3: Messaging & Proof Points</h2>
                        <div>
                            <Label className="text-gray-300">Messaging Hypothesis</Label>
                            <Textarea value={formData.messaging_hypothesis} onChange={e => setFormData(prev => ({...prev, messaging_hypothesis: e.target.value}))} className="orbit-input h-24" placeholder="Our core value proposition for this client is..."/>
                        </div>
                        <div>
                            <Label className="text-gray-300">Sample Projects / Proof Points</Label>
                            <Textarea value={formData.sample_projects} onChange={e => setFormData(prev => ({...prev, sample_projects: e.target.value}))} className="orbit-input h-24" placeholder="- Similar project for Company A\n- Achieved X% savings for Company B"/>
                        </div>
                    </div>
                );
            case 4:
                // Conditional rendering for Step 4: Review vs. Pitch Pack Ready
                if (createdPitch) {
                    return (
                        <Card className="orbit-card p-8 text-center">
                            <CardHeader>
                                <CardTitle className="text-white text-2xl">Pitch Pack Ready</CardTitle>
                                <p className="text-gray-400">Your pitch dossier is compiled and ready for export.</p>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <Button
                                size="lg"
                                className="bg-green-600 hover:bg-green-700 text-white w-full"
                                onClick={() => window.open(createPageUrl(`PitchDossierPrintable?id=${createdPitch.id}`), '_blank')}
                                >
                                <Download className="mr-2 h-5 w-5" />
                                Export Dossier (PDF)
                                </Button>
                                <Button size="lg" variant="outline" className="orbit-button w-full" onClick={handleGenerateCalendarInvite}>
                                <CalendarPlus className="mr-2 h-5 w-5" />
                                Create Calendar Invite
                                </Button>
                                <Button size="lg" variant="outline" className="orbit-button w-full" onClick={handleStartNewPitch}>
                                    Start New Pitch
                                </Button>
                            </CardContent>
                        </Card>
                    );
                } else {
                    return (
                        <div className="space-y-4">
                            <h2 className="text-xl font-semibold text-white">Step 4: Review & Finalize</h2>
                            <div className="p-4 bg-gray-800/50 rounded-lg space-y-2 text-sm">
                                <p><strong>Company:</strong> {formData.company_name}</p>
                                <p><strong>Meeting:</strong> {formData.meeting_dt ? new Date(formData.meeting_dt).toLocaleString() : 'Not set'}</p>
                                <p><strong>Brief:</strong> {formData.project_brief.substring(0, Math.min(formData.project_brief.length, 100))}...</p>
                                <p><strong>Messaging:</strong> {formData.messaging_hypothesis.substring(0, Math.min(formData.messaging_hypothesis.length, 100))}...</p>
                            </div>
                            <p className="text-xs text-gray-400">Finalizing will create a new Pitch record and enable dossier export.</p>

                            <div className="mt-8 space-y-4">
                                <div className="text-center">
                                    <p className="text-gray-400">Pitch Readiness Score</p>
                                    <p className={`text-6xl font-bold ${readinessScore >= 70 ? 'text-green-400' : 'text-amber-400'}`}>{readinessScore}</p>
                                </div>
                                {readinessScore < 70 &&
                                    <div className="p-4 bg-amber-900/50 border border-amber-700 text-amber-300 rounded-lg text-sm">
                                        <AlertTriangle className="inline w-4 h-4 mr-2" />
                                        Readiness score is below the recommended 70. You can proceed, but completing all steps is advised.
                                    </div>
                                }
                                <Button onClick={handleIssuePitch} className="w-full orbit-button-active text-white" size="lg" disabled={isLoading}>
                                    {isLoading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Check className="w-5 h-5 mr-2" />}
                                    Issue Pitch Pack
                                </Button>
                            </div>
                        </div>
                    );
                }
            default: return null;
        }
    }

    return (
        <div className="p-4 sm:p-6 md:p-8">
            <div className="max-w-2xl mx-auto">
                <div className="mb-8 text-center">
                    <h1 className="text-3xl font-bold text-white mb-2">Pitch Master</h1>
                    <p className="text-gray-300">Assemble and finalize your pitch materials.</p>
                </div>
                
                <div className="orbit-card p-8">
                    <StepIndicator current={step} total={4} />
                    <div className="min-h-[300px]">
                        {renderStep()}
                    </div>
                    <div className="flex justify-between items-center mt-8">
                        {/* Back button: visible if not on step 1 and no pitch has been created yet (i.e., not on the final "Pitch Pack Ready" screen) */}
                        {step > 1 && !createdPitch && (
                            <Button variant="outline" onClick={handleBack} className="orbit-button">
                                <ArrowLeft className="w-4 h-4 mr-2"/> Back
                            </Button>
                        )}
                        
                        {/* Next button: visible for steps 1, 2, 3 (before finalization) and no pitch has been created */}
                        {step < 4 && !createdPitch ? (
                            <Button onClick={handleNext} className="bg-orange-500 hover:bg-orange-600 ml-auto" disabled={isLoading}> {/* Use ml-auto to push right when back button is absent */}
                                {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : null}
                                Next <ArrowRight className="w-4 h-4 ml-2"/>
                            </Button>
                        ) : null }

                        {/* The "Finalize & Create Pitch" button (now "Issue Pitch Pack") is handled within renderStep() for case 4 */}
                        {/* No navigation buttons if step is 4 and createdPitch is true, as the card handles actions */}
                    </div>
                </div>
            </div>

            <Dialog open={showOverrideDialog} onOpenChange={setShowOverrideDialog}>
                <DialogContent className="orbit-card text-white">
                    <DialogHeader>
                        <DialogTitle>Readiness Score Below {70}</DialogTitle>
                        <DialogDescription className="text-gray-400">
                            The pitch readiness score is {readinessScore}. Are you sure you want to proceed? Please provide a reason for overriding the recommendation.
                        </DialogDescription>
                    </DialogHeader>
                    <Textarea 
                        value={overrideReason}
                        onChange={(e) => setOverrideReason(e.target.value)}
                        placeholder="e.g., Time-sensitive opportunity, verbal confirmation received, client priority."
                        className="orbit-input mt-4"
                    />
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setShowOverrideDialog(false)}>Cancel</Button>
                        {/* The "Proceed Anyway" button re-calls handleIssuePitch, which will then proceed since overrideReason is now set. */}
                        <Button onClick={handleIssuePitch} disabled={!overrideReason || isLoading}>Proceed Anyway</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
