import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { RFPResponse } from '@/api/entities';
import { RFPRequest } from '@/api/entities';
import { PropertySubmission } from '@/api/entities';
import { Document } from '@/api/entities';
import HOAEditor from '../components/hoa-editor/HOAEditor';
import { Loader2, FileDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function RFPResponseDetails() {
    const [response, setResponse] = useState(null);
    const [hoaDocument, setHoaDocument] = useState(null);
    const [property, setProperty] = useState(null);
    const [loading, setLoading] = useState(true);
    const location = useLocation();

    useEffect(() => {
        const loadData = async () => {
            const params = new URLSearchParams(location.search);
            const responseId = params.get('id');
            if (!responseId) {
                setLoading(false);
                return;
            }
            try {
                const responseData = await RFPResponse.get(responseId);
                setResponse(responseData);

                const propertyData = await PropertySubmission.get(responseData.property_submission_id);
                setProperty(propertyData);

                if (responseData.heads_of_agreement_document_id) {
                    const docData = await Document.get(responseData.heads_of_agreement_document_id);
                    setHoaDocument(docData);
                }
            } catch (error) {
                console.error("Error loading data:", error);
            } finally {
                setLoading(false);
            }
        };
        loadData();
    }, [location.search]);
    
    if (loading) return <div className="flex items-center justify-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-orange-400" /></div>;
    if (!response || !property) return <div className="flex items-center justify-center h-screen text-red-500">Could not load RFP response.</div>;
    
    const terms = response.headline_terms;

    return (
        <div className="p-8 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <header className="mb-8">
                    <h1 className="text-3xl font-bold text-white mb-2">RFP Response: {property.property_title}</h1>
                    <p className="text-gray-300">Submitted by {response.agent_email}</p>
                </header>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-1 space-y-6">
                        <div className="orbit-card p-6">
                            <h3 className="text-lg font-bold text-white mb-4">Headline Terms</h3>
                            <div className="space-y-3 text-sm">
                                <div className="flex justify-between"><span className="text-gray-400">Net Face Rent:</span><span className="font-semibold text-white">${terms.net_face_rent}/sqm</span></div>
                                <div className="flex justify-between"><span className="text-gray-400">Outgoings:</span><span className="font-semibold text-white">${terms.outgoings}/sqm</span></div>
                                <div className="flex justify-between"><span className="text-gray-400">Incentive:</span><span className="font-semibold text-white">{terms.incentive_percentage}%</span></div>
                                <div className="flex justify-between"><span className="text-gray-400">Lease Term:</span><span className="font-semibold text-white">{terms.lease_term} Years</span></div>
                            </div>
                        </div>
                         <div className="orbit-card p-6">
                            <h3 className="text-lg font-bold text-white mb-4">Heads of Agreement</h3>
                            {hoaDocument ? (
                                <a href={hoaDocument.file_url} target="_blank" rel="noopener noreferrer">
                                    <Button className="w-full orbit-button bg-orange-500 hover:bg-orange-600">
                                        <FileDown className="w-4 h-4 mr-2"/>
                                        Download Submitted HOA
                                    </Button>
                                </a>
                            ) : (
                                <p className="text-gray-400">No HOA document found.</p>
                            )}
                        </div>
                    </div>
                    <div className="lg:col-span-2">
                        <div className="orbit-card p-2">
                            {hoaDocument ? (
                                <HOAEditor documentId={hoaDocument.id} />
                            ) : (
                                <div className="p-8 text-center text-gray-400">
                                    <p>Heads of Agreement document is not available for editing.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}