import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Pitch, Company, Signal, Contact } from '@/api/entities/PitchMaster'; // Assuming they are part of a module
import { Loader2, Briefcase, User, Target, Zap, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Mock entities if they are not defined in PitchMaster module
const MockPitch = { get: async () => ({ pitch_name: 'Sample Pitch', company_id: '1', project_brief: 'A sample project brief.', messaging_hypothesis: 'A sample messaging hypothesis.' }) };
const MockCompany = { get: async () => ({ name: 'Sample Company', sector: 'SaaS', hq_city: 'Sydney', notes: 'A sample company note.' }) };
const MockSignal = { filter: async () => ([{ type: 'funding', headline: 'Raised $10M', date: '2023-10-01' }]) };
const MockContact = { filter: async () => ([{ name: 'John Doe', role: 'CEO', decision_level: 'economic' }]) };

const PitchEntity = Pitch || MockPitch;
const CompanyEntity = Company || MockCompany;
const SignalEntity = Signal || MockSignal;
const ContactEntity = Contact || MockContact;


export default function PitchDossierPrintable() {
    const [pitch, setPitch] = useState(null);
    const [company, setCompany] = useState(null);
    const [signals, setSignals] = useState([]);
    const [contacts, setContacts] = useState([]);
    const [loading, setLoading] = useState(true);
    const location = useLocation();

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const pitchId = params.get('id');
        if (pitchId) {
            loadData(pitchId);
        } else {
            setLoading(false);
        }
    }, [location.search]);

    const loadData = async (pitchId) => {
        try {
            const pitchData = await PitchEntity.get(pitchId);
            setPitch(pitchData);

            if (pitchData) {
                const [companyData, signalData, contactData] = await Promise.all([
                    CompanyEntity.get(pitchData.company_id),
                    SignalEntity.filter({ company_id: pitchData.company_id }),
                    ContactEntity.filter({ company_id: pitchData.company_id })
                ]);
                setCompany(companyData);
                setSignals(signalData || []);
                setContacts(contactData || []);
            }
        } catch (error) {
            console.error("Error loading dossier data:", error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-gray-800" /></div>;
    }

    if (!pitch || !company) {
        return <div className="text-center p-8">Pitch or Company not found.</div>;
    }

    return (
        <div className="bg-white text-gray-800 p-8 font-sans">
             <style>
                {`
                    @media print {
                        .no-print { display: none; }
                        body { -webkit-print-color-adjust: exact; }
                    }
                `}
            </style>
            
            <div className="no-print mb-8 flex justify-end gap-4">
                <Button onClick={() => window.print()}>Print or Save as PDF</Button>
            </div>
            
            <div className="max-w-4xl mx-auto">
                <header className="border-b-2 border-gray-200 pb-4 mb-8 text-center">
                    <h1 className="text-4xl font-bold text-gray-900">Pitch Dossier: {company.name}</h1>
                    <p className="text-lg text-gray-600">{pitch.pitch_name}</p>
                </header>

                <main className="space-y-10">
                    <section>
                        <h2 className="flex items-center gap-3 text-2xl font-semibold text-gray-800 border-b pb-2 mb-4">
                            <Briefcase /> Project Overview
                        </h2>
                        <p>{pitch.project_brief}</p>
                    </section>

                    <section>
                        <h2 className="flex items-center gap-3 text-2xl font-semibold text-gray-800 border-b pb-2 mb-4">
                            <User /> Company Profile
                        </h2>
                        <div className="grid grid-cols-2 gap-4">
                            <p><strong>Sector:</strong> {company.sector}</p>
                            <p><strong>Location:</strong> {company.hq_city}</p>
                        </div>
                        <p className="mt-4 bg-gray-100 p-3 rounded-md italic">{company.notes}</p>
                    </section>
                    
                     <section>
                        <h2 className="flex items-center gap-3 text-2xl font-semibold text-gray-800 border-b pb-2 mb-4">
                            <Zap /> Recent Signals (Last 180 Days)
                        </h2>
                        <ul className="list-disc list-inside space-y-2">
                           {signals.length > 0 ? signals.map(s => (
                               <li key={s.id}><strong>{s.type}:</strong> {s.headline} ({new Date(s.date).toLocaleDateString()})</li>
                           )) : <li>No recent signals found.</li>}
                        </ul>
                    </section>
                    
                    <section>
                        <h2 className="flex items-center gap-3 text-2xl font-semibold text-gray-800 border-b pb-2 mb-4">
                            <Target /> Key Contacts & Decision-Makers
                        </h2>
                        <ul className="list-disc list-inside space-y-2">
                            {contacts.length > 0 ? contacts.map(c => (
                               <li key={c.id}><strong>{c.name}</strong> ({c.role}) - <span className="capitalize font-medium">{c.decision_level}</span></li>
                           )) : <li>No contacts identified.</li>}
                        </ul>
                    </section>

                    <section>
                        <h2 className="flex items-center gap-3 text-2xl font-semibold text-gray-800 border-b pb-2 mb-4">
                            <MessageSquare /> Messaging Hypothesis
                        </h2>
                        <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                           <p className="text-blue-800">{pitch.messaging_hypothesis}</p>
                        </div>
                    </section>
                </main>
            </div>
        </div>
    );
}