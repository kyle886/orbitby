import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { computeTenantTiles } from "@/api/functions";

export default function TenantDashboard() {
  const [tiles, setTiles] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    (async () => {
      try {
        const { data } = await computeTenantTiles();
        setTiles(data?.tiles || []);
      } catch (error) {
        console.error('Failed to load tenant tiles:', error);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <div className="p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Property Dashboard</h1>
          <p className="text-gray-600">Track your requirements, documents, and upcoming milestones</p>
        </div>

        <div className="grid gap-6">
          {tiles.map((tile, index) => (
            <Card key={index} className="orbit-card">
              <CardHeader>
                <CardTitle className="text-white">{tile.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-gray-300">{tile.content}</div>
                {tile.actions && (
                  <div className="mt-4 space-y-2">
                    {tile.actions.map((action, i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                        <span className="text-white">{action.label}</span>
                        <span className="text-xs text-gray-400">{action.dueAt}</span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}