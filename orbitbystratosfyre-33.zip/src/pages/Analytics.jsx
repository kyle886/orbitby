
import React, { useState, useEffect, useCallback } from "react";
import { Client } from "@/api/entities";
import { PropertySubmission } from "@/api/entities";
import { TenantRequirement } from "@/api/entities";
import { ClientUpdate } from "@/api/entities";
import { AuditLog } from "@/api/entities";
import { KPICards } from "@/components/analytics/KPICards";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Area, AreaChart
} from 'recharts';
import { 
  TrendingUp, 
  Users, 
  Building2, 
  Clock, 
  DollarSign,
  CheckCircle,
  AlertCircle,
  Calendar,
  Download,
  Filter
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Analytics() {
  const [clients, setClients] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [briefs, setBriefs] = useState([]);
  const [updates, setUpdates] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('30'); // days
  const [kpiData, setKpiData] = useState({});

  const calculateKPIs = useCallback((clientsData, submissionsData, briefsData, updatesData) => {
    const now = new Date();
    const cutoffDate = new Date(now.getTime() - (parseInt(dateRange) * 24 * 60 * 60 * 1000));

    const filteredClients = (clientsData || []).filter(c => 
      new Date(c.created_date) >= cutoffDate
    );

    const filteredSubmissions = (submissionsData || []).filter(s => 
      new Date(s.created_date) >= cutoffDate
    );

    const activeClients = (clientsData || []).filter(c => 
      ['discovery', 'search_active', 'negotiation', 'lease_execution'].includes(c.engagement_status)
    ).length;

    const completedDeals = (clientsData || []).filter(c => 
      c.engagement_status === 'completed'
    ).length;

    const totalClients = (clientsData || []).length;
    const conversionRate = totalClients > 0 ? ((completedDeals / totalClients) * 100).toFixed(1) : 0;

    // Calculate average response time (mock data for now)
    const avgResponseTime = 4.2;

    // Calculate total deal value (mock - would need deal value tracking)
    const avgDealSize = submissionsData && submissionsData.length > 0 ? 
      Math.round(submissionsData.reduce((acc, s) => acc + (s.floor_area_sqm || 0), 0) / submissionsData.length) : 0;

    const totalDealValue = completedDeals * avgDealSize * 800; // Estimated at $800/sqm avg rent

    setKpiData({
      activeClients,
      totalSubmissions: submissionsData?.length || 0,
      avgResponseTime,
      conversionRate: parseFloat(conversionRate),
      dealsCompleted: completedDeals,
      totalDealValue,
      avgDealSize,
      clientSatisfaction: 4.8,
      newClients: filteredClients.length,
      newSubmissions: filteredSubmissions.length
    });
  }, [dateRange]);

  const loadAnalyticsData = useCallback(async () => {
    setLoading(true);
    try {
      const [clientsData, submissionsData, briefsData, updatesData, auditData] = await Promise.all([
        Client.list("-created_date"),
        PropertySubmission.list("-created_date"),
        TenantRequirement.list("-created_date"),
        ClientUpdate.list("-created_date"),
        AuditLog.list("-timestamp", 100)
      ]);

      setClients(clientsData || []);
      setSubmissions(submissionsData || []);
      setBriefs(briefsData || []);
      setUpdates(updatesData || []);
      setAuditLogs(auditData || []);

      calculateKPIs(clientsData || [], submissionsData || [], briefsData || [], updatesData || []);
    } catch (error) {
      console.error("Error loading analytics data:", error);
    } finally {
      setLoading(false);
    }
  }, [calculateKPIs]);

  useEffect(() => {
    loadAnalyticsData();
  }, [loadAnalyticsData]);

  const getEngagementStats = () => {
    const statusCounts = {};
    const clientArray = Array.isArray(clients) ? clients : [];
    clientArray.forEach(client => {
      const status = client.engagement_status || 'unknown';
      statusCounts[status] = (statusCounts[status] || 0) + 1;
    });

    return [
      { name: 'Discovery', value: statusCounts.discovery || 0, color: '#8884d8' },
      { name: 'Active Search', value: statusCounts.search_active || 0, color: '#82ca9d' },
      { name: 'Negotiation', value: statusCounts.negotiation || 0, color: '#ffc658' },
      { name: 'Execution', value: statusCounts.lease_execution || 0, color: '#ff7300' },
      { name: 'Completed', value: statusCounts.completed || 0, color: '#0088fe' }
    ];
  };

  const getSubmissionTrends = () => {
    const last30Days = Array.from({ length: 30 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (29 - i));
      return date.toISOString().split('T')[0];
    });

    return last30Days.map(date => {
      const daySubmissions = (submissions || []).filter(s => 
        s.created_date && s.created_date.split('T')[0] === date
      ).length;

      return {
        date: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        submissions: daySubmissions
      };
    });
  };

  const getIndustryBreakdown = () => {
    const industries = {};
    const clientArray = Array.isArray(clients) ? clients : [];
    clientArray.forEach(client => {
      if (client.industry) {
        const industry = client.industry.replace('_', ' ').toUpperCase();
        industries[industry] = (industries[industry] || 0) + 1;
      }
    });

    return Object.entries(industries).map(([industry, count]) => ({
      industry,
      count,
      color: `#${Math.floor(Math.random()*16777215).toString(16)}`
    }));
  };

  const exportData = () => {
    const exportData = {
      summary: kpiData,
      clients: clients,
      submissions: submissions,
      briefs: briefs,
      generated: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `orbit-analytics-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="p-8 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <div className="text-center p-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-400 mx-auto mb-4"></div>
            <p className="text-gray-300">Loading analytics data...</p>
          </div>
        </div>
      </div>
    );
  }

  const engagementStats = getEngagementStats();
  const submissionTrends = getSubmissionTrends();
  const industryData = getIndustryBreakdown();

  return (
    <div className="p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Analytics Dashboard</h1>
            <p className="text-gray-300">Business intelligence and performance metrics</p>
          </div>
          <div className="flex gap-3">
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-40 orbit-input text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
                <SelectItem value="365">Last year</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={exportData} className="orbit-button bg-orange-500 hover:bg-orange-600">
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>

        {/* KPI Cards */}
        <KPICards data={kpiData} />

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-8 mt-8">
          {/* Engagement Pipeline */}
          <div className="orbit-card p-6">
            <h3 className="text-xl font-bold text-white mb-6">Client Engagement Pipeline</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={engagementStats}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value, percent }) => `${name}: ${value} (${(percent * 100).toFixed(0)}%)`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {engagementStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  labelStyle={{ color: '#F3F4F6' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Submission Trends */}
          <div className="orbit-card p-6">
            <h3 className="text-xl font-bold text-white mb-6">Daily Submission Volume</h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={submissionTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="date" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  labelStyle={{ color: '#F3F4F6' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="submissions" 
                  stroke="#f97316" 
                  fill="#f97316" 
                  fillOpacity={0.6}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Industry Analysis */}
        <div className="orbit-card p-6 mt-8">
          <h3 className="text-xl font-bold text-white mb-6">Client Industry Distribution</h3>
          <div className="grid lg:grid-cols-2 gap-8">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={industryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ industry, count }) => `${industry}: ${count}`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {industryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  labelStyle={{ color: '#F3F4F6' }}
                />
              </PieChart>
            </ResponsiveContainer>

            <div className="space-y-4">
              <h4 className="font-semibold text-white">Industry Insights</h4>
              {industryData.map((item, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
                  <span className="font-medium text-gray-300">{item.industry}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{item.count}</span>
                    <span className="text-sm text-gray-400">
                      ({clients.length > 0 ? ((item.count / clients.length) * 100).toFixed(1) : 0}%)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Activity Feed */}
        <div className="orbit-card p-6 mt-8">
          <h3 className="text-xl font-bold text-white mb-6">Recent Activity</h3>
          <div className="space-y-3 max-h-60 overflow-y-auto">
            {auditLogs.slice(0, 10).map(log => (
              <div key={log.id} className="flex items-start gap-3 p-3 bg-gray-800/30 rounded-lg">
                <div className="p-2 bg-orange-500/20 rounded-full">
                  <Calendar className="w-4 h-4 text-orange-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white">
                    {log.user_email} {log.action_type}d {log.entity_type}
                  </p>
                  <p className="text-xs text-gray-400">
                    {new Date(log.timestamp).toLocaleString()}
                  </p>
                  {log.additional_context && (
                    <p className="text-xs text-gray-500 mt-1">{log.additional_context}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
