import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Users, Building, Briefcase, Upload } from "lucide-react";

export default function UpdateUserType() {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    user_type: '',
    first_name: '',
    last_name: '',
    title: '',
    company: '',
    mobile: ''
  });
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      setFormData({
        user_type: currentUser.user_type || '',
        first_name: currentUser.first_name || '',
        last_name: currentUser.last_name || '',
        title: currentUser.title || '',
        company: currentUser.company || '',
        mobile: currentUser.mobile || ''
      });
    } catch (error) {
      console.error("Error loading user:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setUpdating(true);

    try {
      await User.updateMyUserData(formData);
      alert("Profile updated successfully!");
      window.location.reload(); // Refresh to update navigation
    } catch (error) {
      console.error("Error updating profile:", error);
      alert("Failed to update profile. Please try again.");
    } finally {
      setUpdating(false);
    }
  };

  const getUserTypeDescription = (type) => {
    switch (type) {
      case 'stratosfyre_admin':
        return {
          title: 'Stratosfyre Team Member',
          description: 'Full access to all platform features including client management, analytics, and system administration.',
          icon: Briefcase
        };
      case 'client':
        return {
          title: 'Client/Occupier',
          description: 'Access to view your property search progress, documents, and provide feedback on shortlisted properties.',
          icon: Building
        };
      case 'agent_landlord':
        return {
          title: 'Agent/Landlord',
          description: 'Submit property listings and manage your property submissions through the platform.',
          icon: Upload
        };
      default:
        return {
          title: 'Select User Type',
          description: 'Choose your role to access the appropriate platform features.',
          icon: Users
        };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  const userTypeInfo = getUserTypeDescription(formData.user_type);
  const Icon = userTypeInfo.icon;

  return (
    <div className="min-h-screen bg-gray-900 p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <div className="orbit-card p-8">
          <div className="text-center mb-8">
            <div className="bg-gradient-to-br from-orange-500 to-amber-500 p-4 rounded-full w-16 h-16 mx-auto mb-4">
              <Icon className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Complete Your Profile</h1>
            <p className="text-gray-400">Please provide your details to access the platform</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label className="text-gray-300 mb-2 block">User Type *</Label>
              <Select value={formData.user_type} onValueChange={(value) => setFormData(prev => ({...prev, user_type: value}))}>
                <SelectTrigger className="orbit-input text-white">
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="stratosfyre_admin">Stratosfyre Team Member</SelectItem>
                  <SelectItem value="client">Client/Occupier</SelectItem>
                  <SelectItem value="agent_landlord">Agent/Landlord</SelectItem>
                </SelectContent>
              </Select>
              
              {formData.user_type && (
                <div className="mt-4 p-4 bg-gray-800 rounded-lg">
                  <h3 className="font-semibold text-white mb-2">{userTypeInfo.title}</h3>
                  <p className="text-gray-400 text-sm">{userTypeInfo.description}</p>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">First Name *</Label>
                <Input
                  value={formData.first_name}
                  onChange={(e) => setFormData(prev => ({...prev, first_name: e.target.value}))}
                  className="orbit-input text-white"
                  required
                />
              </div>
              <div>
                <Label className="text-gray-300">Last Name *</Label>
                <Input
                  value={formData.last_name}
                  onChange={(e) => setFormData(prev => ({...prev, last_name: e.target.value}))}
                  className="orbit-input text-white"
                  required
                />
              </div>
            </div>

            <div>
              <Label className="text-gray-300">Job Title</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData(prev => ({...prev, title: e.target.value}))}
                className="orbit-input text-white"
                placeholder="e.g., Director, Agent, Consultant"
              />
            </div>

            <div>
              <Label className="text-gray-300">Company *</Label>
              <Input
                value={formData.company}
                onChange={(e) => setFormData(prev => ({...prev, company: e.target.value}))}
                className="orbit-input text-white"
                required
              />
            </div>

            <div>
              <Label className="text-gray-300">Mobile Phone</Label>
              <Input
                value={formData.mobile}
                onChange={(e) => setFormData(prev => ({...prev, mobile: e.target.value}))}
                className="orbit-input text-white"
                placeholder="+61 4XX XXX XXX"
              />
            </div>

            <Button 
              type="submit" 
              disabled={updating || !formData.user_type || !formData.first_name || !formData.last_name || !formData.company}
              className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold py-3 px-6 rounded-xl hover:from-orange-400 hover:to-amber-400 transition-all duration-200"
            >
              {updating ? 'Updating...' : 'Complete Setup'}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}