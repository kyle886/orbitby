
import React, { useState, useEffect } from "react";
import { Building as BuildingEntity } from "@/api/entities";
// Tenancy import is removed as the outline suggests a different data model for size filtering
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom"; // Changed from Link, useNavigate to just Link as useNavigate is no longer used for card clicks
import { createPageUrl } from "@/utils";
import { Loader2, MapPin } from "lucide-react"; // MapPin added, many other icons removed
// AddBuildingForm and BulkUploader components are removed as per the outline
import BuildingFilters from "../components/building-database/BuildingFilters";

// New imports as per the outline
import { VirtualList } from '@/components/ui/VirtualList';
import BuildingsMap from '@/components/map/BuildingsMap';
import { Card, CardContent, CardHeader } from "@/components/ui/card"; // Assuming these are from shadcn/ui/card
import MapCoverageGuard from '@/components/map/MapCoverageGuard';
import { backfillBuildingGeocodes } from '@/api/functions';

export default function BuildingDatabase() {
  const [buildings, setBuildings] = useState([]);
  const [filteredBuildings, setFilteredBuildings] = useState([]);
  const [loading, setLoading] = useState(true);
  // Filters state initialized as empty object to be populated by BuildingFilters
  const [filters, setFilters] = useState({});
  // New state to toggle map visibility - THIS IS REMOVED as map is always visible
  // const [showMap, setShowMap] = useState(true);
  const [geoCoverage, setGeoCoverage] = useState(null);

  // This useEffect replaces the original loadData function and its effect
  useEffect(() => {
    const fetchBuildings = async () => {
      setLoading(true);
      try {
        // Fetch only buildings, as tenancy data is no longer explicitly used for filtering/display in this version
        const buildingData = await BuildingEntity.list("-created_date");
        setBuildings(buildingData || []);
        
        // Calculate geo coverage
        const withGeo = (buildingData || []).filter(b => b.latitude && b.longitude).length;
        const totalBuildings = (buildingData || []).length;
        const pct = totalBuildings > 0 ? Math.round((withGeo / totalBuildings) * 100) : 0;
        setGeoCoverage({ pct, withGeo, total: totalBuildings });
      } catch (error) {
        console.error("Error loading buildings:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchBuildings();
  }, []);

  // This useEffect replaces the original filtering logic
  useEffect(() => {
    // Process buildings to include a size field for filtering, using building.total_size_sqm
    const buildingsWithProcessedSize = buildings.map(b => ({
      ...b,
      // 'processedSizeForFiltering' is a temporary field for this effect, directly using total_size_sqm
      // as the outline suggests removing tenancy-based available size calculation.
      processedSizeForFiltering: b.total_size_sqm || 0
    }));

    const filtered = buildingsWithProcessedSize.filter(item => {
      // Grade filter
      const gradeMatch = !filters.grade || filters.grade === 'all' || item.grade === filters.grade;

      // Size filter (min/max size are expected from the BuildingFilters component)
      const minSize = parseFloat(filters.minSize);
      const maxSize = parseFloat(filters.maxSize);
      const sizeMatch = (isNaN(minSize) || item.processedSizeForFiltering >= minSize) &&
                        (isNaN(maxSize) || item.processedSizeForFiltering <= maxSize);

      // Search term is removed in this version as per the outline
      return gradeMatch && sizeMatch;
    });

    setFilteredBuildings(filtered);
  }, [buildings, filters]); // Re-run when buildings or filters change

  // New renderRow function for the VirtualList component
  const renderRow = (building) => (
    <Link // Using Link from react-router-dom to navigate
      key={building.id}
      to={createPageUrl(`BuildingDetails?id=${building.id}`)}
      className="flex items-center p-3 hover:bg-gray-800/50 rounded-lg transition-colors"
    >
      <div className="w-1/3 text-white font-medium truncate">{building.name || 'N/A'}</div>
      <div className="w-1/3 text-gray-300 truncate">{building.address || 'N/A'}</div>
      <div className="w-1/6 text-gray-400">{building.grade || 'N/A'}</div>
      <div className="w-1/6 text-gray-400 text-right">{building.total_size_sqm ? building.total_size_sqm.toLocaleString() + ' m²' : 'N/A'}</div>
    </Link>
  );

  const handleBackfillGeo = async () => {
    try {
      const { data } = await backfillBuildingGeocodes({ provider: "nominatim", limit: 200 });
      alert(`Updated ${data.updated}/${data.scanned} building coordinates`);
      // Reload buildings to update coverage
      window.location.reload();
    } catch (error) {
      alert(`Error: ${error.message}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Building Database</h1>
            {/* Displaying count of filtered buildings */}
            <p className="text-gray-600 mt-1">{filteredBuildings.length} buildings matching filters</p>
          </div>
          {/* Button to toggle map view is REMOVED */}
        </div>

        <div className="space-y-6">
          <MapCoverageGuard
            pct={geoCoverage?.pct}
            onBackfill={handleBackfillGeo}
          >
            <BuildingsMap buildings={filteredBuildings} filters={filters} />
          </MapCoverageGuard>
          
          <BuildingFilters onFilterChange={setFilters} currentFilters={filters} />

          {/* Card component to wrap the VirtualList */}
          <Card className="orbit-card mt-6"> {/* The mt-6 is kept as per previous spacing behavior, though space-y-6 will add spacing above. */}
            <CardHeader>
              <div className="flex items-center p-3 text-xs text-gray-400 font-semibold">
                <div className="w-1/3">Name</div>
                <div className="w-1/3">Address</div>
                <div className="w-1/6">Grade</div>
                <div className="w-1/6 text-right">NLA</div> {/* NLA often stands for Net Lettable Area */}
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
                </div>
              ) : filteredBuildings.length > 0 ? (
                <VirtualList
                  rows={filteredBuildings}
                  rowHeight={60} // Each row is 60px tall
                  height={600}   // Total height of the scrollable list
                  render={renderRow} // Function to render each row
                />
              ) : (
                  // Message when no buildings are found after filtering
                  <div className="p-12 text-center">
                    <h3 className="text-xl font-medium text-white mb-2">No buildings found</h3>
                    <p className="text-gray-400 mb-4">Adjust your filters to see more results.</p>
                  </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
