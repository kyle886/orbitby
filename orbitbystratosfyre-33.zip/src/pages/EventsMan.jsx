
import React, { useState, useEffect, useCallback } from 'react';
import { Event } from '@/api/entities';
import { EventROI } from '@/api/entities';
import { BDEventAttendance } from '@/api/entities';
import { User } from '@/api/entities';
import { Document } from '@/api/entities';

import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Calendar, FileText, Users, Check, AlertTriangle, RefreshCw } from 'lucide-react';
import { runJob } from '@/components/utils/runJob';
import { EventActions } from '../components/actions/EventActions';

export default function EventsMan() {
  const [events, setEvents] = useState([]);
  const [rois, setRois] = useState([]);
  const [attendances, setAttendances] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [selectedUsers, setSelectedUsers] = useState(new Set());
  const { toast } = useToast();

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [eventData, roiData, attendanceData, userData] = await Promise.all([
      Event.list('-start_dt'),
      EventROI.list(),
      BDEventAttendance.list(),
      User.list()]
      );
      setEvents(eventData || []);
      setRois(roiData || []);
      setAttendances(attendanceData || []);
      setUsers((userData || []).filter((u) => u.user_type === 'stratosfyre_admin'));
    } catch (error) {
      console.error("Error loading event data:", error);
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to load event data.' });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleAssignClick = (event) => {
    setSelectedEvent(event);
    const currentAttendees = new Set(attendances.filter((a) => a.event_id === event.id).map((a) => a.user_id));
    setSelectedUsers(currentAttendees);
    setAssignDialogOpen(true);
  };

  const handleAssignAttendees = async () => {
    if (!selectedEvent) return;

    const currentAttendees = new Set(attendances.filter((a) => a.event_id === selectedEvent.id).map((a) => a.user_id));
    const usersToAssign = [...selectedUsers].filter((userId) => !currentAttendees.has(userId));
    const usersToUnassign = [...currentAttendees].filter((userId) => !selectedUsers.has(userId));

    try {
      if (usersToAssign.length > 0) {
        const assignmentPromises = usersToAssign.map((userId) => {
          const user = users.find((u) => u.id === userId);
          return BDEventAttendance.create({
            event_id: selectedEvent.id,
            user_id: user.id,
            user_email: user.email,
            decision: 'Pending'
          });
        });
        await Promise.all(assignmentPromises);
      }

      if (usersToUnassign.length > 0) {
        // Find existing attendance records for deletion.
        const unassignPromises = usersToUnassign.map((userId) => {
          const attendanceRecord = attendances.find((a) => a.event_id === selectedEvent.id && a.user_id === userId);
          return attendanceRecord ? BDEventAttendance.delete(attendanceRecord.id) : Promise.resolve();
        });
        await Promise.all(unassignPromises);
      }

      toast({ title: 'Assignments Updated', description: 'Team assignments for the event have been updated.' });
      setAssignDialogOpen(false);
      loadData(); // Reload data after assignment
    } catch (error) {
      console.error('Failed to update assignments', error);
      toast({ variant: 'destructive', title: 'Error', description: 'Could not update assignments.' });
    }
  };

  const handleMarkFeedback = async (attendanceRecord) => {
    if (!attendanceRecord) {
      toast({ title: 'All Feedback Submitted', description: 'Feedback has been submitted for all attendees of this event.', variant: 'default' });
      return;
    }
    try {
      await BDEventAttendance.update(attendanceRecord.id, { status: 'feedback_submitted' });
      toast({ title: 'Feedback Submitted', description: `Feedback for ${attendanceRecord.user_email} marked as submitted.` });
      loadData(); // Re-fetch data to update UI state
    } catch (e) {
      console.error("Failed to mark feedback", e);
      toast({ variant: 'destructive', title: 'Error', description: 'Could not submit feedback.' });
    }
  };

  const generateBrief = async (event) => {
    toast({ title: "Job Queued", description: `Generating brief for ${event.title}` });
    await runJob(
      `Generate Brief: ${event.title}`,
      async () => {
        // In a real app, this would generate and upload a PDF
        // For now, it creates a placeholder Document entry.
        await Document.create({
          event_id: event.id,
          document_name: `Pre-Event Brief - ${event.title}`,
          document_type: 'event_brief',
          document_topic: 'Events',
          file_url: 'https://example.com/placeholder.pdf', // Placeholder URL
          uploaded_by: 'system@orbit'
        });
        return { rows_affected: 1, notes: `Generated and attached brief for ${event.title}` };
      },
      { event_id: event.id }
    );
    loadData(); // Refresh data after job to potentially show new document
  };

  // New EventCard component as per outline
  const EventCard = ({ event }) => {
    // Note: 'rois' is accessible from the parent scope (EventsMan)
    const roi = rois.find((r) => r.event_id === event.id);

    // Using event.start_dt for calculations
    const daysUntil = event.start_dt ? Math.ceil((new Date(event.start_dt) - new Date()) / (1000 * 60 * 60 * 24)) : null;

    // Outline's specific logic for needsROICalculation
    const needsROICalculation = daysUntil !== null && daysUntil >= 0 && daysUntil < 7 && (!roi || !roi.sponsor_rec);

    return (
      <Card className="orbit-card flex flex-col">
        <CardHeader>
          <div className="flex justify-between items-start">
            {/* Using event.title */}
            <CardTitle className="text-blue-100 pr-4 font-semibold leading-none tracking-tight stratos-h3 truncate">{event.title}</CardTitle>
            {/* EventActions component will handle specific actions for this event */}
            {/* onUpdate and onAssign passed for EventActions to trigger parent functions like reloading data or opening dialogs */}
            <EventActions event={event} onUpdate={loadData} onAssign={handleAssignClick} />
          </div>
          {/* Using event.start_dt for date display */}
          <CardDescription>
            {event.start_dt ? new Date(event.start_dt).toLocaleDateString('en-US', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            }) : 'Date TBD'}
          </CardDescription>
        </CardHeader>
        <CardContent className="flex-grow">
          <div className="space-y-2 text-sm text-gray-300">
            {/* Using event.venue */}
            <p><span className="font-semibold text-gray-200">Venue:</span> {event.venue || 'N/A'}</p>
            {/* Using event.provider */}
            <p><span className="font-semibold text-gray-200">Organizer:</span> {event.provider || 'N/A'}</p>
            {/* Using event.city */}
            <p><span className="font-semibold text-gray-200">City:</span> {event.city || 'N/A'}</p>
            {/* Assuming ticket_cost_est_aud exists on Event entity */}
            <p><span className="font-semibold text-gray-200">Est. Cost:</span> AUD ${event.ticket_cost_est_aud?.toLocaleString() || 'N/A'}</p>
            {event.description &&
            <p><span className="font-semibold text-gray-200">Description:</span> {event.description}</p>
            }
          </div>
        </CardContent>
        <CardFooter className="flex flex-wrap gap-2">
          {/* ROI Badge */}
          {roi && roi.sponsor_rec &&
          <Badge
            className={
            roi.sponsor_rec === 'sponsor' ? 'bg-green-500/20 text-green-300 border-green-500/30' :
            roi.sponsor_rec === 'attend' ? 'bg-blue-500/20 text-blue-300 border-blue-500/30' :
            'bg-gray-500/20 text-gray-300 border-gray-500/30'
            }>

              {roi.sponsor_rec.toUpperCase()}
            </Badge>
          }
          
          {/* Days until event */}
          {daysUntil !== null && daysUntil >= 0 &&
          <Badge variant="outline" className="text-blue-200 px-2.5 py-0.5 text-xs font-semibold inline-flex items-center rounded-full border transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2">
              {daysUntil === 0 ? 'Today' :
            daysUntil === 1 ? 'Tomorrow' :
            `${daysUntil} days away`}
            </Badge>
          }
          
          {/* Needs ROI calculation */}
          {needsROICalculation &&
          <Badge variant="destructive" className="animate-pulse">
              Needs ROI
            </Badge>
          }
          
          {/* Event type */}
          {event.type &&
          <Badge variant="secondary" className="text-xs">
              {event.type}
            </Badge>
          }
          
          {/* Topic tags */}
          {event.topic_tags && event.topic_tags.slice(0, 2).map((tag, idx) =>
          <Badge key={idx} variant="outline" className="text-xs">
              #{tag}
            </Badge>
          )}
        </CardFooter>
      </Card>);

  };


  const combinedData = events.map((event) => ({
    event,
    roi: rois.find((r) => r.event_id === event.id),
    attendance: attendances.filter((a) => a.event_id === event.id)
  })).sort((a, b) => (b.roi?.roi_score || -Infinity) - (a.roi?.roi_score || -Infinity));

  if (loading) {
    return <div className="p-8 text-center"><Loader2 className="h-12 w-12 animate-spin text-orange-400 mx-auto" /></div>;
  }

  return (
    <div className="p-4 sm:p-6 md:p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Events Manager</h1>
        <p className="text-gray-300">ROI-driven event selection and team assignment.</p>
      </div>

      <Card className="orbit-card">
        <CardContent className="p-4">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {combinedData.map(({ event, roi, attendance }) =>
            <EventCard
              key={event.id}
              event={event} />

            )}
            </div>
        </CardContent>
      </Card>
      
      {/* Assign Dialog - kept as is, it's triggered by EventActions or elsewhere */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent className="orbit-card text-white">
          <DialogHeader>
            <DialogTitle>Assign Team for: {selectedEvent?.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-4 max-h-80 overflow-y-auto">
            {users.map((user) =>
            <div key={user.id} className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-700/50">
                <Checkbox
                id={`user-${user.id}`}
                checked={selectedUsers.has(user.id)}
                onCheckedChange={(checked) => {
                  setSelectedUsers((prev) => {
                    const newSet = new Set(prev);
                    if (checked) newSet.add(user.id);else
                    newSet.delete(user.id);
                    return newSet;
                  });
                }}
                className="border-2 border-orange-400 data-[state=checked]:bg-orange-500" />

                <Label htmlFor={`user-${user.id}`} className="text-sm font-medium text-gray-200">
                  {user.first_name} {user.last_name}
                </Label>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAssignAttendees} className="bg-orange-500 hover:bg-orange-600">Save Assignments</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

}