
import React, { useState, useEffect, useCallback } from 'react';
import { AIPropertyReview } from '@/api/entities';
import { PropertySubmission } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { Property } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Loader2, Sparkles, ChevronDown, ChevronRight, Building2, Play, RefreshCw } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';

const recommendationStyles = {
  shortlist: "bg-green-500/20 text-green-300 border-green-500/30",
  backup: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
  reject: "bg-red-500/20 text-red-300 border-red-500/30",
  pending: "bg-gray-500/20 text-gray-300 border-gray-500/30",
};

const ScoreGauge = ({ score }) => {
  const radius = 30;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  const color = score > 80 ? "#22c55e" : score > 60 ? "#f59e0b" : "#ef4444";

  return (
    <svg className="w-20 h-20" viewBox="0 0 70 70">
      <circle
        className="text-gray-700"
        strokeWidth="6"
        stroke="currentColor"
        fill="transparent"
        r={radius}
        cx="35"
        cy="35"
      />
      <circle
        strokeWidth="6"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        strokeLinecap="round"
        stroke="currentColor"
        style={{ color }}
        className="transition-all duration-500"
        fill="transparent"
        r={radius}
        cx="35"
        cy="35"
        transform="rotate(-90 35 35)"
      />
      <text
        x="50%"
        y="50%"
        textAnchor="middle"
        dy=".3em"
        className="text-lg font-bold fill-white"
      >
        {score}
      </text>
    </svg>
  );
};

const PropertyReviewCard = ({ review, submission }) => {
  const displayTitle = submission?.property_title || 'Unknown Property';
  const displayAddress = submission?.address || submission?.street_address || 'Address not available';
  const recommendation = review.ai_recommendation || 'pending';
  const matchScore = review.match_score || 0;

  return (
    <div className="orbit-card p-4 flex flex-col gap-3">
      <div className="flex justify-between items-start">
        <div>
          <h4 className="text-md font-bold text-white mb-1">{displayTitle}</h4>
          <p className="text-xs text-gray-400">{displayAddress}</p>
        </div>
        <Badge className={`${recommendationStyles[recommendation]} border text-xs`}>
          {recommendation.toUpperCase()}
        </Badge>
      </div>
      
      <div className="flex justify-between items-center">
        <div className="text-xs">
          <p className="text-gray-400">Size: {submission?.floor_area_sqm || 'N/A'} sqm</p>
          <p className="text-gray-400">Rate: ${submission?.rental_rate_sqm || 'N/A'}/sqm</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-white">{matchScore}</div>
          <div className="text-xs text-gray-400">Match Score</div>
        </div>
      </div>

      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline" className="w-full orbit-button border-gray-600 text-gray-300 hover:bg-gray-800 text-xs">
            View Full Analysis
          </Button>
        </DialogTrigger>
        <DialogContent className="orbit-card sm:max-w-2xl text-white bg-gray-800 border-gray-600">
          <DialogHeader>
            <DialogTitle className="text-2xl">{displayTitle}</DialogTitle>
            <DialogDescription className="text-gray-300">
              AI Analysis Details
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 max-h-[70vh] overflow-y-auto p-2">
            <div>
              <h4 className="font-bold text-lg text-white">AI Recommendation</h4>
              <Badge className={`${recommendationStyles[recommendation]} border text-sm`}>
                {recommendation.toUpperCase()}
              </Badge>
            </div>
            
            <div>
              <h4 className="font-bold text-lg text-white">Match Score: {matchScore}/100</h4>
              <div className="bg-gray-800/50 p-3 rounded space-y-1">
                <p className="text-gray-300">Location Score: {review.criteria_scores?.location_score || 0}/10</p>
                <p className="text-gray-300">Size Score: {review.criteria_scores?.size_score || 0}/10</p>
                <p className="text-gray-300">Budget Score: {review.criteria_scores?.budget_score || 0}/10</p>
                <p className="text-gray-300">Timing Score: {review.criteria_scores?.timing_score || 0}/10</p>
                <p className="text-gray-300">Amenities Score: {review.criteria_scores?.amenities_score || 0}/10</p>
              </div>
            </div>
            
            {review.ai_reasoning && (
              <div>
                <h4 className="font-bold text-lg text-white">AI Reasoning</h4>
                <p className="text-gray-300 bg-gray-800/50 p-3 rounded">{review.ai_reasoning}</p>
              </div>
            )}
            
            {review.deal_prediction?.market_positioning && (
              <div>
                <h4 className="font-bold text-lg text-white">Market Analysis</h4>
                <div className="bg-gray-800/50 p-3 rounded space-y-1">
                  <p className="text-gray-300">Positioning: {review.deal_prediction.market_positioning}</p>
                  <p className="text-gray-300">Confidence: {review.deal_prediction.confidence_level}</p>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const BriefReviewSection = ({ brief, reviews, submissions, expanded, onToggle }) => {
  const submissionMap = new Map(submissions.map(s => [s.id, s]));
  
  // Calculate recommendation counts
  const counts = {
    shortlist: reviews.filter(r => r.ai_recommendation === 'shortlist').length,
    backup: reviews.filter(r => r.ai_recommendation === 'backup').length,
    reject: reviews.filter(r => r.ai_recommendation === 'reject').length,
    pending: reviews.filter(r => !r.ai_recommendation || r.ai_recommendation === 'pending').length, // Count reviews with no recommendation or 'pending'
  };

  return (
    <div className="orbit-card mb-4">
      <div 
        className="p-6 cursor-pointer hover:bg-gray-800/30 transition-colors"
        onClick={() => onToggle(brief.id)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            {expanded ? <ChevronDown className="w-5 h-5 text-gray-400" /> : <ChevronRight className="w-5 h-5 text-gray-400" />}
            <div>
              <h3 className="text-xl font-bold text-white">{brief.company_name}</h3>
              <p className="text-sm text-gray-400">{brief.brief_reference_code || 'No Reference Code'}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {reviews.length === 0 ? (
              <Badge className="bg-gray-600/20 text-gray-300 border-gray-500/30">
                No Reviews Yet
              </Badge>
            ) : (
              <>
                {counts.shortlist > 0 && (
                  <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                    {counts.shortlist} Shortlist
                  </Badge>
                )}
                {counts.backup > 0 && (
                  <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                    {counts.backup} Backup
                  </Badge>
                )}
                {counts.reject > 0 && (
                  <Badge className="bg-red-500/20 text-red-300 border-red-500/30">
                    {counts.reject} Reject
                  </Badge>
                )}
                {counts.pending > 0 && (
                  <Badge className="bg-gray-500/20 text-gray-300 border-gray-500/30">
                    {counts.pending} Pending
                  </Badge>
                )}
              </>
            )}
            <div className="text-right">
              <div className="text-lg font-bold text-white">{reviews.length}</div>
              <div className="text-xs text-gray-400">Properties</div>
            </div>
          </div>
        </div>
      </div>
      
      {expanded && (
        <div className="px-6 pb-6">
          <div className="border-t border-gray-700 pt-6">
            {reviews.length === 0 ? (
              <div className="text-center py-8">
                <Building2 className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-white mb-2">No AI Reviews Yet</h4>
                <p className="text-gray-400 mb-4">
                  Click "Run AI Analysis" to generate property reviews for this brief.
                </p>
                <div className="text-sm text-gray-500">
                  <p>Brief: {brief.property_type} • {brief.min_floor_area} - {brief.max_floor_area || '∞'} sqm</p>
                  <p>Locations: {brief.preferred_suburbs?.join(', ') || 'Any'}</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {reviews
                  .sort((a, b) => (b.match_score || 0) - (a.match_score || 0)) // Sort by match score descending
                  .map(review => (
                    <PropertyReviewCard
                      key={review.id}
                      review={review}
                      submission={submissionMap.get(review.submission_id)}
                    />
                  ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default function AIPropertyReviews() {
  const [reviews, setReviews] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [briefs, setBriefs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedBriefs, setExpandedBriefs] = useState(new Set());
  const [runningAnalysis, setRunningAnalysis] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      setError(null);
      try {
        const [reviewData, submissionData, briefData] = await Promise.all([
          AIPropertyReview.list('-created_date').catch(err => {
            console.error('Failed to load AI reviews:', err);
            return [];
          }),
          PropertySubmission.list('-created_date').catch(err => {
            console.error('Failed to load submissions:', err);
            return [];
          }),
          TenantRequirement.list('-created_date').catch(err => {
            console.error('Failed to load briefs:', err);
            return [];
          }),
        ]);
        
        setReviews(reviewData || []);
        setSubmissions(submissionData || []);
        setBriefs(briefData || []);
        
      } catch (error) {
        console.error("Error loading AI reviews data:", error);
        setError(error.message || 'Failed to load data');
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const runManualAIAnalysis = useCallback(async () => {
    setRunningAnalysis(true);
    try {
      // Get all active briefs
      const activeBriefs = briefs.filter(brief => brief.status === 'active');
      
      if (activeBriefs.length === 0) {
        alert('No active briefs found for analysis.');
        setRunningAnalysis(false);
        return;
      }

      // Get all properties (not just submissions)
      const properties = await Property.list();
      
      if (properties.length === 0) {
        alert('No properties found in the database.');
        setRunningAnalysis(false);
        return;
      }

      // Get all existing submissions to check against
      const allSubmissions = await PropertySubmission.list();
      const existingSubmissionPairs = new Set(); // Stores strings like "normalizedAddress-briefId"
      allSubmissions.forEach(sub => {
        const normalizedAddress = sub.address?.toLowerCase().trim();
        if (normalizedAddress && sub.brief_ids && sub.brief_ids.length > 0) {
          sub.brief_ids.forEach(briefId => {
            existingSubmissionPairs.add(`${normalizedAddress}-${briefId}`);
          });
        }
      });

      let totalAnalyses = 0;
      let createdSubmissions = [];

      for (const property of properties) { // No slice(0, 20) limit for full analysis
        for (const brief of activeBriefs) {
          try {
            // Check if we already have a submission for this property-brief combination
            const submissionKey = `${property.address?.toLowerCase().trim()}-${brief.id}`;
            if (existingSubmissionPairs.has(submissionKey)) {
              console.log(`Skipping analysis for existing submission: Property "${property.title}", Brief "${brief.company_name}"`);
              continue; // Skip if already exists
            }

            // Create a PropertySubmission record for this property-brief combination
            const submissionData = {
              brief_ids: [brief.id],
              client_id: brief.client_id,
              property_title: property.title,
              street_address: property.address,
              address: property.address,
              suburb: property.suburb || 'Unknown',
              floor_area_sqm: property.floor_area_sqm,
              rental_rate_sqm: property.rental_rate_sqm,
              agent_name: property.agents?.[0]?.name || 'Unknown',
              agent_company: property.agents?.[0]?.company || 'Unknown',
              agent_email: property.agents?.[0]?.email || '',
              agent_phone: property.agents?.[0]?.phone || '',
              status: 'submitted',
              brief_match_status: 'partial_match'
            };

            const submission = await PropertySubmission.create(submissionData);
            createdSubmissions.push(submission);

            // Now analyze this submission against the brief
            const analysisPrompt = `Analyze this property against the client brief and provide a detailed assessment:

PROPERTY:
- Title: ${property.title}
- Address: ${property.address}
- Size: ${property.floor_area_sqm} sqm
- Rental Rate: $${property.rental_rate_sqm}/sqm/annum
- Description: ${property.description || 'No description available'}

CLIENT BRIEF:
- Company: ${brief.company_name}
- Required Size: ${brief.min_floor_area} - ${brief.max_floor_area || 'unlimited'} sqm
- Max Budget: $${brief.max_rental_total || 'not specified'}/annum total
- Preferred Suburbs: ${brief.preferred_suburbs?.join(', ') || 'not specified'}
- Required Amenities: ${brief.required_amenities?.join(', ') || 'none specified'}
- Building Grade Preference: ${brief.building_grade?.join(', ') || 'not specified'}

Please provide:
1. An overall match score (0-100)
2. Individual scores for location, size, budget, timing, and amenities (0-10 each)
3. Your recommendation (shortlist, reject, or backup)
4. Detailed reasoning for your recommendation
5. Market positioning assessment (Below Market, At Market, Above Market)
6. Confidence level (High, Medium, Low) based on the match score`;

            const aiAnalysis = await InvokeLLM({
              prompt: analysisPrompt,
              response_json_schema: {
                type: "object",
                properties: {
                  match_score: { type: "number", minimum: 0, maximum: 100 },
                  recommendation: { type: "string", enum: ["shortlist", "reject", "backup"] },
                  reasoning: { type: "string" },
                  location_score: { type: "number", minimum: 0, maximum: 10 },
                  size_score: { type: "number", minimum: 0, maximum: 10 },
                  budget_score: { type: "number", minimum: 0, maximum: 10 },
                  timing_score: { type: "number", minimum: 0, maximum: 10 },
                  amenities_score: { type: "number", minimum: 0, maximum: 10 },
                  market_positioning: { type: "string", enum: ["Below Market", "At Market", "Above Market"] },
                  confidence_level: { type: "string", enum: ["High", "Medium", "Low"] }
                },
                required: ["match_score", "recommendation", "reasoning", "location_score", "size_score", "budget_score", "timing_score", "amenities_score", "market_positioning", "confidence_level"]
              }
            });

            // Create AI review record
            await AIPropertyReview.create({
              submission_id: submission.id,
              brief_id: brief.id,
              ai_recommendation: aiAnalysis.recommendation,
              match_score: aiAnalysis.match_score,
              criteria_scores: {
                location_score: aiAnalysis.location_score,
                size_score: aiAnalysis.size_score,
                budget_score: aiAnalysis.budget_score,
                timing_score: aiAnalysis.timing_score,
                amenities_score: aiAnalysis.amenities_score
              },
              ai_reasoning: aiAnalysis.reasoning,
              deal_prediction: {
                market_positioning: aiAnalysis.market_positioning,
                confidence_level: aiAnalysis.confidence_level
              }
            });

            // Update the submission with AI results
            await PropertySubmission.update(submission.id, {
              brief_match_status: aiAnalysis.recommendation === 'shortlist' ? 'on_brief' :
                                  aiAnalysis.recommendation === 'backup' ? 'partial_match' : 'off_brief',
              match_score: aiAnalysis.match_score,
              status: aiAnalysis.recommendation === 'shortlist' ? 'shortlisted' : 'under_review',
              amplifyre_notes: `AI Analysis: ${(aiAnalysis.reasoning || '').substring(0, 200)}...`
            });

            totalAnalyses++;
          } catch (error) {
            console.error(`Failed to analyze property ${property.title} against brief ${brief.brief_reference_code}:`, error);
          }
        }
      }

      alert(`AI Analysis Complete! Created ${createdSubmissions.length} submissions and completed ${totalAnalyses} property-brief analyses.`);
      
      // Reload the page data
      window.location.reload();

    } catch (error) {
      console.error('Manual AI analysis failed:', error);
      alert('AI analysis failed: ' + error.message);
    } finally {
      setRunningAnalysis(false);
    }
  }, [briefs]);

  // Group reviews by brief - but show ALL active briefs, even those without reviews
  const reviewsByBrief = React.useMemo(() => {
    const grouped = new Map();
    
    // Initialize with all active briefs
    const activeBriefs = briefs.filter(brief => brief.status === 'active');
    activeBriefs.forEach(brief => {
      grouped.set(brief.id, []);
    });
    
    // Add reviews to the appropriate briefs
    reviews.forEach(review => {
      if (grouped.has(review.brief_id)) {
        grouped.get(review.brief_id).push(review);
      }
    });
    
    return grouped;
  }, [reviews, briefs]);

  // Get active briefs to display
  const activeBriefs = React.useMemo(() => {
    return briefs.filter(brief => brief.status === 'active');
  }, [briefs]);

  const handleToggleExpand = (briefId) => {
    setExpandedBriefs(prev => {
      const newSet = new Set(prev);
      if (newSet.has(briefId)) {
        newSet.delete(briefId);
      } else {
        newSet.add(briefId);
      }
      return newSet;
    });
  };

  if (loading) {
    return (
      <div className="p-8 text-center">
        <Loader2 className="h-12 w-12 animate-spin text-orange-400 mx-auto" />
        <p className="text-gray-400 mt-4">Loading AI reviews...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 text-center">
        <div className="orbit-card p-6 max-w-md mx-auto">
          <Building2 className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">Error Loading AI Reviews</h3>
          <p className="text-gray-400 text-sm">{error}</p>
          <Button 
            onClick={() => window.location.reload()} 
            className="mt-4 orbit-button-active"
          >
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Sparkles className="text-orange-400" />
            AI Property Reviews
          </h1>
          <p className="text-gray-300 mt-1">
            Automated AI analysis of properties against client briefs ({reviews.length} reviews across {activeBriefs.length} active briefs)
          </p>
        </div>
        <Button
          onClick={runManualAIAnalysis}
          disabled={runningAnalysis}
          className="mt-4 sm:mt-0 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white font-bold px-6 py-3 rounded-xl shadow-lg"
        >
          {runningAnalysis ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Running Analysis...
            </>
          ) : (
            <>
              <Play className="w-5 h-5 mr-2" />
              Run AI Analysis
            </>
          )}
        </Button>
      </div>
      
      {activeBriefs.length > 0 ? (
        <div className="space-y-4">
          {activeBriefs.map(brief => (
            <BriefReviewSection
              key={brief.id}
              brief={brief}
              reviews={reviewsByBrief.get(brief.id) || []}
              submissions={submissions}
              expanded={expandedBriefs.has(brief.id)}
              onToggle={handleToggleExpand}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-20">
          <div className="orbit-card p-8 max-w-lg mx-auto">
            <Sparkles className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No Active Briefs</h3>
            <p className="text-gray-400 mb-4">
              There are no active client briefs in the system to analyze properties against.
            </p>
            <p className="text-sm text-gray-500">
              Please create some active client briefs first, then return here to run AI property analysis.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
