import React, { useState, useEffect, useCallback } from 'react';
import { Client } from '@/api/entities';
import { ClientUpdate } from '@/api/entities';
import { Document } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { UploadFile } from '@/api/integrations';
import { 
  Plus, 
  Send, 
  Mail, 
  FileText, 
  Calendar, 
  User as UserIcon,
  Filter,
  Search,
  Paperclip,
  Download,
  Eye,
  Clock
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const CommunicationCard = ({ update, client }) => {
  const getUpdateTypeIcon = (type) => {
    const icons = {
      'progress_update': <Clock className="w-4 h-4" />,
      'new_submission': <FileText className="w-4 h-4" />,
      'meeting_scheduled': <Calendar className="w-4 h-4" />,
      'documents_uploaded': <Paperclip className="w-4 h-4" />,
      'negotiation_update': <Send className="w-4 h-4" />
    };
    return icons[type] || <Mail className="w-4 h-4" />;
  };

  const getUpdateTypeColor = (type) => {
    const colors = {
      'progress_update': 'bg-blue-500/20 text-blue-300',
      'new_submission': 'bg-green-500/20 text-green-300',
      'meeting_scheduled': 'bg-purple-500/20 text-purple-300',
      'documents_uploaded': 'bg-yellow-500/20 text-yellow-300',
      'negotiation_update': 'bg-orange-500/20 text-orange-300'
    };
    return colors[type] || 'bg-gray-500/20 text-gray-300';
  };

  return (
    <Card className="orbit-card">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${getUpdateTypeColor(update.update_type)}`}>
              {getUpdateTypeIcon(update.update_type)}
            </div>
            <div>
              <CardTitle className="text-lg text-white">{update.title}</CardTitle>
              <div className="flex items-center gap-2 text-sm text-gray-400 mt-1">
                <span>{client?.company_name}</span>
                <span>•</span>
                <span>{new Date(update.created_date).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
          <Badge className={getUpdateTypeColor(update.update_type)}>
            {update.update_type.replace('_', ' ')}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-gray-300 mb-4">{update.message}</p>
        
        {update.attachments && update.attachments.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-white">Attachments</h4>
            <div className="flex flex-wrap gap-2">
              {update.attachments.map((attachment, index) => (
                <Button key={index} variant="outline" size="sm" asChild>
                  <a href={attachment} target="_blank" rel="noopener noreferrer">
                    <Download className="w-4 h-4 mr-1" />
                    Document {index + 1}
                  </a>
                </Button>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-between items-center mt-4 pt-3 border-t border-gray-700">
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <UserIcon className="w-3 h-3" />
            <span>Stratosfyre Team</span>
          </div>
          <div className="flex items-center gap-1">
            <Eye className="w-4 h-4 text-gray-500" />
            <span className="text-xs text-gray-500">
              {update.is_client_visible ? 'Visible to client' : 'Internal only'}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const NewCommunicationDialog = ({ open, onOpenChange, onCommunicationCreated, clients }) => {
  const [formData, setFormData] = useState({
    client_id: '',
    update_type: 'progress_update',
    title: '',
    message: '',
    is_client_visible: true,
    attachments: []
  });
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await ClientUpdate.create(formData);
      onCommunicationCreated();
      onOpenChange(false);
      toast({ title: 'Communication Sent', description: 'Update has been sent to the client.' });
      
      // Reset form
      setFormData({
        client_id: '',
        update_type: 'progress_update',
        title: '',
        message: '',
        is_client_visible: true,
        attachments: []
      });
    } catch (error) {
      console.error('Error creating communication:', error);
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to send communication.' });
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploading(true);
    try {
      const uploadPromises = files.map(file => UploadFile({ file }));
      const uploadResults = await Promise.all(uploadPromises);
      const urls = uploadResults.map(result => result.file_url);
      
      setFormData({
        ...formData,
        attachments: [...formData.attachments, ...urls]
      });
      
      toast({ title: 'Files Uploaded', description: `${files.length} file(s) uploaded successfully.` });
    } catch (error) {
      console.error('Error uploading files:', error);
      toast({ variant: 'destructive', title: 'Upload Failed', description: 'Failed to upload files.' });
    } finally {
      setUploading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Send Client Communication</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Client *
              </label>
              <Select 
                value={formData.client_id} 
                onValueChange={(value) => setFormData({...formData, client_id: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select client" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map(client => (
                    <SelectItem key={client.id} value={client.id}>
                      {client.company_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Update Type *
              </label>
              <Select 
                value={formData.update_type} 
                onValueChange={(value) => setFormData({...formData, update_type: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="progress_update">Progress Update</SelectItem>
                  <SelectItem value="new_submission">New Submission</SelectItem>
                  <SelectItem value="meeting_scheduled">Meeting Scheduled</SelectItem>
                  <SelectItem value="documents_uploaded">Documents Uploaded</SelectItem>
                  <SelectItem value="negotiation_update">Negotiation Update</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Title *
            </label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              placeholder="Brief summary of the update"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Message *
            </label>
            <Textarea
              value={formData.message}
              onChange={(e) => setFormData({...formData, message: e.target.value})}
              placeholder="Detailed update message..."
              rows={4}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Attachments
            </label>
            <div className="space-y-2">
              <Input
                type="file"
                multiple
                onChange={handleFileUpload}
                disabled={uploading}
                accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png"
              />
              {formData.attachments.length > 0 && (
                <div className="text-sm text-gray-400">
                  {formData.attachments.length} file(s) attached
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="client_visible"
              checked={formData.is_client_visible}
              onChange={(e) => setFormData({...formData, is_client_visible: e.target.checked})}
              className="rounded border-gray-600"
            />
            <label htmlFor="client_visible" className="text-sm text-gray-300">
              Make this update visible to the client
            </label>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading || uploading}>
              {loading ? 'Sending...' : uploading ? 'Uploading...' : 'Send Update'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default function ClientCommunications() {
  const [communications, setCommunications] = useState([]);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClient, setSelectedClient] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [newCommDialogOpen, setNewCommDialogOpen] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [communicationsData, clientsData] = await Promise.all([
        ClientUpdate.list('-created_date'),
        Client.list()
      ]);
      
      setCommunications(communicationsData || []);
      setClients(clientsData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const filteredCommunications = communications.filter(comm => {
    const client = clients.find(c => c.id === comm.client_id);
    const matchesSearch = comm.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         comm.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         client?.company_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClient = selectedClient === 'all' || comm.client_id === selectedClient;
    const matchesType = selectedType === 'all' || comm.update_type === selectedType;
    
    return matchesSearch && matchesClient && matchesType;
  });

  const stats = {
    total: communications.length,
    thisWeek: communications.filter(c => {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return new Date(c.created_date) > weekAgo;
    }).length,
    clientVisible: communications.filter(c => c.is_client_visible).length,
    internal: communications.filter(c => !c.is_client_visible).length
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full p-8">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full animate-pulse bg-white/10 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading communications...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 md:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Client Communications</h1>
          <p className="text-gray-300">Manage client updates and communication history</p>
        </div>
        <Dialog open={newCommDialogOpen} onOpenChange={setNewCommDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Send Update
            </Button>
          </DialogTrigger>
          <NewCommunicationDialog 
            open={newCommDialogOpen} 
            onOpenChange={setNewCommDialogOpen}
            onCommunicationCreated={loadData}
            clients={clients}
          />
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Updates</p>
                <p className="text-2xl font-bold text-white">{stats.total}</p>
              </div>
              <Mail className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">This Week</p>
                <p className="text-2xl font-bold text-white">{stats.thisWeek}</p>
              </div>
              <Calendar className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Client Visible</p>
                <p className="text-2xl font-bold text-white">{stats.clientVisible}</p>
              </div>
              <Eye className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Internal Only</p>
                <p className="text-2xl font-bold text-white">{stats.internal}</p>
              </div>
              <UserIcon className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input
            placeholder="Search communications..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={selectedClient} onValueChange={setSelectedClient}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="All Clients" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Clients</SelectItem>
            {clients.map(client => (
              <SelectItem key={client.id} value={client.id}>
                {client.company_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="progress_update">Progress Update</SelectItem>
            <SelectItem value="new_submission">New Submission</SelectItem>
            <SelectItem value="meeting_scheduled">Meeting Scheduled</SelectItem>
            <SelectItem value="documents_uploaded">Documents Uploaded</SelectItem>
            <SelectItem value="negotiation_update">Negotiation Update</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Communications Feed */}
      <div className="space-y-6">
        {filteredCommunications.map(comm => (
          <CommunicationCard
            key={comm.id}
            update={comm}
            client={clients.find(c => c.id === comm.client_id)}
          />
        ))}
      </div>

      {filteredCommunications.length === 0 && (
        <div className="text-center py-12">
          <Mail className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No communications found</h3>
          <p className="text-gray-400 mb-4">
            {searchTerm || selectedClient !== 'all' || selectedType !== 'all' 
              ? 'Try adjusting your filters' 
              : 'Get started by sending your first client update'
            }
          </p>
          {!searchTerm && selectedClient === 'all' && selectedType === 'all' && (
            <Button onClick={() => setNewCommDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Send First Update
            </Button>
          )}
        </div>
      )}
    </div>
  );
}