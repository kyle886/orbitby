
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { TenantRequirement } from '@/api/entities';
import { PMTask } from '@/api/entities';
import { Client } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Loader2, Plus, Trash2, CalendarIcon, Wand2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { createPageUrl } from '@/utils';
import { format, addDays } from 'date-fns';
import { PRELIMINARY_MILESTONES } from '@/components/utils/pm/templates';

const MilestoneItem = ({ task, onUpdate, onRemove }) => (
  <div className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
    <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
      <Input 
        value={task.title} 
        onChange={(e) => onUpdate(task.id, 'title', e.target.value)} 
        className="orbit-input"
        placeholder="Milestone Name"
      />
      <Select value={task.stage} onValueChange={(val) => onUpdate(task.id, 'stage', val)}>
        <SelectTrigger className="orbit-input"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="design">Design</SelectItem>
          <SelectItem value="tender">Tender</SelectItem>
          <SelectItem value="construction">Construction</SelectItem>
          <SelectItem value="handover">Handover</SelectItem>
        </SelectContent>
      </Select>
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" className="orbit-input justify-start text-left font-normal">
            <CalendarIcon className="mr-2 h-4 w-4" />
            {task.start_dt ? format(new Date(task.start_dt), 'PPP') : 'Start Date'}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={task.start_dt ? new Date(task.start_dt) : undefined} onSelect={date => onUpdate(task.id, 'start_dt', date)} /></PopoverContent>
      </Popover>
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" className="orbit-input justify-start text-left font-normal">
            <CalendarIcon className="mr-2 h-4 w-4" />
            {task.end_dt ? format(new Date(task.end_dt), 'PPP') : 'End Date'}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={task.end_dt ? new Date(task.end_dt) : undefined} onSelect={date => onUpdate(task.id, 'end_dt', date)} /></PopoverContent>
      </Popover>
    </div>
    <Button variant="ghost" size="icon" onClick={() => onRemove(task.id)}>
      <Trash2 className="w-4 h-4 text-red-500" />
    </Button>
  </div>
);

export default function ProjectInitiation() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const briefIdToInitiate = searchParams.get('briefId');

  const [project, setProject] = useState({
    company_name: '',
    client_id: '',
    status: 'Discovery',
    project_phase: 'Initiation',
    completion_pct: 0,
    budget_aud: '',
    additional_notes: '',
    baseline_completion_date: null,
    forecast_completion_date: null,
    brief_reference_code: '', // Initialize brief_reference_code
  });
  const [tasks, setTasks] = useState([]);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        const clientsData = await Client.list();
        setClients(clientsData || []);

        if (briefIdToInitiate) {
          const brief = await TenantRequirement.get(briefIdToInitiate);
          setProject(prev => ({
            ...prev,
            ...brief,
            budget_aud: brief.budget_aud || '',
            baseline_completion_date: brief.baseline_completion_date ? new Date(brief.baseline_completion_date) : null,
            forecast_completion_date: brief.forecast_completion_date ? new Date(brief.forecast_completion_date) : null,
          }));
        }
      } catch (error) {
        toast({ variant: 'destructive', title: 'Error loading data', description: error.message });
      } finally {
        setLoading(false);
      }
    };
    loadInitialData();
  }, [briefIdToInitiate, toast]);
  
  const handleProjectChange = (field, value) => {
    setProject(prev => ({ ...prev, [field]: value }));
  };

  const handleClientChange = (clientId) => {
    const selectedClient = clients.find(c => c.id === clientId);
    if (selectedClient) {
        setProject(prev => ({
            ...prev,
            client_id: clientId,
            company_name: selectedClient.company_name
        }));
    }
  };

  const updateTask = (taskId, field, value) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, [field]: value } : t));
  };
  
  const addTask = () => {
    setTasks(prev => [...prev, { id: `new-${Date.now()}`, title: '', stage: 'design', start_dt: null, end_dt: null }]);
  };
  
  const removeTask = (taskId) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
  };

  const generateMilestones = () => {
    toast({ title: "Generating Milestones", description: "Populating with a standard project template." });
    let lastDate = new Date();
    const generatedTasks = PRELIMINARY_MILESTONES.map(milestone => {
        const startDate = addDays(lastDate, 2);
        const endDate = addDays(startDate, milestone.duration_days);
        lastDate = endDate;
        return {
            id: `new-${Date.now()}-${milestone.title.replace(/\s+/g, '')}`,
            title: milestone.title,
            stage: milestone.stage,
            start_dt: startDate,
            end_dt: endDate
        };
    });
    setTasks(generatedTasks);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!project.company_name || !project.client_id || !project.budget_aud) {
      toast({ variant: 'destructive', title: 'Validation Error', description: 'Please fill in Project Name, select a Client, and set a Budget.' });
      return;
    }
    setIsSubmitting(true);
    try {
      // --- Generate a unique project code ---
      let newProjectCode = project.brief_reference_code;
      if (!project.id) { // Only generate a code for new projects
        const allProjects = await TenantRequirement.list();
        const newProjectNumber = (allProjects?.length || 0) + 1;
        newProjectCode = `TEST-${String(newProjectNumber).padStart(3, '0')}`;
      }

      // Create or update the TenantRequirement record
      const projectData = {
          ...project,
          brief_reference_code: newProjectCode, // Assign the generated code
          budget_aud: parseFloat(project.budget_aud),
          property_type: project.property_type || 'office', // Ensure required fields have defaults
          min_floor_area: project.min_floor_area || 100,
          estimated_project_close_date: project.estimated_project_close_date || new Date().toISOString()
      };
      
      let savedProject;
      if (project.id) {
          await TenantRequirement.update(project.id, projectData);
          savedProject = { ...projectData };
      } else {
          savedProject = await TenantRequirement.create(projectData);
      }

      // Create PMTask records
      const taskPromises = tasks.map(task => PMTask.create({
        ...task,
        project_id: savedProject.id,
        start_dt: task.start_dt?.toISOString(),
        end_dt: task.end_dt?.toISOString()
      }));
      await Promise.all(taskPromises);

      toast({ title: 'Project Initiated', description: `Successfully saved project ${savedProject.company_name}.` });
      navigate(createPageUrl(`FitoutProject?id=${savedProject.id}`));

    } catch (error) {
      console.error("Failed to save project:", error);
      toast({ variant: 'destructive', title: 'Save Failed', description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-full p-8"><Loader2 className="w-12 h-12 animate-spin text-orange-400" /></div>;
  }

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-5xl mx-auto">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-white">Initiate Fitout Project</h1>
        <p className="text-gray-300">Capture the core scope, budget, and milestones to kick off the project.</p>
      </header>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card className="orbit-card">
          <CardHeader><CardTitle>1. Core Details</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="client-select">Client Company</Label>
              <Select onValueChange={handleClientChange} value={project.client_id} required>
                <SelectTrigger id="client-select" className="orbit-input"><SelectValue placeholder="Select a client..." /></SelectTrigger>
                <SelectContent>
                  {clients.map(c => <SelectItem key={c.id} value={c.id}>{c.company_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="project-name">Project Name / Reference</Label>
              <Input id="project-name" value={project.company_name} onChange={e => handleProjectChange('company_name', e.target.value)} className="orbit-input" placeholder="e.g., Acme Corp HQ Fitout" required />
            </div>
          </CardContent>
        </Card>

        <Card className="orbit-card">
          <CardHeader><CardTitle>2. Project Scope</CardTitle></CardHeader>
          <CardContent>
            <Label htmlFor="project-description">High-Level Project Description</Label>
            <Textarea
              id="project-description"
              value={project.additional_notes}
              onChange={e => handleProjectChange('additional_notes', e.target.value)}
              className="orbit-input min-h-[120px]"
              placeholder="Describe the overall objectives, key deliverables, and critical success factors for this fitout project..."
            />
          </CardContent>
        </Card>
        
        <Card className="orbit-card">
          <CardHeader><CardTitle>3. Budget & Dates</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <Label htmlFor="budget">Total Budget (AUD)</Label>
              <Input id="budget" type="number" value={project.budget_aud} onChange={e => handleProjectChange('budget_aud', e.target.value)} className="orbit-input" placeholder="e.g., 2500000" required />
            </div>
            <div className="space-y-2">
              <Label>Baseline Completion Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="orbit-input w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {project.baseline_completion_date ? format(project.baseline_completion_date, 'PPP') : 'Pick a date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={project.baseline_completion_date} onSelect={date => handleProjectChange('baseline_completion_date', date)} /></PopoverContent>
              </Popover>
            </div>
             <div className="space-y-2">
              <Label>Forecast Completion Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="orbit-input w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {project.forecast_completion_date ? format(project.forecast_completion_date, 'PPP') : 'Pick a date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={project.forecast_completion_date} onSelect={date => handleProjectChange('forecast_completion_date', date)} /></PopoverContent>
              </Popover>
            </div>
          </CardContent>
        </Card>

        <Card className="orbit-card">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>4. Initial Milestones</CardTitle>
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={generateMilestones}>
                  <Wand2 className="w-4 h-4 mr-2" />
                  Generate Template
                </Button>
                <Button type="button" onClick={addTask}><Plus className="w-4 h-4 mr-2" />Add Milestone</Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {tasks.length > 0 ? (
              tasks.map(task => <MilestoneItem key={task.id} task={task} onUpdate={updateTask} onRemove={removeTask} />)
            ) : (
              <div className="text-center py-8 text-gray-500">
                <p>No milestones added yet.</p>
                <p className="text-sm">Click "Add Milestone" to create one manually or "Generate Template" to start with a standard set.</p>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-end pt-4">
          <Button type="submit" variant="gradient" size="lg" disabled={isSubmitting}>
            {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : null}
            {project.id ? 'Update Project' : 'Initiate Project'}
          </Button>
        </div>
      </form>
    </div>
  );
}
