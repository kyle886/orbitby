
import React, { useState, useEffect, useCallback } from "react";
import { DocFolder } from "@/api/entities";
import { DocVersion } from "@/api/entities";
import { Document } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Loader2, Upload, FileText, Download, Eye, Plus, Folder, Search, ChevronsRight, Home, ArrowLeft } from "lucide-react";
import DocumentBinderModal from "@/components/doc/DocumentBinderModal";

// Helper function to calculate SHA-256 checksum
const getFileChecksum = async (file) => {
    const buffer = await file.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

const Breadcrumb = ({ path, onNavigate }) => (
    <div className="flex items-center gap-2 text-gray-400 mb-4">
        <button onClick={() => onNavigate(null)} className="hover:text-white">
            <Home className="w-4 h-4" />
        </button>
        {path.map((folder, index) => (
            <React.Fragment key={folder.id}>
                <ChevronsRight className="w-4 h-4" />
                {index === path.length - 1 ? (
                    <span className="font-semibold text-white">{folder.name}</span>
                ) : (
                    <button onClick={() => onNavigate(folder)} className="hover:text-white">
                        {folder.name}
                    </button>
                )}
            </React.Fragment>
        ))}
    </div>
);

const UploadDialog = ({ isOpen, onOpenChange, currentFolderId, onUploadComplete }) => {
    const [file, setFile] = useState(null);
    const [uploading, setUploading] = useState(false);
    const { toast } = useToast();
    const [user, setUser] = useState(null);

    useEffect(() => {
        User.me().then(setUser);
    }, []);

    const handleUpload = async () => {
        if (!file || !currentFolderId || !user) {
            toast({ variant: "destructive", title: "Missing data", description: "File and folder are required." });
            return;
        }

        setUploading(true);
        try {
            const checksum = await getFileChecksum(file);
            const dupes = await DocVersion.filter({ checksum: checksum, folder_id: currentFolderId });
            
            if ((dupes?.length ?? 0) > 0) {
                toast({
                  variant:"destructive",
                  title:"Duplicate file",
                  description:"This exact version already exists in this folder."
                });
                setUploading(false);
                return;
            }

            const { file_url } = await UploadFile({ file });

            const existingVersions = await DocVersion.filter({ folder_id: currentFolderId, name: file.name });
            const newVersionNumber = existingVersions.length > 0 ? Math.max(...existingVersions.map(v => v.version)) + 1 : 1;

            await DocVersion.create({
                folder_id: currentFolderId,
                name: file.name,
                version: newVersionNumber,
                file_url: file_url,
                checksum: checksum,
                uploaded_by: user.email,
                uploaded_at: new Date().toISOString()
            });

            toast({ title: "Upload Successful", description: `${file.name} (v${newVersionNumber}) uploaded.` });
            onUploadComplete();
            onOpenChange(false);
            setFile(null);
        } catch (error) {
            console.error("Upload failed:", error);
            toast({ variant: "destructive", title: "Upload Failed", description: error.message });
        } finally {
            setUploading(false);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="orbit-card text-white">
                <DialogHeader><DialogTitle className="text-white">Upload Document</DialogTitle></DialogHeader>
                <div className="py-4">
                    <Input type="file" onChange={(e) => setFile(e.target.files[0])} className="orbit-input" />
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleUpload} disabled={uploading || !file} className="orbit-button-active">
                        {uploading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                        Upload
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default function DocumentManagement() {
    const [folders, setFolders] = useState([]);
    const [versions, setVersions] = useState([]);
    const [currentFolder, setCurrentFolder] = useState(null);
    const [loading, setLoading] = useState(true);
    const [path, setPath] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [showUploadDialog, setShowUploadDialog] = useState(false);
    const [binderOpen, setBinderOpen] = useState(false);
    const [currentUser, setCurrentUser] = useState(null);
    const { toast } = useToast();

    useEffect(() => {
        User.me().then(setCurrentUser).catch(() => setCurrentUser(null));
    }, []);

    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const [allFolders, allVersions] = await Promise.all([
                DocFolder.list('-created_date'),
                DocVersion.list('-uploaded_at')
            ]);
            setFolders(allFolders || []);
            setVersions(allVersions || []);
        } catch (error) {
            console.error("Error loading documents:", error);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        loadData();
    }, [loadData]);
    
    const handleNavigate = (folder) => {
        setCurrentFolder(folder);
        if (folder === null) {
            setPath([]);
            return;
        }

        const newPath = [];
        let current = folder;
        while (current) {
            newPath.unshift(current);
            current = folders.find(f => f.id === current.parent_id);
        }
        setPath(newPath);
    };
    
    const getVisibleItems = () => {
        const parentId = currentFolder ? currentFolder.id : null;
        const childFolders = folders.filter(f => f.parent_id === parentId);
        const childVersions = versions.filter(v => v.folder_id === parentId);

        if (!searchTerm) {
            return { folders: childFolders, versions: childVersions };
        }

        const lowerSearchTerm = searchTerm.toLowerCase();
        
        const filteredFolders = folders.filter(f => 
            f.name.toLowerCase().includes(lowerSearchTerm) ||
            (f.tags && f.tags.some(tag => tag.toLowerCase().includes(lowerSearchTerm)))
        );

        const filteredVersions = versions.filter(v =>
            v.name.toLowerCase().includes(lowerSearchTerm)
        );

        return { folders: filteredFolders, versions: filteredVersions };
    };

    const { folders: visibleFolders, versions: visibleVersions } = getVisibleItems();

    if (loading) {
        return <div className="p-8 text-center"><Loader2 className="h-8 w-8 mx-auto animate-spin text-orange-400" /></div>;
    }

    return (
        <div className="p-4 sm:p-8 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center mb-6">
                    <div>
                        <h1 className="text-3xl font-bold text-white mb-2">Document Hub</h1>
                        <p className="text-gray-300">Browse, search, and manage all project documents.</p>
                    </div>
                    <div className="flex gap-2">
                        <Button
                            onClick={() => setBinderOpen(true)}
                            disabled={!currentFolder}
                            variant="outline"
                            className="orbit-button border-gray-600 text-gray-300"
                        >
                            <FileText className="w-4 h-4 mr-2" />
                            Create Binder
                        </Button>
                        <Button
                            onClick={() => setShowUploadDialog(true)}
                            disabled={!currentFolder}
                            className="orbit-button-active"
                        >
                            <Plus className="w-5 h-5 mr-2" />
                            Upload to Current Folder
                        </Button>
                    </div>
                </div>

                <div className="relative mb-6">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                        type="text"
                        placeholder="Search by name or tag..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="orbit-input pl-10"
                    />
                </div>

                {currentFolder && <Breadcrumb path={path} onNavigate={handleNavigate} />}

                <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                    {visibleFolders.map(folder => (
                        <Card key={folder.id} className="orbit-card-hover cursor-pointer" onClick={() => handleNavigate(folder)}>
                            <CardContent className="p-4 flex items-center gap-4">
                                <Folder className="w-8 h-8 text-orange-400" />
                                <div>
                                    <p className="font-medium text-white truncate">{folder.name}</p>
                                    {folder.tags && (
                                        <div className="flex flex-wrap gap-1 mt-1">
                                            {folder.tags.map(tag => <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>)}
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                    {visibleVersions.map(version => (
                        <Card key={version.id} className="orbit-card">
                            <CardContent className="p-4 flex flex-col justify-between h-full">
                                <div>
                                    <div className="flex items-start gap-3">
                                        <FileText className="w-6 h-6 text-gray-400 mt-1" />
                                        <div>
                                            <p className="font-medium text-white break-all">{version.name}</p>
                                            <Badge variant="outline" className="text-xs mt-1">v{version.version}</Badge>
                                        </div>
                                    </div>
                                    <p className="text-xs text-gray-500 mt-2">
                                        by {version.uploaded_by} on {new Date(version.uploaded_at).toLocaleDateString()}
                                    </p>
                                </div>
                                <div className="flex gap-2 mt-4">
                                    <Button size="icon" variant="ghost" onClick={() => window.open(version.file_url, '_blank')}><Eye className="w-4 h-4" /></Button>
                                    <Button size="icon" variant="ghost" asChild>
                                        <a href={version.file_url} download={version.name}><Download className="w-4 h-4" /></a>
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {visibleFolders.length === 0 && visibleVersions.length === 0 && (
                    <div className="text-center py-16">
                        <p className="text-gray-400">
                            {searchTerm ? 'No results found.' : 'This folder is empty.'}
                        </p>
                    </div>
                )}

                <UploadDialog
                    isOpen={showUploadDialog}
                    onOpenChange={setShowUploadDialog}
                    currentFolderId={currentFolder?.id}
                    onUploadComplete={loadData}
                />

                <DocumentBinderModal
                    open={binderOpen}
                    onOpenChange={setBinderOpen}
                    context={{
                        folder_id: currentFolder?.id,
                        engagement_id: currentFolder?.engagement_id,
                        user_email: currentUser?.email
                    }}
                />
            </div>
        </div>
    );
}
