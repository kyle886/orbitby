import React, { useState, useEffect } from "react";
import { ClientUpdate } from "@/api/entities";
import { User } from "@/api/entities";
import { Client } from "@/api/entities";
import { Loader2, Calendar, FileText, Building2, AlertCircle, MessageSquare, Bell, CheckCircle } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function ClientUpdates() {
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [client, setClient] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const clients = await Client.list();
      const currentClient = clients.find(c => c.primary_contact_email === currentUser.email);
      setClient(currentClient);

      if (currentClient) {
        const updateData = await ClientUpdate.filter({ 
          client_id: currentClient.id, 
          is_client_visible: true 
        }, "-created_date");
        setUpdates(updateData || []);
      }
    } catch (error) {
      console.error("Error loading updates:", error);
    } finally {
      setLoading(false);
    }
  };

  const getUpdateIcon = (type) => {
    const icons = {
      progress_update: <Bell className="w-5 h-5 text-blue-400" />,
      new_submission: <Building2 className="w-5 h-5 text-green-400" />,
      meeting_scheduled: <Calendar className="w-5 h-5 text-yellow-400" />,
      documents_uploaded: <FileText className="w-5 h-5 text-purple-400" />,
      negotiation_update: <CheckCircle className="w-5 h-5 text-orange-400" />
    };
    return icons[type] || <MessageSquare className="w-5 h-5 text-gray-400" />;
  };

  const getUpdateColor = (type) => {
    const colors = {
      progress_update: "bg-blue-500/20 text-blue-300",
      new_submission: "bg-green-500/20 text-green-300",
      meeting_scheduled: "bg-yellow-500/20 text-yellow-300",
      documents_uploaded: "bg-purple-500/20 text-purple-300",
      negotiation_update: "bg-orange-500/20 text-orange-300"
    };
    return colors[type] || "bg-gray-500/20 text-gray-300";
  };

  const formatUpdateType = (type) => {
    return type.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  if (loading) {
    return (
      <div className="p-8 text-center">
        <Loader2 className="h-12 w-12 animate-spin text-orange-400 mx-auto" />
      </div>
    );
  }

  if (!client) {
    return (
      <div className="p-8 min-h-screen">
        <div className="max-w-4xl mx-auto">
          <Card className="orbit-card">
            <CardContent className="p-12 text-center">
              <Building2 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-white mb-2">Access Not Available</h3>
              <p className="text-gray-400">
                Your client profile is being set up. Please contact your Stratosfyre consultant for access.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-8 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Project Updates</h1>
          <p className="text-gray-300">Stay informed about your property search progress and important milestones.</p>
        </div>

        {updates.length > 0 ? (
          <div className="space-y-6">
            {updates.map((update, index) => (
              <Card key={update.id} className="orbit-card">
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="p-3 bg-gray-800/50 rounded-full mb-2">
                        {getUpdateIcon(update.update_type)}
                      </div>
                      {index < updates.length - 1 && (
                        <div className="flex-grow w-px bg-gray-700/50 mt-2 min-h-[2rem]"></div>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="font-bold text-white text-lg mb-1">{update.title}</h3>
                          <div className="flex items-center gap-2">
                            <Badge className={getUpdateColor(update.update_type)}>
                              {formatUpdateType(update.update_type)}
                            </Badge>
                            <span className="text-xs text-gray-500">
                              {new Date(update.created_date).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray-800/30 p-4 rounded-lg">
                        <p className="text-gray-300 whitespace-pre-wrap">{update.message}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="orbit-card">
            <CardContent className="p-12 text-center">
              <MessageSquare className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-white mb-2">No Updates Yet</h3>
              <p className="text-gray-400">
                Your project timeline and updates will appear here as we progress with your property search.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Footer Info */}
        <div className="mt-12 text-center">
          <div className="bg-gray-800/30 p-6 rounded-lg">
            <h4 className="text-white font-medium mb-2">Stay Connected</h4>
            <p className="text-gray-400 text-sm">
              You'll receive email notifications for important updates. 
              All communications and documents are also available in your ORBIT portal.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}