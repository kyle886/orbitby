import React, { useState } from "react";
import { Client } from "@/api/entities";
import { TenantRequirement } from "@/api/entities";
import { PropertySubmission } from "@/api/entities";
import { InspectionItinerary } from "@/api/entities";
import { InspectionFeedback } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

const clientsData = [
    {"id": "client-completed", "company_name": "Innovate Inc.", "industry": "software", "primary_contact_name": "Jane Doe", "primary_contact_email": "jane@innovate.com", "amplifyre_consultant": "consultant@stratosfyre.com", "engagement_status": "completed"},
    {"id": "client-inspecting", "company_name": "QuantumLeap Tech", "industry": "deep_tech", "primary_contact_name": "John Smith", "primary_contact_email": "john@quantumleap.com", "amplifyre_consultant": "consultant@stratosfyre.com", "engagement_status": "search_active"}
];

const briefsData = [
    {"id": "brief-completed", "client_id": "client-completed", "company_name": "Innovate Inc.", "property_type": "office", "min_floor_area": 400, "max_floor_area": 500, "preferred_suburbs": ["City Core"], "status": "completed", "brief_reference_code": "AMB-INVCMP"},
    {"id": "brief-inspecting", "client_id": "client-inspecting", "company_name": "QuantumLeap Tech", "property_type": "office", "min_floor_area": 800, "max_floor_area": 1000, "preferred_suburbs": ["Western Corridor"], "status": "active", "brief_reference_code": "AMB-QLTGO"}
];

const submissionsData = [
    {"id": "sub-completed-1", "client_id": "client-completed", "brief_id": "brief-completed", "property_title": "The Glass Tower", "address": "123 Main Street", "floor_area_sqm": 450, "rental_rate_sqm": 850, "brief_match_status": "on_brief", "status": "selected", "agent_name": "Agent Alice", "agent_email": "alice@agency.com"},
    {"id": "sub-completed-2", "client_id": "client-completed", "brief_id": "brief-completed", "property_title": "Cityscape Hub", "address": "456 Market Avenue", "floor_area_sqm": 480, "rental_rate_sqm": 820, "brief_match_status": "on_brief", "status": "shortlisted", "agent_name": "Agent Bob", "agent_email": "bob@agency.com"},
    {"id": "sub-inspecting-1", "client_id": "client-inspecting", "brief_id": "brief-inspecting", "property_title": "Tech Park One", "address": "789 Innovation Drive", "floor_area_sqm": 900, "rental_rate_sqm": 650, "brief_match_status": "on_brief", "status": "shortlisted", "agent_name": "Agent Charlie", "agent_email": "charlie@agency.com"},
    {"id": "sub-inspecting-2", "client_id": "client-inspecting", "brief_id": "brief-inspecting", "property_title": "The Quantum Building", "address": "101 Discovery Lane", "floor_area_sqm": 950, "rental_rate_sqm": 700, "brief_match_status": "on_brief", "status": "shortlisted", "agent_name": "Agent Dana", "agent_email": "dana@agency.com"},
    {"id": "sub-inspecting-3", "client_id": "client-inspecting", "brief_id": "brief-inspecting", "property_title": "Westside Labs", "address": "210 Research Road", "floor_area_sqm": 850, "rental_rate_sqm": 620, "brief_match_status": "partial_match", "status": "shortlisted", "agent_name": "Agent Eve", "agent_email": "eve@agency.com"}
];

const itinerariesData = [
    {"id": "itinerary-completed", "client_id": "client-completed", "brief_id": "brief-completed", "itinerary_name": "Innovate Inc. Final Inspection", "inspection_date": "2023-10-15", "properties": [{"property_submission_id": "sub-completed-1", "order": 1, "estimated_time": "30 minutes"}, {"property_submission_id": "sub-completed-2", "order": 2, "estimated_time": "30 minutes"}], "status": "completed"}
];

const feedbackData = [
    {"itinerary_id": "itinerary-completed", "property_submission_id": "sub-completed-1", "attendee_name": "Jane Doe", "attendee_email": "jane@innovate.com", "overall_rating": 5, "notes": "Loved the natural light and the view. Perfect fit for our team."},
    {"itinerary_id": "itinerary-completed", "property_submission_id": "sub-completed-2", "attendee_name": "Jane Doe", "attendee_email": "jane@innovate.com", "overall_rating": 3, "notes": "Layout felt a bit awkward and the lobby was dated."}
];

export default function SeedData() {
    const [loading, setLoading] = useState(false);
    const [status, setStatus] = useState("");

    const handleSeedData = async () => {
        setLoading(true);
        setStatus("Seeding data... This may take a moment.");
        try {
            // Using bulkCreate for each entity
            await Client.bulkCreate(clientsData);
            setStatus("Clients seeded...");
            await TenantRequirement.bulkCreate(briefsData);
            setStatus("Briefs seeded...");
            await PropertySubmission.bulkCreate(submissionsData);
            setStatus("Submissions seeded...");
            await InspectionItinerary.bulkCreate(itinerariesData);
            setStatus("Itineraries seeded...");
            await InspectionFeedback.bulkCreate(feedbackData);
            setStatus("Feedback seeded...");

            setStatus("All sample data has been seeded successfully!");
        } catch (error) {
            console.error("Error seeding data:", error);
            setStatus(`An error occurred: ${error.message}. Some data may not have been seeded.`);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="p-8">
            <div className="max-w-2xl mx-auto orbit-card p-8">
                <h1 className="text-2xl font-bold text-white mb-4">Seed Sample Data</h1>
                <p className="text-gray-300 mb-6">
                    Click the button below to populate the application with sample client projects.
                    This will create data for one completed project and one project ready for inspections.
                </p>
                <Button onClick={handleSeedData} disabled={loading} className="orbit-button">
                    {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    {loading ? "Seeding..." : "Seed Project Data"}
                </Button>
                {status && <p className="mt-4 text-sm text-gray-400">{status}</p>}
            </div>
        </div>
    );
}