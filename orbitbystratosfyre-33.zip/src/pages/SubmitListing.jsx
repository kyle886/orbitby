
import React, { useState, useEffect } from "react";
import { Building } from "@/api/entities";
import { Tenancy } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X, Plus, Upload, Building2, Loader2, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useToast } from "@/components/ui/use-toast";

export default function SubmitListing() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    // Building fields
    name: "",
    address: "",
    type: "Office",
    grade: "Not Rated",
    owner: "",
    nabers_rating: "",
    image_url: "",
    latitude: null,
    longitude: null,
    // Tenancy fields
    floor: "",
    suite: "",
    size_sqm: "",
    status: "Vacant",
    availability_date: "",
    rental_rate_sqm: "",
    // Agent/other info
    agent_name: "",
    agent_company: ""
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);

  // Removed the redirect logic that was preventing stratosfyre_admin users from accessing this page

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleAddressChange = async (address) => {
    handleInputChange('address', address);
    if (address && address.length > 15) {
      try {
        const geoData = await InvokeLLM({
          prompt: `Get the latitude and longitude for this address: ${address}`,
          add_context_from_internet: true,
          response_json_schema: {
            type: "object",
            properties: { latitude: { type: "number" }, longitude: { type: "number" } },
            required: ["latitude", "longitude"]
          }
        });
        if (geoData.latitude && geoData.longitude) {
          setFormData((prev) => ({ ...prev, latitude: geoData.latitude, longitude: geoData.longitude }));
        }
      } catch (geoError) {
        console.error("Geocoding failed, submitting without coordinates:", geoError);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Step 1: Find or Create the Building
      let building;
      const existingBuildings = await Building.filter({ address: formData.address });

      if (existingBuildings.length > 0) {
        building = existingBuildings[0];
      } else {
        // Generate canonical name for deduplication
        const canonicalName = (formData.name || formData.address)
          .toLowerCase()
          .replace(/[^\w\s]/g, '') // Remove special characters
          .replace(/\s+/g, '_')     // Replace spaces with underscores
          .trim();

        const buildingData = {
          canonical_name: canonicalName,
          name: formData.name || formData.address,
          address: formData.address,
          type: formData.type,
          grade: formData.grade,
          owner: formData.owner,
          nabers_rating: formData.nabers_rating,
          image_url: formData.image_url,
          latitude: formData.latitude,
          longitude: formData.longitude,
          leasing_agencies: formData.agent_company ? [formData.agent_company] : []
        };
        building = await Building.create(buildingData);
      }

      // Step 2: Create the Tenancy record
      const tenancyData = {
        building_id: building.id,
        floor: formData.floor,
        suite: formData.suite,
        size_sqm: parseFloat(formData.size_sqm),
        status: formData.status,
        availability_date: formData.availability_date || null,
        rental_rate_sqm: parseFloat(formData.rental_rate_sqm)
      };

      await Tenancy.create(tenancyData);

      setSubmissionSuccess(true);

    } catch (error) {
      console.error("Error submitting listing:", error);
      toast({
        variant: "destructive",
        title: "Submission Failed",
        description: "There was an error saving the listing. Please check the details and try again."
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submissionSuccess) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="orbit-card w-full max-w-lg text-center p-6 sm:p-8">
           <div className="mx-auto bg-green-900/50 border border-green-700 rounded-full p-3 w-fit">
             <CheckCircle className="w-8 sm:w-10 h-8 sm:h-10 text-green-400" />
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white mt-6 mb-2">Listing Submitted</h2>
          <p className="text-sm sm:text-base text-gray-300 mb-6">
            The property has been successfully added to the Building Database.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button onClick={() => setSubmissionSuccess(false)} className="orbit-button bg-amber-500 hover:bg-amber-600 text-white min-h-[44px]">Submit Another</Button>
            <Button onClick={() => navigate(createPageUrl("Listings"))} variant="outline" className="orbit-button text-gray-300 border-gray-600 hover:bg-gray-800 hover:text-white min-h-[44px]">View Listings</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 md:p-8 bg-gray-900 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">Submit New Listing</h1>
          <p className="text-gray-300">Add a new commercial tenancy to the database. This will create or update a building record and add a new tenancy.</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            {/* Building Details */}
            <Card className="orbit-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Building2 className="w-5 h-5" />
                  Building Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Building Name</Label>
                    <Input className="orbit-input" placeholder="e.g., Aurora Place" value={formData.name} onChange={(e) => handleInputChange('name', e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-gray-300">Full Address *</Label>
                    <Input className="orbit-input" placeholder="123 Example Street, Sydney NSW 2000" value={formData.address} onChange={(e) => handleAddressChange(e.target.value)} required />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Property Type *</Label>
                    <Select value={formData.type} onValueChange={(value) => handleInputChange('type', value)}>
                      <SelectTrigger className="orbit-input"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Office">Office</SelectItem>
                        <SelectItem value="Industrial">Industrial</SelectItem>
                        <SelectItem value="Mixed-Use">Mixed-Use</SelectItem>
                        <SelectItem value="Retail">Retail</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {formData.type === 'Office' &&
                  <div>
                      <Label className="text-gray-300">Building Grade</Label>
                      <Select value={formData.grade} onValueChange={(value) => handleInputChange('grade', value)}>
                        <SelectTrigger className="orbit-input"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Premium">Premium</SelectItem>
                          <SelectItem value="A">A</SelectItem>
                          <SelectItem value="B">B</SelectItem>
                          <SelectItem value="C">C</SelectItem>
                          <SelectItem value="Not Rated">Not Rated</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  }
                </div>
                 <div>
                    <Label className="text-gray-300">Image URL</Label>
                    <Input className="orbit-input" placeholder="https://example.com/image.png" value={formData.image_url} onChange={(e) => handleInputChange('image_url', e.target.value)} />
                  </div>
              </CardContent>
            </Card>

            {/* Tenancy Details */}
            <Card className="orbit-card">
              <CardHeader>
                <CardTitle className="text-white">Tenancy Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <Label className="text-gray-300">Floor</Label>
                        <Input className="orbit-input" placeholder="e.g., Level 15" value={formData.floor} onChange={(e) => handleInputChange('floor', e.target.value)} />
                    </div>
                    <div>
                        <Label className="text-gray-300">Suite</Label>
                        <Input className="orbit-input" placeholder="e.g., 15.01" value={formData.suite} onChange={(e) => handleInputChange('suite', e.target.value)} />
                    </div>
                    <div>
                        <Label className="text-gray-300">Size (sqm) *</Label>
                        <Input className="orbit-input" type="number" placeholder="500" value={formData.size_sqm} onChange={(e) => handleInputChange('size_sqm', e.target.value)} required />
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">Status *</Label>
                     <Select value={formData.status} onValueChange={(value) => handleInputChange('status', value)}>
                      <SelectTrigger className="orbit-input"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Vacant">Vacant</SelectItem>
                        <SelectItem value="Occupied">Occupied</SelectItem>
                        <SelectItem value="Under Offer">Under Offer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {formData.status === 'Vacant' &&
                  <>
                       <div>
                        <Label className="text-gray-300">Availability Date</Label>
                        <Input className="orbit-input" type="date" value={formData.availability_date} onChange={(e) => handleInputChange('availability_date', e.target.value)} />
                      </div>
                      <div>
                        <Label className="text-gray-300">Asking Rent ($/sqm) *</Label>
                        <Input className="orbit-input" type="number" placeholder="850" value={formData.rental_rate_sqm} onChange={(e) => handleInputChange('rental_rate_sqm', e.target.value)} required />
                      </div>
                    </>
                  }
                </div>
              </CardContent>
            </Card>

            {/* Agent Information */}
            <Card className="orbit-card">
              <CardHeader>
                <CardTitle className="text-white">Source Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Agent Name</Label>
                    <Input className="orbit-input" placeholder="John Smith" value={formData.agent_name} onChange={(e) => handleInputChange('agent_name', e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-gray-300">Agent Company</Label>
                    <Input className="orbit-input" placeholder="ABC Real Estate" value={formData.agent_company} onChange={(e) => handleInputChange('agent_company', e.target.value)} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex flex-col sm:flex-row justify-end gap-4">
              <Button type="button" variant="outline" className="orbit-button text-gray-300 border-gray-600 hover:bg-gray-800 hover:text-white" onClick={() => navigate(createPageUrl("Listings"))}>Cancel</Button>
              <Button type="submit" disabled={isSubmitting} className="orbit-button bg-gradient-to-r from-orange-500 to-amber-500 text-white border-0 px-8">
                {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Submit Listing
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
