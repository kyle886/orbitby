import React from "react";
import { format } from "date-fns";
import { useBDDashboard } from "@/components/state/useBDDashboard";
import { ZSummary, ZTimeseries, ZFunnel, ZLeaders } from "@/components/bd/validate";
import MetricTile from "@/components/bd/MetricTile";
import ChartCard from "@/components/bd/ChartCard";
import FunnelBar from "@/components/bd/FunnelBar";
import Leaderboard from "@/components/bd/Leaderboard";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  CartesianGrid, 
  BarChart, 
  Bar 
} from "recharts";

function RangePicker() {
  const { range, setRange, load } = useBDDashboard();
  
  return (
    <div className="flex items-center gap-2">
      {(["7d", "14d", "30d", "90d"]).map(r => (
        <button 
          key={r} 
          className={`px-3 py-1 rounded-lg text-sm border transition-all ${
            range === r 
              ? "border-white/40 bg-white/10 text-white" 
              : "border-white/10 bg-white/5 text-gray-300 hover:bg-white/8"
          }`} 
          onClick={() => { setRange(r); load(); }}
        >
          {r.toUpperCase()}
        </button>
      ))}
    </div>
  );
}

function formatDate(d) { 
  return format(new Date(d), "d MMM"); 
}

export default function BusinessDevelopmentDashboard() {
  const { summary, timeseries, funnel, leaders, activity, load } = useBDDashboard();
  const [ready, setReady] = React.useState(false);

  React.useEffect(() => { 
    load().then(() => setReady(true)); 
  }, [load]);

  const sum = ZSummary.safeParse(summary).success ? summary : { totals: {} };
  const ts = ZTimeseries.safeParse(timeseries).success ? timeseries : { series: [] };
  const fun = ZFunnel.safeParse(funnel).success ? funnel : { stages: [] };
  const lead = ZLeaders.safeParse(leaders).success ? leaders : { topSources: [], topSuburbs: [], topBrokers: [] };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Business Development Dashboard</h1>
          <p className="text-gray-400">Track BD performance and pipeline metrics</p>
        </div>
        <RangePicker />
      </div>

      {/* KPI Row */}
      <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricTile label="New Leads" value={(sum.totals.leadsNew || 0).toLocaleString()} />
        <MetricTile label="New Listings" value={(sum.totals.listingsNew || 0).toLocaleString()} />
        <MetricTile label="Agent Scans" value={(sum.totals.scansRun || 0).toLocaleString()} />
        <MetricTile label="Errors" value={(sum.totals.errors || 0).toLocaleString()} />
        <MetricTile label="Active Brokers" value={(sum.totals.activeBrokers || 0).toLocaleString()} />
        <MetricTile 
          label="Median Response" 
          value={sum.totals.responseMedianMs ? `${Math.round(sum.totals.responseMedianMs)} ms` : "—"} 
        />
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-3 gap-3">
        <ChartCard title="Daily Flow (Listings vs Scans)">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={ts.series}>
              <defs>
                <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ea580c" stopOpacity={0.6} />
                  <stop offset="95%" stopColor="#ea580c" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.6} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeOpacity={0.1} />
              <XAxis dataKey="date" tickFormatter={formatDate} stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid rgba(255,255,255,0.1)', 
                  borderRadius: '8px' 
                }}
              />
              <Area 
                type="monotone" 
                dataKey="listings" 
                name="Listings" 
                stroke="#ea580c"
                strokeWidth={2} 
                fillOpacity={0.4} 
                fill="url(#g1)" 
              />
              <Area 
                type="monotone" 
                dataKey="scans" 
                name="Scans" 
                stroke="#06b6d4"
                strokeWidth={2} 
                fillOpacity={0.4} 
                fill="url(#g2)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Daily Leads">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={ts.series}>
              <CartesianGrid strokeOpacity={0.1} />
              <XAxis dataKey="date" tickFormatter={formatDate} stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid rgba(255,255,255,0.1)', 
                  borderRadius: '8px' 
                }}
              />
              <Line 
                type="monotone" 
                dataKey="leads" 
                stroke="#10b981"
                strokeWidth={2} 
                dot={false} 
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Daily Errors">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ts.series}>
              <CartesianGrid strokeOpacity={0.1} />
              <XAxis dataKey="date" tickFormatter={formatDate} stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid rgba(255,255,255,0.1)', 
                  borderRadius: '8px' 
                }}
              />
              <Bar dataKey="errors" fill="#ef4444" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Funnel + Leaderboards */}
      <div className="grid lg:grid-cols-2 gap-3">
        <FunnelBar stages={(fun.stages || []).map((s) => ({ label: s.label, value: s.value }))} />
        <div className="grid sm:grid-cols-2 gap-3">
          <Leaderboard title="Top Sources" items={lead.topSources} />
          <Leaderboard title="Top Suburbs" items={lead.topSuburbs} />
          <Leaderboard title="Top Brokers" items={lead.topBrokers} />
        </div>
      </div>

      {/* Activity */}
      <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
        <div className="text-sm font-medium mb-2 text-white">Recent Activity</div>
        <div className="space-y-1">
          {(activity?.items || []).map((a) => (
            <div key={a.id} className="text-sm flex items-center justify-between border-b border-white/5 py-1">
              <div className="truncate">
                <span className={a.ok ? "text-emerald-400" : "text-red-400"}>●</span> 
                <span className="text-gray-300 ml-2">{a.label || a.key}</span>
              </div>
              <div className="text-xs text-neutral-500">
                {format(new Date(a.at), "d MMM HH:mm")} {a.user ? `• ${a.user}` : ""}
              </div>
            </div>
          ))}
          {!activity?.items?.length && (
            <div className="text-xs text-neutral-500">No recent activity</div>
          )}
        </div>
      </div>
    </div>
  );
}