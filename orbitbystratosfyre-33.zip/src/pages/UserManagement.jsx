
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { UserInvitation } from "@/api/entities";
import { SendEmail } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Users, Mail, Trash2, UserCheck, UserX, Loader2, Shield, Edit } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";

const submarketOptions = [
"City Core", "Western Corridor", "Midtown", "Southern CBD",
"Sydney Fringe", "North Sydney/North Shore", "Parramatta",
"Melbourne CBD", "Melbourne Fringe", "Brisbane CBD", "Perth CBD"];


const SubmarketEditor = ({ user, onUpdate }) => {
  // Initialize with user's current submarkets or an empty array if undefined
  const [selected, setSelected] = useState(user.submarkets_of_operation || []);

  const handleUpdate = async () => {
    try {
      await User.update(user.id, { submarkets_of_operation: selected });
      onUpdate(user.id, selected);
      // Optionally, close popover or show success message
    } catch (error) {
      console.error("Failed to update submarkets:", error);
      alert("Error updating submarkets.");
    }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="text-white border-gray-600 hover:bg-gray-800">
          <Edit className="w-4 h-4 mr-2" />
          Edit Submarkets
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-0 orbit-card">
        <div className="p-4">
          <h4 className="font-medium text-white mb-2">Edit Submarkets</h4>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {submarketOptions.map((market) =>
            <div key={market} className="flex items-center space-x-2">
                <Checkbox
                id={`${user.id}-${market}`}
                checked={selected.includes(market)}
                onCheckedChange={(checked) => {
                  setSelected((prev) => checked ? [...prev, market] : prev.filter((m) => m !== market));
                }}
                className="border-2 border-orange-400 data-[state=checked]:bg-orange-500" />

                <Label htmlFor={`${user.id}-${market}`} className="text-sm text-gray-300">{market}</Label>
              </div>
            )}
          </div>
          <Button onClick={handleUpdate} className="w-full mt-4 bg-orange-500 hover:bg-orange-600 text-white">
            Save Changes
          </Button>
        </div>
      </PopoverContent>
    </Popover>);

};


export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [invitations, setInvitations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  const [inviteForm, setInviteForm] = useState({
    invited_email: "",
    user_type: "",
    permission_level: "user",
    personal_message: ""
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [currentUserData, usersData, invitationsData] = await Promise.all([
      User.me(),
      User.list("-created_date"),
      UserInvitation.list("-created_date")]
      );

      setCurrentUser(currentUserData);
      setUsers(Array.isArray(usersData) ? usersData : []);
      setInvitations(Array.isArray(invitationsData) ? invitationsData : []);
    } catch (error) {
      console.error("Error loading user data:", error);
      setUsers([]);
      setInvitations([]);
    } finally {
      setLoading(false);
    }
  };

  const sendInvitation = async (e) => {
    e.preventDefault();

    try {
      // Generate invitation token
      const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);

      // Create invitation record
      const invitation = await UserInvitation.create({
        ...inviteForm,
        invited_by: currentUser.email,
        invitation_token: token,
        expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days
      });

      const roleNames = {
        stratosfyre_admin: "Stratosfyre Team Member",
        client: "Client/Occupier",
        agent_landlord: "Agent/Landlord"
      };

      const permissionNames = {
        admin: "Administrator",
        user: "Standard User",
        readonly: "Read-Only Access"
      };

      // Create signup URL
      const baseUrl = window.location.origin;
      const signupUrl = `${baseUrl}/UserSignup?token=${token}`;

      const emailBody = `Hello,

You've been invited to join ORBIT by Stratosfyre as a ${roleNames[inviteForm.user_type]} with ${permissionNames[inviteForm.permission_level]} permissions.

${inviteForm.personal_message ? `Personal message from ${currentUser.first_name} ${currentUser.last_name}:\n"${inviteForm.personal_message}"\n\n` : ''}

To complete your registration, please click the link below:

${signupUrl}

This invitation will expire in 7 days.

If you have any questions, please contact your Stratosfyre consultant.

Best regards,
The Stratosfyre Team`;

      await SendEmail({
        to: inviteForm.invited_email,
        subject: "Invitation to join ORBIT by Stratosfyre",
        body: emailBody,
        from_name: "Stratosfyre ORBIT"
      });

      // Reset form and close dialog
      setInviteForm({ invited_email: "", user_type: "", permission_level: "user", personal_message: "" });
      setShowInviteDialog(false);
      loadData();

      alert("Invitation sent successfully! The user will receive an email with a signup link.");

    } catch (error) {
      console.error("Error sending invitation:", error);
      alert("Failed to send invitation. Please try again.");
    }
  };

  const updateUserPermissions = async (userId, permission_level) => {
    try {
      await User.update(userId, { permission_level });
      setUsers((prev) => (prev || []).map((u) => u.id === userId ? { ...u, permission_level } : u));
    } catch (error) {
      console.error("Error updating user permissions:", error);
      alert("Failed to update user permissions.");
    }
  };

  const handleSubmarketUpdate = (userId, submarkets) => {
    setUsers((prev) => (prev || []).map((u) => u.id === userId ? { ...u, submarkets_of_operation: submarkets } : u));
  };

  const handleDeactivate = async (userId) => {
    try {
      await User.update(userId, { is_active: false });
      setUsers((prev) => (prev || []).map((u) => u.id === userId ? { ...u, is_active: false } : u));
    } catch (error) {
      console.error("Error deactivating user:", error);
      alert("Failed to deactivate user.");
    }
  };

  const handleReactivate = async (userId) => {
    try {
      await User.update(userId, { is_active: true });
      setUsers((prev) => (prev || []).map((u) => u.id === userId ? { ...u, is_active: true } : u));
    } catch (error) {
      console.error("Error reactivating user:", error);
      alert("Failed to reactivate user.");
    }
  };

  const deleteInvitation = async (invitationId) => {
    if (window.confirm("Are you sure you want to delete this invitation?")) {
      try {
        await UserInvitation.delete(invitationId);
        setInvitations((prev) => (prev || []).filter((i) => i.id !== invitationId));
      } catch (error) {
        console.error("Error deleting invitation:", error);
        alert("Failed to delete invitation.");
      }
    }
  };

  const getUserTypeBadge = (userType) => {
    const styles = {
      stratosfyre_admin: "bg-orange-600 text-white",
      client: "bg-blue-600 text-white",
      agent_landlord: "bg-purple-600 text-white"
    };

    const labels = {
      stratosfyre_admin: "Stratosfyre Team",
      client: "Client",
      agent_landlord: "Agent/Landlord"
    };

    return (
      <div className={`px-3 py-1 rounded-full text-xs font-bold ${styles[userType] || 'bg-gray-600 text-white'}`}>
        {labels[userType] || 'Unknown'}
      </div>);

  };

  const getPermissionBadge = (permissionLevel) => {
    const styles = {
      admin: "bg-red-600 text-white",
      user: "bg-gray-600 text-white",
      readonly: "bg-yellow-600 text-white"
    };

    const labels = {
      admin: "Admin",
      user: "User",
      readonly: "Read-Only"
    };

    return (
      <div className={`px-2 py-1 rounded text-xs font-bold ${styles[permissionLevel] || 'bg-gray-600 text-white'}`}>
        {labels[permissionLevel] || 'User'}
      </div>);

  };

  if (loading) {
    return (
      <div className="p-8 min-h-screen">
        <div className="max-w-6xl mx-auto">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-orange-400 mx-auto" />
          </div>
        </div>
      </div>);

  }

  const usersArray = Array.isArray(users) ? users : [];
  const invitationsArray = Array.isArray(invitations) ? invitations : [];

  return (
    <div className="p-4 sm:p-6 lg:p-8 min-h-screen">
      <div className="max-w-full mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">User Management</h1>
            <p className="text-gray-300">Manage access and permissions for all platform users</p>
          </div>
          
          <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
            <DialogTrigger asChild>
              <Button className="bg-orange-500 hover:bg-orange-600 text-white font-medium px-6 py-3">
                <Plus className="w-5 h-5 mr-2" />
                Invite User
              </Button>
            </DialogTrigger>
            <DialogContent className="orbit-card text-white">
              <DialogHeader>
                <DialogTitle>Invite New User</DialogTitle>
              </DialogHeader>
              <form onSubmit={sendInvitation} className="space-y-4">
                <div>
                  <Label className="text-gray-300">Email Address *</Label>
                  <Input
                    type="email"
                    value={inviteForm.invited_email}
                    onChange={(e) => setInviteForm((prev) => ({ ...prev, invited_email: e.target.value }))}
                    className="orbit-input text-white"
                    required />

                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">User Type *</Label>
                    <Select
                      value={inviteForm.user_type}
                      onValueChange={(value) => setInviteForm((prev) => ({ ...prev, user_type: value }))}>

                      <SelectTrigger className="orbit-input text-white">
                        <SelectValue placeholder="Select user type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="stratosfyre_admin">Stratosfyre Team Member</SelectItem>
                        <SelectItem value="client">Client/Occupier</SelectItem>
                        <SelectItem value="agent_landlord">Agent/Landlord</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-gray-300">Permission Level *</Label>
                    <Select
                      value={inviteForm.permission_level}
                      onValueChange={(value) => setInviteForm((prev) => ({ ...prev, permission_level: value }))}>

                      <SelectTrigger className="orbit-input text-white">
                        <SelectValue placeholder="Select permission" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">Administrator</SelectItem>
                        <SelectItem value="user">Standard User</SelectItem>
                        <SelectItem value="readonly">Read-Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label className="text-gray-300">Personal Message (Optional)</Label>
                  <Textarea
                    value={inviteForm.personal_message}
                    onChange={(e) => setInviteForm((prev) => ({ ...prev, personal_message: e.target.value }))}
                    className="orbit-input h-20 text-white"
                    placeholder="Add a personal note to the invitation..." />

                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setShowInviteDialog(false)} className="text-white border-gray-600 hover:bg-gray-800">
                    Cancel
                  </Button>
                  <Button type="submit" className="bg-orange-500 hover:bg-orange-600 text-white font-medium">
                    Send Invitation
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Active Users */}
        <div className="orbit-card p-0 mt-8">
          <div className="p-6 border-b border-gray-700">
            <h3 className="text-xl font-bold text-white">Active Users</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-800 border-b border-gray-700">
                <tr>
                  <th className="text-left font-bold p-4 text-white">Name</th>
                  <th className="text-left font-bold p-4 text-white">Email</th>
                  <th className="text-left font-bold p-4 text-white">Company</th>
                  <th className="text-left font-bold p-4 text-white">Type</th>
                  <th className="text-left font-bold p-4 text-white">Permissions</th>
                  <th className="text-left font-bold p-4 text-white">Submarkets</th>
                  <th className="text-center font-bold p-4 text-white">Status</th>
                  <th className="text-right font-bold p-4 text-white">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {usersArray.map((user) =>
                <tr key={user.id} className="text-white hover:bg-gray-800/50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{user.first_name} {user.last_name}</p>
                        <p className="text-sm text-gray-400">{user.title}</p>
                      </div>
                    </td>
                    <td className="p-4 text-gray-300">{user.email}</td>
                    <td className="p-4 text-gray-300">{user.company}</td>
                    <td className="p-4">{getUserTypeBadge(user.user_type)}</td>
                    <td className="text-slate-950 p-4">
                      <Select
                      value={user.permission_level || 'user'}
                      onValueChange={(value) => updateUserPermissions(user.id, value)}
                      disabled={user.permission_level === 'admin'}>

                        <SelectTrigger className="w-24 h-8 text-xs border-gray-600">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="admin">Admin</SelectItem>
                          <SelectItem value="user">User</SelectItem>
                          <SelectItem value="readonly">Read-Only</SelectItem>
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="p-4 text-gray-300">
                      {user.user_type === 'agent_landlord' ?
                    <SubmarketEditor user={user} onUpdate={handleSubmarketUpdate} /> :
                    'N/A'}
                    </td>
                    <td className="p-4 text-center">
                      <div className={`px-3 py-1 rounded-full text-xs font-bold ${
                    user.is_active ? 'bg-green-600 text-green-100' : 'bg-red-600 text-red-100'}`
                    }>
                        {user.is_active ? 'Active' : 'Inactive'}
                      </div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-right">
                      {user.is_active ?
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-red-900/50 text-red-300 border-red-700 hover:bg-red-900"
                      onClick={() => handleDeactivate(user.id)}
                      disabled={user.permission_level === 'admin'}>

                          Deactivate
                        </Button> :

                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-green-900/50 text-green-300 border-green-700 hover:bg-green-900"
                      onClick={() => handleReactivate(user.id)}
                      disabled={user.permission_level === 'admin'}>

                          Reactivate
                        </Button>
                    }
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pending Invitations */}
        <div className="orbit-card">
          <div className="p-6 border-b border-gray-700">
            <h3 className="text-xl font-bold text-white">Pending Invitations</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-800 border-b border-gray-700">
                <tr>
                  <th className="text-left font-bold p-4 text-white">Email</th>
                  <th className="text-left font-bold p-4 text-white">Type</th>
                  <th className="text-left font-bold p-4 text-white">Permissions</th>
                  <th className="text-left font-bold p-4 text-white">Invited By</th>
                  <th className="text-left font-bold p-4 text-white">Sent Date</th>
                  <th className="text-left font-bold p-4 text-white">Status</th>
                  <th className="text-right font-bold p-4 text-white">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {invitationsArray.map((invitation) =>
                <tr key={invitation.id} className="text-white hover:bg-gray-800/50">
                    <td className="p-4 font-medium">{invitation.invited_email}</td>
                    <td className="p-4">{getUserTypeBadge(invitation.user_type)}</td>
                    <td className="p-4">{getPermissionBadge(invitation.permission_level)}</td>
                    <td className="p-4 text-gray-300">{invitation.invited_by}</td>
                    <td className="p-4 text-gray-300">
                      {new Date(invitation.created_date).toLocaleDateString()}
                    </td>
                    <td className="p-4">
                      <div className={`px-3 py-1 rounded-full text-xs font-bold ${
                    invitation.status === 'pending' ? 'bg-yellow-600 text-yellow-100' :
                    invitation.status === 'accepted' ? 'bg-green-600 text-green-100' :
                    'bg-red-600 text-red-100'}`
                    }>
                        {(invitation.status || 'pending').toUpperCase()}
                      </div>
                    </td>
                    <td className="p-4 text-right">
                      <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteInvitation(invitation.id)}
                      className="text-red-400 border-red-600 hover:bg-red-900">

                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            {invitationsArray.length === 0 &&
            <div className="text-center p-8 text-gray-400">
                <Mail className="w-12 h-12 mx-auto mb-3 text-gray-600" />
                <p>No pending invitations</p>
              </div>
            }
          </div>
        </div>
      </div>
    </div>);

}