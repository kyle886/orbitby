
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { UnitsBar } from '@/components/ui/UnitsBar';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import PageHeader from '@/components/ui/PageHeader';
import KPIChip from '@/components/ui/KPIChip';
import KPICard from '@/components/ui/KPICard';
import Sparkline from '@/components/charts/Sparkline';
import PipelinePanel from '@/components/command/PipelinePanel';
import { Sparkles, Play, Database, RefreshCw, BarChart, FileText, Target as TargetIcon, AlertTriangle, Calendar, Users, Building, TrendingUp, Zap, MapPin, Brain, Activity, BarChart3, Briefcase, ChevronRight, Compass } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Target as TargetEntity } from '@/api/entities';
import { Event } from '@/api/entities';
import { EventROI } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { Building as BuildingEntity } from '@/api/entities';
import { Company } from '@/api/entities';
import { Pitch } from '@/api/entities';
import { runJob } from '@/components/utils/runJob';
import { useToast } from '@/components/ui/use-toast';
import { mapEngagements, mapBD } from '@/components/utils/pipeline/fromEntities';

const TargetRow = ({ target, rank, onPin, onUnpin, company }) =>
  <div className="grid grid-cols-[28px_1fr_80px_80px_60px_40px_minmax(60px,1fr)_32px] items-center gap-2 h-11 px-3 rounded-lg transition-colors duration-150 group hover:bg-gray-800">
    <div className="text-gray-400 font-semibold text-xs">#{String(rank).padStart(2, '0')}</div>
    <div className="text-gray-100 font-semibold text-sm truncate">{company?.name || 'Unknown Company'}</div>
    <div className="bg-orange-900/30 text-orange-200 px-2 py-0.5 rounded-full font-semibold text-xs text-center min-w-[48px]">
      {target.priority_score}%
    </div>
    <div className="text-cyan-400 font-semibold text-xs">High</div>
    <div className="text-xs text-gray-500">2d ago</div>
    <div className="text-xs font-medium text-gray-400">JD</div>
    <div className="h-1.5 rounded-full bg-gray-800 overflow-hidden">
      <div
        className="h-full rounded-full"
        style={{ width: `${target.priority_score || 0}%`, background: 'linear-gradient(90deg, #FFB36B, #F15A2B)' }}>
      </div>
    </div>
    <div className="opacity-0 group-hover:opacity-100 transition-opacity flex justify-end">
      <Button
        size="sm"
        variant="ghost"
        onClick={target.pinned ? () => onUnpin(target.id) : () => onPin(target.id)}
        className="h-6 w-6 p-0">
        📌
      </Button>
    </div>
  </div>;


const EventTile = ({ event, roi }) => {
  const daysUntil = event.start_dt ? Math.ceil((new Date(event.start_dt) - new Date()) / (1000 * 60 * 60 * 24)) : null;

  return (
    <div className="flex justify-between items-center bg-gray-800 p-3 rounded-md hover:bg-gray-700 transition-colors">
      <div>
        <h4 className="text-sm font-medium text-white truncate">{event.title}</h4>
        <div className="text-xs text-gray-400">
          {daysUntil !== null && daysUntil >= 0 && (
            <Badge variant="outline" className="text-xs mr-1">
              {daysUntil === 0 ? 'Today' : daysUntil === 1 ? 'Tomorrow' : `${daysUntil} days`}
            </Badge>
          )}
          {roi && (
            <Badge variant={roi.sponsor_rec === 'sponsor' ? 'default' : roi.sponsor_rec === 'attend' ? 'secondary' : 'outline'} className="text-xs">
              {roi.sponsor_rec?.toUpperCase()}
            </Badge>
          )}
        </div>
      </div>
      <div className="flex-shrink-0 ml-4">
        <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white p-1 h-auto">
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
};

const QuickActionButton = ({ Icon, label, actionKey, onClick }) => (
  <Button
    variant="ghost"
    className="flex flex-col items-center justify-center h-20 w-full text-center group transition-colors duration-150 rounded-lg hover:bg-gray-800"
    onClick={() => onClick(actionKey)}
  >
    <Icon className="w-6 h-6 text-orange-400 mb-1 group-hover:text-orange-300" />
    <span className="text-xs text-gray-300 font-medium group-hover:text-white">{label}</span>
  </Button>
);

const EngagementRow = ({ engagement }) => (
  <div className="flex items-center justify-between py-3 px-3 hover:bg-gray-800/50 rounded-md">
    <div>
      <h3 className="text-sm font-medium text-white">{engagement.company_name || 'Unknown Client'}</h3>
      <div className="text-xs text-gray-400">Next Action: {engagement.next_action || 'Review next steps'}</div>
    </div>
    <div className="flex items-center gap-2">
      <Badge variant="outline" className="text-xs">{engagement.state}</Badge>
      <Button variant="ghost" size="sm" className="p-1 h-auto text-gray-400 hover:text-white">
        <ChevronRight className="w-4 h-4" />
      </Button>
    </div>
  </div>
);

const DataQualityRow = ({ issue, onFix }) => (
  <div className="flex items-center justify-between py-3 px-3 hover:bg-gray-800/50 rounded-md">
    <p className="text-sm text-gray-300">{issue.message}</p>
    <Button
      variant="ghost"
      size="sm"
      className="text-yellow-400 hover:text-yellow-300 p-1 h-auto"
      onClick={onFix}
    >
      Fix
    </Button>
  </div>
);


export default function CommandCentre() {
  const [dashboardData, setDashboardData] = useState({
    targets: [],
    events: [],
    engagements: [],
    dataQualityIssues: [],
    companies: [],
    engagedPipeline: [],
    bdPipeline: [],
    loading: true,
    error: null
  });
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setDashboardData((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const [targets, events, eventROIs, engagements, buildings, companies, pitches] = await Promise.all([
        TargetEntity.filter({ is_top_20: true }),
        Event.list('-start_dt', 10),
        EventROI.list(),
        TenantRequirement.list('-updated_date', 50), // Increased to get more data
        BuildingEntity.list('-updated_date', 20),
        Company.list(),
        Pitch.list('-created_date', 50)
      ]);

      const upcomingEvents = events.
        filter((e) => e.start_dt && new Date(e.start_dt) > new Date() &&
          new Date(e.start_dt) <= new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)).
        slice(0, 6);

      const eventsWithROI = upcomingEvents.map((event) => ({
        event,
        roi: eventROIs.find((r) => r.event_id === event.id)
      }));

      const dataQualityIssues = [];
      const duplicateBuildings = buildings.filter((building, index, arr) =>
        arr.findIndex((b) => b.address?.toLowerCase() === building.address?.toLowerCase()) !== index
      ).length;

      if (duplicateBuildings > 0) {
        dataQualityIssues.push({ type: 'duplicates', count: duplicateBuildings, message: `${duplicateBuildings} duplicate buildings found` });
      }

      const staleBuildingsCount = buildings.filter((b) =>
        !b.updated_date || new Date(b.updated_date) < new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
      ).length;

      if (staleBuildingsCount > 0) {
        dataQualityIssues.push({ type: 'stale', count: staleBuildingsCount, message: `${staleBuildingsCount} buildings not updated in 90+ days` });
      }

      const engagementsProcessed = engagements.map((engagement) => ({
        ...engagement,
        state: engagement.status || engagement.state || 'Unknown',
        next_action: engagement.next_action || 'Review next steps'
      }));
      
      const engagedPipelineData = mapEngagements(engagements);
      const bdPipelineData = mapBD(pitches);

      setDashboardData({
        targets: targets.slice(0, 10),
        events: eventsWithROI,
        engagements: engagementsProcessed.slice(0, 5),
        dataQualityIssues,
        companies: companies,
        engagedPipeline: engagedPipelineData,
        bdPipeline: bdPipelineData,
        loading: false,
        error: null
      });

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setDashboardData((prev) => ({ ...prev, loading: false, error: 'Failed to load dashboard data due to a network issue. Please check your connection and try again.' }));
    }
  };

  const recomputeScores = async () => {
    console.log("Recomputing scores...");
    return { rows_affected: 0, notes: "Score recomputation would happen here." };
  };

  const generateInboundPlan = async () => {
    console.log("Generating inbound plan...");
    return { rows_affected: 1, notes: "Inbound plan generation would create recommendations here." };
  };

  const handleQuickAction = async (actionName) => {
    let jobLogic;
    let description = '';
    let refreshData = false;
    let navigateTo = null;

    switch (actionName) {
      case 'ingest_source':
        jobLogic = () => ({ rows_affected: 0, notes: 'Ingest Source job would run here' });
        description = "Starting data ingestion...";
        refreshData = true;
        break;
      case 'market_rescan':
        jobLogic = () => ({ rows_affected: 0, notes: 'Market rescan job would run here' });
        description = "Starting market rescan...";
        refreshData = true;
        break;
      case 'recompute_scores':
        jobLogic = recomputeScores;
        description = "Starting score recomputation...";
        refreshData = true;
        break;
      case 'generate_inbound_plan':
      case 'inbound_plan':
        jobLogic = generateInboundPlan;
        description = "Starting inbound plan generation...";
        refreshData = true;
        break;
      case 'parse_extracted_records':
        jobLogic = () => ({ rows_affected: 0, notes: 'Parse extracted records job would run here' });
        description = "Parsing extracted records...";
        refreshData = true;
        break;
      case 'deduplicate_buildings':
        jobLogic = () => ({ rows_affected: 0, notes: 'Deduplication job would run here' });
        description = "Deduplicating buildings...";
        refreshData = true;
        break;
      case 'run_data_quality_sweep':
        jobLogic = () => ({ rows_affected: 0, notes: 'Running data quality sweep...' });
        description = "Running data quality sweep...";
        refreshData = true;
        break;
      case 'find_targets':
        navigateTo = createPageUrl('TargetsWizard');
        description = "Navigating to find targets...";
        break;
      case 'new_pitch':
        navigateTo = createPageUrl('PitchMaster');
        description = "Navigating to create pitch...";
        break;
      case 'market_scan':
          jobLogic = () => ({ rows_affected: 0, notes: 'Starting market scan job...' });
          description = "Starting market scan...";
          refreshData = true;
          break;
      case 'run_daily_refresh':
          jobLogic = () => ({ rows_affected: 0, notes: 'Running daily refresh tasks...' });
          description = "Starting daily refresh...";
          refreshData = true;
          break;
      case 'admin_console':
          navigateTo = createPageUrl('BDAdminConsole');
          description = "Navigating to Admin Console...";
          break;
      default:
        toast({ variant: "destructive", title: "Error", description: `Unknown quick action: ${actionName}.` });
        return;
    }

    if (navigateTo) {
      toast({ title: "Navigating", description: description });
      navigate(navigateTo);
      return;
    }

    toast({ title: "Job Queued", description: description });
    try {
      await runJob(actionName, jobLogic);
      toast({ title: "Job Complete", description: `${actionName} finished successfully.` });
      if (refreshData) {
        loadDashboardData();
      }
    } catch (error) {
      toast({ variant: "destructive", title: "Job Failed", description: error.message });
    }
  };

  const handlePinTarget = async (targetId) => {
    try {
      await TargetEntity.update(targetId, {
        pinned: true,
        pinned_until: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
      });
      loadDashboardData();
      toast({ title: "Target Pinned", description: "Target pinned for 7 days." });
    } catch (error) {
      toast({ variant: "destructive", title: "Pin Failed" });
    }
  };

  const handleUnpinTarget = async (targetId) => {
    try {
      await TargetEntity.update(targetId, { pinned: false, pinned_until: null });
      loadDashboardData();
      toast({ title: "Target Unpinned" });
    } catch (error) {
      toast({ variant: "destructive", title: "Unpin Failed" });
    }
  };

  if (dashboardData.loading) {
    return (
      <div className="flex justify-center items-center h-full min-h-screen">
        <div className="w-8 h-8 rounded-full animate-pulse" style={{ background: 'rgba(255,255,255,0.1)' }}></div>
      </div>
    );
  }

  if (dashboardData.error) {
    return (
      <div className="flex justify-center items-center h-full min-h-screen p-8">
        <Card className="orbit-card w-full max-w-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-400">
              <AlertTriangle className="w-5 h-5" />
              Connection Error
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 mb-6">{dashboardData.error}</p>
            <Button onClick={loadDashboardData} className="w-full bg-orange-500 hover:bg-orange-600">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Move calculations here, after loading checks
  const { topTargets, activeBriefs, inspectionsCount, openNegotiations } = {
    topTargets: dashboardData.targets,
    activeBriefs: dashboardData.engagements.filter(e => ['Briefing', 'Market', 'Shortlist', 'Inspections', 'RFP'].includes(e.state)),
    inspectionsCount: dashboardData.events.filter(e => e.type === 'Inspection' && new Date(e.start_dt) > new Date()).length,
    openNegotiations: dashboardData.engagements.filter(e => ['HOA', 'LeaseExecute'].includes(e.state)).length
  };

  // Example selectors (replace with real data if present)
  // These are placeholders as ProspectSignal, outreachCount, winsQtr, pipeline are not defined elsewhere in the file.
  const bdSignals = []; // reuse your ProspectSignal list if available
  const bdSignals30 = (bdSignals || []).filter(s => daysSince(s.published_at || s.date) <= 30);
  const bdSignals30Delta = 25; // placeholder: replace with real WoW or MoM
  const bdSignals30Series = null; // set to an array of counts per day to override fallback
  const reachoutsMonth = 0; // outreachCount || 0;
  const reachoutsDelta = 12;
  const reachoutsSeries = null;
  const winCountQtr = 0; // winsQtr || 0;
  const winDelta = -5;
  const winSeries = null;
  const pipelineValueAud = 0; // (pipeline || []).reduce((a,b)=>a+(b.weighted_value_aud||0),0);
  const pipelineDelta = 7;
  const pipelineSeries = null;

  function daysSince(iso){ try { return Math.floor((Date.now() - new Date(iso).getTime())/864e5); } catch { return 0; } }

  return (
    <div className="space-y-4 max-w-[1200px] mx-auto px-3 md:px-4">
      <UnitsBar />
      <PageHeader
        title="Command Centre"
        subtitle="One view of BD, engagements, and live transactions."
        actions={
          <>
            <Button variant="gradient" onClick={() => handleQuickAction('run_daily_refresh')}>Run Daily Refresh</Button>
            <Button variant="outline" onClick={() => handleQuickAction('admin_console')}>Open Command Palette</Button>
          </>
        }
      />

      {/* KPI row (chips) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KPIChip label="Top targets" value={(topTargets?.length || 0)} trend={12} />
        <KPIChip label="Active briefs" value={(activeBriefs?.length || 0)} trend={3} />
        <KPIChip label="Inspections this week" value={inspectionsCount || 0} trend={-4} />
        <KPIChip label="Open negotiations" value={openNegotiations || 0} />
      </div>

      {/* KPI card grid with sparklines */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard
          title="BD Signals (30d)"
          value={(bdSignals30?.length ?? bdSignals?.length ?? 0)}
          delta={deltaPct(bdSignals30Delta)}
          footnote="News + funding + expansion"
          spark={<Sparkline data={seriesOrFallback(bdSignals30Series, (bdSignals30?.length ?? 0))} />}
        />
        <KPICard
          title="Target Reachouts"
          value={(reachoutsMonth ?? 0)}
          delta={deltaPct(reachoutsDelta)}
          footnote="Sent last 30 days"
          spark={<Sparkline data={seriesOrFallback(reachoutsSeries, (reachoutsMonth ?? 0))} stroke="#22c55e" fill="rgba(34,197,94,0.15)" />}
        />
        <KPICard
          title="Mandates Won"
          value={(winCountQtr ?? 0)}
          delta={deltaPct(winDelta)}
          footnote="This quarter"
          spark={<Sparkline data={seriesOrFallback(winSeries, (winCountQtr ?? 0))} stroke="#38bdf8" fill="rgba(56,189,248,0.15)" />}
        />
        <KPICard
          title="Pipeline Value (A$ m)"
          value={toMillions(pipelineValueAud)}
          delta={deltaPct(pipelineDelta)}
          footnote="Weighted, next 90 days"
          spark={<Sparkline data={seriesOrFallback(pipelineSeries, toMillions(pipelineValueAud))} stroke="#f59e0b" fill="rgba(245,158,11,0.15)" />}
        />
      </div>

      {/* Integrated Pipeline Panel */}
      <PipelinePanel
        currency="A$"
        engaged={dashboardData.engagedPipeline}
        bd={dashboardData.bdPipeline}
      />

      {/* Priority Targets */}
      <Card className="shadow-elevated lg:col-span-2">
        <CardHeader className="pb-3">
          <CardTitle className="text-base text-white">Top 20 Targets</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {dashboardData.targets.length > 0 ? (
            <div className="space-y-1">
              {dashboardData.targets.slice(0, 5).map((target, index) => {
                const company = dashboardData.companies.find(c => c.id === target.company_id);
                return (
                  <TargetRow
                    key={target.id || index}
                    rank={index + 1}
                    target={target}
                    company={company}
                    onPin={handlePinTarget}
                    onUnpin={handleUnpinTarget}
                  />
                );
              })}
            </div>
          ) : (
            <div className="text-sm text-gray-400 p-6 border border-dashed border-gray-700 rounded-lg text-center">
              No priority targets yet. <br />
              <Button variant="link" className="p-0 h-auto text-orange-400" onClick={() => handleQuickAction('find_targets')}>
                <strong>Find New Targets</strong>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions - This structure was previously 'Quick Actions & Events' */}
      {/* The sibling 'Upcoming Events' card has been moved into the new 'Events & Signals' card below */}
      <div className="space-y-4">
        <Card className="shadow-elevated">
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-white">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-2 text-center">
              <QuickActionButton Icon={TargetIcon} label="Find Targets" actionKey="find_targets" onClick={handleQuickAction} />
              <QuickActionButton Icon={Sparkles} label="Inbound Plan" actionKey="inbound_plan" onClick={handleQuickAction} />
              <QuickActionButton Icon={FileText} label="New Pitch" actionKey="new_pitch" onClick={handleQuickAction} />
              <QuickActionButton Icon={Compass} label="Market Scan" actionKey="market_scan" onClick={handleQuickAction} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Live Engagements */}
      <Card className="shadow-elevated">
        <CardHeader className="pb-3">
          <CardTitle className="text-base text-white">Live Engagements</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {dashboardData.engagements.length > 0 ? (
            <div className="divide-y divide-gray-800">
              {dashboardData.engagements.map((engagement) => (
                <EngagementRow key={engagement.id} engagement={engagement} />
              ))}
            </div>
          ) : (
            <div className="text-sm text-gray-400 p-6 border border-dashed border-gray-700 rounded-lg text-center">
              No active engagements. <br />
              <Button variant="link" className="p-0 h-auto text-orange-400" onClick={() => navigate(createPageUrl('ClientManagement'))}>
                <strong>Create New Client</strong>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Events & Signals - Combines previous Upcoming Events with new signals data (if any) */}
      <Card className="shadow-elevated">
        <CardHeader className="pb-3">
          <CardTitle className="text-base text-white">Events & Signals</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {dashboardData.events.length > 0 ? (
            dashboardData.events.slice(0, 3).map(({ event, roi }) => (
              <EventTile key={event.id} event={event} roi={roi} />
            ))
          ) : (
            <div className="text-sm text-gray-400 p-6 border border-dashed border-gray-700 rounded-lg text-center">
              No upcoming events. <br />
              <Button variant="link" className="p-0 h-auto text-orange-400" onClick={() => navigate(createPageUrl('EventsMan'))}>
                <strong>Explore Events</strong>
              </Button>
            </div>
          )}
          {/* Add more signal-related content here if available */}
        </CardContent>
      </Card>

      {/* Data Quality */}
      {dashboardData.dataQualityIssues.length > 0 && (
        <Card className="shadow-elevated">
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-yellow-400 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" /> Data Quality
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="divide-y divide-gray-800">
              {dashboardData.dataQualityIssues.map((issue, index) => (
                <DataQualityRow key={index} issue={issue} onFix={() => handleQuickAction('run_data_quality_sweep')} />
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ---------- helpers (local, zero-dep) ----------
function deltaPct(v){
  const n = Number(v ?? 0);
  if (!isFinite(n)) return 0;
  return Math.max(-99, Math.min(300, Math.round(n)));
}
function toMillions(n){
  try {
    const x = Number(n ?? 0) / 1_000_000;
    return Math.round(x * 10) / 10; // 1 decimal
  } catch { return 0; }
}
function seriesOrFallback(series, anchor=0){
  if (Array.isArray(series) && series.length >= 2) return series;
  // build a gentle 12-point series around anchor (±8%)
  const base = Math.max(0, Number(anchor || 0));
  const len = 12;
  const out = [];
  for (let i=0;i<len;i++){
    // deterministic wiggle using a cosine; no randomness
    const t = i / (len-1);
    const wiggle = (Math.cos((t+0.25)*Math.PI*2) * 0.06) + (t*0.02); // ±6% + slight uptrend
    out.push(Math.max(0, Math.round(base * (1 + wiggle))));
  }
  return out;
}
