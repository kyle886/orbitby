
import React, { useState, useEffect, useCallback } from 'react';
import BulkUploader from '@/components/building-database/BulkUploader';
import { JobRun } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, RefreshCw, CheckCircle, AlertTriangle, FileUp } from 'lucide-react';

const JobRunItem = ({ job }) => {
  const getStatusInfo = (status) => {
    switch (status) {
      case 'success':
        return { icon: <CheckCircle className="text-green-400" />, color: 'text-green-400' };
      case 'partial':
        return { icon: <AlertTriangle className="text-yellow-400" />, color: 'text-yellow-400' };
      case 'failed':
        return { icon: <AlertTriangle className="text-red-400" />, color: 'text-red-400' };
      default:
        return { icon: <Loader2 className="animate-spin text-blue-400" />, color: 'text-blue-400' };
    }
  };

  const { icon, color } = getStatusInfo(job.status);
  const results = job.results || {};

  return (
    <div className="border-b border-gray-700/50 p-4 flex items-start gap-4">
      <div className={`mt-1 ${color}`}>{icon}</div>
      <div className="flex-1">
        <p className="font-semibold text-white">{job.job_name}</p>
        <p className="text-sm text-gray-400 mb-2">
          Started by {job.triggered_by} on {new Date(job.started_at).toLocaleString()}
        </p>
        <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs">
          <span className="text-gray-300">Status: <span className={`font-medium ${color}`}>{job.status}</span></span>
          <span className="text-green-400">Created: {results.created || 0}</span>
          <span className="text-blue-400">Updated: {results.updated || 0}</span>
          <span className="text-yellow-400">Duplicates: {results.duplicates || 0}</span>
          <span className="text-red-400">Errors: {results.errors || 0}</span>
        </div>
        {job.notes && (
          <pre className="text-xs text-gray-500 mt-2 bg-gray-900/50 p-2 rounded-md whitespace-pre-wrap font-mono">
            {job.notes}
          </pre>
        )}
      </div>
    </div>
  );
};

export default function DataIngestion() {
  const [jobRuns, setJobRuns] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadJobRuns = useCallback(async () => {
    setLoading(true);
    try {
      const jobs = await JobRun.filter({ job_name: { "$regex": "Ingest" } }, '-started_at', 50);
      setJobRuns(jobs || []);
    } catch (error) {
      console.error("Failed to load job runs:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadJobRuns();
  }, [loadJobRuns]);

  return (
    <div className="p-4 sm:p-8 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Data Ingestion</h1>
          <p className="text-gray-300">Upload CSV files to bulk-create or update records in the database.</p>
        </div>

        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-white">
              <FileUp className="w-5 h-5 text-orange-400" />
              New Ingestion Job
            </CardTitle>
          </CardHeader>
          <CardContent>
            <BulkUploader onUploadComplete={loadJobRuns} />
          </CardContent>
        </Card>

        <Card className="orbit-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-white">Recent Ingestion Jobs</CardTitle>
            <Button variant="ghost" size="icon" onClick={loadJobRuns} disabled={loading}>
              <RefreshCw className={`w-4 h-4 text-gray-400 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="p-8 text-center"><Loader2 className="w-6 h-6 mx-auto animate-spin text-gray-400" /></div>
            ) : jobRuns.length > 0 ? (
              <div>
                {jobRuns.map(job => <JobRunItem key={job.id} job={job} />)}
              </div>
            ) : (
              <div className="p-8 text-center text-gray-400">No recent ingestion jobs found.</div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
