
import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Target } from '@/api/entities';
import { Company } from '@/api/entities';
import { Signal } from '@/api/entities';
import { Building } from '@/api/entities';
import { Brief } from '@/api/entities';
import { Lease } from '@/api/entities';
import { User } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations'; // This import seems unused
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'; // Removed DialogTrigger as it's not used directly anymore
import { Textarea } from '@/components/ui/textarea'; // This import seems unused after removing note dialog
import { useToast } from '@/components/ui/use-toast';
import { runJob } from '@/components/utils/runJob'; // New import for runJob
import { 
  Target as TargetIcon, 
  Building as BuildingIcon, 
  Users, 
  Mail, 
  FileText, 
  Plus, 
  Loader2,
  Filter,
  ExternalLink,
  UserCheck,
  MessageSquare
} from 'lucide-react';
import {
  calculateFundingMomentum,
  calculateLeaseExpiryProximity, 
  calculateBuildingLeverage,
  calculateSectorFit,
  calculateHiringSignal,
  calculateNewsHeat,
  calculatePriorityScore
} from '@/components/utils/scoringCalculations';
import { TargetActions } from '@/components/actions/TargetActions'; // New import for TargetActions

// TargetRow component is replaced by TargetCard in the 'recommended' tab,
// but could potentially be kept for other uses if desired.
// For this change, it's assumed to be entirely replaced for the main target display.
/*
const TargetRow = ({ target, company, onAssign, onEmailDraft, onAddNote }) => {
  const getStatusColor = (status) => {
    const colors = {
      prospect: 'bg-orange-500/20 text-orange-300',
      working: 'bg-blue-500/20 text-blue-300', 
      won: 'bg-green-500/20 text-green-300',
      disqualified: 'bg-red-500/20 text-red-300'
    };
    return colors[status] || colors.prospect;
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    if (score >= 40) return 'text-orange-400';
    return 'text-red-400';
  };

  return (
    <tr className="border-b border-gray-700/50 hover:bg-gray-800/30">
      <td className="p-4">
        <div className="flex items-center gap-3">
          <div>
            <Link to={createPageUrl(`TargetDetails?id=${target.id}`)} className="font-medium text-white hover:text-orange-400">
              {company?.name || 'Unknown Company'}
            </Link>
            <p className="text-xs text-gray-400">{company?.sector} • {company?.hq_city}</p>
          </div>
        </div>
      </td>
      <td className="p-4">
        <Badge className={getStatusColor(target.status)}>{target.status}</Badge>
      </td>
      <td className="p-4">
        <span className={`text-2xl font-bold ${getScoreColor(target.priority_score)}`}>
          {target.priority_score}
        </span>
      </td>
      <td className="p-4 text-xs space-y-1">
        <div>Funding: {target.funding_momentum_score || 0}</div>
        <div>Lease: {target.lease_expiry_proximity_score || 0}</div>
        <div>Building: {target.building_leverage_score || 0}</div>
      </td>
      <td className="p-4 text-xs space-y-1">
        <div>Sector: {target.sector_fit_score || 0}</div>
        <div>Hiring: {target.hiring_signal_score || 0}</div>
        <div>News: {target.news_heat_score || 0}</div>
      </td>
      <td className="p-4">
        <div className="flex gap-2">
          <Button size="sm" onClick={() => onAssign(target)} className="bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 text-xs">
            <UserCheck className="w-3 h-3 mr-1" />
            Assign
          </Button>
          <Button size="sm" variant="outline" onClick={() => onEmailDraft(target, company)} className="orbit-button px-2 py-1 text-xs">
            <Mail className="w-3 h-3 mr-1" />
            Email
          </Button>
          <Button size="sm" variant="outline" onClick={() => onAddNote(target)} className="orbit-button px-2 py-1 text-xs">
            <MessageSquare className="w-3 h-3 mr-1" />
            Note
          </Button>
          <Link to={createPageUrl(`BuildingDetails?id=${target.building_id}`)} target="_blank">
            <Button size="sm" variant="ghost" className="px-2 py-1 text-xs text-gray-400 hover:text-white">
              <BuildingIcon className="w-3 h-3 mr-1" />
              Building
            </Button>
          </Link>
        </div>
      </td>
    </tr>
  );
};
*/

const LeverageRow = ({ company, building, onAddAsTarget }) => (
  <tr className="border-b border-gray-700/50 hover:bg-gray-800/30">
    <td className="p-4">
      <div>
        <p className="font-medium text-white">{company.name}</p>
        <p className="text-xs text-gray-400">{company.sector}</p>
      </div>
    </td>
    <td className="p-4">
      <div>
        <p className="text-sm text-white">{building?.name}</p>
        <p className="text-xs text-gray-400">{building?.address}</p>
      </div>
    </td>
    <td className="p-4">
      <Badge className="bg-green-500/20 text-green-300">Active Brief</Badge>
    </td>
    <td className="p-4">
      <Button size="sm" onClick={() => onAddAsTarget(company)} className="bg-orange-500 hover:bg-orange-600 text-white px-3 py-1">
        <Plus className="w-4 h-4 mr-1" />
        Add as Target
      </Button>
    </td>
  </tr>
);

export default function TargetsWizard() {
  const [targets, setTargets] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [leverageOpportunities, setLeverageOpportunities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    sector: 'all',
    city: 'all',
    building: 'all', // This filter is not used in the UI, but kept for consistency
    expiryBand: 'all', // This filter is not used in the UI, but kept for consistency
    minScore: 0
  });
  
  // Dialog states for assign, email, note are now assumed to be handled by TargetActions component internally
  // const [assignDialog, setAssignDialog] = useState({ show: false, target: null });
  // const [emailDialog, setEmailDialog] = useState({ show: false, target: null, company: null });
  // const [noteDialog, setNoteDialog] = useState({ show: false, target: null });
  const [isProcessing, setIsProcessing] = useState(false); // Kept for handleAddAsTarget

  const { toast } = useToast();

  // Helper function for status badge color (used by TargetCard)
  const getStatusColor = (status) => {
    const colors = {
      prospect: 'bg-orange-500/20 text-orange-300',
      working: 'bg-blue-500/20 text-blue-300', 
      won: 'bg-green-500/20 text-green-300',
      disqualified: 'bg-red-500/20 text-red-300'
    };
    return colors[status] || colors.prospect;
  };

  // Helper function for priority score badge color (new, used by TargetCard)
  const getPriorityColor = (score) => {
    if (score >= 80) return 'bg-green-500/20 text-green-300 border border-green-500/30';
    if (score >= 60) return 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/30';
    if (score >= 40) return 'bg-orange-500/20 text-orange-300 border border-orange-500/30';
    return 'bg-red-500/20 text-red-300 border border-red-500/30';
  };

  // New TargetCard component definition
  const TargetCard = ({ target, company }) => (
    <Card className="orbit-card overflow-hidden hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Link to={createPageUrl(`TargetDetails?id=${target.id}`)} className="font-bold text-white text-xl hover:text-orange-400">
                {company?.name || 'Unknown Company'}
              </Link>
              <Badge className={`${getPriorityColor(target.priority_score)}`}>
                {target.priority_score}
              </Badge>
            </div>
            <p className="text-gray-400 text-sm">{company?.sector || 'Unknown Sector'} • {company?.hq_city}</p>
            <p className="text-gray-400 text-xs mt-1">Status: <Badge className={getStatusColor(target.status)}>{target.status}</Badge></p>
          </div>
          <div className="flex items-center gap-2">
            {target.is_top_20 && (
              <Badge className="bg-gradient-to-r from-orange-500 to-amber-500 text-white">
                Top 20
              </Badge>
            )}
            {target.pinned && (
              <Badge className="bg-blue-500/20 text-blue-300 border border-blue-500/30">
                📌 Pinned
              </Badge>
            )}
            <TargetActions target={target} onUpdate={loadTargets} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm mb-4">
          <div>
            <p className="text-gray-400">Primary Scores:</p>
            <ul className="list-disc list-inside text-gray-300 text-xs">
              <li>Funding: {target.funding_momentum_score || 0}</li>
              <li>Lease: {target.lease_expiry_proximity_score || 0}</li>
              <li>Building: {target.building_leverage_score || 0}</li>
            </ul>
          </div>
          <div>
            <p className="text-gray-400">Secondary Scores:</p>
            <ul className="list-disc list-inside text-gray-300 text-xs">
              <li>Sector: {target.sector_fit_score || 0}</li>
              <li>Hiring: {target.hiring_signal_score || 0}</li>
              <li>News: {target.news_heat_score || 0}</li>
            </ul>
          </div>
        </div>
        <div className="flex items-center text-xs text-gray-400 gap-2">
          {target.building_id && (
            <Link to={createPageUrl(`BuildingDetails?id=${target.building_id}`)} target="_blank" className="hover:text-white flex items-center">
              <BuildingIcon className="w-3 h-3 mr-1" />
              View Building
            </Link>
          )}
          {target.reason && (
            <div className="truncate max-w-full flex items-center gap-1">
              <FileText className="w-3 h-3" />
              <span className="text-gray-400 text-xs italic">{target.reason.split('\n')[0]}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  // Renamed from loadTargetsData to loadTargets
  const loadTargets = useCallback(async () => {
    setLoading(true);
    try {
      const [targetsData, companiesData, signalsData, buildingsData, briefsData, leasesData] = await Promise.all([
        Target.list('-priority_score'), // Fetching targets, sorted by priority score
        Company.list(),
        Signal.list('-date'),
        Building.list(),
        Brief.list(),
        Lease.list()
      ]);

      // Create lookup maps
      const companyMap = new Map(companiesData.map(c => [c.id, c]));
      const signalsByCompany = signalsData.reduce((acc, signal) => {
        if (!acc[signal.company_id]) acc[signal.company_id] = [];
        acc[signal.company_id].push(signal);
        return acc;
      }, {});

      // Recompute scores for each target
      const enrichedTargets = targetsData.map(target => {
        const company = companyMap.get(target.company_id);
        const signals = signalsByCompany[target.company_id] || [];
        
        // Calculate all sub-scores
        const funding_momentum_score = calculateFundingMomentum(signals);
        const lease_expiry_proximity_score = calculateLeaseExpiryProximity(target.lease_expiry_date);
        const building_leverage_score = calculateBuildingLeverage(target.building_id, briefsData, buildingsData);
        const sector_fit_score = calculateSectorFit(company?.sector);
        const hiring_signal_score = calculateHiringSignal(signals);
        const news_heat_score = calculateNewsHeat(signals);
        
        // Calculate priority score
        const priority_score = calculatePriorityScore({
          funding_momentum_score,
          lease_expiry_proximity_score, 
          building_leverage_score,
          sector_fit_score,
          hiring_signal_score,
          news_heat_score
        });

        return {
          ...target,
          funding_momentum_score,
          lease_expiry_proximity_score,
          building_leverage_score,
          sector_fit_score,
          hiring_signal_score,
          news_heat_score,
          priority_score,
          pinned: target.pinned ?? false // Ensure pinned property exists, default to false if not from DB
        };
      });

      // Sort by priority_score and mark top 20
      enrichedTargets.sort((a, b) => b.priority_score - a.priority_score);
      const targetsWithTop20 = enrichedTargets.map((target, index) => ({
        ...target,
        is_top_20: index < 20 // Mark first 20 as top 20
      }));

      // Find leverage opportunities (companies in buildings with active/won briefs)
      const activeBriefBuildingIds = new Set(
        briefsData
          .filter(b => ['active', 'won'].includes(b.status))
          .map(b => b.building_id)
          .filter(Boolean)
      );

      const leverageCompanies = leasesData
        .filter(lease => activeBriefBuildingIds.has(lease.building_id))
        .map(lease => ({
          company: companyMap.get(lease.company_id),
          building: buildingsData.find(b => b.id === lease.building_id)
        }))
        .filter(item => item.company && item.building)
        .slice(0, 50); // Limit for performance

      setTargets(targetsWithTop20); // Use targets with top 20 flag
      setCompanies(companiesData);
      setLeverageOpportunities(leverageCompanies);
      
    } catch (error) {
      console.error('Error loading targets data:', error);
      toast({ variant: "destructive", title: "Data Load Failed", description: "Could not load targets data." });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadTargets(); // Use new function name
  }, [loadTargets]); // Use new function name in dependency array

  const filteredTargets = targets.filter(target => {
    const company = companies.find(c => c.id === target.company_id);
    
    if (filters.sector !== 'all' && company?.sector !== filters.sector) return false;
    if (filters.city !== 'all' && company?.hq_city !== filters.city) return false;
    if (filters.minScore > 0 && target.priority_score < filters.minScore) return false;
    
    return true;
  });

  // These dialog handling functions are now assumed to be handled within TargetActions component.
  // const handleAssign = async (assignTo) => {
  //   if (!assignDialog.target || !assignTo) return;
    
  //   setIsProcessing(true);
  //   try {
  //     await Assignment.create({
  //       object_type: 'target',
  //       object_id: assignDialog.target.id,
  //       user_id: assignTo,
  //       role: 'owner',
  //       due_dt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
  //       status: 'open'
  //     });

  //     // Update target owner
  //     await Target.update(assignDialog.target.id, { owner_user_id: assignTo });
      
  //     toast({ title: "Target Assigned", description: `Target assigned successfully with 7-day deadline.` });
  //     setAssignDialog({ show: false, target: null });
  //     loadTargets();
      
  //   } catch (error) {
  //     console.error('Error assigning target:', error);
  //     toast({ variant: "destructive", title: "Assignment Failed", description: "Could not assign target." });
  //   } finally {
  //     setIsProcessing(false);
  //   }
  // };

  // const handleEmailDraft = async (target, company) => {
  //   setEmailDialog({ show: true, target, company });
  // };

  // const handleAddNote = async (target, note) => {
  //   if (!note.trim()) return;
    
  //   setIsProcessing(true);
  //   try {
  //     await Target.update(target.id, {
  //       reason: `${target.reason || ''}\n\n[${new Date().toLocaleDateString()}] ${note}`.trim()
  //     });
      
  //     toast({ title: "Note Added", description: "Target note updated successfully." });
  //     setNoteDialog({ show: false, target: null });
      
  //   } catch (error) {
  //     console.error('Error adding note:', error);
  //     toast({ variant: "destructive", title: "Note Failed", description: "Could not add note." });
  //   } finally {
  //     setIsProcessing(false);
  //   }
  // };

  const handleAddAsTarget = async (company) => {
    setIsProcessing(true);
    try {
      // Check if target already exists for this company
      const existingTargets = await Target.filter({ company_id: company.id });
      
      if (existingTargets.length > 0) {
        toast({ 
          title: "Target Already Exists", 
          description: `${company.name} is already in your targets list.`,
          variant: "destructive"
        });
        setIsProcessing(false);
        return;
      }

      const currentUser = await User.me();
      
      await Target.create({
        company_id: company.id,
        owner_user_id: currentUser.id,
        status: 'prospect',
        priority_score: 70, // Higher default for leverage opportunities
        reason: `Added from leverage view - in building with active/won brief`,
        next_action_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
      });

      toast({ title: "Target Created", description: `${company.name} added as high-priority target.` });
      loadTargets(); // Use new function name
      
    } catch (error) {
      console.error('Error adding target:', error);
      toast({ variant: "destructive", title: "Creation Failed", description: "Could not create target." });
    } finally {
      setIsProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8 text-center">
        <Loader2 className="h-12 w-12 animate-spin text-orange-400 mx-auto mb-4" />
        <p className="text-gray-300">Loading targets data...</p>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 md:p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Targets Wizard</h1>
        <p className="text-gray-300">Score-driven target identification and management system.</p>
      </div>

      <Tabs defaultValue="recommended" className="space-y-6">
        <TabsList className="bg-gray-800">
          <TabsTrigger value="recommended" className="text-white data-[state=active]:bg-orange-500">
            Recommended Targets ({filteredTargets.length})
          </TabsTrigger>
          <TabsTrigger value="leverage" className="text-white data-[state=active]:bg-orange-500">
            Leverage View ({leverageOpportunities.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="recommended">
          {/* Filters */}
          <Card className="orbit-card mb-6">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Filter className="w-5 h-5" />
                Filters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <Select value={filters.sector} onValueChange={(value) => setFilters(prev => ({...prev, sector: value}))}>
                  <SelectTrigger className="orbit-input text-white">
                    <SelectValue placeholder="All Sectors" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sectors</SelectItem>
                    <SelectItem value="Education">Education</SelectItem>
                    <SelectItem value="LifeSci">Life Sciences</SelectItem>
                    <SelectItem value="Biotech">Biotech</SelectItem>
                    <SelectItem value="Fintech">Fintech</SelectItem>
                    <SelectItem value="SaaS">SaaS</SelectItem>
                    <SelectItem value="AI">AI</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filters.city} onValueChange={(value) => setFilters(prev => ({...prev, city: value}))}>
                  <SelectTrigger className="orbit-input text-white">
                    <SelectValue placeholder="All Cities" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Cities</SelectItem>
                    <SelectItem value="Sydney">Sydney</SelectItem>
                    <SelectItem value="Melbourne">Melbourne</SelectItem>
                    <SelectItem value="Brisbane">Brisbane</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  type="number"
                  placeholder="Min Score"
                  value={filters.minScore}
                  onChange={(e) => setFilters(prev => ({...prev, minScore: parseInt(e.target.value) || 0}))}
                  className="orbit-input text-white"
                />

                <Button onClick={loadTargets} disabled={loading} className="bg-orange-500 hover:bg-orange-600">
                  {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                  Refresh Scores
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Targets Grid (formerly table) */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTargets.length > 0 ? (
              filteredTargets.map(target => {
                const company = companies.find(c => c.id === target.company_id);
                return (
                  <TargetCard
                    key={target.id}
                    target={target}
                    company={company}
                  />
                );
              })
            ) : (
              <div className="md:col-span-3 text-center p-12 text-gray-500">
                <TargetIcon className="w-12 h-12 mx-auto mb-3" />
                <h3 className="text-lg font-medium text-white">No Targets Found</h3>
                <p>Adjust your filters or check back after data refresh.</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="leverage">
          <Card className="orbit-card">
            <CardHeader>
              <CardTitle className="text-white">Leverage Opportunities</CardTitle>
              <p className="text-gray-400 text-sm">Companies in buildings with active or recently won briefs - high conversion potential.</p>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-800/50">
                    <tr>
                      <th className="text-left p-4 font-medium text-white">Company</th>
                      <th className="text-left p-4 font-medium text-white">Building</th>
                      <th className="text-left p-4 font-medium text-white">Opportunity</th>
                      <th className="text-left p-4 font-medium text-white">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {leverageOpportunities.length > 0 ? (
                      leverageOpportunities.map((item, index) => (
                        <LeverageRow
                          key={index}
                          company={item.company}
                          building={item.building}
                          onAddAsTarget={handleAddAsTarget}
                        />
                      ))
                    ) : (
                      <tr>
                        <td colSpan="4" className="text-center p-12 text-gray-500">
                          <BuildingIcon className="w-12 h-12 mx-auto mb-3" />
                          <h3 className="text-lg font-medium text-white">No Leverage Opportunities</h3>
                          <p>No companies found in buildings with active briefs.</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Assignment Dialog and Note Dialog are assumed to be handled internally by TargetActions */}
      {/* Therefore, removed from here */}

    </div>
  );
}
