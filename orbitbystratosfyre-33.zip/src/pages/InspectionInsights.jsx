import React, { useState, useEffect, useCallback } from 'react';
import { InspectionItinerary } from '@/api/entities';
import { InspectionFeedback } from '@/api/entities';
import { PropertySubmission } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { Client } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { 
  Eye, 
  Star, 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Building2, 
  Calendar,
  MapPin,
  Download,
  Filter
} from 'lucide-react';

const RatingDisplay = ({ rating, size = 'sm' }) => {
  const stars = [];
  for (let i = 1; i <= 5; i++) {
    stars.push(
      <Star
        key={i}
        className={`${size === 'sm' ? 'w-4 h-4' : 'w-5 h-5'} ${
          i <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-600'
        }`}
      />
    );
  }
  return <div className="flex">{stars}</div>;
};

const PropertyInsightCard = ({ property, feedback, avgRating, totalFeedback }) => {
  const criteriaScores = feedback.reduce((acc, f) => {
    Object.entries(f.criteria_ratings || {}).forEach(([criterion, rating]) => {
      if (!acc[criterion]) acc[criterion] = [];
      acc[criterion].push(rating);
    });
    return acc;
  }, {});

  const criteriaAvgs = Object.entries(criteriaScores).map(([criterion, ratings]) => ({
    criterion: criterion.replace('criterion_', 'Criterion '),
    average: (ratings.reduce((sum, r) => sum + r, 0) / ratings.length).toFixed(1)
  }));

  return (
    <Card className="orbit-card">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg text-white">{property.property_title}</CardTitle>
            <p className="text-sm text-gray-400">{property.street_address}</p>
            <div className="flex items-center gap-2 mt-2">
              <RatingDisplay rating={Math.round(avgRating)} />
              <span className="text-sm text-gray-400">({totalFeedback} reviews)</span>
            </div>
          </div>
          <Badge variant="outline" className="text-white">
            {property.floor_area_sqm} sqm
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-300">Overall Satisfaction</span>
              <span className="text-sm font-semibold text-white">{avgRating.toFixed(1)}/5</span>
            </div>
            <Progress value={(avgRating / 5) * 100} className="h-2" />
          </div>
          
          {criteriaAvgs.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-white">Criteria Breakdown</h4>
              {criteriaAvgs.map((criteria, index) => (
                <div key={index} className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">{criteria.criterion}</span>
                  <div className="flex items-center gap-1">
                    <RatingDisplay rating={Math.round(criteria.average)} size="sm" />
                    <span className="text-gray-300 ml-1">{criteria.average}</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {feedback.length > 0 && feedback[0].notes && (
            <div className="pt-2 border-t border-gray-700">
              <p className="text-xs text-gray-400">Latest feedback:</p>
              <p className="text-sm text-gray-300 mt-1 line-clamp-2">
                {feedback[0].notes}
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

const ItineraryOverview = ({ itinerary, feedback }) => {
  const itineraryFeedback = feedback.filter(f => f.itinerary_id === itinerary.id);
  const avgRating = itineraryFeedback.length > 0 
    ? itineraryFeedback.reduce((sum, f) => sum + f.overall_rating, 0) / itineraryFeedback.length 
    : 0;

  return (
    <Card className="orbit-card">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-white">{itinerary.itinerary_name}</CardTitle>
            <div className="flex items-center gap-4 mt-2 text-sm text-gray-400">
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>{new Date(itinerary.inspection_date).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center gap-1">
                <Building2 className="w-4 h-4" />
                <span>{itinerary.properties?.length || 0} properties</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                <span>{itineraryFeedback.length} responses</span>
              </div>
            </div>
          </div>
          <Badge className={`${itinerary.status === 'completed' ? 'bg-green-500/20 text-green-300' : 'bg-blue-500/20 text-blue-300'}`}>
            {itinerary.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {avgRating > 0 && (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <RatingDisplay rating={Math.round(avgRating)} />
              <span className="text-sm text-gray-300">{avgRating.toFixed(1)} average rating</span>
            </div>
            <Button variant="outline" size="sm">View Details</Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default function InspectionInsights() {
  const [itineraries, setItineraries] = useState([]);
  const [feedback, setFeedback] = useState([]);
  const [properties, setProperties] = useState([]);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('30');
  const [selectedClient, setSelectedClient] = useState('all');

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [itinerariesData, feedbackData, propertiesData, clientsData] = await Promise.all([
        InspectionItinerary.list('-inspection_date'),
        InspectionFeedback.list('-created_date'),
        PropertySubmission.list(),
        Client.list()
      ]);
      
      setItineraries(itinerariesData || []);
      setFeedback(feedbackData || []);
      setProperties(propertiesData || []);
      setClients(clientsData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Filter data based on selected period and client
  const filteredItineraries = itineraries.filter(itinerary => {
    const inspectionDate = new Date(itinerary.inspection_date);
    const daysAgo = (new Date() - inspectionDate) / (1000 * 60 * 60 * 24);
    const withinPeriod = daysAgo <= parseInt(selectedPeriod);
    const matchesClient = selectedClient === 'all' || itinerary.client_id === selectedClient;
    
    return withinPeriod && matchesClient;
  });

  // Calculate insights
  const propertyInsights = properties.map(property => {
    const propertyFeedback = feedback.filter(f => f.property_submission_id === property.id);
    const avgRating = propertyFeedback.length > 0 
      ? propertyFeedback.reduce((sum, f) => sum + f.overall_rating, 0) / propertyFeedback.length 
      : 0;
    
    return {
      property,
      feedback: propertyFeedback,
      avgRating,
      totalFeedback: propertyFeedback.length
    };
  }).filter(p => p.totalFeedback > 0).sort((a, b) => b.avgRating - a.avgRating);

  // Prepare chart data
  const ratingDistribution = [
    { rating: '5 Stars', count: feedback.filter(f => f.overall_rating === 5).length },
    { rating: '4 Stars', count: feedback.filter(f => f.overall_rating === 4).length },
    { rating: '3 Stars', count: feedback.filter(f => f.overall_rating === 3).length },
    { rating: '2 Stars', count: feedback.filter(f => f.overall_rating === 2).length },
    { rating: '1 Star', count: feedback.filter(f => f.overall_rating === 1).length }
  ];

  const monthlyTrends = {};
  feedback.forEach(f => {
    const month = new Date(f.created_date).toISOString().slice(0, 7);
    if (!monthlyTrends[month]) {
      monthlyTrends[month] = { month, ratings: [], count: 0 };
    }
    monthlyTrends[month].ratings.push(f.overall_rating);
    monthlyTrends[month].count++;
  });

  const trendsData = Object.values(monthlyTrends)
    .map(m => ({
      ...m,
      avgRating: (m.ratings.reduce((sum, r) => sum + r, 0) / m.ratings.length).toFixed(1)
    }))
    .sort((a, b) => a.month.localeCompare(b.month));

  const overallStats = {
    totalInspections: filteredItineraries.length,
    totalFeedback: feedback.length,
    avgRating: feedback.length > 0 ? (feedback.reduce((sum, f) => sum + f.overall_rating, 0) / feedback.length).toFixed(1) : 0,
    responseRate: filteredItineraries.length > 0 ? ((feedback.length / (filteredItineraries.length * 3)) * 100).toFixed(1) : 0 // Assuming avg 3 attendees per inspection
  };

  const exportData = () => {
    const csvContent = [
      ['Property', 'Address', 'Average Rating', 'Total Reviews', 'Last Inspection'].join(','),
      ...propertyInsights.map(p => [
        p.property.property_title,
        p.property.street_address,
        p.avgRating.toFixed(1),
        p.totalFeedback,
        p.feedback.length > 0 ? new Date(p.feedback[0].created_date).toLocaleDateString() : ''
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `inspection-insights-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full p-8">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full animate-pulse bg-white/10 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading inspection insights...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 md:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Inspection Insights</h1>
          <p className="text-gray-300">Analyze client feedback and property performance data</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedClient} onValueChange={setSelectedClient}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="All Clients" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Clients</SelectItem>
              {clients.map(client => (
                <SelectItem key={client.id} value={client.id}>
                  {client.company_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={exportData}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Inspections</p>
                <p className="text-2xl font-bold text-white">{overallStats.totalInspections}</p>
              </div>
              <Eye className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Feedback Received</p>
                <p className="text-2xl font-bold text-white">{overallStats.totalFeedback}</p>
              </div>
              <Users className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Average Rating</p>
                <div className="flex items-center gap-2">
                  <p className="text-2xl font-bold text-white">{overallStats.avgRating}</p>
                  <RatingDisplay rating={Math.round(parseFloat(overallStats.avgRating))} size="sm" />
                </div>
              </div>
              <Star className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Response Rate</p>
                <p className="text-2xl font-bold text-white">{overallStats.responseRate}%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="properties" className="space-y-6">
        <TabsList>
          <TabsTrigger value="properties">Property Performance</TabsTrigger>
          <TabsTrigger value="itineraries">Recent Inspections</TabsTrigger>
          <TabsTrigger value="trends">Trends & Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="properties">
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">Top Performing Properties</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {propertyInsights.slice(0, 9).map((insight, index) => (
                  <PropertyInsightCard
                    key={insight.property.id}
                    property={insight.property}
                    feedback={insight.feedback}
                    avgRating={insight.avgRating}
                    totalFeedback={insight.totalFeedback}
                  />
                ))}
              </div>
              {propertyInsights.length === 0 && (
                <div className="text-center py-8">
                  <Building2 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">No feedback data yet</h3>
                  <p className="text-gray-400">Property insights will appear once inspections are completed and feedback is collected.</p>
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="itineraries">
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">Recent Inspection Itineraries</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredItineraries.slice(0, 8).map(itinerary => (
                  <ItineraryOverview
                    key={itinerary.id}
                    itinerary={itinerary}
                    feedback={feedback}
                  />
                ))}
              </div>
              {filteredItineraries.length === 0 && (
                <div className="text-center py-8">
                  <Calendar className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">No recent inspections</h3>
                  <p className="text-gray-400">Inspection itineraries will appear here once they are scheduled and completed.</p>
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="trends">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="orbit-card">
              <CardHeader>
                <CardTitle className="text-white">Rating Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={ratingDistribution}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="rating" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1F2937', 
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Bar dataKey="count" fill="#F59E0B" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="orbit-card">
              <CardHeader>
                <CardTitle className="text-white">Monthly Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={trendsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="month" stroke="#9CA3AF" />
                    <YAxis domain={[1, 5]} stroke="#9CA3AF" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1F2937', 
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Line type="monotone" dataKey="avgRating" stroke="#10B981" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}