import React, { useState, useEffect } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import MapLite from "@/components/inspection/MapLite";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, MapPin, Clock, Send, CheckCircle } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

export default function InspectionShared() {
  const { packId } = useParams();
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  
  const [pack, setPack] = useState(null);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState({});
  const [questions, setQuestions] = useState({});
  const [attendeeInfo, setAttendeeInfo] = useState({ name: '', email: '' });
  const [mine, setMine] = useState({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    async function loadPack() {
      setLoading(true);
      try {
        const { data } = await window.base44.functions.getInspectionPackShared({ id: packId, token });
        setPack(data);
        
        // Load existing feedback for this user
        if (attendeeInfo.email) {
          const feedbackResult = await window.base44.functions.listInspectionFeedback({ id: packId });
          const myFeedback = {};
          const meEmail = attendeeInfo.email.toLowerCase();
          (feedbackResult.items || []).filter(x => x.attendeeEmail === meEmail).forEach(x => {
            myFeedback[x.stopId] = x;
          });
          setMine(myFeedback);
        }
      } catch (e) {
        toast({ variant: "destructive", title: "Error", description: "Could not load inspection pack." });
      } finally {
        setLoading(false);
      }
    }
    
    if (packId && token) {
      loadPack();
    }
  }, [packId, token, attendeeInfo.email]);

  const submitFeedback = async (stopId) => {
    if (!attendeeInfo.email) {
      toast({ variant: "destructive", title: "Email required", description: "Please enter your email address." });
      return;
    }

    setSubmitting(true);
    try {
      await window.base44.functions.submitInspectionFeedback({
        id: packId,
        token,
        stopId,
        attendee: attendeeInfo,
        feedback: feedback[stopId] || '',
        questions: questions[stopId] || ''
      });
      
      // Update mine state to show submitted feedback
      setMine(prev => ({
        ...prev,
        [stopId]: {
          feedback: feedback[stopId] || '',
          questions: questions[stopId] || '',
          attendeeName: attendeeInfo.name,
          attendeeEmail: attendeeInfo.email
        }
      }));
      
      toast({ title: "Feedback submitted", description: "Thank you for your input!" });
    } catch (e) {
      toast({ variant: "destructive", title: "Failed to submit", description: e.message });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="p-6 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto text-white" /></div>;
  if (!pack) return <div className="p-6 text-center text-red-400">Inspection pack not found.</div>;

  const stops = pack.stops || [];
  const props = stops.filter(s => s.type === "property");

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 p-4 sm:p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card className="card">
          <CardHeader>
            <CardTitle className="text-white text-xl">{pack.title}</CardTitle>
            <div className="flex items-center gap-4">
              <Badge className="bg-blue-600">
                <MapPin className="w-3 h-3 mr-1" />
                {props.length} Properties
              </Badge>
              <Badge className="bg-purple-600">
                <Clock className="w-3 h-3 mr-1" />
                {new Date(pack.startISO).toLocaleDateString()}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <MapLite points={props.map(p => ({ lat: p.lat, lng: p.lng, label: p.title }))} />
          </CardContent>
        </Card>

        {/* Attendee Info */}
        <Card className="card">
          <CardHeader>
            <CardTitle className="text-white text-lg">Your Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name" className="text-gray-300">Name (Optional)</Label>
                <Input
                  id="name"
                  value={attendeeInfo.name}
                  onChange={(e) => setAttendeeInfo(prev => ({ ...prev, name: e.target.value }))}
                  className="orbit-input text-white mt-1"
                  placeholder="Your name"
                />
              </div>
              <div>
                <Label htmlFor="email" className="text-gray-300">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={attendeeInfo.email}
                  onChange={(e) => setAttendeeInfo(prev => ({ ...prev, email: e.target.value }))}
                  className="orbit-input text-white mt-1"
                  placeholder="your.email@company.com"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Inspection Criteria */}
        {pack.criteria && pack.criteria.length > 0 && (
          <Card className="card">
            <CardHeader>
              <CardTitle className="text-white text-lg">Inspection Criteria</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {pack.criteria.map((criterion, idx) => (
                  <li key={idx} className="text-gray-300 flex items-start">
                    <span className="text-orange-400 mr-2">•</span>
                    {criterion}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        {/* Property Stops */}
        <div className="space-y-6">
          {props.map((stop, idx) => (
            <Card key={stop.id} className="card">
              <CardHeader>
                <CardTitle className="text-white">
                  {idx + 1}. {stop.title}
                </CardTitle>
                {stop.arrival && (
                  <div className="text-gray-400 text-sm">
                    {new Date(stop.arrival).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} - {new Date(stop.depart).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </div>
                )}
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Show existing feedback if already submitted */}
                {mine[stop.id] && (
                  <div className="bg-green-900/20 border border-green-700 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-4 h-4 text-green-400" />
                      <span className="text-green-400 font-medium">Feedback Submitted</span>
                    </div>
                    {mine[stop.id].feedback && (
                      <div className="text-sm text-gray-300 mb-1">
                        <span className="font-medium">Feedback:</span> {mine[stop.id].feedback}
                      </div>
                    )}
                    {mine[stop.id].questions && (
                      <div className="text-sm text-gray-300">
                        <span className="font-medium">Questions:</span> {mine[stop.id].questions}
                      </div>
                    )}
                  </div>
                )}

                {/* Feedback Form */}
                <div className="space-y-3">
                  <div>
                    <Label className="text-gray-300">Your Feedback</Label>
                    <Textarea
                      value={feedback[stop.id] || ''}
                      onChange={(e) => setFeedback(prev => ({ ...prev, [stop.id]: e.target.value }))}
                      className="orbit-input text-white mt-1"
                      rows={3}
                      placeholder="Share your thoughts about this property..."
                    />
                  </div>
                  
                  <div>
                    <Label className="text-gray-300">Questions or Concerns</Label>
                    <Textarea
                      value={questions[stop.id] || ''}
                      onChange={(e) => setQuestions(prev => ({ ...prev, [stop.id]: e.target.value }))}
                      className="orbit-input text-white mt-1"
                      rows={2}
                      placeholder="Any questions about this property?"
                    />
                  </div>
                  
                  <Button
                    onClick={() => submitFeedback(stop.id)}
                    disabled={submitting || !attendeeInfo.email}
                    className="orbit-button-primary"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {submitting ? 'Submitting...' : 'Submit Feedback'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}