import React from "react";
import { useListingsSearch } from "@/components/state/useListingsSearch";
import MapCluster from "@/components/map/MapCluster";
import ListingCard from "@/components/listings/ListingCard";
import VirtualList from "@/components/listings/VirtualList";
import { Search, Filter, MapPin } from "lucide-react";

function Filters() {
  const s = useListingsSearch();
  
  const apply = () => {
    s.set("page", 1);
    s.search();
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      apply();
    }
  };

  return (
    <div className="orbit-card p-4 space-y-4">
      <div className="flex items-center gap-2 mb-3">
        <Filter className="w-4 h-4 text-orange-400" />
        <h3 className="text-sm font-semibold text-white">Search & Filter</h3>
      </div>
      
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input 
          className="orbit-input w-full pl-10" 
          placeholder="Search properties..." 
          value={s.q} 
          onChange={e => s.set("q", e.target.value)} 
          onKeyDown={handleKeyPress}
        />
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <label className="text-xs text-gray-400">Min Size (m²)</label>
          <input 
            className="orbit-input w-full" 
            type="number" 
            placeholder="Any" 
            value={s.minSize || ""} 
            onChange={e => s.set("minSize", e.target.value ? Number(e.target.value) : undefined)} 
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs text-gray-400">Max Size (m²)</label>
          <input 
            className="orbit-input w-full" 
            type="number" 
            placeholder="Any" 
            value={s.maxSize || ""} 
            onChange={e => s.set("maxSize", e.target.value ? Number(e.target.value) : undefined)} 
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs text-gray-400">Min Rent (AUD/m²)</label>
          <input 
            className="orbit-input w-full" 
            type="number" 
            placeholder="Any" 
            value={s.minRent || ""} 
            onChange={e => s.set("minRent", e.target.value ? Number(e.target.value) : undefined)} 
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs text-gray-400">Max Rent (AUD/m²)</label>
          <input 
            className="orbit-input w-full" 
            type="number" 
            placeholder="Any" 
            value={s.maxRent || ""} 
            onChange={e => s.set("maxRent", e.target.value ? Number(e.target.value) : undefined)} 
          />
        </div>
      </div>
      
      <div className="flex justify-end">
        <button 
          className="orbit-button-primary px-4 py-2 text-sm"
          onClick={apply}
        >
          Apply Filters
        </button>
      </div>
    </div>
  );
}

export default function ListingsExplore() {
  const s = useListingsSearch();

  // Extract complex expressions to separate variables for dependency array
  const gradeString = JSON.stringify(s.grade);
  const statusString = JSON.stringify(s.status);
  const bboxString = JSON.stringify(s.bbox);

  React.useEffect(() => {
    const timer = setTimeout(() => {
      s.search();
    }, 150);
    return () => clearTimeout(timer);
  }, [s.q, s.minSize, s.maxSize, s.minRent, s.maxRent, gradeString, statusString, bboxString, s.page, s.search]);

  const renderListItem = (item, index) => (
    <div className="p-2">
      <ListingCard 
        item={item} 
        onOpen={(id) => window.location.href = `/listings/${id}`}
      />
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      <div className="space-header">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-orange-600/20">
            <MapPin className="w-6 h-6 text-orange-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Property Listings</h1>
            <p className="text-gray-400">Explore available commercial properties</p>
          </div>
        </div>
      </div>
      
      <div className="grid lg:grid-cols-[420px_1fr] gap-6">
        {/* Left Panel: Filters + List */}
        <div className="space-y-4">
          <Filters />
          
          <div className="orbit-card p-3">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm text-gray-300">
                {s.loading ? (
                  "Searching..."
                ) : (
                  `${s.total.toLocaleString()} results • Page ${s.page}`
                )}
              </div>
            </div>
            
            <VirtualList
              items={s.items}
              itemHeight={180}
              containerHeight={Math.min(600, window.innerHeight - 300)}
              renderItem={renderListItem}
              loading={s.loading}
            />
            
            {s.items.length > 0 && (
              <div className="flex justify-between items-center pt-3 mt-3 border-t border-white/10">
                <button 
                  className="orbit-button px-3 py-1 text-sm" 
                  disabled={s.page <= 1} 
                  onClick={() => s.set("page", s.page - 1)}
                >
                  Previous
                </button>
                <span className="text-xs text-gray-400">
                  Page {s.page} of {Math.ceil(s.total / s.pageSize)}
                </span>
                <button 
                  className="orbit-button px-3 py-1 text-sm" 
                  disabled={s.page * s.pageSize >= s.total} 
                  onClick={() => s.set("page", s.page + 1)}
                >
                  Next
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Panel: Map */}
        <div className="orbit-card p-4 h-[calc(100vh-150px)]">
          <div className="flex items-center gap-2 mb-4">
            <MapPin className="w-4 h-4 text-orange-400" />
            <h3 className="text-sm font-semibold text-white">Map View</h3>
            <div className="text-xs text-gray-400">
              ({s.items.length} properties shown)
            </div>
          </div>
          
          <div className="h-full rounded-lg overflow-hidden">
            <MapCluster
              points={s.items.map(item => ({
                id: item.id,
                lat: item.lat,
                lng: item.lng,
                title: item.title
              }))}
              onBoundsChange={(bbox) => s.setBBox(bbox)}
              onSelect={(id) => window.location.href = `/listings/${id}`}
            />
          </div>
        </div>
      </div>
    </div>
  );
}