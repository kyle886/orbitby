
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { DevCase } from '@/api/entities';
import { Scenario } from '@/api/entities';
import { DevChecklistItem } from '@/api/entities';
import { Subcontractor } from '@/api/entities';
import { User } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, 
  Plus, 
  Calculator, 
  CheckSquare, 
  Users, 
  FileText,
  TrendingUp,
  Building,
  DollarSign,
  Clock,
  AlertTriangle
} from 'lucide-react';
import ScenarioForm from '@/components/dev/ScenarioForm';
import DecisionMatrix from '@/components/dev/DecisionMatrix';

const STATE_CONFIG = {
  'Screening': { color: 'bg-gray-500/20 text-gray-300', description: 'Initial assessment' },
  'Analysis': { color: 'bg-blue-500/20 text-blue-300', description: 'Detailed analysis in progress' },
  'PartnerSelect': { color: 'bg-yellow-500/20 text-yellow-300', description: 'Selecting partners' },
  'Approvals': { color: 'bg-orange-500/20 text-orange-300', description: 'Seeking approvals' },
  'Design': { color: 'bg-purple-500/20 text-purple-300', description: 'Design phase' },
  'Tender': { color: 'bg-pink-500/20 text-pink-300', description: 'Tender process' },
  'Construction': { color: 'bg-red-500/20 text-red-300', description: 'Under construction' },
  'Commissioning': { color: 'bg-green-500/20 text-green-300', description: 'Commissioning' },
  'Operational': { color: 'bg-emerald-500/20 text-emerald-300', description: 'Operational' }
};

export default function DevCasePage() {
  const [searchParams] = useSearchParams();
  const devCaseId = searchParams.get('id');
  
  const [devCase, setDevCase] = useState(null);
  const [scenarios, setScenarios] = useState([]);
  const [checklistItems, setChecklistItems] = useState([]);
  const [subcontractors, setSubcontractors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [showScenarioForm, setShowScenarioForm] = useState(false);
  const [editForm, setEditForm] = useState({});
  const [activeTab, setActiveTab] = useState('overview');

  const loadDevCase = useCallback(async () => {
    if (!devCaseId) {
      setLoading(false);
      return;
    }

    try {
      const [caseData, scenarioData, checklistData, contractorData] = await Promise.all([
        DevCase.get(devCaseId),
        Scenario.filter({ devcase_id: devCaseId }),
        DevChecklistItem.filter({ devcase_id: devCaseId }),
        Subcontractor.filter({ devcase_id: devCaseId })
      ]);

      setDevCase(caseData);
      setScenarios(scenarioData || []);
      setChecklistItems(checklistData || []);
      setSubcontractors(contractorData || []);
      setEditForm(caseData || {});
    } catch (error) {
      console.error('Failed to load dev case:', error);
    } finally {
      setLoading(false);
    }
  }, [devCaseId]);

  useEffect(() => {
    loadDevCase();
  }, [loadDevCase]);

  const updateDevCase = async () => {
    try {
      const updated = await DevCase.update(devCaseId, editForm);
      setDevCase(updated);
      setEditing(false);
    } catch (error) {
      console.error('Failed to update dev case:', error);
    }
  };

  const addChecklistItem = async (phase, item) => {
    try {
      const user = await User.me();
      const newItem = await DevChecklistItem.create({
        devcase_id: devCaseId,
        phase,
        item,
        owner_user_id: user.id,
        status: 'open'
      });
      setChecklistItems([...checklistItems, newItem]);
    } catch (error) {
      console.error('Failed to add checklist item:', error);
    }
  };

  const toggleChecklistItem = async (itemId, currentStatus) => {
    try {
      const newStatus = currentStatus === 'open' ? 'done' : 'open';
      const updated = await DevChecklistItem.update(itemId, { status: newStatus });
      setChecklistItems(checklistItems.map(item => 
        item.id === itemId ? { ...item, status: newStatus } : item
      ));
    } catch (error) {
      console.error('Failed to update checklist item:', error);
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-700 rounded w-1/3"></div>
          <div className="h-64 bg-gray-700 rounded"></div>
        </div>
      </div>
    );
  }

  if (!devCase) {
    return (
      <div className="p-8">
        <div className="text-center">
          <Building className="w-16 h-16 mx-auto mb-4 text-gray-500" />
          <h2 className="text-xl font-semibold text-white mb-2">Development Case Not Found</h2>
          <Link to="/DevelopmentFeasibility">
            <Button variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Development Cases
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const stateConfig = STATE_CONFIG[devCase.state] || STATE_CONFIG['Screening'];
  const bestScenario = scenarios.reduce((best, scenario) => {
    if (!best) return scenario;
    return (scenario.npv_aud || 0) > (best.npv_aud || 0) ? scenario : best;
  }, null);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-4 mb-2">
            <Link to="/DevelopmentFeasibility">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <Badge className={stateConfig.color}>
              {devCase.state}
            </Badge>
          </div>
          
          {editing ? (
            <div className="space-y-4 max-w-2xl">
              <Input
                value={editForm.name || ''}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                className="text-2xl font-bold bg-transparent border-none p-0 text-white"
                placeholder="Development case name..."
              />
              <Textarea
                value={editForm.notes || ''}
                onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                placeholder="Add notes about this development case..."
                className="min-h-[100px]"
              />
              <div className="flex gap-2">
                <Button onClick={updateDevCase} size="sm">Save</Button>
                <Button variant="outline" onClick={() => setEditing(false)} size="sm">Cancel</Button>
              </div>
            </div>
          ) : (
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">{devCase.name}</h1>
              <p className="text-gray-400 mb-4">{stateConfig.description}</p>
              {devCase.notes && (
                <p className="text-gray-300 mb-4">{devCase.notes}</p>
              )}
              <Button variant="outline" onClick={() => setEditing(true)} size="sm">
                Edit Details
              </Button>
            </div>
          )}
        </div>

        <div className="flex gap-3">
          <Select value={devCase.decision} onValueChange={(value) => 
            DevCase.update(devCaseId, { decision: value }).then(() => 
              setDevCase({ ...devCase, decision: value })
            )
          }>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Undecided">Undecided</SelectItem>
              <SelectItem value="Lease">Lease</SelectItem>
              <SelectItem value="Buy">Buy</SelectItem>
              <SelectItem value="Develop">Develop</SelectItem>
              <SelectItem value="Hybrid">Hybrid</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="surface">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/20">
                <DollarSign className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <div className="text-lg font-bold text-white">
                  ${bestScenario ? (bestScenario.npv_aud / 1000000).toFixed(1) : '0'}M
                </div>
                <div className="text-xs text-gray-400">Best NPV</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="surface">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/20">
                <Calculator className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <div className="text-lg font-bold text-white">{scenarios.length}</div>
                <div className="text-xs text-gray-400">Scenarios</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="surface">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/20">
                <CheckSquare className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <div className="text-lg font-bold text-white">
                  {checklistItems.filter(i => i.status === 'done').length}/{checklistItems.length}
                </div>
                <div className="text-xs text-gray-400">Tasks Done</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="surface">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/20">
                <Users className="w-5 h-5 text-orange-400" />
              </div>
              <div>
                <div className="text-lg font-bold text-white">{subcontractors.length}</div>
                <div className="text-xs text-gray-400">Partners</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
          <TabsTrigger value="checklist">Checklist</TabsTrigger>
          <TabsTrigger value="partners">Partners</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <DecisionMatrix scenarios={scenarios} />
          
          {bestScenario && (
            <Card className="surface">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Recommended Scenario: {bestScenario.name}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">
                      ${(bestScenario.npv_aud / 1000000).toFixed(1)}M
                    </div>
                    <div className="text-sm text-gray-400">Net Present Value</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">
                      {bestScenario.irr_pct?.toFixed(1) || 'N/A'}%
                    </div>
                    <div className="text-sm text-gray-400">Internal Rate of Return</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-400">
                      {bestScenario.payback_years?.toFixed(1) || 'N/A'}
                    </div>
                    <div className="text-sm text-gray-400">Payback (Years)</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="scenarios" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-white">Financial Scenarios</h3>
            <Button onClick={() => setShowScenarioForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Scenario
            </Button>
          </div>

          <div className="grid gap-6">
            {scenarios.map(scenario => (
              <Card key={scenario.id} className="surface">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-white">{scenario.name}</CardTitle>
                      <Badge variant="outline" className="mt-1">
                        {scenario.type}
                      </Badge>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-green-400">
                        NPV: ${scenario.npv_aud ? (scenario.npv_aud / 1000000).toFixed(1) : '0'}M
                      </div>
                      <div className="text-sm text-gray-400">
                        IRR: {scenario.irr_pct?.toFixed(1) || 'N/A'}%
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Payback Period:</span>
                      <div className="font-medium text-white">
                        {scenario.payback_years?.toFixed(1) || 'N/A'} years
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-400">Total Investment:</span>
                      <div className="font-medium text-white">
                        ${scenario.inputs_json?.total_cost ? (scenario.inputs_json.total_cost / 1000000).toFixed(1) : 'N/A'}M
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-400">Annual Yield:</span>
                      <div className="font-medium text-white">
                        {scenario.inputs_json?.yield_pct?.toFixed(1) || 'N/A'}%
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {showScenarioForm && (
            <ScenarioForm
              devCaseId={devCaseId}
              onSave={(newScenario) => {
                setScenarios([...scenarios, newScenario]);
                setShowScenarioForm(false);
              }}
              onCancel={() => setShowScenarioForm(false)}
            />
          )}
        </TabsContent>

        <TabsContent value="checklist" className="space-y-6">
          <div className="space-y-4">
            {Object.entries(STATE_CONFIG).map(([phase, config]) => {
              const phaseItems = checklistItems.filter(item => item.phase === phase);
              return (
                <Card key={phase} className="surface">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center justify-between">
                      <span>{phase} Phase</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const item = prompt(`Add task for ${phase} phase:`);
                          if (item) addChecklistItem(phase, item);
                        }}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Task
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {phaseItems.length === 0 ? (
                        <p className="text-gray-400 text-sm">No tasks yet for this phase</p>
                      ) : (
                        phaseItems.map(item => (
                          <div
                            key={item.id}
                            className="flex items-center gap-3 p-3 rounded-lg border border-white/10"
                          >
                            <input
                              type="checkbox"
                              checked={item.status === 'done'}
                              onChange={() => toggleChecklistItem(item.id, item.status)}
                              className="w-4 h-4 rounded"
                            />
                            <span className={`flex-1 ${item.status === 'done' ? 'line-through text-gray-400' : 'text-white'}`}>
                              {item.item}
                            </span>
                            {item.due_dt && (
                              <div className="text-xs text-gray-400 flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {new Date(item.due_dt).toLocaleDateString()}
                              </div>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="partners" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-white">Project Partners</h3>
            <Button
              onClick={() => {
                // Add partner form logic here
                console.log('Add partner');
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Partner
            </Button>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {subcontractors.map(contractor => (
              <Card key={contractor.id} className="surface">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h4 className="font-medium text-white">{contractor.company_name}</h4>
                      <Badge variant="outline" className="text-xs mt-1">
                        {contractor.trade}
                      </Badge>
                    </div>
                    <Badge className={contractor.status === 'appointed' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'}>
                      {contractor.status}
                    </Badge>
                  </div>
                  
                  {contractor.contract_value_aud && (
                    <div className="text-sm">
                      <span className="text-gray-400">Contract Value: </span>
                      <span className="font-medium text-white">
                        ${(contractor.contract_value_aud / 1000).toLocaleString()}k
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {subcontractors.length === 0 && (
            <div className="text-center py-12">
              <Users className="w-12 h-12 mx-auto mb-4 text-gray-500" />
              <h4 className="text-lg font-medium text-white mb-2">No Partners Yet</h4>
              <p className="text-gray-400">Add project partners and subcontractors to track progress.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
