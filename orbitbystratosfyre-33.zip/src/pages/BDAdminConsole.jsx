import React from "react";
import { Navigate } from "react-router-dom";

// Redirect to unified SystemOperations page
export default function BDAdminConsole() {
  return <Navigate to="/SystemOperations" replace />;
}