import React, { useState, useEffect, useMemo } from 'react';
import { Company } from '@/api/entities';
import { Building } from '@/api/entities';
import { Tenancy } from '@/api/entities';
import { Signal } from '@/api/entities';
import { JobRun } from '@/api/entities';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Loader2, Check, X, Trash2, ChevronDown, Merge } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { runJob } from '@/components/utils/runJob';
import { mergeAndReparent } from '@/components/utils/data/mergeUtils';

const DuplicateComparison = ({ duplicate }) => {
  const { type, record1, record2 } = duplicate;

  const renderFieldComparison = (label, value1, value2) => {
    const isDifferent = String(value1 || '').trim().toLowerCase() !== String(value2 || '').trim().toLowerCase();
    return (
      <div className="grid grid-cols-1 md:grid-cols-11 gap-4 py-3 border-b border-gray-700/60 last:border-b-0">
        <div className="md:col-span-3 text-sm font-medium text-gray-400">{label}</div>
        <div className={`md:col-span-4 text-sm text-white bg-gray-800/50 p-2 rounded-md ${isDifferent ? 'ring-2 ring-amber-500/50' : 'opacity-70'}`}>{value1 || <span className="text-gray-500">N/A</span>}</div>
        <div className={`md:col-span-4 text-sm text-white bg-gray-800/50 p-2 rounded-md ${isDifferent ? 'ring-2 ring-amber-500/50' : 'opacity-70'}`}>{value2 || <span className="text-gray-500">N/A</span>}</div>
      </div>
    );
  };

  const getFieldsForType = (rec1, rec2) => {
    switch (type) {
      case 'Company':
        return [
          { label: 'Name', v1: rec1.name, v2: rec2.name },
          { label: 'Website', v1: rec1.website, v2: rec2.website },
          { label: 'Sector', v1: rec1.sector, v2: rec2.sector },
        ];
      case 'Building':
        return [
          { label: 'Name', v1: rec1.name, v2: rec2.name },
          { label: 'Address', v1: rec1.address, v2: rec2.address },
          { label: 'Suburb', v1: rec1.suburb, v2: rec2.suburb },
          { label: 'Grade', v1: rec1.grade, v2: rec2.grade },
        ];
      case 'Tenancy':
        return [
          { label: 'Floor', v1: rec1.floor, v2: rec2.floor },
          { label: 'Suite', v1: rec1.suite, v2: rec2.suite },
          { label: 'Size (sqm)', v1: rec1.size_sqm, v2: rec2.size_sqm },
        ];
      case 'Signal':
        return [
          { label: 'Name', v1: rec1.name, v2: rec2.name },
          { label: 'Type', v1: rec1.type, v2: rec2.type },
          { label: 'Date', v1: rec1.date, v2: rec2.date },
        ];
      default:
        // Fallback for unexpected types or if specific fields are not defined
        const keys1 = Object.keys(rec1 || {});
        const keys2 = Object.keys(rec2 || {});
        const commonKeys = Array.from(new Set([...keys1, ...keys2]));
        return commonKeys.filter(key => key !== 'id' && key !== '__typename').slice(0, 5).map(key => ({
            label: key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, ' '),
            v1: rec1[key],
            v2: rec2[key]
        }));
    }
  };

  const fields = getFieldsForType(record1, record2);

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-1 md:grid-cols-11 gap-4 text-xs font-semibold text-gray-300 px-2">
        <div className="md:col-span-3">Field</div>
        <div className="md:col-span-4">Record 1 (Winner)</div>
        <div className="md:col-span-4">Record 2 (Loser)</div>
      </div>
      {fields.map((f, index) => renderFieldComparison(f.label, f.v1, f.v2))}
    </div>
  );
};


export default function DuplicateReview() {
  const [duplicates, setDuplicates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [selected, setSelected] = useState(new Set());
  const [processingId, setProcessingId] = useState(null);
  const { toast } = useToast();

  const groupedDuplicates = useMemo(() => {
    const groups = {};
    duplicates.forEach(d => {
      if (!groups[d.type]) {
        groups[d.type] = [];
      }
      groups[d.type].push(d);
    });
    return groups;
  }, [duplicates]);

  const loadDuplicates = React.useCallback(async () => {
    setLoading(true);
    try {
      // Find the most recent successful duplicate scan job
      const recentJobs = await JobRun.filter({ job_name: 'Scan for Duplicates', status: 'success' }, '-finished_at', 1);

      if (recentJobs.length === 0 || !recentJobs[0].results) {
        toast({
          title: "No Scan Results Found",
          description: "Run a 'Scan for Duplicates' job from the Admin Console to see results here.",
        });
        setDuplicates([]);
        return;
      }
      
      const scanResults = recentJobs[0].results;
      const allDuplicates = [
        ...(scanResults.companies || []),
        ...(scanResults.buildings || []),
        ...(scanResults.tenancies || []),
        ...(scanResults.signals || []),
      ].map((d, index) => ({ ...d, id: d.id || `${d.type}-${index}` })); // Ensure a unique ID for keys

      setDuplicates(allDuplicates);
      
      // Show summary of what was auto-processed
      if (scanResults.auto_deleted > 0) {
        toast({
          title: "Auto-Processing Complete",
          description: `${scanResults.auto_deleted} perfect matches were automatically deleted. ${allDuplicates.length} duplicates remain for your review.`,
        });
      }
      
    } catch (error) {
      console.error("Error loading duplicates:", error);
      toast({
        variant: "destructive",
        title: "Load Failed",
        description: "Could not load duplicate scan results."
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadDuplicates();
  }, [loadDuplicates]);

  const toggleSelection = (duplicateId) => {
    setSelected(prev => {
      const newSet = new Set(prev);
      if (newSet.has(duplicateId)) {
        newSet.delete(duplicateId);
      } else {
        newSet.add(duplicateId);
      }
      return newSet;
    });
  };

  const toggleSelectAllForGroup = (groupType) => {
    const groupIds = groupedDuplicates[groupType]?.map(d => d.id) || [];
    const allSelectedInGroup = groupIds.every(id => selected.has(id));

    setSelected(prev => {
      const newSet = new Set(prev);
      if (allSelectedInGroup) {
        groupIds.forEach(id => newSet.delete(id));
      } else {
        groupIds.forEach(id => newSet.add(id));
      }
      return newSet;
    });
  };

  const handleBulkDelete = async () => {
    setProcessing(true);
    const selectedItems = duplicates.filter(d => selected.has(d.id));
    
    let successCount = 0;
    for (const item of selectedItems) {
      try {
        await handleMerge(item);
        successCount++;
      } catch (e) {
        // Error is toasted inside handleMerge
      }
    }
    
    toast({
        title: `Bulk Merge Complete`,
        description: `${successCount} of ${selectedItems.length} items merged successfully.`
    });
    setSelected(new Set());
    setProcessing(false);
  };
  
  const handleMerge = async (duplicate) => {
    setProcessingId(duplicate.id);
    try {
      await runJob(`Merge Duplicate: ${duplicate.type} ${duplicate.record2.id}`, async () => {
        return await mergeAndReparent(duplicate.type, duplicate.record1, duplicate.record2);
      });

      setDuplicates(prev => prev.filter(d => d.id !== duplicate.id));
      setSelected(prev => {
        const newSet = new Set(prev);
        newSet.delete(duplicate.id);
        return newSet;
      });

      toast({
          title: "Merge Successful",
          description: `${duplicate.type} record ${duplicate.record2.id} was merged into ${duplicate.record1.id}.`,
      });
    } catch (error) {
      console.error("Error merging duplicate:", error);
      toast({
        variant: "destructive",
        title: "Merge Failed",
        description: `Could not merge duplicate: ${error.message || 'Unknown error'}`
      });
    } finally {
      setProcessingId(null);
    }
  };

  const handleRejectDeletion = (duplicate) => {
    setDuplicates(prev => prev.filter(d => d.id !== duplicate.id));
    toast({
        title: "Marked as Not Duplicate",
        description: "The records will be kept as separate entities."
    });
  };

  if (loading) {
    return (
      <div className="p-8 min-h-screen bg-void flex justify-center items-center">
        <Loader2 className="w-12 h-12 animate-spin text-orange-400" />
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-8 min-h-screen bg-void">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Duplicate Review</h1>
          <p className="text-gray-300">Review potential duplicates. Merging will transfer all related records from the loser to the winner before deleting it.</p>
        </div>

        {duplicates.length === 0 ? (
          <Alert className="bg-green-900/30 border-green-700/50">
            <Check className="h-4 w-4 text-green-400" />
            <AlertDescription className="text-green-200">
              No duplicates found that require manual review. Run a new scan from the Admin Console to check for new duplicates.
            </AlertDescription>
          </Alert>
        ) : (
          <>
            <Card className="orbit-card mb-6 p-4">
              <div className="flex items-center gap-4">
                  <p className="text-sm font-medium text-white">{selected.size} item(s) selected</p>
                  <Button
                    size="sm"
                    onClick={handleBulkDelete}
                    disabled={selected.size === 0 || processing}
                    className="bg-orange-600 hover:bg-orange-700 text-white"
                  >
                    {processing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Merge className="w-4 h-4 mr-2" />}
                    Bulk Merge Selected
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => { setSelected(new Set())}}
                    disabled={selected.size === 0 || processing}
                    className="text-gray-300 hover:text-white"
                  >
                     <X className="w-4 h-4 mr-2" />
                    Clear Selection
                  </Button>
              </div>
            </Card>

            <div className="space-y-8">
              {Object.entries(groupedDuplicates).map(([type, group]) => {
                const isAllSelected = group.every(d => selected.has(d.id));
                const isIndeterminate = !isAllSelected && group.some(d => selected.has(d.id));

                return (
                  <div key={type}>
                    <div className="flex items-center gap-3 mb-4">
                       <Checkbox
                          checked={isAllSelected}
                          onCheckedChange={() => toggleSelectAllForGroup(type)}
                          aria-label={`Select all ${type} duplicates`}
                          data-state={isIndeterminate ? 'indeterminate' : (isAllSelected ? 'checked' : 'unchecked')}
                          className="data-[state=indeterminate]:bg-amber-500"
                        />
                      <h2 className="text-xl font-semibold text-white">{type} Duplicates</h2>
                      <Badge variant="secondary">{group.length}</Badge>
                    </div>
                    <Accordion type="multiple" className="space-y-4">
                      {group.map((duplicate) => {
                        const isCurrentProcessing = processingId === duplicate.id;
                        return (
                        <AccordionItem key={duplicate.id} value={duplicate.id} className="orbit-card p-0 border-none">
                          <AccordionTrigger className="p-4 hover:no-underline flex items-center gap-4 w-full">
                            <div className="flex items-center gap-4 flex-1">
                                <Checkbox
                                    checked={selected.has(duplicate.id)}
                                    onCheckedChange={() => toggleSelection(duplicate.id)}
                                    onClick={(e) => e.stopPropagation()} // prevent accordion from toggling
                                    aria-label="Select duplicate"
                                />
                                <div className="text-left">
                                    <p className="font-medium text-white">{duplicate.record1.name || duplicate.record1.address || duplicate.record1.id}</p>
                                    <p className="text-sm text-gray-400">vs. {duplicate.record2.name || duplicate.record2.address || duplicate.record2.id}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-4">
                                <Badge variant="secondary">{duplicate.similarity_score}% Match</Badge>
                                <ChevronDown className="h-4 w-4 shrink-0 transition-transform duration-200" />
                            </div>
                          </AccordionTrigger>
                          <AccordionContent className="px-4 pb-4">
                            <div className="flex flex-wrap gap-2 mb-4">
                                {duplicate.match_reasons.map((reason, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs border-amber-500/30 text-amber-200">
                                    {reason}
                                </Badge>
                                ))}
                            </div>
                            <DuplicateComparison duplicate={duplicate} />
                             <div className="flex justify-end gap-3 pt-4 mt-4 border-t border-gray-700/50">
                                <Button variant="outline" onClick={() => handleRejectDeletion(duplicate)} disabled={isCurrentProcessing} className="text-gray-300 hover:text-white">
                                    <X className="w-4 h-4 mr-2" /> Keep Both
                                </Button>
                                <Button onClick={() => handleMerge(duplicate)} disabled={isCurrentProcessing} className="bg-orange-600 hover:bg-orange-700 text-white">
                                    {isCurrentProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Merge className="w-4 h-4 mr-2" />}
                                    Merge & Delete Record 2
                                </Button>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      )})}
                    </Accordion>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}