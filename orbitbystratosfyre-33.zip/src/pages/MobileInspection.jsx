import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { InspectionItinerary } from '@/api/entities';
import { PropertySubmission } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { InspectionFeedback } from '@/api/entities';
import { User } from '@/api/entities';
import { Loader2, Star, Building, Send, CheckCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';

const StarRating = ({ rating, setRating, disabled = false }) => (
  <div className="flex gap-1">
    {[1, 2, 3, 4, 5].map((star) => (
      <Star
        key={star}
        className={`w-8 h-8 cursor-pointer transition-colors ${
          rating >= star ? 'text-yellow-400 fill-current' : 'text-gray-600'
        }`}
        onClick={() => !disabled && setRating(star)}
      />
    ))}
  </div>
);

export default function MobileInspection() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const itineraryId = searchParams.get('itineraryId');
  const propertyId = searchParams.get('propertyId');

  const [itinerary, setItinerary] = useState(null);
  const [property, setProperty] = useState(null);
  const [brief, setBrief] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [feedback, setFeedback] = useState({
    attendee_name: '',
    attendee_email: '',
    overall_rating: 0,
    criteria_ratings: {},
    notes: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadData = useCallback(async () => {
    if (!itineraryId || !propertyId) {
      setError("Missing itinerary or property ID.");
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const [itineraryData, propertyData, userData] = await Promise.all([
        InspectionItinerary.get(itineraryId),
        PropertySubmission.get(propertyId),
        User.me().catch(() => null)
      ]);

      setItinerary(itineraryData);
      setProperty(propertyData);

      if (userData) {
        setFeedback(prev => ({
          ...prev,
          attendee_name: userData.full_name || `${userData.first_name} ${userData.last_name}`,
          attendee_email: userData.email,
        }));
      }

      if (itineraryData.brief_id && itineraryData.brief_id !== 'confidential') {
        const briefData = await TenantRequirement.get(itineraryData.brief_id);
        setBrief(briefData);
        // Initialize criteria ratings
        if (briefData.top_5_criteria) {
          const initialCriteria = briefData.top_5_criteria.reduce((acc, _, index) => {
            acc[`criterion_${index + 1}`] = 0;
            return acc;
          }, {});
          setFeedback(prev => ({ ...prev, criteria_ratings: initialCriteria }));
        }
      }
    } catch (err) {
      console.error("Error loading inspection data:", err);
      setError("Failed to load inspection details.");
    } finally {
      setLoading(false);
    }
  }, [itineraryId, propertyId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleCriteriaRatingChange = (criterionKey, rating) => {
    setFeedback(prev => ({
      ...prev,
      criteria_ratings: {
        ...prev.criteria_ratings,
        [criterionKey]: rating
      }
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (feedback.overall_rating === 0) {
      toast({ variant: 'destructive', title: 'Incomplete', description: 'Please provide an overall rating.' });
      return;
    }
    if (!feedback.attendee_name || !feedback.attendee_email) {
      toast({ variant: 'destructive', title: 'Incomplete', description: 'Please enter your name and email.' });
      return;
    }
    
    setIsSubmitting(true);
    try {
      await InspectionFeedback.create({
        ...feedback,
        itinerary_id: itineraryId,
        property_submission_id: propertyId
      });
      setSubmitted(true);
      toast({ title: 'Success', description: 'Your feedback has been submitted.' });
    } catch (error) {
      console.error("Failed to submit feedback:", error);
      toast({ variant: 'destructive', title: 'Submission Failed', description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return <div className="p-8 text-center"><Loader2 className="w-12 h-12 animate-spin text-orange-400 mx-auto" /></div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-400">{error}</div>;
  }
  
  if (submitted) {
    return (
      <div className="p-8 min-h-screen bg-gray-900 flex flex-col items-center justify-center text-center text-white">
        <CheckCircle className="w-24 h-24 text-green-400 mb-6" />
        <h1 className="text-3xl font-bold mb-2">Thank You!</h1>
        <p className="text-gray-300 mb-8">Your feedback for {property.property_title} has been received.</p>
        <Button onClick={() => navigate(`/InspectionPack?token=${itinerary.share_token}`)}>
          Back to Itinerary
        </Button>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 min-h-screen bg-gray-900 text-white">
      <div className="max-w-2xl mx-auto">
        <header className="mb-6">
          <p className="text-orange-400 text-sm font-medium">Feedback Form</p>
          <h1 className="text-2xl sm:text-3xl font-bold text-white mt-1">{property.property_title}</h1>
          <p className="text-gray-400">{property.address}</p>
        </header>

        <form onSubmit={handleSubmit} className="space-y-8">
          <Card className="orbit-card">
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Your Name</Label>
                <Input 
                  id="name" 
                  value={feedback.attendee_name} 
                  onChange={e => setFeedback(f => ({...f, attendee_name: e.target.value}))}
                  className="orbit-input"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Your Email</Label>
                <Input 
                  id="email" 
                  type="email"
                  value={feedback.attendee_email} 
                  onChange={e => setFeedback(f => ({...f, attendee_email: e.target.value}))}
                  className="orbit-input"
                  required
                />
              </div>
            </CardContent>
          </Card>
          
          <Card className="orbit-card">
            <CardContent className="p-6 space-y-4">
              <div className="text-center">
                <Label className="text-lg">Overall Rating</Label>
                <div className="flex justify-center mt-2">
                  <StarRating rating={feedback.overall_rating} setRating={(r) => setFeedback(f => ({...f, overall_rating: r}))} />
                </div>
              </div>
            </CardContent>
          </Card>

          {brief && brief.top_5_criteria && brief.top_5_criteria.length > 0 && (
            <Card className="orbit-card">
              <CardContent className="p-6 space-y-6">
                <h3 className="text-lg font-medium text-center">Criteria Ratings</h3>
                {brief.top_5_criteria.map((criterion, index) => {
                  const criterionKey = `criterion_${index + 1}`;
                  return (
                    <div key={criterionKey} className="text-center sm:text-left sm:flex sm:items-center sm:justify-between">
                      <Label className="text-base mb-2 sm:mb-0">{criterion}</Label>
                      <StarRating 
                        rating={feedback.criteria_ratings[criterionKey] || 0}
                        setRating={(r) => handleCriteriaRatingChange(criterionKey, r)}
                      />
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          )}

          <Card className="orbit-card">
            <CardContent className="p-6 space-y-2">
              <Label htmlFor="notes" className="text-lg">Additional Notes</Label>
              <Textarea 
                id="notes"
                placeholder="Any other thoughts, pros, cons, or questions?"
                value={feedback.notes}
                onChange={e => setFeedback(f => ({...f, notes: e.target.value}))}
                className="orbit-input h-32"
              />
            </CardContent>
          </Card>

          <div className="flex flex-col gap-3">
            <Button type="submit" size="lg" disabled={isSubmitting} className="w-full bg-orange-600 hover:bg-orange-700">
              {isSubmitting ? (
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              ) : (
                <Send className="w-5 h-5 mr-2" />
              )}
              Submit Feedback
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => navigate(`/InspectionPack?token=${itinerary.share_token}`)}
              className="w-full"
            >
              Back to Itinerary
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}