
import React, { useState, useEffect, useCallback } from 'react';
import { Target } from '@/api/entities';
import { Company } from '@/api/entities';
import { Lease } from '@/api/entities';
import { Loader2, Calendar, Save, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

export default function LeaseHygiene() {
  const [targets, setTargets] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const topTargets = await Target.filter({ is_top_20: true }, '-priority_score');
      const companies = await Company.list();
      const leases = await Lease.list();

      const combinedData = topTargets.map(target => {
        const company = companies.find(c => c.id === target.company_id);
        const lease = leases.find(l => l.company_id === target.company_id);
        return {
          targetId: target.id,
          companyId: company?.id,
          companyName: company?.name || 'Unknown Company',
          leaseId: lease?.id,
          expiryDate: lease?.expiry_date || '',
        };
      }).filter(item => !item.expiryDate); // Only show those missing an expiry date

      setTargets(combinedData);
    } catch (error) {
      console.error("Error fetching data for lease hygiene:", error);
      toast({ variant: 'destructive', title: 'Failed to load data.' });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleDateChange = (index, value) => {
    const updatedTargets = [...targets];
    updatedTargets[index].expiryDate = value;
    setTargets(updatedTargets);
  };

  const handleSave = async (item) => {
    if (!item.companyId || !item.expiryDate) {
      toast({ variant: 'destructive', title: 'Missing Information', description: 'Company or expiry date is missing.' });
      return;
    }

    try {
      if (item.leaseId) {
        // Update existing lease
        await Lease.update(item.leaseId, { expiry_date: item.expiryDate });
      } else {
        // Create new lease record
        // We might be missing some required fields like building_id. This is a simplification.
        await Lease.create({ 
            company_id: item.companyId, 
            expiry_date: item.expiryDate,
            source: 'manual_hygiene_entry' 
        });
      }
      toast({ title: 'Lease Updated', description: `Expiry date for ${item.companyName} saved.` });
      fetchData(); // Refresh the list
    } catch (error) {
      console.error("Error saving lease data:", error);
      toast({ variant: 'destructive', title: 'Save Failed' });
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-64"><Loader2 className="w-12 h-12 animate-spin text-orange-400" /></div>;
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="mb-8">
        <h1 className="stratos-h1 mb-2">Lease Expiry Hygiene</h1>
        <p className="stratos-body">Update missing lease expiry dates for your Top-20 targets to improve priority scoring.</p>
      </div>

      <div className="orbit-card">
        {targets.length === 0 ? (
          <div className="p-12 text-center">
            <Calendar className="w-12 h-12 mx-auto text-green-500 mb-4" />
            <h3 className="text-xl font-medium text-white mb-2">All Clear!</h3>
            <p className="text-gray-400">All Top-20 targets have a lease expiry date recorded.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm stratos-table">
              <thead>
                <tr>
                  <th className="p-4 text-left">Company</th>
                  <th className="p-4 text-left">Set Expiry Date</th>
                  <th className="p-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {targets.map((item, index) => (
                  <tr key={item.targetId}>
                    <td className="p-4 font-medium text-white">{item.companyName}</td>
                    <td className="p-4">
                      <Input
                        type="date"
                        value={item.expiryDate}
                        onChange={(e) => handleDateChange(index, e.target.value)}
                        className="orbit-input w-48"
                      />
                    </td>
                    <td className="p-4 text-right">
                      <Button onClick={() => handleSave(item)} size="sm">
                        <Save className="mr-2 h-4 w-4" />
                        Save
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
