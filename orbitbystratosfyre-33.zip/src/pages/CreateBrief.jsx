
import React, { useState, useEffect, useCallback } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { TenantRequirement } from "@/api/entities";
import { Client } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { createPageUrl } from "@/utils";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"; // Added Card imports
import { Loader2, Upload, DollarSign, CalendarIcon } from "lucide-react"; // Removed Edit, Building, Compass, Users, Briefcase as they are not used
import TechnicalRequirementsForm from "../components/brief-forms/TechnicalRequirementsForm";
import ESGRequirementsForm from "../components/brief-forms/ESGRequirementsForm";
import GovernanceRequirementsForm from "../components/brief-forms/GovernanceRequirementsForm";
import FeeEstimator from "../components/brief-forms/FeeEstimator";
import PageHeader from "@/components/ui/PageHeader";
import { useToast } from "@/components/ui/use-toast";

export default function CreateBrief() {
    const navigate = useNavigate();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isUploadingLogo, setIsUploadingLogo] = useState(false);
    // const [editingBrief, setEditingBrief] = useState(null); // Removed: formData.id will indicate editing mode

    const [searchParams] = useSearchParams();
    const briefId = searchParams.get('id');
    const clientId = searchParams.get('clientId');
    const { toast } = useToast();

    const [formData, setFormData] = useState({
        client_id: clientId || '',
        company_name: "",
        company_logo_url: "",
        contact_name: "",
        contact_email: "",
        contact_phone: "",
        property_type: "office",
        property_grade: "secondary",
        preferred_suburbs: "",
        min_floor_area: "",
        max_floor_area: "",
        max_rental_total: "",
        max_opex_total: "",
        min_parking: "",
        required_date: "",
        estimated_project_close_date: undefined, // Will be stored as 'YYYY-MM-DD' string after loading or selection
        lease_term_years: "",
        building_grade: [],
        required_amenities: "",
        top_5_criteria: "",
        additional_notes: "",
        has_technical_requirements: false,
        has_esg_requirements: false,
        has_governance_requirements: false,
        technical_requirements: {},
        esg_requirements: {},
        governance_requirements: {},
        estimated_fee_min_aud: 0,
        estimated_fee_max_aud: 0,
        pipeline_value_aud: 0,
        fee_recognition_type: "success-based",
        milestone_1_pct: 10,
        milestone_2_pct: 20,
        milestone_3_pct: 30,
        milestone_4_pct: 40,
    });

    const loadBriefForEditing = useCallback(async (id) => {
        try {
            const brief = await TenantRequirement.get(id);
            // setEditingBrief(brief); // Removed

            // Convert estimated_project_close_date from string to 'YYYY-MM-DD' string for consistent state storage
            const loadedEstimatedCloseDate = brief.estimated_project_close_date
                ? format(new Date(brief.estimated_project_close_date), 'yyyy-MM-dd')
                : undefined;

            setFormData({
                ...brief,
                // Ensure array fields are joined for string input display
                preferred_suburbs: Array.isArray(brief.preferred_suburbs) ? brief.preferred_suburbs.join(', ') : '',
                required_amenities: Array.isArray(brief.required_amenities) ? brief.required_amenities.join(', ') : '',
                top_5_criteria: Array.isArray(brief.top_5_criteria) ? brief.top_5_criteria.join(', ') : '',
                
                // Ensure number fields are set to empty string if null/undefined for input consistency
                min_floor_area: brief.min_floor_area || "",
                max_floor_area: brief.max_floor_area || "",
                max_rental_total: brief.max_rental_total || "",
                max_opex_total: brief.max_opex_total || "",
                min_parking: brief.min_parking || "",
                lease_term_years: brief.lease_term_years || "",

                building_grade: Array.isArray(brief.building_grade) ? brief.building_grade : [],
                property_grade: brief.property_grade || "secondary",
                estimated_project_close_date: loadedEstimatedCloseDate, // Now a 'YYYY-MM-DD' string
                estimated_fee_min_aud: brief.estimated_fee_min_aud || 0,
                estimated_fee_max_aud: brief.estimated_fee_max_aud || 0,
                pipeline_value_aud: brief.pipeline_value_aud || 0,
                fee_recognition_type: brief.fee_recognition_type || "success-based", // Set default if null
                milestone_1_pct: brief.milestone_1_pct || 10, // Set default if null
                milestone_2_pct: brief.milestone_2_pct || 20, // Set default if null
                milestone_3_pct: brief.milestone_3_pct || 30, // Set default if null
                milestone_4_pct: brief.milestone_4_pct || 40, // Set default if null

                // Ensure nested objects and boolean flags are loaded
                technical_requirements: brief.technical_requirements || {},
                esg_requirements: brief.esg_requirements || {},
                governance_requirements: brief.governance_requirements || {},
                has_technical_requirements: brief.has_technical_requirements || false,
                has_esg_requirements: brief.has_esg_requirements || false,
                has_governance_requirements: brief.has_governance_requirements || false,
            });
        } catch (error) {
            toast({ variant: "destructive", title: "Load Failed", description: "Could not load brief data for editing." });
            console.error("Error loading brief:", error);
        }
    }, [toast]);

    useEffect(() => {
        const initializeBrief = async () => {
            if (briefId) {
                await loadBriefForEditing(briefId);
            } else if (clientId) {
                try {
                    const client = await Client.get(clientId);
                    setFormData(prev => ({
                        ...prev,
                        client_id: clientId,
                        company_name: client.company_name,
                        contact_name: client.primary_contact_name || '',
                        contact_email: client.primary_contact_email || '',
                        contact_phone: client.primary_contact_phone || '',
                        company_logo_url: client.company_logo_url || '',
                    }));
                } catch (error) {
                    toast({ variant: "destructive", title: "Client Load Failed", description: "Could not load client data for pre-filling." });
                    console.error("Error loading client:", error);
                }
            }
        };
        initializeBrief();
    }, [briefId, clientId, loadBriefForEditing, toast]); // Added toast to deps

    const handleInputChange = (field, value) => {
        // If the value is a Date object (from Calendar), convert it to a 'YYYY-MM-DD' string
        if (value instanceof Date) {
            setFormData(prev => ({ ...prev, [field]: format(value, 'yyyy-MM-dd') }));
        } else {
            setFormData(prev => ({ ...prev, [field]: value }));
        }
    };

    const handleMultiSelectChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleLogoUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        setIsUploadingLogo(true);
        try {
            const { file_url } = await UploadFile({ file });
            handleInputChange('company_logo_url', file_url);
            toast({ title: "Logo Uploaded", description: "Company logo uploaded successfully." });
        } catch (error) {
            console.error("Error uploading logo:", error);
            toast({ variant: "destructive", title: "Upload Failed", description: "Failed to upload logo." });
        } finally {
            setIsUploadingLogo(false);
        }
    };

    const handleFeeEstimateChange = (feeData) => {
        setFormData(prev => ({
            ...prev,
            estimated_fee_min_aud: feeData.estimated_fee_min_aud || 0,
            estimated_fee_max_aud: feeData.estimated_fee_max_aud || 0,
            pipeline_value_aud: feeData.pipeline_value_aud || 0,
            fee_recognition_type: feeData.fee_recognition_type,
            milestone_1_pct: feeData.milestone_1_pct,
            milestone_2_pct: feeData.milestone_2_pct,
            milestone_3_pct: feeData.milestone_3_pct,
            milestone_4_pct: feeData.milestone_4_pct,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);

        // Validate required fields
        if (!formData.company_name.trim()) {
            toast({ variant: "destructive", title: "Validation Error", description: "Company name is required." });
            setIsSubmitting(false);
            return;
        }
        if (!formData.contact_name.trim()) {
            toast({ variant: "destructive", title: "Validation Error", description: "Contact name is required." });
            setIsSubmitting(false);
            return;
        }
        if (!formData.contact_email.trim()) {
            toast({ variant: "destructive", title: "Validation Error", description: "Contact email is required." });
            setIsSubmitting(false);
            return;
        }
        if (!formData.property_type) {
            toast({ variant: "destructive", title: "Validation Error", description: "Property type is required." });
            setIsSubmitting(false);
            return;
        }
        if (!formData.min_floor_area || parseInt(formData.min_floor_area) <= 0) {
            toast({ variant: "destructive", title: "Validation Error", description: "Minimum floor area is required and must be greater than 0." });
            setIsSubmitting(false);
            return;
        }
        if (!formData.estimated_project_close_date) {
            toast({ variant: "destructive", title: "Validation Error", description: "Estimated project close date is required." });
            setIsSubmitting(false);
            return;
        }

        try {
            let currentClientId = formData.client_id;

            if (!currentClientId) {
                // If no client_id is set (i.e., not coming from URL param), try to find or create a client
                const existingClients = await Client.filter({ company_name: formData.company_name });

                if (existingClients.length > 0) {
                    currentClientId = existingClients[0].id;
                    // Update existing client with latest contact details from form
                    await Client.update(currentClientId, {
                        primary_contact_name: formData.contact_name,
                        primary_contact_email: formData.contact_email,
                        primary_contact_phone: formData.contact_phone,
                        company_logo_url: formData.company_logo_url,
                    });
                } else {
                    // Create new client record
                    const newClientRecord = await Client.create({
                        company_name: formData.company_name,
                        industry: formData.property_type === 'education' ? 'education' : 'other', // Example logic for industry
                        primary_contact_name: formData.contact_name,
                        primary_contact_email: formData.contact_email,
                        primary_contact_phone: formData.contact_phone,
                        engagement_status: 'discovery', // Default status for new client
                        company_logo_url: formData.company_logo_url,
                    });
                    currentClientId = newClientRecord.id;
                }
            } else {
                // If client_id exists (e.g., pre-filled from URL param), update the client with current form data
                await Client.update(currentClientId, {
                    company_name: formData.company_name,
                    primary_contact_name: formData.contact_name,
                    primary_contact_email: formData.contact_email,
                    primary_contact_phone: formData.contact_phone,
                    company_logo_url: formData.company_logo_url,
                });
            }

            const submissionData = {
                ...formData,
                client_id: currentClientId, // Add current client_id to the brief
                preferred_suburbs: formData.preferred_suburbs.split(',').map(s => s.trim()).filter(Boolean),
                required_amenities: formData.required_amenities.split(',').map(s => s.trim()).filter(Boolean),
                top_5_criteria: formData.top_5_criteria.split(',').map(s => s.trim()).filter(Boolean),
                min_floor_area: parseInt(formData.min_floor_area),
                max_floor_area: formData.max_floor_area ? parseInt(formData.max_floor_area) : null,
                max_rental_total: formData.max_rental_total ? parseFloat(formData.max_rental_total) : null,
                max_opex_total: formData.max_opex_total ? parseFloat(formData.max_opex_total) : null,
                min_parking: formData.min_parking ? parseInt(formData.min_parking) : null,
                lease_term_years: formData.lease_term_years ? parseFloat(formData.lease_term_years) : null,
                // Convert 'YYYY-MM-DD' string to ISO string for submission
                estimated_project_close_date: formData.estimated_project_close_date ? new Date(formData.estimated_project_close_date).toISOString() : null,
                // Ensure we only include technical/esg/governance requirements if the flags are true
                technical_requirements: formData.has_technical_requirements ? formData.technical_requirements : {},
                esg_requirements: formData.has_esg_requirements ? formData.esg_requirements : {},
                governance_requirements: formData.has_governance_requirements ? formData.governance_requirements : {},
                // Ensure fee percentages are numbers for submission
                estimated_fee_min_aud: parseFloat(formData.estimated_fee_min_aud),
                estimated_fee_max_aud: parseFloat(formData.estimated_fee_max_aud),
                pipeline_value_aud: parseFloat(formData.pipeline_value_aud),
                milestone_1_pct: parseFloat(formData.milestone_1_pct),
                milestone_2_pct: parseFloat(formData.milestone_2_pct),
                milestone_3_pct: parseFloat(formData.milestone_3_pct),
                milestone_4_pct: parseFloat(formData.milestone_4_pct),
            };

            if (formData.id) { // Check if formData has an id to determine editing mode
                await TenantRequirement.update(formData.id, submissionData);
                toast({ title: "Brief Updated", description: `Brief ${formData.id} updated successfully.` });
                navigate(createPageUrl(`BriefDetails?id=${formData.id}`));
            } else {
                const newRequirement = await TenantRequirement.create(submissionData);
                const brief_reference_code = `AMB-${newRequirement.id.slice(-6).toUpperCase()}`;
                await TenantRequirement.update(newRequirement.id, { brief_reference_code });
                toast({ title: "Brief Created", description: `New brief ${brief_reference_code} created.` });
                navigate(createPageUrl(`BriefDetails?id=${newRequirement.id}`));
            }

        } catch (error) {
            console.error("Error saving brief:", error);
            toast({ variant: "destructive", title: "Save Failed", description: "Failed to save brief. Please check the form and try again." });
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="min-h-screen">
            <div className="max-w-4xl mx-auto">
                <PageHeader
                    title={formData.id ? "Edit Client Brief" : "Create New Client Brief"}
                    description="Fill in the details below. It will be saved as a draft."
                />

                <form onSubmit={handleSubmit}>
                    <div className="space-y-6">
                        <div className="orbit-card p-6">
                            <h3 className="text-lg font-semibold text-white mb-4">Client Information</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Company Name *</Label>
                                    <Input value={formData.company_name} onChange={e => handleInputChange('company_name', e.target.value)} required className="orbit-input" />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Company Logo</Label>
                                    <div className="flex items-center gap-4">
                                        <Input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" id="logo-upload" />
                                        <Label htmlFor="logo-upload" className="orbit-button cursor-pointer flex items-center gap-2 px-4 py-2 text-gray-300 border border-gray-600 rounded-lg">
                                            {isUploadingLogo ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
                                            Upload
                                        </Label>
                                        {formData.company_logo_url && (
                                            <img src={formData.company_logo_url} alt="Company logo" className="h-12 w-12 object-contain bg-white/10 rounded-md p-1" />
                                        )}
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Brief Contact Name *</Label>
                                    <Input value={formData.contact_name} onChange={e => handleInputChange('contact_name', e.target.value)} required className="orbit-input" />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Brief Contact Email *</Label>
                                    <Input type="email" value={formData.contact_email} onChange={e => handleInputChange('contact_email', e.target.value)} required className="orbit-input" />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Brief Contact Phone</Label>
                                    <Input type="tel" value={formData.contact_phone} onChange={e => handleInputChange('contact_phone', e.target.value)} className="orbit-input" />
                                </div>
                            </div>
                        </div>

                        <div className="orbit-card p-6">
                            <h3 className="text-lg font-semibold text-white mb-4">Property Requirements</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Property Type *</Label>
                                    <Select value={formData.property_type} onValueChange={value => handleInputChange('property_type', value)}>
                                        <SelectTrigger className="orbit-input"><SelectValue placeholder="Select type" /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="office">Office</SelectItem>
                                            <SelectItem value="industrial">Industrial</SelectItem>
                                            <SelectItem value="warehouse">Warehouse</SelectItem>
                                            <SelectItem value="retail">Retail</SelectItem>
                                            <SelectItem value="mixed_use">Mixed Use</SelectItem>
                                            <SelectItem value="education">Education</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Property Grade *</Label>
                                    <Select value={formData.property_grade} onValueChange={value => handleInputChange('property_grade', value)}>
                                        <SelectTrigger className="orbit-input"><SelectValue placeholder="Select grade" /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="prime">Prime Grade</SelectItem>
                                            <SelectItem value="secondary">Secondary Grade</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Preferred Suburbs (comma-separated)</Label>
                                    <Input value={formData.preferred_suburbs} onChange={e => handleInputChange('preferred_suburbs', e.target.value)} className="orbit-input" />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Minimum Floor Area (sqm) *</Label>
                                    <Input
                                        type="number"
                                        value={formData.min_floor_area}
                                        onChange={e => handleInputChange('min_floor_area', e.target.value)}
                                        required
                                        min="1"
                                        className="orbit-input"
                                        placeholder="e.g., 500"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Maximum Floor Area (sqm)</Label>
                                    <Input
                                        type="number"
                                        value={formData.max_floor_area}
                                        onChange={e => handleInputChange('max_floor_area', e.target.value)}
                                        className="orbit-input"
                                        placeholder="e.g., 1000"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Required Amenities (comma-separated)</Label>
                                    <Input value={formData.required_amenities} onChange={e => handleInputChange('required_amenities', e.target.value)} placeholder="e.g. End-of-trip, Natural light" className="orbit-input" />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-gray-300">Top 5 Inspection Criteria (comma-separated)</Label>
                                    <Input value={formData.top_5_criteria} onChange={e => handleInputChange('top_5_criteria', e.target.value)} placeholder="e.g. Location, Fitout Quality" className="orbit-input" />
                                </div>
                                <div className="space-y-2 md:col-span-2">
                                    <Label className="text-gray-300">Additional Notes</Label>
                                    <Textarea value={formData.additional_notes} onChange={e => handleInputChange('additional_notes', e.target.value)} className="orbit-input" />
                                </div>
                            </div>
                        </div>

                        <Card className="orbit-card p-6">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <DollarSign className="w-5 h-5 text-orange-400" />
                                    Commercial & Financial
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <Label className="text-gray-300">Max Annual Rental ($)</Label>
                                        <Input type="number" value={formData.max_rental_total} onChange={e => handleInputChange('max_rental_total', e.target.value)} className="orbit-input" placeholder="e.g., 500000" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-gray-300">Max Annual Outgoings ($)</Label>
                                        <Input type="number" value={formData.max_opex_total} onChange={e => handleInputChange('max_opex_total', e.target.value)} className="orbit-input" placeholder="e.g., 150000" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-gray-300">Estimated Project Close Date *</Label>
                                        <Popover>
                                            <PopoverTrigger asChild>
                                                <Button
                                                    variant={"outline"}
                                                    className={`orbit-input w-full justify-start text-left font-normal ${!formData.estimated_project_close_date && "text-muted-foreground"}`}
                                                >
                                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                                    {formData.estimated_project_close_date ? format(new Date(formData.estimated_project_close_date), "PPP") : <span>Pick a date</span>}
                                                </Button>
                                            </PopoverTrigger>
                                            <PopoverContent className="w-auto p-0">
                                                <Calendar
                                                    mode="single"
                                                    selected={formData.estimated_project_close_date ? new Date(formData.estimated_project_close_date) : undefined}
                                                    onSelect={(date) => handleInputChange('estimated_project_close_date', date)}
                                                    initialFocus
                                                />
                                            </PopoverContent>
                                        </Popover>
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-gray-300">Min. Parking Spaces</Label>
                                        <Input type="number" value={formData.min_parking} onChange={e => handleInputChange('min_parking', e.target.value)} min="0" className="orbit-input" placeholder="e.g., 10" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-gray-300">Required Date (dd/mm/yyyy)</Label>
                                        <Input type="text" value={formData.required_date} onChange={e => handleInputChange('required_date', e.target.value)} placeholder="e.g., 01/01/2024" className="orbit-input" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-gray-300">Lease Term (years)</Label>
                                        <Input type="number" value={formData.lease_term_years} onChange={e => handleInputChange('lease_term_years', e.target.value)} min="1" className="orbit-input" placeholder="e.g., 5" />
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Technical Requirements Section */}
                        <div className="orbit-card p-6">
                            <div className="flex items-center space-x-3 mb-4">
                                <Checkbox
                                    checked={formData.has_technical_requirements}
                                    onCheckedChange={(checked) => handleInputChange('has_technical_requirements', checked)}
                                    className="border-2 border-orange-400 data-[state=checked]:bg-orange-500"
                                />
                                <h3 className="text-lg font-semibold text-white">Technical Requirements</h3>
                            </div>

                            {formData.has_technical_requirements && (
                                <TechnicalRequirementsForm
                                    requirements={formData.technical_requirements}
                                    onChange={(reqs) => handleInputChange('technical_requirements', reqs)}
                                />
                            )}
                        </div>

                        {/* ESG Requirements Section */}
                        <div className="orbit-card p-6">
                            <div className="flex items-center space-x-3 mb-4">
                                <Checkbox
                                    checked={formData.has_esg_requirements}
                                    onCheckedChange={(checked) => handleInputChange('has_esg_requirements', checked)}
                                    className="border-2 border-orange-400 data-[state=checked]:bg-orange-500"
                                />
                                <h3 className="text-lg font-semibold text-white">ESG Requirements</h3>
                            </div>

                            {formData.has_esg_requirements && (
                                <ESGRequirementsForm
                                    requirements={formData.esg_requirements}
                                    onChange={(reqs) => handleInputChange('esg_requirements', reqs)}
                                />
                            )}
                        </div>

                        {/* Governance Requirements Section */}
                        <div className="orbit-card p-6">
                            <div className="flex items-center space-x-3 mb-4">
                                <Checkbox
                                    checked={formData.has_governance_requirements}
                                    onCheckedChange={(checked) => handleInputChange('has_governance_requirements', checked)}
                                    className="border-2 border-orange-400 data-[state=checked]:bg-orange-500"
                                />
                                <h3 className="text-lg font-semibold text-white">Governance Requirements</h3>
                            </div>

                            {formData.has_governance_requirements && (
                                <GovernanceRequirementsForm
                                    requirements={formData.governance_requirements}
                                    onChange={(reqs) => handleInputChange('governance_requirements', reqs)}
                                />
                            )}
                        </div>

                        {/* Fee Estimate Card */}
                        <FeeEstimator
                            brief={{
                                min_floor_area: formData.min_floor_area,
                                max_floor_area: formData.max_floor_area,
                                property_grade: formData.property_grade,
                                preferred_suburbs: formData.preferred_suburbs,
                                fee_recognition_type: formData.fee_recognition_type,
                                milestone_1_pct: formData.milestone_1_pct,
                                milestone_2_pct: formData.milestone_2_pct,
                                milestone_3_pct: formData.milestone_3_pct,
                                milestone_4_pct: formData.milestone_4_pct
                            }}
                            onChange={handleFeeEstimateChange}
                        />

                        <div className="flex justify-end">
                            <Button type="submit" disabled={isSubmitting} className="orbit-button bg-gradient-to-r from-orange-500 to-amber-500 text-white border-0 px-8 py-3 rounded-lg">
                                {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : "Save Brief"}
                            </Button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
}
