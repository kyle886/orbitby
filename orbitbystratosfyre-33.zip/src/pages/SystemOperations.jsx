import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ActionGrid, { DEFAULT_GROUPS } from "@/components/admin/ActionGrid";

export default function SystemOperations() {
  const handleAiHarvestTest = async (e) => {
    e.preventDefault();
    const url = new FormData(e.currentTarget).get("url");
    if (!url) return;
    
    try {
      const r = await window.base44.functions.system_aiHarvestTest({ url });
      alert(`main=${!!r?.images?.main} | gallery=${r?.counts?.gallery ?? 0}`);
    } catch (error) {
      alert(`Test failed: ${error.message}`);
    }
  };

  return (
    <div className="p-6 space-y-6 min-h-screen bg-void">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">System Operations</h1>
          <p className="text-gray-300">
            Unified admin console for all system maintenance and diagnostic operations
          </p>
        </div>

        <ActionGrid groups={DEFAULT_GROUPS} />

        {/* AI Harvest Test inline */}
        <Card className="orbit-card">
          <CardContent className="p-6">
            <h3 className="text-white font-semibold mb-4">AI Harvest Test</h3>
            <form onSubmit={handleAiHarvestTest} className="flex gap-4">
              <Input
                name="url"
                placeholder="https://example.com/listing"
                className="orbit-input flex-1"
                type="url"
              />
              <Button type="submit" className="orbit-button">
                Test URL
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}