import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { DevCase } from '@/api/entities';
import { Scenario } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Plus, Sliders, Layers, BarChart, FileText, AlertCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { runJob } from '@/components/utils/runJob';
import { massingSolve } from '@/api/functions';
import { capitalPack } from '@/api/functions';

import ScenarioForm from '@/components/dev/ScenarioForm';
import FeasibilityOutputs from '@/components/dev/FeasibilityOutputs';
import SensitivityTab from '@/components/dev/SensitivityTab';
import MassingControls from '@/components/dev/MassingControls';

const DevelopmentFeasibility = () => {
  const [searchParams] = useSearchParams();
  const devCaseId = searchParams.get('id');
  const { toast } = useToast();

  const [devCase, setDevCase] = useState(null);
  const [scenarios, setScenarios] = useState([]);
  const [activeScenarioId, setActiveScenarioId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [user, setUser] = useState(null);

  const loadData = useCallback(async () => {
    if (!devCaseId) {
      setError('No Development Case ID provided in URL. Please provide an ID parameter.');
      setLoading(false);
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      // Load user first
      const currentUser = await User.me();
      setUser(currentUser);
      
      // Try to load the development case
      const caseData = await DevCase.get(devCaseId);
      if (!caseData) {
        throw new Error(`Development Case with ID ${devCaseId} not found.`);
      }
      
      setDevCase(caseData);
      
      // Load scenarios for this case
      const scenariosData = await Scenario.filter({ dealId: devCaseId });
      setScenarios(scenariosData || []);
      
      if (scenariosData && scenariosData.length > 0) {
        setActiveScenarioId(scenariosData[0].id);
      }
      
    } catch (error) {
      console.error("Failed to load data:", error);
      setError(error.message);
      toast({ 
        variant: 'destructive', 
        title: 'Failed to load development case', 
        description: error.message 
      });
    } finally {
      setLoading(false);
    }
  }, [devCaseId, toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleCreateDevCase = async () => {
    if (!user) return;
    
    try {
      const newDevCase = await DevCase.create({
        name: "New Development Case",
        owner_user_id: user.id,
        state: "Screening"
      });
      
      // Redirect to the new dev case
      window.location.href = `/DevelopmentFeasibility?id=${newDevCase.id}`;
      
    } catch (error) {
      console.error("Failed to create dev case:", error);
      toast({ 
        variant: 'destructive', 
        title: 'Failed to create development case', 
        description: error.message 
      });
    }
  };

  const handleCreateScenario = async () => {
    if (!devCase) return;
    
    const newScenarioName = `Scenario ${scenarios.length + 1}`;
    try {
      const newScenario = await Scenario.create({
        dealId: devCase.id,
        name: newScenarioName,
        assumptions: {
          area_sqm: 10000,
          rent_per_sqm_pa: 950,
          opex_per_sqm_pa: 250,
          construction_cost_per_sqm: 4500,
          land_cost: 20000000,
          lease_term_years: 10,
          exit_cap_rate_pct: 5.0,
          discount_rate_pct: 7.5,
        },
        isApproved: false,
        createdBy: user?.email || 'system',
        createdAt: new Date().toISOString()
      });
      
      setScenarios([...scenarios, newScenario]);
      setActiveScenarioId(newScenario.id);
      toast({ title: "Scenario Created", description: `Successfully created ${newScenarioName}.` });
    } catch (error) {
      console.error("Failed to create scenario:", error);
      toast({ variant: 'destructive', title: 'Failed to create scenario', description: error.message });
    }
  };
  
  const updateScenarioData = (scenarioId, updatedData) => {
    setScenarios(prev => prev.map(s => s.id === scenarioId ? { ...s, ...updatedData } : s));
  };

  const activeScenario = scenarios.find(s => s.id === activeScenarioId);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full p-8">
        <Loader2 className="w-12 h-12 animate-spin text-orange-400" />
      </div>
    );
  }

  // Error state - show options to create or navigate
  if (error) {
    return (
      <div className="p-4 sm:p-6 md:p-8">
        <div className="max-w-2xl mx-auto text-center">
          <Card className="orbit-card">
            <CardContent className="p-8">
              <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-4">Development Case Not Found</h2>
              <p className="text-gray-300 mb-6">{error}</p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button onClick={handleCreateDevCase} className="bg-orange-500 hover:bg-orange-600">
                  <Plus className="w-4 h-4 mr-2" />
                  Create New Development Case
                </Button>
                <Button variant="outline" onClick={() => window.history.back()}>
                  Go Back
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!devCase) {
    return (
      <div className="p-8 text-center text-gray-400">
        <p>Development Case not found.</p>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 md:p-8">
      <header className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">{devCase.name}</h1>
          <p className="text-gray-300">Development Feasibility Analysis</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleCreateScenario}>
            <Plus className="w-4 h-4 mr-2"/>New Scenario
          </Button>
          <Button>
            <FileText className="w-4 h-4 mr-2"/>Export Report
          </Button>
        </div>
      </header>

      {scenarios.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-gray-400 mb-4">No scenarios exist for this development case.</p>
          <Button onClick={handleCreateScenario}>
            <Plus className="w-4 h-4 mr-2"/>Create First Scenario
          </Button>
        </div>
      ) : (
        <Tabs value={activeScenarioId} onValueChange={setActiveScenarioId}>
          <TabsList className="mb-4">
            {scenarios.map(s => (
              <TabsTrigger key={s.id} value={s.id}>{s.name}</TabsTrigger>
            ))}
          </TabsList>

          {scenarios.map(scenario => (
            <TabsContent key={scenario.id} value={scenario.id}>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Left Column: Inputs */}
                <div className="lg:col-span-1 space-y-6">
                  <ScenarioForm 
                    scenario={scenario} 
                    onUpdate={(updatedAssumptions) => {
                      const updatedScenario = { ...scenario, assumptions: updatedAssumptions };
                      updateScenarioData(scenario.id, updatedScenario);
                      Scenario.update(scenario.id, { assumptions: updatedAssumptions });
                    }}
                  />
                  <MassingControls
                    scenario={scenario}
                    onMassingResult={(result) => {
                       const updatedScenario = { ...scenario, massing_result: result };
                       updateScenarioData(scenario.id, updatedScenario);
                       Scenario.update(scenario.id, { massing_result: result });
                    }}
                  />
                </div>

                {/* Right Column: Outputs */}
                <div className="lg:col-span-2 space-y-6">
                   <FeasibilityOutputs scenario={scenario} />
                   <SensitivityTab scenario={scenario} onUpdateScenario={updateScenarioData} />
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      )}
    </div>
  );
};

export default DevelopmentFeasibility;