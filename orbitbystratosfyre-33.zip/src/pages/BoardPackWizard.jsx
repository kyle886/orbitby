
import React, { useMemo, useState, useEffect, useCallback } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { FeasibilityScenario } from "@/api/entities";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/use-toast";
import { generateBoardPack } from '@/api/functions';
import { geostatsSummarize } from '@/api/functions'; // New import
import SiteRadiusPicker from '@/components/map/SiteRadiusPicker'; // New import


const fmt = (n)=> n.toLocaleString(undefined,{style:"currency",currency:"AUD",maximumFractionDigits:0});

export default function BoardPackWizard(){
  const { dealId = "ADHOC" } = useParams();
  const [sp] = useSearchParams();
  const scenarioId = sp.get("scenarioId") || "";
  const [scenario, setScenario] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    async function fetchScenario(sid){ 
        if(!sid) return;
        try {
            const data = await FeasibilityScenario.get(sid);
            setScenario(data);
        } catch(e) {
            console.error(e);
            toast({ title: "Error", description: "Failed to load scenario" });
        }
    }
    fetchScenario(scenarioId);
  }, [scenarioId, toast]);

  const [step, setStep] = useState(0);
  // Updated inputs state to include radius_m in site object
  const [inputs, setInputs] = useState({
    site: { address: "", lat: undefined, lng: undefined, sitePlanUrl: "", radius_m: undefined }, 
    scores: { transport: 0.6, amenities: 0.6, workforce: 0.5, market: 0.5, esg: 0.4 },
    weights: { transport: 0.25, amenities: 0.2, workforce: 0.2, market: 0.2, esg: 0.15 },
    analysis: { demographicsSummary: "", risks: [] },
    ownerOccupier: { enabled: false, lease: null, buy: null, discountRatePct: 8 }
  });

  // New state variables for SiteRadiusPicker and geostats
  const [siteRadius, setSiteRadius] = useState(undefined);
  const [localStats, setLocalStats] = useState(null);
  
  const o = scenario?.outputs || {};
  const siteScore = useMemo(()=>{
    const s=inputs.scores,w=inputs.weights; const c=(n)=>Math.max(0,Math.min(1,n));
    return (w.transport*c(s.transport)+w.amenities*c(s.amenities)+w.workforce*c(s.workforce)+w.market*c(s.market)+w.esg*c(s.esg));
  },[inputs]);

  const placeholders = useMemo(()=>{
    const m=[]; const site=inputs.site||{}; const a=inputs.analysis||{};
    if(!site.address) m.push("Site address");
    // Updated condition for map coordinates to consider radius_m as well
    if((site.lat == null || site.lng == null) && site.radius_m == null) m.push("Map coordinates/area");
    if(!site.sitePlanUrl) m.push("Site plan");
    if(!a.demographicsSummary) m.push("Demographics summary");
    if(!a.risks?.length) m.push("Risk register");
    if(inputs.ownerOccupier?.enabled && (!inputs.ownerOccupier.lease || !inputs.ownerOccupier.buy)) m.push("Owner‑occupier buy vs lease inputs");
    return m;
  },[inputs]);

  return (
    <div className="p-6 space-y-6 bg-gradient-to-b from-neutral-950 to-neutral-900 min-h-screen text-neutral-100">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">ATLAS Board Pack</h1>
        <div className="text-neutral-400 text-sm">Scenario: {scenarioId || "(none)"}</div>
      </div>

      <Tabs value={String(step)}>
        <TabsList className="bg-neutral-800/60">
          <TabsTrigger value="0" onClick={()=>setStep(0)}>Inputs</TabsTrigger>
          <TabsTrigger value="1" onClick={()=>setStep(1)} disabled={!scenario}>Review</TabsTrigger>
          <TabsTrigger value="2" onClick={()=>setStep(2)} disabled={!scenario}>Generate</TabsTrigger>
        </TabsList>

        <TabsContent value="0">
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="p-4 bg-black/40 backdrop-blur-xl">
              <div className="text-sm text-neutral-300 mb-2">Site & Media</div>
              <Labeled label="Address"><Input value={inputs.site.address} onChange={e=>setInputs({...inputs, site:{...inputs.site, address:e.target.value}})} /></Labeled>
              <div className="grid grid-cols-2 gap-2">
                <Labeled label="Latitude"><Input value={inputs.site.lat??""} onChange={e=>setInputs({...inputs, site:{...inputs.site, lat:Number(e.target.value||0)}})} /></Labeled>
                <Labeled label="Longitude"><Input value={inputs.site.lng??""} onChange={e=>setInputs({...inputs, site:{...inputs.site, lng:Number(e.target.value||0)}})} /></Labeled>
              </div>
              <Labeled label="Site plan URL (image/PDF)"><Input value={inputs.site.sitePlanUrl} onChange={e=>setInputs({...inputs, site:{...inputs.site, sitePlanUrl:e.target.value}})} /></Labeled>
              <div className="text-xs text-neutral-400 mt-2">Maps and POIs render in the binder; placeholders appear if coordinates are missing.</div>
            </Card>

            {/* New Card for SiteRadiusPicker */}
            <Card className="p-4 bg-black/40 backdrop-blur-xl">
              <div className="text-sm text-neutral-300 mb-2">Map Selection (or provide address above)</div>
              <SiteRadiusPicker value={siteRadius} onChange={async (sel) => {
                setSiteRadius(sel);
                try {
                  const { data: stats } = await geostatsSummarize(sel);
                  setLocalStats(stats);
                  setInputs(prevInputs => ({
                    ...prevInputs,
                    site: { ...(prevInputs.site || {}), lat: sel.lat, lng: sel.lng, radius_m: sel.radius_m },
                    analysis: {
                      ...(prevInputs.analysis || {}),
                      demographicsSummary: prevInputs.analysis?.demographicsSummary || (stats?.placeholders?.length ? stats.placeholders.join(' ') : '')
                    }
                  }));
                } catch (error) {
                  console.error("Failed to fetch local stats:", error);
                  toast({ variant: "destructive", title: "Error fetching map data" });
                }
              }} />
              {localStats && (
                <div className="mt-3 text-xs text-neutral-300">
                  <div>Dwellings (12/24/36m): {String(localStats.dwellings?.m12 ?? '—')} / {String(localStats.dwellings?.m24 ?? '—')} / {String(localStats.dwellings?.m36 ?? '—')}</div>
                  <div>Planned infrastructure: {(localStats.plannedInfra || []).length || '—'}</div>
                  <div>DAs/SSDAs: {(localStats.das || []).length || '—'}</div>
                </div>
              )}
            </Card>
            {/* End New Card */}

            <Card className="p-4 bg-black/40 backdrop-blur-xl">
              <div className="text-sm text-neutral-300 mb-2">Scoring (0–1) & Weights</div>
              {(["transport","amenities","workforce","market","esg"]).map(k=> (
                <div key={k} className="mb-3">
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-neutral-300 capitalize">{k}</div>
                    <div className="text-xs text-neutral-400">Score {inputs.scores[k].toFixed(2)} • W {inputs.weights[k].toFixed(2)}</div>
                  </div>
                  <Slider value={[inputs.scores[k]]} min={0} max={1} step={0.01} onValueChange={v=>setInputs({...inputs, scores:{...inputs.scores, [k]:v[0]}})} />
                  <Slider className="mt-1" value={[inputs.weights[k]]} min={0} max={1} step={0.01} onValueChange={v=>setInputs({...inputs, weights:{...inputs.weights, [k]:v[0]}})} />
                </div>
              ))}
              <div className="text-xs text-neutral-400">Composite site score: {(siteScore*100).toFixed(0)}%</div>
            </Card>

            <Card className="p-4 bg-black/40 backdrop-blur-xl md:col-span-2">
              <div className="text-sm text-neutral-300 mb-2">Narratives & Risks</div>
              <Labeled label="Demographics (short summary)"><Input value={inputs.analysis.demographicsSummary} onChange={e=>setInputs({...inputs, analysis:{...inputs.analysis, demographicsSummary:e.target.value}})} /></Labeled>
              <RiskEditor value={inputs.analysis.risks} onChange={(v)=>setInputs({...inputs, analysis:{...inputs.analysis, risks:v}})} />
            </Card>

            <Card className="p-4 bg-black/40 backdrop-blur-xl md:col-span-2">
              <div className="flex items-center justify-between">
                <div className="text-sm text-neutral-300">Owner‑Occupier Buy vs Lease</div>
                <Switch checked={inputs.ownerOccupier.enabled} onCheckedChange={(v)=>setInputs({...inputs, ownerOccupier:{...inputs.ownerOccupier, enabled:v}})} />
              </div>
              {inputs.ownerOccupier.enabled && (
                <div className="grid md:grid-cols-2 gap-3 mt-2">
                  <OwnerLeaseInputs value={inputs.ownerOccupier.lease} onChange={(v)=>setInputs({...inputs, ownerOccupier:{...inputs.ownerOccupier, lease:v}})} />
                  <OwnerBuyInputs value={inputs.ownerOccupier.buy} onChange={(v)=>setInputs({...inputs, ownerOccupier:{...inputs.ownerOccupier, buy:v}})} />
                </div>
              )}
            </Card>
          </div>
          <div className="flex justify-end mt-4"><Button className="bg-white/20" onClick={()=>setStep(1)} disabled={!scenario}>Review Outputs</Button></div>
        </TabsContent>

        <TabsContent value="1">
          <div className="grid md:grid-cols-3 gap-3">
            <Card className="p-4 bg-black/40 backdrop-blur-xl"><div className="text-xs text-neutral-400">GDV</div><div className="text-xl text-white">{fmt(o.gdv||0)}</div></Card>
            <Card className="p-4 bg-black/40 backdrop-blur-xl"><div className="text-xs text-neutral-400">Margin on cost</div><div className="text-xl text-white">{(o.marginOnCostPct||0).toFixed(1)}%</div></Card>
            <Card className="p-4 bg-black/40 backdrop-blur-xl"><div className="text-xs text-neutral-400">Residual land value</div><div className="text-xl text-white">{fmt(o.residualLandValue||0)}</div></Card>
            <Card className="p-4 bg-black/40 backdrop-blur-xl md:col-span-3">
              <div className="text-sm text-neutral-300 mb-2">Readiness Check</div>
              {placeholders.length ? (
                <ul className="list-disc ml-5 text-amber-300 text-sm">
                  {placeholders.map(p=> <li key={p}>Missing: {p}</li>)}
                </ul>
              ) : <div className="text-green-400 text-sm">All required inputs present</div>}
              <div className="text-xs text-neutral-500 mt-2">Missing items will be inserted into the binder as <code>[[MISSING: FIELD]]</code> placeholders.</div>
            </Card>
          </div>
          <div className="flex justify-end mt-4"><Button className="bg-white/20" onClick={()=>setStep(2)}>Generate Pack</Button></div>
        </TabsContent>

        <TabsContent value="2">
          <Card className="p-6 bg-black/40 backdrop-blur-xl space-y-3">
            <div className="text-sm text-neutral-300">Generate and download the ATLAS Board Pack</div>
            <Button onClick={async()=>{
              try{
                const { data: res } = await generateBoardPack({ dealId, scenarioId, inputs });
                if(res?.binderUrl) window.open(res.binderUrl, "_blank");
                toast({title: "Board pack generated"});
              }catch(e){ toast({title: e?.message||"Failed to generate", variant: "destructive"}); }
            }}>Generate & Download</Button>
            <div className="text-xs text-neutral-500">An audit record is written with any missing modules.</div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Labeled({label, children}){ return <div className="space-y-1 mb-2"><Label className="text-neutral-300 text-xs">{label}</Label>{children}</div>; }

function RiskEditor({ value, onChange }){
  const [items, setItems] = useState(value||[]);
  const add=()=>{ const n=[...items,{category:"",desc:"",mitigation:"",owner:""}]; setItems(n); onChange(n); };
  const set=(idx,k,v)=>{ const n=items.map((r,i)=> i===idx?{...r,[k]:v}:r); setItems(n); onChange(n); };
  return (
    <div className="space-y-2">
      {items.map((r,idx)=> (
        <div key={idx} className="grid md:grid-cols-4 gap-2 items-center">
          <Input placeholder="Category" value={r.category} onChange={e=>set(idx,"category",e.target.value)} />
          <Input placeholder="Risk description" value={r.desc} onChange={e=>set(idx,"desc",e.target.value)} />
          <Input placeholder="Mitigation" value={r.mitigation} onChange={e=>set(idx,"mitigation",e.target.value)} />
          <Input placeholder="Owner" value={r.owner} onChange={e=>set(idx,"owner",e.target.value)} />
        </div>
      ))}
      <Button className="bg-white/10" onClick={add}>Add Risk</Button>
    </div>
  );
}

function OwnerLeaseInputs({ value, onChange }){
  const v=value||{ areaM2:0, rentPerM2:0, outgoingsPerM2:0, escalationPct:3, incentives:{ rentFreeMonths:0, fitoutContribution:0 }, makeGood:0, otherCapex:0 };
  return (
    <Card className="p-3 bg-neutral-900/50">
      <div className="text-xs text-neutral-400 mb-1">Lease inputs</div>
      <Row l="Area (m²)" v={v.areaM2} s={(x)=>onChange({...v, areaM2:Number(x)})} />
      <Row l="Rent ($/m²)" v={v.rentPerM2} s={(x)=>onChange({...v, rentPerM2:Number(x)})} />
      <Row l="Outgoings ($/m²)" v={v.outgoingsPerM2} s={(x)=>onChange({...v, outgoingsPerM2:Number(x)})} />
      <Row l="Escalation (%)" v={v.escalationPct} s={(x)=>onChange({...v, escalationPct:Number(x)})} />
      <Row l="Rent‑free (months)" v={v.incentives.rentFreeMonths} s={(x)=>onChange({...v, incentives:{...v.incentives, rentFreeMonths:Number(x)}})} />
      <Row l="Fit‑out contribution ($)" v={v.incentives.fitoutContribution} s={(x)=>onChange({...v, incentives:{...v.incentives, fitoutContribution:Number(x)}})} />
      <Row l="Make‑good ($)" v={v.makeGood} s={(x)=>onChange({...v, makeGood:Number(x)})} />
      <Row l="Other capex ($)" v={v.otherCapex} s={(x)=>onChange({...v, otherCapex:Number(x)})} />
    </Card>
  );
}
function OwnerBuyInputs({ value, onChange }){
  const v=value||{ price:0, acqCostsPct:5.5, holdingOutgoingsPerM2:0, capex:0, lvrPct:60, interestRatePct:7, exitYear:10, exitCapRate:6, saleCostsPct:2 };
  return (
    <Card className="p-3 bg-neutral-900/50">
      <div className="text-xs text-neutral-400 mb-1">Buy inputs</div>
      <Row l="Purchase price ($)" v={v.price} s={(x)=>onChange({...v, price:Number(x)})} />
      <Row l="Acq costs (%)" v={v.acqCostsPct} s={(x)=>onChange({...v, acqCostsPct:Number(x)})} />
      <Row l="Holding outgoings ($/m²)" v={v.holdingOutgoingsPerM2} s={(x)=>onChange({...v, holdingOutgoingsPerM2:Number(x)})} />
      <Row l="Capex ($)" v={v.capex} s={(x)=>onChange({...v, capex:Number(x)})} />
      <Row l="LVR (%)" v={v.lvrPct} s={(x)=>onChange({...v, lvrPct:Number(x)})} />
      <Row l="Interest rate (%)" v={v.interestRatePct} s={(x)=>onChange({...v, interestRatePct:Number(x)})} />
      <Row l="Exit year" v={v.exitYear} s={(x)=>onChange({...v, exitYear:Number(x)})} />
      <Row l="Exit cap rate (%)" v={v.exitCapRate} s={(x)=>onChange({...v, exitCapRate:Number(x)})} />
      <Row l="Sale costs (%)" v={v.saleCostsPct} s={(x)=>onChange({...v, saleCostsPct:Number(x)})} />
    </Card>
  );
}
function Row({l,v,s}){ return (
  <div className="grid grid-cols-2 gap-2 items-center my-1">
    <div className="text-xs text-neutral-300">{l}</div>
    <Input value={v??""} onChange={e=>s(e.target.value)} className="bg-neutral-900/60 border-neutral-800" />
  </div>
); }
