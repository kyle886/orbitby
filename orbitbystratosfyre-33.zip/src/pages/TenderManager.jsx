import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { TenantRequirement } from '@/api/entities';
import { TenderRound } from '@/api/entities';
import { VendorEnvelope } from '@/api/entities';
import { TenderQnA } from '@/api/entities';
import { TenderAddendum } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Plus, Users, HelpCircle, FileText, Send } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import PageHeader from '@/components/ui/PageHeader';

const VendorList = ({ vendors = [] }) => (
  <div className="space-y-3">
    {vendors.length > 0 ? vendors.map(v => (
      <div key={v.id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
        <p className="font-medium text-white">{v.vendorOrgId}</p>
        <span className="text-xs font-semibold px-2 py-1 rounded-full bg-blue-500/20 text-blue-300">Invited</span>
      </div>
    )) : <p className="text-gray-400 text-center py-4">No vendors invited to this round yet.</p>}
  </div>
);

const QnARegister = ({ qnaItems = [], onAnswerSubmit }) => {
  const [answers, setAnswers] = useState({});

  const handleAnswerChange = (id, text) => {
    setAnswers(prev => ({ ...prev, [id]: text }));
  };

  return (
    <div className="space-y-4">
      {qnaItems.length > 0 ? qnaItems.map(q => (
        <div key={q.id} className="p-4 bg-gray-800/50 rounded-lg">
          <p className="text-sm text-gray-400">Q from {q.askedBy}:</p>
          <p className="text-white mb-2">{q.question}</p>
          {q.answer ? (
            <p className="text-sm text-green-300 bg-green-500/10 p-2 rounded-md">A: {q.answer}</p>
          ) : (
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="Type your answer..." 
                className="orbit-input flex-grow"
                value={answers[q.id] || ''}
                onChange={(e) => handleAnswerChange(q.id, e.target.value)}
              />
              <Button size="sm" onClick={() => onAnswerSubmit(q.id, answers[q.id] || '')} disabled={!answers[q.id]}>Answer</Button>
            </div>
          )}
        </div>
      )) : <p className="text-gray-400 text-center py-4">No questions have been asked in this round.</p>}
    </div>
  );
};

const AddendumList = ({ addendums = [] }) => (
    <div className="space-y-3">
      {addendums.length > 0 ? addendums.map(a => (
        <div key={a.id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
          <p className="font-medium text-white">Addendum #{a.number}: {a.summary}</p>
          <a href={a.fileUrl} target="_blank" rel="noopener noreferrer"><Button variant="outline" size="sm">View PDF</Button></a>
        </div>
      )) : <p className="text-gray-400 text-center py-4">No addendums issued for this round.</p>}
    </div>
);


export default function TenderManager() {
  const [searchParams] = useSearchParams();
  const briefId = searchParams.get('briefId');
  const { toast } = useToast();

  const [brief, setBrief] = useState(null);
  const [rounds, setRounds] = useState([]);
  const [activeRound, setActiveRound] = useState(null);
  const [vendors, setVendors] = useState([]);
  const [qna, setQna] = useState([]);
  const [addendums, setAddendums] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    if (!briefId) {
      toast({ variant: 'destructive', title: 'Error', description: 'No Brief ID specified.' });
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const briefData = await TenantRequirement.get(briefId);
      setBrief(briefData);

      const roundData = await TenderRound.filter({ dealId: briefId }, '-createdAt');
      setRounds(roundData || []);

      if (roundData?.length > 0) {
        const currentRound = roundData[0];
        setActiveRound(currentRound);
        const [vendorData, qnaData, addendumData] = await Promise.all([
          VendorEnvelope.filter({ roundId: currentRound.id }),
          TenderQnA.filter({ roundId: currentRound.id }),
          TenderAddendum.filter({ roundId: currentRound.id })
        ]);
        setVendors(vendorData || []);
        setQna(qnaData || []);
        setAddendums(addendumData || []);
      }
    } catch (error) {
      console.error("Failed to load tender data:", error);
      toast({ variant: "destructive", title: "Load Failed", description: error.message });
    } finally {
      setLoading(false);
    }
  }, [briefId, toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);
  
  const handleCreateRound = async () => {
      // TODO: Replace with a modal form to get round name and due date
      const roundName = `Round ${rounds.length + 1}`;
      const dueDate = new Date();
      dueDate.setDate(dueDate.getDate() + 14);

      try {
        await TenderRound.create({
            dealId: briefId,
            name: roundName,
            status: 'OPEN',
            dueAt: dueDate.toISOString(),
            // createdBy will be set by the platform
        });
        toast({ title: 'Success', description: `${roundName} has been created.` });
        loadData(); // Refresh all data
      } catch(error) {
        toast({ variant: "destructive", title: "Creation Failed", description: error.message });
      }
  };
  
  const handleAnswerSubmit = async (qnaId, answerText) => {
    if (!answerText) return;
    try {
        await TenderQnA.update(qnaId, {
            answer: answerText,
            answeredAt: new Date().toISOString(),
            // answeredBy will be set by platform/function
        });
        toast({ title: 'Success', description: 'Answer has been published.' });
        loadData();
    } catch (error) {
        toast({ variant: "destructive", title: "Answer Failed", description: error.message });
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-orange-400" /></div>;
  }

  if (!brief) {
    return <div className="text-center p-8 text-gray-400">Brief not found.</div>;
  }

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-7xl mx-auto">
      <PageHeader
        title="Tender & RFP Manager"
        description={`Managing tender process for: ${brief.company_name}`}
        actions={<Button onClick={handleCreateRound}><Plus className="mr-2 h-4 w-4" /> Create New Tender Round</Button>}
      />

      <div className="grid grid-cols-4 gap-6">
        {/* Left sidebar for rounds */}
        <div className="col-span-1">
            <Card className="orbit-card sticky top-6">
                <CardHeader>
                    <CardTitle>Tender Rounds</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-2">
                        {rounds.map(round => (
                            <button key={round.id} 
                                className={`w-full text-left p-3 rounded-lg transition-colors ${activeRound?.id === round.id ? 'bg-orange-500/20 text-orange-300' : 'hover:bg-gray-800/70'}`}
                                onClick={() => setActiveRound(round)} // Simplified; in reality this would refetch data for the selected round
                            >
                                <p className="font-semibold">{round.name}</p>
                                <p className="text-xs capitalize">{round.status.toLowerCase()}</p>
                            </button>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>

        {/* Main content for active round */}
        <div className="col-span-3">
            {activeRound ? (
                 <Tabs defaultValue="vendors" className="w-full">
                    <TabsList className="grid w-full grid-cols-4 bg-gray-800/50">
                        <TabsTrigger value="vendors"><Users className="mr-2 h-4 w-4" />Vendors</TabsTrigger>
                        <TabsTrigger value="qna"><HelpCircle className="mr-2 h-4 w-4" />Q&A Register</TabsTrigger>
                        <TabsTrigger value="addendums"><FileText className="mr-2 h-4 w-4" />Addendums</TabsTrigger>
                        <TabsTrigger value="bids"><Send className="mr-2 h-4 w-4" />Bids</TabsTrigger>
                    </TabsList>
                    <TabsContent value="vendors" className="mt-4">
                        <Card className="orbit-card">
                            <CardHeader>
                                <CardTitle>Invited Vendors</CardTitle>
                                <CardDescription>Contractors who have been invited to submit a bid for this round.</CardDescription>
                            </CardHeader>
                            <CardContent><VendorList vendors={vendors} /></CardContent>
                        </Card>
                    </TabsContent>
                    <TabsContent value="qna" className="mt-4">
                        <Card className="orbit-card">
                            <CardHeader><CardTitle>Q&A Register</CardTitle></CardHeader>
                            <CardContent><QnARegister qnaItems={qna} onAnswerSubmit={handleAnswerSubmit} /></CardContent>
                        </Card>
                    </TabsContent>
                    <TabsContent value="addendums" className="mt-4">
                         <Card className="orbit-card">
                            <CardHeader><CardTitle>Addendums</CardTitle></CardHeader>
                            <CardContent><AddendumList addendums={addendums} /></CardContent>
                        </Card>
                    </TabsContent>
                    <TabsContent value="bids" className="mt-4">
                         <Card className="orbit-card">
                            <CardHeader><CardTitle>Bid Submissions</CardTitle></CardHeader>
                            <CardContent><p className="text-gray-400 text-center py-4">Bid submission portal is under construction.</p></CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            ) : (
                <div className="flex items-center justify-center h-96 border-2 border-dashed border-gray-700 rounded-lg">
                    <div className="text-center">
                        <h3 className="text-lg font-semibold text-white">No Tender Rounds Found</h3>
                        <p className="text-gray-400 mt-1">Create a new tender round to begin the RFP process.</p>
                        <Button onClick={handleCreateRound} className="mt-4"><Plus className="mr-2 h-4 w-4" /> Create First Round</Button>
                    </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
}