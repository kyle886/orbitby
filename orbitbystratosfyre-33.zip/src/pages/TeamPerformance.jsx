import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { Client } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { ClientUpdate } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Loader2, TrendingUp, Briefcase, DollarSign, Activity, CheckCircle, AlertTriangle, XCircle, User as UserIcon } from 'lucide-react';

const AVERAGE_RENT_PER_SQM = 850; // A baseline assumption for pipeline value

const ConsultantCard = ({ consultant }) => {
  const getPacingIndicator = (status) => {
    switch (status) {
      case 'on_track':
        return <CheckCircle className="w-6 h-6 text-green-400" />;
      case 'needs_monitoring':
        return <AlertTriangle className="w-6 h-6 text-yellow-400" />;
      case 'at_risk':
        return <XCircle className="w-6 h-6 text-red-400" />;
      default:
        return <UserIcon className="w-6 h-6 text-gray-400" />;
    }
  };

  return (
    <Link to={createPageUrl(`TeamMemberPerformance?userId=${consultant.id}`)} className="block orbit-card p-6 group hover:border-orange-500/50 transition-all duration-300 hover:shadow-2xl hover:-translate-y-1">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-bold text-white">{consultant.first_name} {consultant.last_name}</h3>
          <p className="text-sm text-gray-400">{consultant.title || 'Consultant'}</p>
        </div>
        {getPacingIndicator(consultant.pacingStatus)}
      </div>
      <div className="mt-6 space-y-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2 text-gray-300">
            <Briefcase className="w-4 h-4 text-amber-400" />
            <span className="text-sm">Active Briefs</span>
          </div>
          <span className="font-bold text-white text-lg">{consultant.activeBriefs}</span>
        </div>
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2 text-gray-300">
            <DollarSign className="w-4 h-4 text-amber-400" />
            <span className="text-sm">Est. Pipeline</span>
          </div>
          <span className="font-bold text-white text-lg">${(consultant.pipelineValue / 1_000_000).toFixed(1)}M</span>
        </div>
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2 text-gray-300">
            <Activity className="w-4 h-4 text-amber-400" />
            <span className="text-sm">Avg. Pacing</span>
          </div>
          <span className="font-bold text-white capitalize text-sm">{consultant.pacingStatus.replace('_', ' ')}</span>
        </div>
      </div>
    </Link>
  );
};

export default function TeamPerformance() {
  const [consultants, setConsultants] = useState([]);
  const [loading, setLoading] = useState(true);

  const calculatePerformance = useCallback(async (users, clients, briefs, updates) => {
    const consultantData = {};

    users.forEach(user => {
      consultantData[user.id] = {
        ...user,
        clients: [],
        briefs: [],
        activeBriefs: 0,
        pipelineValue: 0,
        pacingStatus: 'on_track',
      };
    });

    clients.forEach(client => {
      (client.stratosfyre_consultants || []).forEach(consultantRef => {
        if (consultantData[consultantRef.id]) {
          consultantData[consultantRef.id].clients.push(client);
        }
      });
    });

    briefs.forEach(brief => {
      const client = clients.find(c => c.id === brief.client_id);
      if (client && client.stratosfyre_consultants) {
        (client.stratosfyre_consultants || []).forEach(consultantRef => {
          if (consultantData[consultantRef.id] && brief.status !== 'completed' && brief.status !== 'cancelled') {
            consultantData[consultantRef.id].briefs.push(brief);
          }
        });
      }
    });

    Object.values(consultantData).forEach(consultant => {
      consultant.activeBriefs = consultant.briefs.length;
      consultant.pipelineValue = consultant.briefs.reduce((acc, brief) => {
        const area = brief.max_floor_area || brief.min_floor_area || 0;
        return acc + (area * AVERAGE_RENT_PER_SQM);
      }, 0);

      let riskScore = 0;
      consultant.briefs.forEach(brief => {
        const daysSinceUpdate = (new Date() - new Date(brief.updated_date)) / (1000 * 3600 * 24);
        if (daysSinceUpdate > 60) riskScore += 2;
        else if (daysSinceUpdate > 30) riskScore += 1;
      });
      
      const clientIds = consultant.clients.map(c => c.id);
      const recentUpdates = updates.filter(u => clientIds.includes(u.client_id));
      const lastUpdateTime = recentUpdates.length > 0 ? new Date(Math.max(...recentUpdates.map(u => new Date(u.created_date)))) : new Date(0);
      const daysSinceComms = (new Date() - lastUpdateTime) / (1000 * 3600 * 24);

      if (daysSinceComms > 30) riskScore += 2;
      else if (daysSinceComms > 14) riskScore += 1;
      
      if (riskScore >= 3) consultant.pacingStatus = 'at_risk';
      else if (riskScore >= 1) consultant.pacingStatus = 'needs_monitoring';
      else consultant.pacingStatus = 'on_track';
    });

    return Object.values(consultantData);
  }, []);

  useEffect(() => {
    const loadAllData = async () => {
      setLoading(true);
      try {
        const [usersData, clientsData, briefsData, updatesData] = await Promise.all([
          User.list(),
          Client.list(),
          TenantRequirement.list(),
          ClientUpdate.list("-created_date", 500)
        ]);

        const stratosfyreAdmins = (usersData || []).filter(u => u.user_type === 'stratosfyre_admin');
        const performanceData = await calculatePerformance(
          stratosfyreAdmins, 
          clientsData || [], 
          briefsData || [], 
          updatesData || []
        );
        
        setConsultants(performanceData);
      } catch (error) {
        console.error("Error loading team performance data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadAllData();
  }, [calculatePerformance]);

  if (loading) {
    return (
      <div className="p-8 min-h-screen">
        <div className="text-center p-12">
          <Loader2 className="h-12 w-12 animate-spin text-orange-400 mx-auto" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Team Performance</h1>
          <p className="text-gray-300">Management overview of consultant workload and performance pacing.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {consultants.map(consultant => (
            <ConsultantCard key={consultant.id} consultant={consultant} />
          ))}
        </div>
        
        {consultants.length === 0 && (
          <div className="orbit-card p-12 text-center">
            <UserIcon className="w-12 h-12 mx-auto text-gray-500 mb-4"/>
            <h3 className="text-xl font-medium text-white">No Stratosfyre Team Members Found</h3>
            <p className="text-gray-400">Ensure users are assigned the 'Stratosfyre Team Member' role in User Management.</p>
          </div>
        )}
      </div>
    </div>
  );
}