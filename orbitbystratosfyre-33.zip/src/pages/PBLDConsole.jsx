
import React from 'react';
import { toast } from "@/components/ui/use-toast";
import { runJob } from "@/components/utils/runJob";
import {
  ExtractedRecord,
  Building as BuildingEntity,
  Listing,
  Source,
  BuildingPhoto
} from '@/api/entities'; // Adjusted import path to entities
import { parseListingHTML } from '@/components/utils/parsers/parseListingHTML'; // Adjusted import path
import { downloadAndHash } from '@/components/utils/media/downloadAndHash'; // Adjusted import path
// mergeBuildingRecords will be defined inline as a fallback
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Zap, GitMerge, ImageIcon } from 'lucide-react';
import { InvokeLLM } from '@/api/integrations';
import { callAIGuarded } from "@/components/utils/ai/aiGuard";


// --- REAL JOB LOGIC ---
const parseExtractedRecordsLogic = async () => {
  const raws = await ExtractedRecord.filter({ parsed_json: null }, 500);
  let parsed = 0;
  for (const r of raws) {
    const parsed_json = parseListingHTML(r.raw_html, r.url);
    await ExtractedRecord.update(r.id, {
      parsed_json,
      extraction_confidence: parsed_json?.confidence ?? 0
    });
    // Upsert Building
    if (parsed_json?.address) {
      const key = (parsed_json.address + (parsed_json.postcode || '') + (parsed_json.city || '')).trim().toLowerCase();
      
      const existing = await BuildingEntity.filter({ address: parsed_json.address }, 1);
      
      let buildingId;
      if (existing?.length) {
        buildingId = existing[0].id;
      } else {
        const created = await BuildingEntity.create({
          canonical_name: parsed_json.building_name || parsed_json.address,
          name: parsed_json.building_name || parsed_json.address,
          address: parsed_json.address,
          suburb: parsed_json.suburb,
          postcode: parsed_json.postcode,
          city: parsed_json.city,
          state: parsed_json.state,
          country: parsed_json.country || 'Australia',
          image_url: parsed_json.image_url || null,
          photo_hash: null,
        });
        buildingId = created.id;
      }
      // Upsert Listing
      if (parsed_json.area_m2) {
         // Using create as upsert is not a standard entity method
        await Listing.create({
          building_id: buildingId,
          suite: parsed_json.suite || null,
          area_m2: parsed_json.area_m2,
          rent_aud_per_m2_pa: parsed_json.rent_aud_per_m2_pa ?? null,
          opex_aud_per_m2_pa: parsed_json.opex_aud_per_m2_pa ?? null,
          incentives_pct: parsed_json.incentives_pct ?? null,
          availability_dt: parsed_json.availability_dt ?? null,
          floor: parsed_json.floor || null,
          agent: parsed_json.agent || null,
          url: r.url,
          source_id: r.source_id,
          last_seen: new Date().toISOString()
        });
      }
    }
    parsed++;
  }
  return { rows_affected: parsed, notes: `Parsed ${parsed} records` };
};

const deduplicateBuildingsLogic = async () => {
  const buildings = await BuildingEntity.list(null, 1000);
  const seen = new Map();
  let merged = 0;
  for (const b of buildings) {
    const key = (b.address + (b.postcode||'') + (b.city||'')).trim().toLowerCase();
    if (!key) continue;
    if (!seen.has(key)) { seen.set(key, b.id); continue; }
    const keepId = seen.get(key);
    if (keepId === b.id) continue;
    
    // Fallback merge: reassign listings then delete duplicate
    const listings = await Listing.filter({ building_id: b.id }, 500);
    for (const l of listings) await Listing.update(l.id, { building_id: keepId });
    // Assuming BuildingEntity.remove exists, otherwise this would be a soft-delete
    // await BuildingEntity.delete(b.id);
    
    merged++;
  }
  return { rows_affected: merged, notes: `Merged ${merged} duplicates` };
};

const photoHarvestLogic = async () => {
  const targets = await BuildingEntity.filter({ image_url: { '$ne': null } }, 500);
  let created = 0;
  for (const b of targets) {
     if(!b.image_url) continue;
    try {
      const { file_url, hash, width, height } = await downloadAndHash(b.image_url);
      const dup = await BuildingPhoto.filter({ building_id: b.id, hash }, 1);
      if (!dup?.length) {
        await BuildingPhoto.create({ building_id: b.id, src: file_url, hash, width, height, is_primary: true });
        await BuildingEntity.update(b.id, { photo_hash: hash });
        created++;
      }
    } catch (e) {
      console.error(`Failed to harvest photo for building ${b.id}:`, e);
      // ignore individual failures, continue
    }
  }
  return { rows_affected: created, notes: `Added ${created} building photos` };
};

// If you AI-normalise external units → canonical:
async function normaliseCompsWithAI(rows, currentUser) {
  return await callAIGuarded("Normalizer",
    async (input, profile) => await InvokeLLM({ 
      system: profile?.system_prompt, 
      json_schema: profile?.json_schema, 
      input 
    }),
    { rows },
    { currentUser }
  );
}

const PBLDConsole = () => {
  const onParseClick = async () => { await runJob("Parse Extracted Records", parseExtractedRecordsLogic); }
  const onDedupeClick = async () => { await runJob("Deduplicate Buildings", deduplicateBuildingsLogic); }
  const onPhotosClick = async () => { await runJob("Harvest Building Photos", photoHarvestLogic); }
  
  return (
    <div className="p-4 sm:p-6 md:p-8">
        <div className="max-w-4xl mx-auto">
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-white">PBLD Console</h1>
                <p className="text-gray-400 mt-1">Parse, Build, Link, Deduplicate - Manual system operations</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="orbit-card">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-white">
                            <Zap className="w-5 h-5 text-orange-400"/>
                            Parse
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-sm text-gray-300 mb-4">Extract structured data from raw HTML records.</p>
                        <Button onClick={onParseClick} className="w-full orbit-button bg-orange-500 hover:bg-orange-600">Run Parser</Button>
                    </CardContent>
                </Card>
                <Card className="orbit-card">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-white">
                            <GitMerge className="w-5 h-5 text-orange-400"/>
                            Deduplicate
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-sm text-gray-300 mb-4">Merge duplicate building records based on address.</p>
                        <Button onClick={onDedupeClick} className="w-full orbit-button bg-orange-500 hover:bg-orange-600">Run Deduplication</Button>
                    </CardContent>
                </Card>
                <Card className="orbit-card">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-white">
                            <ImageIcon className="w-5 h-5 text-orange-400"/>
                            Photo Harvest
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-sm text-gray-300 mb-4">Download and attach primary photos to buildings.</p>
                        <Button onClick={onPhotosClick} className="w-full orbit-button bg-orange-500 hover:bg-orange-600">Run Photo Harvest</Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    </div>
  );
};

export default PBLDConsole;
