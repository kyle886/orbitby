import React from 'react';
import AutomationDashboard from '../components/triggers/AutomationDashboard';

export default function AutomationsManager() {
  return (
    <div className="p-4 sm:p-6 md:p-8">
      <AutomationDashboard />
    </div>
  );
}