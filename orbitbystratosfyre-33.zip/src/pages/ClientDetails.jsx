import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Client } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import { Loader2, ArrowLeft, Plus } from 'lucide-react';

export default function ClientDetails() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const clientId = searchParams.get('id');

  const [client, setClient] = useState(null);
  const [briefs, setBriefs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        console.log('Loading client data for ID:', clientId);
        
        if (!clientId) {
          console.log('No client ID provided, redirecting...');
          navigate(createPageUrl('ClientManagement'));
          return;
        }

        setLoading(true);
        setError(null);

        // Get all clients and find the one we need
        const allClients = await Client.list();
        console.log('All clients loaded:', allClients?.length);
        
        const foundClient = allClients?.find(c => c.id === clientId);
        console.log('Found client:', foundClient);
        
        if (foundClient) {
          setClient(foundClient);
          
          // Try to load briefs
          try {
            const briefsData = await TenantRequirement.filter({ client_id: clientId }, "-created_date");
            console.log('Briefs loaded:', briefsData?.length);
            setBriefs(Array.isArray(briefsData) ? briefsData : []);
          } catch (briefError) {
            console.error('Error loading briefs:', briefError);
            setBriefs([]);
          }
        } else {
          console.log('Client not found');
          setClient(null);
          setBriefs([]);
        }
        
      } catch (err) {
        console.error('Error in loadData:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [clientId, navigate]);

  // Show error state
  if (error) {
    return (
      <div className="p-8">
        <div className="orbit-card p-6">
          <h2 className="text-xl text-red-400 mb-4">Error Loading Client</h2>
          <p className="text-gray-300 mb-4">{error}</p>
          <Button onClick={() => navigate(createPageUrl('ClientManagement'))}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Client Management
          </Button>
        </div>
      </div>
    );
  }

  // Show loading state
  if (loading) {
    return (
      <div className="flex justify-center items-center h-full p-8">
        <div className="orbit-card p-6">
          <Loader2 className="w-8 h-8 animate-spin text-orange-400 mx-auto mb-4" />
          <p className="text-gray-300">Loading client details...</p>
        </div>
      </div>
    );
  }

  // Show client not found
  if (!client) {
    return (
      <div className="p-8">
        <div className="orbit-card p-6">
          <h2 className="text-xl text-white mb-4">Client Not Found</h2>
          <p className="text-gray-400 mb-4">Could not find client with ID: {clientId}</p>
          <Button onClick={() => navigate(createPageUrl('ClientManagement'))}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Client Management
          </Button>
        </div>
      </div>
    );
  }

  // Main content
  return (
    <div className="min-h-screen p-8">
      <div className="max-w-6xl mx-auto">
        
        {/* Back button */}
        <div className="mb-6">
          <Button 
            variant="outline"
            className="orbit-button border-gray-600 hover:bg-gray-800"
            onClick={() => navigate(createPageUrl('ClientManagement'))}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to All Clients
          </Button>
        </div>

        {/* Client info */}
        <div className="orbit-card p-6 mb-8">
          <h1 className="text-3xl font-bold text-white">{client.company_name}</h1>
          <p className="text-gray-400 mt-2">{client.primary_contact_name} - {client.primary_contact_email}</p>
        </div>

        {/* Briefs section */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">Client Briefs ({briefs.length})</h2>
          <Button 
            onClick={() => navigate(createPageUrl('CreateBrief'))}
            className="orbit-button-active text-white px-4 py-2"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create New Brief
          </Button>
        </div>

        {/* Briefs list or empty state */}
        {briefs.length > 0 ? (
          <div className="grid gap-4">
            {briefs.map((brief) => (
              <div key={brief.id} className="orbit-card p-4">
                <h3 className="text-lg font-bold text-white">{brief.company_name}</h3>
                <p className="text-gray-400">{brief.brief_reference_code}</p>
                <p className="text-gray-300">{brief.property_type} - {brief.min_floor_area} sqm</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="orbit-card p-8 text-center">
            <h3 className="text-xl text-white mb-2">No Briefs Yet</h3>
            <p className="text-gray-400">This client doesn't have any briefs created.</p>
          </div>
        )}
      </div>
    </div>
  );
}