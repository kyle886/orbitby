
import React, { useMemo, useState, useEffect, useCallback } from "react";
import { useSearchParams, useNavigate } from "react-router-dom"; // Added useNavigate
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"; // Added CardHeader, CardTitle, CardContent
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/components/ui/use-toast";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from "recharts";

// New imports for dialog and select components from shadcn/ui
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import EducationBusinessCasePanel from '@/components/dev/EducationBusinessCasePanel';

// FIXED: Import entities using proper Base44 SDK
import { FeasibilityScenario } from '@/api/entities';
import { Deal } from '@/api/entities';

// Import lucide-react icons
import { AlertTriangle, RefreshCw } from 'lucide-react';

// New imports for functions
import { generatePack } from "@/api/functions";
import { renderPackPDF } from "@/api/functions";
import { buyVsLeaseCompare } from "@/api/functions";


// -----------------------------
// Helpers
// -----------------------------

function clamp(n, lo, hi) {
  return Math.max(lo, Math.min(hi, n));
}

const pct = (x) => x / 100;

const fmt = (n) => n.toLocaleString(undefined, {
  style: "currency",
  currency: "AUD",
  maximumFractionDigits: 0
});

// Simple IRR using Newton-Raphson over monthly cashflows
function irr(cashflows, guess = 0.1) {
  let rate = guess; // monthly rate guess
  for (let i = 0; i < 50; i++) {
    let npv = 0, d = 0; // derivative
    for (let t = 0; t < cashflows.length; t++) {
      const cf = cashflows[t];
      const denom = Math.pow(1 + rate, t);
      npv += cf / denom;
      d -= (t * cf) / (denom * (1 + rate));
    }
    if (Math.abs(npv) < 1e-6) return rate;
    const step = npv / d;
    rate -= step;
    if (!isFinite(rate) || rate <= -0.99) return null;
  }
  return null;
}

function compute(inputs) {
  const gdv = inputs.nsaM2 * inputs.pricePerM2 + inputs.otherRevenue;

  const hardCost = inputs.gfaM2 * inputs.buildRatePerM2;
  const professionalFees = hardCost * pct(inputs.professionalFeePct);
  const baseForCont = hardCost + professionalFees;
  const contingency = baseForCont * pct(inputs.contingencyPct);
  const marketingSales = gdv * pct(inputs.marketingSalesPct);

  const stamp = inputs.landPrice * pct(inputs.stampDutyPct);
  const acquisitionCosts = stamp + inputs.legalsAndDD;
  const authorityCosts = inputs.authorityFees;

  const gstOnBuild = inputs.applyGST ? (hardCost + professionalFees + contingency) * pct(inputs.gstPct) : 0;

  // Finance (simplified):
  const monthsPreCon = inputs.preconMonths;
  const monthsConst = inputs.constructionMonths;
  const monthsSettle = inputs.settlementMonths;
  const totalMonths = monthsPreCon + monthsConst + monthsSettle;

  const softBlock = professionalFees + contingency + authorityCosts;
  const buildBlock = hardCost;
  const marketingBlock = marketingSales;
  const avgDraw = inputs.landPrice
    + 0.5 * (buildBlock + softBlock) // drawn across precon+construction
    + 0.5 * marketingBlock; // drawn across settlement

  const interest = (inputs.interestRatePA / 100) * (avgDraw) * (totalMonths / 12);

  // Loan amount capped by LVR of total cost
  const costExMarketing = inputs.landPrice + acquisitionCosts + hardCost + professionalFees + contingency + authorityCosts + gstOnBuild;
  const loanCap = costExMarketing * pct(inputs.lvrPct);
  const loanFee = loanCap * pct(inputs.loanFeePct);
  const financeCost = interest + loanFee;

  const totalDevCost = costExMarketing + marketingSales + financeCost;
  const totalCostExLand = totalDevCost - inputs.landPrice;

  const profit = gdv - totalDevCost;
  const marginOnCostPct = totalCostExLand > 0 ? (profit / totalCostExLand) * 100 : 0;
  const marginOnRevenuePct = gdv > 0 ? (profit / gdv) * 100 : 0;

  const residualLandValue = gdv - (totalDevCost - inputs.landPrice);

  // Simple cashflow for IRR (monthly):
  const months = totalMonths;
  const cf = Array.from({ length: months + 1 }, () => 0);

  // t0: equity for land + some softs
  const equityLand = inputs.landPrice + acquisitionCosts;
  cf[0] = -equityLand;

  // precon: softs spread
  const softTotal = professionalFees + authorityCosts;
  for (let m = 1; m <= monthsPreCon; m++) cf[m] -= softTotal / monthsPreCon;

  // construction: hard + contingency + remaining softs
  const consSpan = Math.max(1, monthsConst);
  for (let m = monthsPreCon + 1; m <= monthsPreCon + monthsConst; m++) {
    cf[m] -= (hardCost + contingency) / consSpan;
  }

  // settlement: marketing out, revenue in at the end
  const setSpan = Math.max(1, monthsSettle);
  for (let m = monthsPreCon + monthsConst + 1; m <= months; m++) {
    cf[m] -= marketingSales / setSpan;
  }

  // finance fee at start of construction
  cf[Math.min(monthsPreCon + 1, months)] -= loanFee;

  // interest at end
  cf[months] -= interest;

  // revenue at end of settlement
  cf[months] += gdv;

  const monthlyIrr = irr(cf);
  const irrPct = monthlyIrr != null ? (Math.pow(1 + monthlyIrr, 12) - 1) * 100 : null;

  // Equity required = total cost - loan cap
  const equityRequired = Math.max(0, totalDevCost - loanCap);

  return {
    gdv,
    hardCost,
    professionalFees,
    contingency,
    marketingSales,
    acquisitionCosts,
    authorityCosts,
    financeCost,
    totalDevCost,
    totalCostExLand,
    profit,
    marginOnCostPct,
    marginOnRevenuePct,
    residualLandValue,
    equityRequired,
    irrPct,
    cashflow: cf,
  };
}

function Sensitivity({ base, onRecompute }) {
  const data = useMemo(() => {
    const deltas = [-10, -5, 0, 5, 10];
    return deltas.map((d) => {
      const tweak = { ...base, pricePerM2: base.pricePerM2 * (1 + d / 100) };
      const out = onRecompute(tweak);
      return {
        delta: `${d}%`,
        margin: Math.round(out.marginOnCostPct),
        rlv: out.residualLandValue
      };
    });
  }, [base, onRecompute]);

  return (
    <div className="h-64">
      <ResponsiveContainer>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="delta" />
          <YAxis yAxisId="left" />
          <YAxis yAxisId="right" orientation="right" />
          <Tooltip
            formatter={(v, n) => n === "rlv" ? fmt(v) : `${v}%`}
          />
          <Bar dataKey="margin" yAxisId="left" fill="#8884d8" />
          <Bar dataKey="rlv" yAxisId="right" fill="#82ca9d" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// -----------------------------
// New Components for Scenario Management
// -----------------------------

function SaveScenarioDialog({ onSave }) {
  const [name, setName] = useState("");
  const [open, setOpen] = useState(false);

  const handleSave = () => {
    if (name.trim()) {
      onSave(name.trim());
      setName("");
      setOpen(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="bg-white/10 text-white hover:bg-white/20">Save Scenario</Button>
      </DialogTrigger>
      <DialogContent className="bg-gray-900 text-white border-gray-700">
        <DialogHeader>
          <DialogTitle>Save Scenario</DialogTitle>
          <DialogDescription>
            Give this feasibility scenario a name to save it for future reference.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <Label htmlFor="scenario-name" className="text-gray-300">Scenario Name</Label>
          <Input
            id="scenario-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Base Case, Optimistic, Conservative"
            className="bg-gray-800 border-gray-700 text-white"
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} className="bg-white/10 text-white hover:bg-white/20 border-gray-700">Cancel</Button>
          <Button onClick={handleSave} disabled={!name.trim()} className="bg-orange-500 hover:bg-orange-600 text-white">Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ScenarioSelector({ scenarios, onSelect, activeScenarioId }) {
  const [selectedScenarioId, setSelectedScenarioId] = useState("");

  useEffect(() => {
    // Sync internal state with activeScenarioId from parent
    if (activeScenarioId !== selectedScenarioId) {
      setSelectedScenarioId(activeScenarioId || "");
    }

    // This logic ensures a default selection if no active scenario is set
    // or if the active scenario is no longer in the list.
    if (scenarios.length > 0) {
      if (!activeScenarioId || !scenarios.some(s => s.id === activeScenarioId)) {
        const firstScenarioId = scenarios[0].id;
        if (selectedScenarioId !== firstScenarioId) {
          onSelect(firstScenarioId);
          setSelectedScenarioId(firstScenarioId);
        }
      }
    } else if (scenarios.length === 0 && selectedScenarioId !== "") {
      setSelectedScenarioId("");
      onSelect("");
    }
  }, [scenarios, onSelect, activeScenarioId, selectedScenarioId]);

  return (
    <Select value={selectedScenarioId} onValueChange={(value) => {
      setSelectedScenarioId(value);
      onSelect(value);
    }}>
      <SelectTrigger className="w-[250px] bg-gray-800/50 border-gray-700 text-white">
        <SelectValue placeholder="Select a scenario..." />
      </SelectTrigger>
      <SelectContent className="bg-gray-900 text-white border-gray-700">
        {scenarios.length === 0 ? (
          <SelectItem value="no-scenarios" disabled>No saved scenarios</SelectItem>
        ) : (
          scenarios.map((scenario) => (
            <SelectItem key={scenario.id} value={scenario.id}>
              {scenario.name}
            </SelectItem>
          ))
        )}
      </SelectContent>
    </Select>
  );
}

// -----------------------------
// Component
// -----------------------------

export default function DevFeasibilityModule() {
  const [searchParams] = useSearchParams();
  const dealId = searchParams.get('dealId') || searchParams.get('id') || "ADHOC";
  const { toast } = useToast();
  const navigate = useNavigate(); // Initialize useNavigate

  const [inputs, setInputs] = useState({
    // Land & Acquisition
    landPrice: 1000000,
    stampDutyPct: 5.5,
    legalsAndDD: 25000,

    // Development Parameters
    gfaM2: 1500,
    nsaM2: 1200,
    pricePerM2: 8000,
    buildRatePerM2: 3000,

    // Professional & Soft Costs
    professionalFeePct: 12,
    contingencyPct: 5,
    authorityFees: 50000,

    // Marketing & Sales
    marketingSalesPct: 3,
    otherRevenue: 0,

    // Finance
    interestRatePA: 7,
    lvrPct: 70,
    loanFeePct: 1,

    // Timing
    preconMonths: 6,
    constructionMonths: 18,
    settlementMonths: 3,

    // GST
    applyGST: true,
    gstPct: 10
  });

  const [scenarios, setScenarios] = useState([]);
  const [deal, setDeal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeScenarioId, setActiveScenarioId] = useState(null);

  const outputs = useMemo(() => compute(inputs), [inputs]);

  const updateInput = (field, value) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const loadScenarios = useCallback(async () => {
    setLoading(true);
    setError(null); // Clear previous errors
    try {
      const fetchedScenarios = await FeasibilityScenario.filter({ dealId });
      setScenarios(fetchedScenarios || []);

      if (dealId !== "ADHOC") {
        try {
          const dealData = await Deal.get(dealId);
          setDeal(dealData);
        } catch (dealError) {
          console.warn("Deal not found, using ADHOC mode for dealId:", dealId);
          setDeal(null);
        }
      } else {
        setDeal(null); // Ensure deal is null for ADHOC
      }
    } catch (err) {
      console.error("Error loading scenarios or deal:", err);
      setError(err.message || "An unknown error occurred while loading data.");
      toast({
        variant: "destructive",
        title: "Error loading scenarios",
        description: err.message
      });
    } finally {
      setLoading(false);
    }
  }, [dealId, toast]);

  const handleLoadScenario = async (scenarioId) => {
    try {
      const scenario = await FeasibilityScenario.get(scenarioId);
      if (scenario) {
        setInputs(scenario.inputs);
        setActiveScenarioId(scenario.id);
        toast({
          title: "Scenario Loaded",
          description: `Loaded scenario: ${scenario.name}`
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Scenario not found.",
        });
      }
    } catch (err) {
      console.error("Failed to load scenario", err);
      toast({
        variant: "destructive",
        title: "Error loading scenario",
        description: err.message
      });
    }
  };

  const handleSaveScenario = async (name) => {
    try {
      const scenarioData = {
        dealId: dealId,
        name: name,
        inputs: inputs,
        outputs: outputs,
        createdBy: "current-user" // This should be replaced with actual user ID
      };
      const saved = await FeasibilityScenario.create(scenarioData);

      await loadScenarios(); // Refresh the list of scenarios
      setActiveScenarioId(saved.id); // Set new scenario as active

      toast({
        title: "Scenario Saved",
        description: `Scenario "${name}" saved successfully with ID: ${saved.id}`,
      });
    } catch (err) {
      console.error("Failed to save scenario", err);
      toast({
        variant: "destructive",
        title: "Error saving scenario",
        description: err.message
      });
    }
  };

  // Renamed and updated the original `generateBoardPack` to match outline's `handleBoardPackWizard` intent
  const handleBoardPackWizard = () => {
    navigate(`/BoardPackWizard?from=feaso&dealId=${dealId}`);
  };

  const handleOneClickPDF = async () => {
    try {
      toast({
        title: "Generating Board Pack",
        description: "This might take a moment...",
      });
      const packResult = await generatePack({
        dealId,
        include: ["map", "site", "feasoSummary", "risks", "timeline"]
      });
      toast({
        title: "Board Pack Created",
        description: `Pack ID: ${packResult.data.packId}. Rendering PDF...`,
      });
      const pdfResult = await renderPackPDF({ packId: packResult.data.packId });
      window.open(pdfResult.data.url, "_blank");
      toast({
        title: "PDF Generated Successfully",
        description: "Your board pack PDF is ready in a new tab.",
      });
    } catch (error) {
      console.error('Failed to generate PDF:', error);
      toast({
        variant: "destructive",
        title: "Failed to generate PDF",
        description: error.message || "An unexpected error occurred.",
      });
    }
  };

  const handleBuyVsLease = async () => {
    try {
      toast({
        title: "Running Buy vs Lease Analysis",
        description: "Processing comparison...",
      });
      const compare = await buyVsLeaseCompare({
        dealId,
        rentEscalation: 3.5,
        capexResponsibility: "tenant",
        leaseType: "net"
      });
      console.log('Buy vs Lease comparison:', compare.data);
      toast({
        title: "Buy vs Lease Analysis Complete",
        description: "Comparison results logged to console.",
      });
    } catch (error) {
      console.error('Buy vs Lease comparison failed:', error);
      toast({
        variant: "destructive",
        title: "Buy vs Lease Comparison Failed",
        description: error.message || "An unexpected error occurred.",
      });
    }
  };

  useEffect(() => {
    loadScenarios();
  }, [loadScenarios]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-black text-white p-4 sm:p-6 lg:p-8">
        <div className="p-8 flex justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-black text-white p-4 sm:p-6 lg:p-8">
        <div className="p-8">
          <Alert variant="destructive" className="bg-red-900/50 border-red-700 text-red-100">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
          <Button onClick={loadScenarios} className="mt-4 bg-orange-500 hover:bg-orange-600 text-white">
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto"> {/* Changed max-w-7xl for consistent styling with existing components */}
        <header className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-white">Development Feasibility</h1>
            <p className="text-gray-400">
              {deal ? `Deal: ${deal.name}` : 'Ad-hoc Analysis'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            {scenarios.length > 0 && (
              <ScenarioSelector
                scenarios={scenarios}
                onSelect={handleLoadScenario}
                activeScenarioId={activeScenarioId}
              />
            )}
            <SaveScenarioDialog onSave={handleSaveScenario} />
            <Button
              onClick={handleBoardPackWizard} // Updated to use the new wizard handler
              className="bg-orange-500 hover:bg-orange-600 text-white"
            >
              Generate Board Pack
            </Button>
          </div>
        </header>

        <Tabs defaultValue="inputs" className="space-y-4">
          <TabsList className="bg-gray-800/60 grid w-full grid-cols-4">
            <TabsTrigger value="inputs">Inputs</TabsTrigger>
            <TabsTrigger value="outputs">Outputs</TabsTrigger>
            <TabsTrigger value="sensitivity">Sensitivity</TabsTrigger>
            <TabsTrigger value="cashflow">Cashflow</TabsTrigger>
            <TabsTrigger value="education">Education</TabsTrigger>
          </TabsList>

          <TabsContent value="inputs">
            <div className="grid md:grid-cols-3 gap-4">
              <Card className="orbit-card p-4">
                <SectionTitle title="Revenue" />
                <Field label="Net saleable area (m²)">
                  <NumberInput
                    value={inputs.nsaM2}
                    onChange={(v) => updateInput('nsaM2', v)}
                  />
                </Field>
                <Field label="Avg sale price ($/m²)">
                  <NumberInput
                    value={inputs.pricePerM2}
                    onChange={(v) => updateInput('pricePerM2', v)}
                  />
                </Field>
                <Field label="Other revenue ($)">
                  <NumberInput
                    value={inputs.otherRevenue}
                    onChange={(v) => updateInput('otherRevenue', v)}
                  />
                </Field>
              </Card>

              <Card className="orbit-card p-4">
                <SectionTitle title="Land & Acquisition" />
                <Field label="Land price ($)">
                  <NumberInput
                    value={inputs.landPrice}
                    onChange={(v) => updateInput('landPrice', v)}
                  />
                </Field>
                <Field label="Stamp duty (%)">
                  <NumberInput
                    value={inputs.stampDutyPct}
                    onChange={(v) => updateInput('stampDutyPct', v)}
                  />
                </Field>
                <Field label="Legals & DD ($)">
                  <NumberInput
                    value={inputs.legalsAndDD}
                    onChange={(v) => updateInput('legalsAndDD', v)}
                  />
                </Field>
              </Card>

              <Card className="orbit-card p-4">
                <SectionTitle title="Hard Costs" />
                <Field label="GFA (m²)">
                  <NumberInput
                    value={inputs.gfaM2}
                    onChange={(v) => updateInput('gfaM2', v)}
                  />
                </Field>
                <Field label="Build rate ($/m²)">
                  <NumberInput
                    value={inputs.buildRatePerM2}
                    onChange={(v) => updateInput('buildRatePerM2', v)}
                  />
                </Field>
              </Card>

              <Card className="orbit-card p-4">
                <SectionTitle title="Soft Costs" />
                <Field label="Professional fees (% of hard)">
                  <NumberInput
                    value={inputs.professionalFeePct}
                    onChange={(v) => updateInput('professionalFeePct', v)}
                  />
                </Field>
                <Field label="Contingency (% of hard+prof)">
                  <NumberInput
                    value={inputs.contingencyPct}
                    onChange={(v) => updateInput('contingencyPct', v)}
                  />
                </Field>
                <Field label="Authority fees ($)">
                  <NumberInput
                    value={inputs.authorityFees}
                    onChange={(v) => updateInput('authorityFees', v)}
                  />
                </Field>
                <Field label="Marketing+Sales (% of GDV)">
                  <NumberInput
                    value={inputs.marketingSalesPct}
                    onChange={(v) => updateInput('marketingSalesPct', v)}
                  />
                </Field>
              </Card>

              <Card className="orbit-card p-4">
                <SectionTitle title="Programme (months)" />
                <Field label="Pre-construction">
                  <NumberInput
                    value={inputs.preconMonths}
                    onChange={(v) => updateInput('preconMonths', Math.round(v))}
                  />
                </Field>
                <Field label="Construction">
                  <NumberInput
                    value={inputs.constructionMonths}
                    onChange={(v) => updateInput('constructionMonths', Math.round(v))}
                  />
                </Field>
                <Field label="Settlement">
                  <NumberInput
                    value={inputs.settlementMonths}
                    onChange={(v) => updateInput('settlementMonths', Math.round(v))}
                  />
                </Field>
              </Card>

              <Card className="orbit-card p-4">
                <SectionTitle title="Finance" />
                <Field label="Interest rate (% p.a.)">
                  <NumberInput
                    value={inputs.interestRatePA}
                    onChange={(v) => updateInput('interestRatePA', v)}
                  />
                </Field>
                <Field label="LVR (% of total cost cap)">
                  <NumberInput
                    value={inputs.lvrPct}
                    onChange={(v) => updateInput('lvrPct', clamp(v, 0, 90))}
                  />
                </Field>
                <Field label="Loan fee (% of loan)">
                  <NumberInput
                    value={inputs.loanFeePct}
                    onChange={(v) => updateInput('loanFeePct', v)}
                  />
                </Field>
                <div className="flex items-center justify-between rounded-lg bg-gray-800/50 p-3 mt-2">
                  <div>
                    <div className="text-sm text-gray-300">Apply GST on build inputs</div>
                    <div className="text-xs text-gray-500">
                      {inputs.gstPct}% applied to hard/soft/contingency
                    </div>
                  </div>
                  <Switch
                    checked={inputs.applyGST}
                    onCheckedChange={(v) => updateInput('applyGST', v)}
                  />
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="outputs">
            <FeasibilityOutputs outputs={outputs} />
          </TabsContent>

          <TabsContent value="sensitivity">
            <SensitivityTab
              baseScenario={inputs}
              onRun={compute} // The 'compute' function acts as the recomputation logic
              results={null} // Placeholder, as the current Sensitivity component computes internally
              loading={false} // Placeholder, as the current Sensitivity component doesn't have loading state
            />
          </TabsContent>

          <TabsContent value="cashflow">
            <Card className="orbit-card p-4">
              <div className="h-64">
                <ResponsiveContainer>
                  <LineChart data={outputs.cashflow.map((v, idx) => ({ idx, cf: v }))}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                      dataKey="idx"
                      tickFormatter={(t) => `M${t}`}
                    />
                    <YAxis />
                    <Tooltip
                      formatter={(v) => fmt(v)}
                      labelFormatter={(l) => `Month ${l}`}
                    />
                    <Line
                      type="monotone"
                      dataKey="cf"
                      stroke="#8884d8"
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="education">
            <EducationBusinessCasePanel />
          </TabsContent>
        </Tabs>

        {/* Board Pack Integration */}
        <Card className="orbit-card bg-gray-800/50 border-gray-700 mt-6">
          <CardHeader>
            <CardTitle className="text-white">Additional Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 flex-wrap">
              <Button
                onClick={handleBoardPackWizard}
                className="bg-blue-700 hover:bg-blue-600 text-white"
              >
                Open Board Pack Wizard
              </Button>
              <Button
                onClick={handleOneClickPDF}
                className="bg-green-700 hover:bg-green-600 text-white"
              >
                One-click Generate PDF
              </Button>
              <Button
                onClick={handleBuyVsLease}
                className="bg-purple-700 hover:bg-purple-600 text-white"
              >
                Buy vs Lease Analysis
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// -----------------------------
// Primitives
// -----------------------------

function SectionTitle({ title }) {
  return <div className="text-sm font-medium text-gray-300 mb-2">{title}</div>;
}

function Field({ label, children }) {
  return (
    <div className="space-y-1 mb-2">
      <Label className="text-gray-300 text-xs">{label}</Label>
      {children}
    </div>
  );
}

function NumberInput({ value, onChange }) {
  return (
    <Input
      inputMode="decimal"
      className="orbit-input bg-gray-800 border-gray-700 text-white"
      value={isNaN(value) ? "" : value}
      onChange={(e) => onChange(Number(e.target.value || 0))}
    />
  );
}

function Kpi({ title, value, highlight }) {
  return (
    <Card className={`orbit-card p-4 ${highlight ? "ring-1 ring-white/10" : ""}`}>
      <div className="text-xs text-gray-400">{title}</div>
      <div className="text-xl font-semibold text-white">{value}</div>
    </Card>
  );
}

// New component to encapsulate Feasibility Outputs
function FeasibilityOutputs({ outputs }) {
  return (
    <div className="grid lg:grid-cols-4 gap-4">
      <Kpi title="GDV" value={fmt(outputs.gdv)} />
      <Kpi title="Hard cost" value={fmt(outputs.hardCost)} />
      <Kpi title="Prof. fees" value={fmt(outputs.professionalFees)} />
      <Kpi title="Contingency" value={fmt(outputs.contingency)} />
      <Kpi title="Marketing+Sales" value={fmt(outputs.marketingSales)} />
      <Kpi title="Acquisition costs" value={fmt(outputs.acquisitionCosts)} />
      <Kpi title="Authority fees" value={fmt(outputs.authorityCosts)} />
      <Kpi title="Finance cost" value={fmt(outputs.financeCost)} />
      <Kpi title="Total dev cost" value={fmt(outputs.totalDevCost)} highlight />
      <Kpi title="Residual land value" value={fmt(outputs.residualLandValue)} highlight />
      <Kpi title="Margin on cost" value={`${outputs.marginOnCostPct.toFixed(1)}%`} highlight />
      <Kpi title="Margin on revenue" value={`${outputs.marginOnRevenuePct.toFixed(1)}%`} />
      <Kpi title="Equity required" value={fmt(outputs.equityRequired)} />
      <Kpi
        title="IRR (annualised)"
        value={outputs.irrPct != null ? `${outputs.irrPct.toFixed(1)}%` : "—"}
      />
    </div>
  );
}

// New component to encapsulate Sensitivity Tab content
function SensitivityTab({ baseScenario, onRun, results, loading }) {
  // `onRun`, `results`, `loading` from the outline for SensitivityTab are not directly used by the current `Sensitivity` component.
  // The `Sensitivity` component itself takes a `base` object (inputs) and `onRecompute` function.
  // We pass `baseScenario` as `base` and `onRun` (which is `compute` in the parent) as `onRecompute`.
  return (
    <Card className="orbit-card p-4 bg-gray-800/50 border-gray-700">
      <div className="mb-2 text-sm text-gray-300">
        Price sensitivity (±10%) vs margin and RLV
      </div>
      <Sensitivity base={baseScenario} onRecompute={onRun} />
    </Card>
  );
}
