import React, { useState, useEffect, useCallback } from 'react';
import { Client } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { PropertySubmission } from '@/api/entities';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Users,
  Building2,
  Calendar,
  TrendingUp,
  Plus,
  Search,
  Filter,
  MoreVertical,
  Mail,
  Phone,
  MapPin,
  Briefcase,
  Clock } from
'lucide-react';

const ClientCard = ({ client, briefs, submissions }) => {
  const getStatusColor = (status) => {
    const colors = {
      'discovery': 'bg-blue-500/20 text-blue-300',
      'search_active': 'bg-green-500/20 text-green-300',
      'negotiation': 'bg-yellow-500/20 text-yellow-300',
      'lease_execution': 'bg-purple-500/20 text-purple-300',
      'completed': 'bg-gray-500/20 text-gray-300'
    };
    return colors[status] || colors['discovery'];
  };

  const activeBriefs = briefs.filter((b) => b.status === 'active');
  const totalSubmissions = submissions.length;
  const shortlistedSubmissions = submissions.filter((s) => s.status === 'shortlisted').length;

  return (
    <Card className="orbit-card hover:shadow-lg transition-all">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="text-lg text-white mb-1">
              <Link to={createPageUrl(`ClientDetails?id=${client.id}`)} className="hover:text-orange-400">
                {client.company_name}
              </Link>
            </CardTitle>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <Badge className={getStatusColor(client.engagement_status)}>
                {client.engagement_status?.replace('_', ' ').toUpperCase()}
              </Badge>
              <span>•</span>
              <span>{client.industry}</span>
            </div>
          </div>
          <Button variant="ghost" size="icon">
            <MoreVertical className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          {/* Contact Info */}
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm">
              <Mail className="w-4 h-4 text-gray-500" />
              <span className="text-gray-300">{client.primary_contact_name}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <span className="w-4"></span>
              <a href={`mailto:${client.primary_contact_email}`} className="hover:text-orange-400">
                {client.primary_contact_email}
              </a>
            </div>
            {client.primary_contact_phone &&
            <div className="flex items-center gap-2 text-sm text-gray-400">
                <Phone className="w-4 h-4 text-gray-500" />
                <span>{client.primary_contact_phone}</span>
              </div>
            }
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-3 gap-3 pt-3 border-t border-gray-700">
            <div className="text-center">
              <div className="text-lg font-semibold text-white">{activeBriefs.length}</div>
              <div className="text-xs text-gray-400">Active Briefs</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-white">{totalSubmissions}</div>
              <div className="text-xs text-gray-400">Properties</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-white">{shortlistedSubmissions}</div>
              <div className="text-xs text-gray-400">Shortlisted</div>
            </div>
          </div>

          {/* Target Move Date */}
          {client.target_move_date &&
          <div className="flex items-center gap-2 text-sm pt-2 border-t border-gray-700">
              <Calendar className="w-4 h-4 text-orange-400" />
              <span className="text-gray-300">
                Target: {new Date(client.target_move_date).toLocaleDateString()}
              </span>
              <span className="text-xs text-gray-500">
                ({Math.ceil((new Date(client.target_move_date) - new Date()) / (1000 * 60 * 60 * 24))} days)
              </span>
            </div>
          }
        </div>
      </CardContent>
    </Card>);

};

const NewClientDialog = ({ open, onOpenChange, onClientCreated }) => {
  const [formData, setFormData] = useState({
    company_name: '',
    industry: 'software',
    primary_contact_name: '',
    primary_contact_email: '',
    primary_contact_phone: '',
    engagement_status: 'discovery',
    target_move_date: '',
    current_location: '',
    team_size: '',
    growth_projection: '',
    budget_range_min: '',
    budget_range_max: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const clientData = {
        ...formData,
        team_size: formData.team_size ? parseInt(formData.team_size) : null,
        growth_projection: formData.growth_projection ? parseInt(formData.growth_projection) : null,
        budget_range_min: formData.budget_range_min ? parseFloat(formData.budget_range_min) : null,
        budget_range_max: formData.budget_range_max ? parseFloat(formData.budget_range_max) : null,
        target_move_date: formData.target_move_date || null,
        engagement_start_date: new Date().toISOString().split('T')[0]
      };

      await Client.create(clientData);
      onClientCreated();
      onOpenChange(false);

      // Reset form
      setFormData({
        company_name: '',
        industry: 'software',
        primary_contact_name: '',
        primary_contact_email: '',
        primary_contact_phone: '',
        engagement_status: 'discovery',
        target_move_date: '',
        current_location: '',
        team_size: '',
        growth_projection: '',
        budget_range_min: '',
        budget_range_max: ''
      });
    } catch (error) {
      console.error('Error creating client:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Add New Client</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Company Name *
              </label>
              <Input
                value={formData.company_name}
                onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
                required className="bg-background text-slate-900 px-3 py-2 text-base flex h-10 w-full rounded-md border border-input ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm" />

            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Industry *
              </label>
              <Select value={formData.industry} onValueChange={(value) => setFormData({ ...formData, industry: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="deep_tech">Deep Tech</SelectItem>
                  <SelectItem value="education">Education</SelectItem>
                  <SelectItem value="software">Software</SelectItem>
                  <SelectItem value="fintech">Fintech</SelectItem>
                  <SelectItem value="biotech">Biotech</SelectItem>
                  <SelectItem value="cleantech">Cleantech</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Primary Contact *
              </label>
              <Input
                value={formData.primary_contact_name}
                onChange={(e) => setFormData({ ...formData, primary_contact_name: e.target.value })}
                required className="bg-background text-slate-900 px-3 py-2 text-base flex h-10 w-full rounded-md border border-input ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm" />

            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Email *
              </label>
              <Input
                type="email"
                value={formData.primary_contact_email}
                onChange={(e) => setFormData({ ...formData, primary_contact_email: e.target.value })}
                required />

            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Phone
              </label>
              <Input
                value={formData.primary_contact_phone}
                onChange={(e) => setFormData({ ...formData, primary_contact_phone: e.target.value })} />

            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Engagement Status
              </label>
              <Select value={formData.engagement_status} onValueChange={(value) => setFormData({ ...formData, engagement_status: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="discovery">Discovery</SelectItem>
                  <SelectItem value="search_active">Search Active</SelectItem>
                  <SelectItem value="negotiation">Negotiation</SelectItem>
                  <SelectItem value="lease_execution">Lease Execution</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Target Move Date
              </label>
              <Input
                type="date"
                value={formData.target_move_date}
                onChange={(e) => setFormData({ ...formData, target_move_date: e.target.value })} />

            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Current Location
              </label>
              <Input
                value={formData.current_location}
                onChange={(e) => setFormData({ ...formData, current_location: e.target.value })} className="bg-background text-gray-900 px-3 py-2 text-base flex h-10 w-full rounded-md border border-input ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm" />

            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Team Size
              </label>
              <Input
                type="number"
                value={formData.team_size}
                onChange={(e) => setFormData({ ...formData, team_size: e.target.value })} />

            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Growth Projection (2-3 years)
              </label>
              <Input
                type="number"
                value={formData.growth_projection}
                onChange={(e) => setFormData({ ...formData, growth_projection: e.target.value })} />

            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Min Monthly Budget ($)
              </label>
              <Input
                type="number"
                value={formData.budget_range_min}
                onChange={(e) => setFormData({ ...formData, budget_range_min: e.target.value })} />

            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Max Monthly Budget ($)
              </label>
              <Input
                type="number"
                value={formData.budget_range_max}
                onChange={(e) => setFormData({ ...formData, budget_range_max: e.target.value })} />

            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Creating...' : 'Create Client'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>);

};

export default function ClientManagement() {
  const [clients, setClients] = useState([]);
  const [briefs, setBriefs] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [industryFilter, setIndustryFilter] = useState('all');
  const [newClientDialogOpen, setNewClientDialogOpen] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [clientsData, briefsData, submissionsData] = await Promise.all([
      Client.list('-updated_date'),
      TenantRequirement.list(),
      PropertySubmission.list()]
      );

      setClients(clientsData || []);
      setBriefs(briefsData || []);
      setSubmissions(submissionsData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const filteredClients = clients.filter((client) => {
    const matchesSearch = client.company_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.primary_contact_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || client.engagement_status === statusFilter;
    const matchesIndustry = industryFilter === 'all' || client.industry === industryFilter;

    return matchesSearch && matchesStatus && matchesIndustry;
  });

  const getClientBriefs = (clientId) => briefs.filter((b) => b.client_id === clientId);
  const getClientSubmissions = (clientId) => submissions.filter((s) => s.brief_ids?.includes(clientId));

  const stats = {
    total: clients.length,
    active: clients.filter((c) => c.engagement_status === 'search_active').length,
    negotiating: clients.filter((c) => c.engagement_status === 'negotiation').length,
    completing: clients.filter((c) => c.engagement_status === 'lease_execution').length
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full p-8">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full animate-pulse bg-white/10 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading clients...</p>
        </div>
      </div>);

  }

  return (
    <div className="p-4 sm:p-6 md:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Client Management</h1>
          <p className="text-gray-300">Manage active client engagements and track progress</p>
        </div>
        <Dialog open={newClientDialogOpen} onOpenChange={setNewClientDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Client
            </Button>
          </DialogTrigger>
          <NewClientDialog
            open={newClientDialogOpen}
            onOpenChange={setNewClientDialogOpen}
            onClientCreated={loadData} />

        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Clients</p>
                <p className="text-2xl font-bold text-white">{stats.total}</p>
              </div>
              <Users className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Active Search</p>
                <p className="text-2xl font-bold text-white">{stats.active}</p>
              </div>
              <Search className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Negotiating</p>
                <p className="text-2xl font-bold text-white">{stats.negotiating}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Completing</p>
                <p className="text-2xl font-bold text-white">{stats.completing}</p>
              </div>
              <Briefcase className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input
            placeholder="Search clients..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10" />

        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="bg-background text-gray-900 px-3 py-2 text-sm flex h-10 items-center justify-between rounded-md border border-input ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1 w-[160px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="discovery">Discovery</SelectItem>
            <SelectItem value="search_active">Search Active</SelectItem>
            <SelectItem value="negotiation">Negotiation</SelectItem>
            <SelectItem value="lease_execution">Lease Execution</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
        <Select value={industryFilter} onValueChange={setIndustryFilter}>
          <SelectTrigger className="bg-background text-gray-900 px-3 py-2 text-sm flex h-10 items-center justify-between rounded-md border border-input ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1 w-[160px]">
            <SelectValue placeholder="Industry" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Industries</SelectItem>
            <SelectItem value="deep_tech">Deep Tech</SelectItem>
            <SelectItem value="education">Education</SelectItem>
            <SelectItem value="software">Software</SelectItem>
            <SelectItem value="fintech">Fintech</SelectItem>
            <SelectItem value="biotech">Biotech</SelectItem>
            <SelectItem value="cleantech">Cleantech</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Clients Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClients.map((client) =>
        <ClientCard
          key={client.id}
          client={client}
          briefs={getClientBriefs(client.id)}
          submissions={getClientSubmissions(client.id)} />

        )}
      </div>

      {filteredClients.length === 0 &&
      <div className="text-center py-12">
          <Users className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No clients found</h3>
          <p className="text-gray-400 mb-4">
            {searchTerm || statusFilter !== 'all' || industryFilter !== 'all' ?
          'Try adjusting your filters' :
          'Get started by adding your first client'
          }
          </p>
          {!searchTerm && statusFilter === 'all' && industryFilter === 'all' &&
        <Button onClick={() => setNewClientDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add First Client
            </Button>
        }
        </div>
      }
    </div>);

}