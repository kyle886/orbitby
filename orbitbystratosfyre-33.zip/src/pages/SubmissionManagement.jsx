
import React, { useState, useEffect } from "react";
import { PropertySubmission } from "@/api/entities";
import { Client } from "@/api/entities";
import { TenantRequirement } from "@/api/entities";
import { InspectionItinerary } from "@/api/entities";
import { SendEmail } from "@/api/integrations";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Building, Briefcase, Filter, ChevronDown, CheckCircle, AlertCircle, XCircle, MapPin, Calendar, AlertTriangle, Eye, Square, DollarSign, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import ClientBriefSelector from "@/components/ClientBriefSelector";
import KanbanView from "@/components/submissions/KanbanView";

export default function SubmissionManagement() {
  const [submissions, setSubmissions] = useState([]);
  const [allClients, setAllClients] = useState([]);
  const [allBriefs, setAllBriefs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    client_id: "",
    status: "",
    brief_match_status: ""
  });
  const [inspectionItems, setInspectionItems] = useState({});
  const [rfpItems, setRfpItems] = useState([]); // New state for RFP selection
  const [rejectionDialog, setRejectionDialog] = useState({ open: false, submission: null });
  const [rejectionReason, setRejectionReason] = useState("");
  const [customReason, setCustomReason] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState('kanban'); // Changed default to kanban
  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [submissionsData, clientsData, briefsData] = await Promise.all([
        PropertySubmission.list("-created_date"),
        Client.list(),
        TenantRequirement.list("-created_date")
      ]);
      setSubmissions(submissionsData || []);
      setAllClients(clientsData || []);
      setAllBriefs(briefsData || []);
      
      console.log('Loaded data:', {
        submissions: submissionsData?.length || 0,
        clients: clientsData?.length || 0, 
        briefs: briefsData?.length || 0
      });
    } catch (error) {
      console.error("Error loading data:", error);
      setSubmissions([]);
      setAllClients([]);
      setAllBriefs([]);
    } finally {
      setLoading(false);
    }
  };

  const onSubmissionUpdate = (submissionId, updateData) => {
    setSubmissions(prev => (prev || []).map(s => 
      s.id === submissionId ? { ...s, ...updateData } : s
    ));
  };
  
  const getAssignmentDetails = (submission) => {
    const assignedBriefs = (submission.brief_ids || [])
        .map(briefId => (allBriefs || []).find(b => b.id === briefId))
        .filter(Boolean);

    if (assignedBriefs.length === 0) {
        return { clientNames: "Not Assigned", briefCodes: [] };
    }

    const clientIds = [...new Set(assignedBriefs.map(b => b.client_id))];
    const clientNames = clientIds.map(clientId => {
        const client = (allClients || []).find(c => c.id === clientId);
        return client ? client.company_name : "Unknown Client";
    }).join(', ');

    return {
        clientNames,
        briefCodes: assignedBriefs.map(b => b.brief_reference_code)
    };
  };

  const detectConflicts = (submission) => {
    const samePropertySubmissions = (submissions || []).filter(s => 
      s.address === submission.address && 
      s.status === 'shortlisted' && 
      s.id !== submission.id
    );
    
    if (samePropertySubmissions.length > 0) {
        const currentClients = getAssignmentDetails(submission).clientNames;
        const conflictClients = samePropertySubmissions
            .map(s => getAssignmentDetails(s).clientNames)
            .filter(name => name !== "Not Assigned" && name !== currentClients);
      
        if (conflictClients.length > 0) {
            return [...new Set(conflictClients.flatMap(name => name.split(', ')))];
        }
    }
    return [];
  };

  const sendAgentNotification = async (submission, status, rejectionReason = null) => {
    // More robust check for a valid email before attempting to send
    if (!submission.agent_email || !submission.agent_email.includes('@')) {
      console.warn(`Skipping agent notification for submission ${submission.id} due to invalid or missing email:`, submission.agent_email);
      return;
    }

    const assignment = getAssignmentDetails(submission);
    
    let subject = "";
    let body = "";

    switch (status) {
      case 'under_review':
        subject = "Property Submission Update: Under Review";
        body = `Dear ${submission.agent_name || 'Agent'},

Your property submission for "${submission.property_title}" at ${submission.address} is now under review.

${assignment.clientNames !== "Not Assigned" ? 
  `This property is being reviewed for our client(s): ${assignment.clientNames}
Brief Reference(s): ${assignment.briefCodes.join(', ')}` : 
  'This property is being reviewed against current client requirements.'}

We will keep you updated on the progress.

Best regards,
Stratosfyre Team
ORBIT Platform`;
        break;

      case 'shortlisted':
        subject = "Great News: Property Shortlisted";
        body = `Dear ${submission.agent_name || 'Agent'},

Congratulations! Your property submission for "${submission.property_title}" at ${submission.address} has been shortlisted.

${assignment.clientNames !== "Not Assigned" ? `Client(s): ${assignment.clientNames}` : ''}
${assignment.briefCodes.length > 0 ? `Brief Reference(s): ${assignment.briefCodes.join(', ')}` : ''}

We may contact you soon to arrange inspections or request additional information.

Best regards,
Stratosfyre Team
ORBIT Platform`;
        break;

      case 'rejected':
        subject = "Property Submission Update: Not Proceeding";
        body = `Dear ${submission.agent_name || 'Agent'},

Thank you for submitting "${submission.property_title}" at ${submission.address}.

Unfortunately, this property does not meet our current client requirements.

${rejectionReason ? `Reason: ${rejectionReason}` : ''}

We appreciate your submission and encourage you to submit other suitable properties in the future.

Best regards,
Stratosfyre Team
ORBIT Platform`;
        break;

      default:
        return;
    }

    try {
      await SendEmail({
        to: submission.agent_email,
        subject: subject,
        body: body,
        from_name: "Stratosfyre ORBIT"
      });
    } catch (error) {
      console.error("Error sending agent notification:", error);
    }
  };

  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({ ...prev, [filterName]: value === null ? "" : value }));
  };

  const handleStatusChange = async (submissionId, newStatus) => {
    if (newStatus === 'rejected') {
      const submission = (submissions || []).find(s => s.id === submissionId);
      setRejectionDialog({ open: true, submission });
      return;
    }

    try {
      const submission = (submissions || []).find(s => s.id === submissionId);
      if (!submission) return;

      const updatedSubmission = { ...submission, status: newStatus };
      if (!updatedSubmission.street_address && updatedSubmission.address) {
        updatedSubmission.street_address = updatedSubmission.address;
      }

      await PropertySubmission.update(submissionId, updatedSubmission);
      setSubmissions(prev => (prev || []).map(s => s.id === submissionId ? updatedSubmission : s));
      
      if (newStatus === 'under_review' || newStatus === 'shortlisted') {
        await sendAgentNotification(updatedSubmission, newStatus);
      }
      
    } catch (error) {
      console.error("Error updating status:", error);
      alert("Failed to update status.");
    }
  };

  const handleRejectSubmission = async () => {
    if (!rejectionReason && !customReason) {
      alert("Please select a rejection reason or provide custom feedback.");
      return;
    }

    try {
      const submission = rejectionDialog.submission;
      const finalReason = rejectionReason === 'other' ? customReason : rejectionReason;
      
      const updateData = { 
        status: 'rejected',
        rejection_reason: finalReason 
      };

      const updatedSubmission = { ...submission, ...updateData };
      if (!updatedSubmission.street_address && updatedSubmission.address) {
        updatedSubmission.street_address = updatedSubmission.address;
      }
      
      await PropertySubmission.update(submission.id, updatedSubmission);
      
      setSubmissions(prev => (prev || []).map(s => 
        s.id === submission.id ? updatedSubmission : s
      ));

      await sendAgentNotification(updatedSubmission, 'rejected', finalReason);
      
      setRejectionDialog({ open: false, submission: null });
      setRejectionReason("");
      setCustomReason("");

    } catch (error) {
      console.error("Error rejecting submission:", error);
      alert("Failed to reject submission.");
    }
  };

  const filteredSubmissions = (submissions || []).filter(s => {
    const assignedBriefs = (s.brief_ids || []).map(bid => (allBriefs || []).find(b => b.id === bid)).filter(Boolean);
    const assignedClientIds = [...new Set(assignedBriefs.map(b => b.client_id))];

    const clientMatch = !filters.client_id || assignedClientIds.includes(filters.client_id);
    const statusMatch = !filters.status || s.status === filters.status;
    const briefMatchStatusMatch = !filters.brief_match_status || s.brief_match_status === filters.brief_match_status;

    return clientMatch && statusMatch && briefMatchStatusMatch;
  });

  const getStatusPill = (status) => {
    const styles = {
      submitted: "bg-gray-600 text-gray-100",
      under_review: "bg-blue-600 text-blue-100",
      shortlisted: "bg-yellow-600 text-yellow-100",
      rejected: "bg-red-600 text-red-100",
      in_negotiation: "bg-purple-600 text-purple-100",
      selected: "bg-green-600 text-green-100",
    };
    return (
      <div className={`px-3 py-1 rounded-full text-xs font-bold ${styles[status] || styles.submitted}`}>
        {status.replace('_', ' ').toUpperCase()}
      </div>
    );
  }

  const getStatusColor = (status) => {
    const styles = {
      submitted: "bg-gray-600 text-gray-100",
      under_review: "bg-blue-600 text-blue-100",
      shortlisted: "bg-yellow-600 text-yellow-100",
      rejected: "bg-red-600 text-red-100",
      in_negotiation: "bg-purple-600 text-purple-100",
      selected: "bg-green-600 text-green-100",
    };
    return styles[status] || styles.submitted;
  };
  
  const getMatchPill = (status) => {
    const styles = {
        on_brief: 'bg-green-600 text-green-100',
        partial_match: 'bg-yellow-600 text-yellow-100',
        off_brief: 'bg-red-600 text-red-100',
    };
    const icons = {
        on_brief: CheckCircle,
        partial_match: AlertCircle,
        off_brief: XCircle
    };
    const Icon = icons[status];
    return (
        <div className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-2 ${styles[status] || 'bg-gray-600 text-gray-100'}`}>
            <Icon className="w-3 h-3" />
            <span>{status.replace('_', ' ').toUpperCase()}</span>
        </div>
    );
  }

  const toggleInspectionItem = (submissionId, isChecked) => {
    if (isChecked) {
      setInspectionItems(prev => ({
        ...prev,
        [submissionId]: { order: Object.keys(prev).length + 1 }
      }));
    } else {
      setInspectionItems(prev => {
        const { [submissionId]: removed, ...rest } = prev;
        let newOrder = 1;
        const reordered = {};
        Object.keys(rest).forEach(key => {
            reordered[key] = { ...rest[key], order: newOrder++ };
        });
        return reordered;
      });
    }
  };

  const updateInspectionOrder = (submissionId, order) => {
    setInspectionItems(prev => ({
      ...prev,
      [submissionId]: { ...prev[submissionId], order: parseInt(order) }
    }));
  };

  const generateInspectionPack = async () => {
    if (Object.keys(inspectionItems).length === 0) {
      alert("Please select at least one property for inspection.");
      return;
    }

    // Always navigate to setup page instead of bypassing
    const selectedIds = Object.keys(inspectionItems);
    const queryString = `properties=${selectedIds.join(',')}`;
    navigate(createPageUrl(`InspectionSetup?${queryString}`));
  };

  const toggleRfpItem = (submissionId, isChecked) => {
    setRfpItems(prev => {
        if (isChecked) {
            return [...new Set([...prev, submissionId])];
        } else {
            return prev.filter(id => id !== submissionId);
        }
    });
  };

  const handleCreateRfp = () => {
    if (rfpItems.length > 0) {
        navigate(createPageUrl(`RequestFinancialProposals?submission_ids=${rfpItems.join(',')}`));
    }
  };

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto p-4 sm:p-8">
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center mb-6 sm:mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">Property Submissions</h1>
            <p className="text-sm sm:text-base text-gray-300">Review and manage property submissions from agents.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 w-full sm:w-auto">
            {/* View Mode Toggle */}
            <div className="flex items-center gap-1 bg-gray-800 rounded-lg p-1">
              <Button
                variant={viewMode === 'kanban' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('kanban')}
                className="text-xs px-3 py-1"
              >
                Kanban
              </Button>
              <Button
                variant={viewMode === 'table' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('table')}
                className="text-xs px-3 py-1"
              >
                Table
              </Button>
            </div>

            {Object.keys(inspectionItems).length > 0 && (
              <Button 
                onClick={generateInspectionPack}
                className="orbit-button bg-gradient-to-r from-green-500 to-green-600 text-white border-0 px-4 sm:px-6 py-2 sm:py-3 w-full sm:w-auto"
              >
                <MapPin className="w-5 h-5 mr-2" />
                Generate Inspection Pack ({Object.keys(inspectionItems).length})
              </Button>
            )}
            {rfpItems.length > 0 && (
              <Button 
                onClick={handleCreateRfp}
                className="orbit-button bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 px-4 sm:px-6 py-2 sm:py-3 w-full sm:w-auto"
              >
                <FileText className="w-5 h-5 mr-2" />
                Create RFP ({rfpItems.length})
              </Button>
            )}
            <Button 
              variant="outline" 
              onClick={() => setShowFilters(!showFilters)} 
              className="orbit-button bg-white text-black border-gray-300 hover:bg-gray-100 w-full sm:w-auto"
            >
              <Filter className="w-4 h-4 mr-2" />
              {showFilters ? 'Hide' : 'Show'} Filters
            </Button>
          </div>
        </div>

        {showFilters && (
          <div className="orbit-card p-4 sm:p-6 mb-6 sm:mb-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-300">Client</Label>
                <Select value={filters.client_id} onValueChange={(value) => handleFilterChange('client_id', value)}>
                  <SelectTrigger className="orbit-input text-white">
                    <SelectValue placeholder="All Clients" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>All Clients</SelectItem>
                    {(allClients || []).map(c => <SelectItem key={c.id} value={c.id}>{c.company_name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-300">Status</Label>
                <Select value={filters.status} onValueChange={(value) => handleFilterChange('status', value)}>
                  <SelectTrigger className="orbit-input text-white">
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>All Statuses</SelectItem>
                    <SelectItem value="submitted">Submitted</SelectItem>
                    <SelectItem value="under_review">Under Review</SelectItem>
                    <SelectItem value="shortlisted">Shortlisted</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="in_negotiation">In Negotiation</SelectItem>
                    <SelectItem value="selected">Selected</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-300">Brief Match</Label>
                <Select value={filters.brief_match_status} onValueChange={(value) => handleFilterChange('brief_match_status', value)}>
                  <SelectTrigger className="orbit-input text-white">
                    <SelectValue placeholder="Match Quality" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>All Match Qualities</SelectItem>
                    <SelectItem value="on_brief">On Brief</SelectItem>
                    <SelectItem value="partial_match">Partial Match</SelectItem>
                    <SelectItem value="off_brief">Off Brief</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )}

        {loading ? (
          <div className="text-center p-8">
            <Loader2 className="h-8 w-8 mx-auto animate-spin text-amber-400" />
          </div>
        ) : (
          <>
            {viewMode === 'kanban' ? (
              <KanbanView
                filteredSubmissions={filteredSubmissions}
                onStatusChange={handleStatusChange}
                inspectionItems={inspectionItems}
                rfpItems={rfpItems}
                onToggleInspection={toggleInspectionItem}
                onToggleRfp={toggleRfpItem}
                onUpdateInspectionOrder={updateInspectionOrder}
                onSubmissionUpdate={onSubmissionUpdate}
                allClients={allClients}
                allBriefs={allBriefs}
                detectConflicts={detectConflicts}
              />
            ) : (
              <>
                {/* Mobile Card View */}
                <div className="block lg:hidden space-y-4">
                  {filteredSubmissions.length === 0 ? (
                    <div className="text-center p-12 text-gray-300">
                      <Building className="w-12 h-12 mx-auto mb-3 text-gray-500" />
                      <h3 className="text-lg font-medium text-white">No Submissions Found</h3>
                      <p>No submissions match the current filters.</p>
                    </div>
                  ) : (
                    filteredSubmissions.map((submission) => {
                      const conflicts = detectConflicts(submission);
                      return (
                        <div key={submission.id} className="orbit-card p-4">
                          <div className="flex justify-between items-start mb-3">
                            <h3 className="font-semibold text-white text-lg">{submission.property_title}</h3>
                            <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(submission.status)}`}>
                              {submission.status.replace('_', ' ').toUpperCase()}
                            </div>
                          </div>
                          
                          <p className="text-sm text-gray-400 mb-3 flex items-start gap-2">
                            <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                            <span>{submission.address}</span>
                          </p>
                          
                          <div className="grid grid-cols-2 gap-2 text-sm text-gray-300 mb-4">
                            <div className="flex items-center gap-2">
                              <Square className="w-4 h-4 text-amber-400" />
                              <span>{submission.floor_area_sqm} sqm</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <DollarSign className="w-4 h-4 text-amber-400" />
                              <span>${submission.rental_rate_sqm}/sqm</span>
                            </div>
                          </div>

                          <div className="mb-4">
                            <ClientBriefSelector
                              submission={submission}
                              onUpdate={onSubmissionUpdate}
                              allClients={allClients}
                              allBriefs={allBriefs}
                            />
                            {conflicts.length > 0 && (
                                <div className="flex items-center gap-1 mt-2 px-2 py-1 bg-red-900/50 border border-red-700 rounded text-xs text-red-200">
                                  <AlertTriangle className="w-3 h-3" />
                                  <span>Conflict: {conflicts.join(', ')}</span>
                                </div>
                              )}
                          </div>

                          <div className="flex flex-col gap-3 mb-4">
                            <div className="flex items-center gap-2">
                                <Checkbox
                                  id={`inspect-mobile-${submission.id}`}
                                  checked={!!inspectionItems[submission.id]}
                                  onCheckedChange={(checked) => toggleInspectionItem(submission.id, checked)}
                                  className="border-2 border-orange-400 data-[state=checked]:bg-orange-500 data-[state=checked]:border-orange-500"
                                />
                                <Label htmlFor={`inspect-mobile-${submission.id}`} className="text-xs font-medium text-white">Add to itinerary</Label>
                              </div>
                              {inspectionItems[submission.id] && (
                                <Input
                                  type="number"
                                  min="1"
                                  value={inspectionItems[submission.id].order || ''}
                                  onChange={(e) => updateInspectionOrder(submission.id, e.target.value)}
                                  placeholder="Order"
                                  className="w-16 h-8 text-xs mt-2 orbit-input text-white"
                                />
                              )}
                              {['shortlisted', 'in_negotiation', 'selected'].includes(submission.status) && (
                                <div className="flex items-center gap-2">
                                    <Checkbox
                                        id={`rfp-mobile-${submission.id}`}
                                        checked={rfpItems.includes(submission.id)}
                                        onCheckedChange={(checked) => toggleRfpItem(submission.id, checked)}
                                        className="border-2 border-blue-400 data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
                                    />
                                    <Label htmlFor={`rfp-mobile-${submission.id}`} className="text-xs font-medium text-white">Select for RFP</Label>
                                </div>
                              )}
                          </div>

                          <div className="flex flex-col sm:flex-row gap-2">
                            <Select 
                              value={submission.status} 
                              onValueChange={(value) => handleStatusChange(submission.id, value)}
                            >
                              <SelectTrigger className="orbit-input text-sm">
                                <SelectValue placeholder="Set status" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="submitted">Submitted</SelectItem>
                                <SelectItem value="under_review">Under Review</SelectItem>
                                <SelectItem value="shortlisted">Shortlisted</SelectItem>
                                <SelectItem value="rejected">Rejected</SelectItem>
                                <SelectItem value="in_negotiation">In Negotiation</SelectItem>
                                <SelectItem value="selected">Selected</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button 
                              variant="outline" 
                              className="orbit-button border-gray-600 text-gray-300 hover:bg-gray-800 text-sm"
                              onClick={() => navigate(createPageUrl(`SubmissionDetails?id=${submission.id}`))}
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              View Details
                            </Button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Desktop Table View */}
                <div className="hidden lg:block orbit-card overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="min-w-full text-sm">
                      <thead className="bg-gray-800 border-b border-gray-700">
                        <tr>
                          <th className="text-left font-bold p-4 text-white">Inspection</th>
                          <th className="text-left font-bold p-4 text-white">RFP</th>
                          <th className="text-left font-bold p-4 text-white">Property</th>
                          <th className="text-left font-bold p-4 text-white">Client Assignment</th>
                          <th className="text-left font-bold p-4 text-white">Match</th>
                          <th className="text-left font-bold p-4 text-white">Status</th>
                          <th className="text-right font-bold p-4 text-white">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-700">
                        {filteredSubmissions.length === 0 ? (
                          <tr><td colSpan="7" className="text-center p-12 text-gray-300"><Building className="w-12 h-12 mx-auto mb-3 text-gray-500" /><h3 className="text-lg font-medium text-white">No Submissions Found</h3><p>No submissions match the current filters.</p></td></tr>
                        ) : filteredSubmissions.map(s => {
                          const conflicts = detectConflicts(s);
                          return (
                            <tr key={s.id} className="text-white hover:bg-gray-800/50">
                              <td className="p-4">
                                <div className="flex flex-col gap-2">
                                  <div className="flex items-center gap-2">
                                    <Checkbox
                                      id={`inspect-${s.id}`}
                                      checked={!!inspectionItems[s.id]}
                                      onCheckedChange={(checked) => toggleInspectionItem(s.id, checked)}
                                      className="border-2 border-orange-400 data-[state=checked]:bg-orange-500 data-[state=checked]:border-orange-500"
                                    />
                                    <Label htmlFor={`inspect-${s.id}`} className="text-xs font-medium text-white">Inspect</Label>
                                  </div>
                                  {inspectionItems[s.id] && (
                                    <Input
                                      type="number"
                                      min="1"
                                      value={inspectionItems[s.id].order || ''}
                                      onChange={(e) => updateInspectionOrder(s.id, e.target.value)}
                                      placeholder="Order"
                                      className="w-16 h-8 text-xs mt-2 orbit-input text-white"
                                    />
                                  )}
                                </div>
                              </td>
                              <td className="p-4">
                                {['shortlisted', 'in_negotiation', 'selected'].includes(s.status) && (
                                    <div className="flex items-center gap-2">
                                        <Checkbox
                                            id={`rfp-${s.id}`}
                                            checked={rfpItems.includes(s.id)}
                                            onCheckedChange={(checked) => toggleRfpItem(s.id, checked)}
                                            className="border-2 border-blue-400 data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
                                        />
                                        <Label htmlFor={`rfp-${s.id}`} className="text-xs font-medium text-white">RFP</Label>
                                    </div>
                                )}
                              </td>
                              <td className="p-4">
                                <Link 
                                  to={createPageUrl(`SubmissionDetails?id=${s.id}`)}
                                  className="text-left hover:underline hover:text-orange-400 transition-colors"
                                >
                                  <p className="font-bold text-white">{s.property_title}</p>
                                  <p className="text-sm text-gray-300">{s.address}</p>
                                </Link>
                              </td>
                              <td className="p-4">
                                <div className="w-48">
                                  <ClientBriefSelector 
                                    submission={s} 
                                    onUpdate={onSubmissionUpdate}
                                    allClients={allClients}
                                    allBriefs={allBriefs}
                                  />
                                  {conflicts.length > 0 && (
                                    <div className="flex items-center gap-1 mt-1 px-2 py-1 bg-red-900/50 border border-red-700 rounded text-xs text-red-200">
                                      <AlertTriangle className="w-3 h-3" />
                                      <span>Conflict: {conflicts.join(', ')}</span>
                                    </div>
                                  )}
                                </div>
                              </td>
                              <td className="p-4">{getMatchPill(s.brief_match_status)}</td>
                              <td className="p-4">{getStatusPill(s.status)}</td>
                              <td className="p-4 text-right space-x-2">
                                <Button 
                                    variant="outline" 
                                    size="icon" 
                                    className="orbit-button text-gray-300 border-gray-600 hover:bg-gray-800 h-8 w-8"
                                    onClick={() => navigate(createPageUrl(`SubmissionDetails?id=${s.id}`))}
                                >
                                    <Eye className="w-4 h-4" />
                                </Button>
                                <Select value={s.status} onValueChange={(newStatus) => handleStatusChange(s.id, newStatus)}>
                                  <SelectTrigger className="orbit-input w-40 text-white inline-flex h-8">
                                      <SelectValue placeholder="Set status" />
                                  </SelectTrigger>
                                  <SelectContent>
                                      <SelectItem value="submitted">Submitted</SelectItem>
                                      <SelectItem value="under_review">Under Review</SelectItem>
                                      <SelectItem value="shortlisted">Shortlisted</SelectItem>
                                      <SelectItem value="rejected">Rejected</SelectItem>
                                      <SelectItem value="in_negotiation">In Negotiation</SelectItem>
                                      <SelectItem value="selected">Mark as Selected</SelectItem>
                                  </SelectContent>
                                </Select>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}
          </>
        )}

        {/* Rejection Dialog */}
        <Dialog open={rejectionDialog.open} onOpenChange={(open) => setRejectionDialog({ open, submission: null })}>
          <DialogContent className="orbit-card max-w-lg text-white">
            <DialogHeader>
              <DialogTitle>Reject Property Submission</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="rejectionReason">Rejection Reason *</Label>
                <Select value={rejectionReason} onValueChange={setRejectionReason}>
                  <SelectTrigger id="rejectionReason" className="orbit-input text-white mt-2">
                    <SelectValue placeholder="Select rejection reason" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="size_mismatch">Size doesn't match requirements</SelectItem>
                    <SelectItem value="location_unsuitable">Location not suitable</SelectItem>
                    <SelectItem value="rent_too_high">Rent exceeds budget</SelectItem>
                    <SelectItem value="condition_poor">Property condition not acceptable</SelectItem>
                    <SelectItem value="lease_terms">Lease terms incompatible</SelectItem>
                    <SelectItem value="timing_issue">Availability timing issue</SelectItem>
                    <SelectItem value="other">Other (please specify below)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {rejectionReason === 'other' && (
                <div>
                  <Label htmlFor="customReason">Custom Rejection Reason *</Label>
                  <Textarea
                    id="customReason"
                    placeholder="Please provide specific feedback for the agent..."
                    value={customReason}
                    onChange={(e) => setCustomReason(e.target.value)}
                    className="orbit-input text-white mt-2 h-24"
                  />
                </div>
              )}
              
              <div className="text-sm text-gray-400">
                This feedback will be automatically sent to the submitting agent: <span className="font-medium">{rejectionDialog.submission?.agent_email || 'N/A'}</span>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setRejectionDialog({ open: false, submission: null })}>
                Cancel
              </Button>
              <Button 
                onClick={handleRejectSubmission}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Reject & Notify Agent
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
