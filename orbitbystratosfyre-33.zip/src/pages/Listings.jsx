
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Tenancy } from '@/api/entities';
import { Building } from '@/api/entities';
import { Loader2, LayoutGrid, List, MapPin, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Link as RouterLink } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useUnits } from '@/components/utils/units';
import { UnitsBar } from '@/components/ui/UnitsBar';
import PropertyListItem from '@/components/listings/PropertyListItem';
import { format } from 'date-fns';
import { ExternalLink, Clock } from 'lucide-react';
import ListingsMap from '@/components/map/ListingsMap';
import MapCoverageGuard from '@/components/map/MapCoverageGuard';
import { backfillBuildingGeocodes } from '@/api/functions';

// Inline SVG placeholder avoids adding files to /public
const placeholderImage = `data:image/svg+xml;utf8,
<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='800'>
  <rect width='100%' height='100%' fill='%23222631'/>
  <text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle'
    fill='%2390a4ae' font-family='Arial, Helvetica' font-size='28'>
    Building photo not available
  </text>
</svg>`;

const PropertyCard = ({ tenancy, building }) => {
  const { convertEconomics } = useUnits();
  
  const economics = convertEconomics({
    area_m2: tenancy.size_sqm,
    rent_aud_per_m2_pa: tenancy.rental_rate_sqm,
  });

  if (!building) {
    return (
      <div className="orbit-card animate-pulse">
        <div className="h-48 bg-gray-700/50"></div>
        <div className="p-4 space-y-3">
          <div className="h-5 bg-gray-700/50 rounded w-3/4"></div>
          <div className="h-4 bg-gray-700/50 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <RouterLink to={createPageUrl(`BuildingDetails?id=${building.id}`)} className="block">
      <div className="orbit-card overflow-hidden flex flex-col h-full group">
        <div className="relative">
          <img src={building.image_url || placeholderImage} alt={building.name} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
          <Badge className="absolute top-3 right-3 bg-gray-900/50 text-white backdrop-blur-sm">{building.grade || 'Not Rated'}</Badge>
          {/* Live Listing Link */}
          {tenancy.url && (
            <a 
              href={tenancy.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="absolute top-3 left-3 p-2 bg-orange-500 hover:bg-orange-600 rounded-lg transition-colors"
              onClick={(e) => e.stopPropagation()}
              title="View Live Listing"
            >
              <ExternalLink className="w-4 h-4 text-white" />
            </a>
          )}
        </div>
        <div className="p-4 flex flex-col flex-grow">
          <h3 className="text-lg font-bold text-white truncate">{building.name}</h3>
          <p className="text-sm text-gray-300 mb-3 truncate flex items-center gap-2"><MapPin className="w-4 h-4" /> {building.address}</p>
          
          {/* Last Updated Timestamp */}
          {tenancy.updated_date && (
            <div className="flex items-center gap-1 text-xs text-gray-400 mb-3">
              <Clock className="w-3 h-3" />
              <span>Updated {format(new Date(tenancy.updated_date), 'dd MMM yyyy, HH:mm')}</span>
            </div>
          )}
          
          <div className="mt-auto space-y-2 text-sm">
            <div className="flex justify-between items-center text-gray-300">
              <span>Suite/Floor</span>
              <span className="font-semibold text-white">{tenancy.suite || tenancy.floor}</span>
            </div>
            <div className="flex justify-between items-center text-gray-300">
              <span>Size</span>
              <span className="font-semibold text-white">{economics.area?.value} {economics.area?.unit}</span>
            </div>
            <div className="flex justify-between items-center text-gray-300">
              <span>Rent</span>
              <span className="font-semibold text-white">{economics.rent ? `$${economics.rent.value}` : 'N/A'} <span className="text-gray-400">{economics.rent?.unit}</span></span>
            </div>
             <div className="flex justify-between items-center text-gray-300">
              <span>Status</span>
              <Badge variant={tenancy.status === 'Vacant' ? 'default' : 'secondary'} className={tenancy.status === 'Vacant' ? 'bg-green-500/80 text-white' : ''}>
                {tenancy.status}
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </RouterLink>
  );
};


export default function Listings() {
  const [tenancies, setTenancies] = useState([]);
  const [buildings, setBuildings] = useState([]);
  const [enrichedTenancies, setEnrichedTenancies] = useState([]);
  const [filteredListings, setFilteredListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState('grid');
  const [geoCoverage, setGeoCoverage] = useState(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [tenancyData, buildingData] = await Promise.all([
        Tenancy.list('-created_date'),
        Building.list()
      ]);
      setTenancies(tenancyData || []);
      setBuildings(buildingData || []);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);
  
  useEffect(() => {
    const buildingMap = new Map(buildings.map(b => [b.id, b]));
    const enriched = tenancies
      .map(tenancy => ({
        ...tenancy,
        building: buildingMap.get(tenancy.building_id),
      }))
      .filter(t => t.building);
      
    setEnrichedTenancies(enriched);
    
    // Calculate geo coverage from buildings
    const withGeo = buildings.filter(b => b.latitude && b.longitude).length;
    const pct = buildings.length > 0 ? Math.round((withGeo / buildings.length) * 100) : 0;
    setGeoCoverage({ pct, withGeo, total: buildings.length });
  }, [tenancies, buildings]);

  useEffect(() => {
    let filtered = enrichedTenancies;
    if (searchTerm) {
        const term = searchTerm.toLowerCase();
        filtered = filtered.filter(t =>
            t.building?.name?.toLowerCase().includes(term) ||
            t.building?.address?.toLowerCase().includes(term) ||
            t.floor?.toLowerCase().includes(term) ||
            t.suite?.toLowerCase().includes(term)
        );
    }
    setFilteredListings(filtered);
  }, [searchTerm, enrichedTenancies]);

  const handleBackfillGeo = async () => {
    try {
      const { data } = await backfillBuildingGeocodes({ provider: "nominatim", limit: 200 });
      alert(`Updated ${data.updated}/${data.scanned} building coordinates`);
      loadData(); // Reload to update coverage
    } catch (error) {
      alert(`Error: ${error.message}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
          <UnitsBar />
          <div className="flex justify-center items-center h-full p-8">
            <div className="space-y-4 w-full max-w-4xl">
              <div className="h-8 bg-gray-800/50 animate-pulse rounded-lg w-1/3"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="h-80 bg-gray-800/50 animate-pulse rounded-lg"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <UnitsBar />
        <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Property Listings</h1>
            <p className="text-gray-600 mt-1">Showing {filteredListings.length} available tenancies.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => setViewMode('grid')} className={viewMode === 'grid' ? 'bg-orange-500/20 text-orange-400' : 'text-gray-500'}>
              <LayoutGrid className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setViewMode('list')} className={viewMode === 'list' ? 'bg-orange-500/20 text-orange-400' : 'text-gray-500'}>
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
        
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500"/>
          <input
              type="text"
              placeholder="Search by building, address, or suite..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="orbit-input pl-10 w-full max-w-lg"
          />
        </div>

        <div className="space-y-6">
          <MapCoverageGuard
            pct={geoCoverage?.pct}
            onBackfill={handleBackfillGeo}
          >
            <ListingsMap listings={filteredListings} filters={{}} />
          </MapCoverageGuard>
          
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredListings.map(tenancy => (
                <PropertyCard key={tenancy.id} tenancy={tenancy} building={tenancy.building} />
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredListings.map(tenancy => (
                <PropertyListItem key={tenancy.id} tenancy={tenancy} building={tenancy.building} />
              ))}
            </div>
          )}
          
          {!loading && filteredListings.length === 0 && (
            <div className="text-center py-20">
              <div className="text-sm text-gray-600 p-6 border border-dashed border-gray-300 rounded-lg max-w-md mx-auto">
                <MapPin className="w-12 h-12 mx-auto text-gray-400 mb-4"/>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">No Listings Found</h3>
                <p className="mb-4 text-gray-600">No results match your current search.</p>
                <Button variant="outline" onClick={() => setSearchTerm('')} className="orbit-button border-gray-400 text-gray-700 hover:bg-gray-100">
                  Clear Search
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
