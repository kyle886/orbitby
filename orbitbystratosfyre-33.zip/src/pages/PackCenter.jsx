import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { FeasibilityScenario } from "@/api/entities";
import { generatePack } from "@/api/functions";

export default function PackCenter() {
  const { dealId = "ADHOC" } = useParams();
  const [scenarios, setScenarios] = useState([]);
  const [scenarioId, setScenarioId] = useState("");
  const [packType, setPackType] = useState("BOARD");
  const [inputs, setInputs] = useState({ 
    risks: [], 
    site: { sitePlanUrl: "" }, 
    credit: { dscr: null, lvr: null, covenants: [] }
  });
  const { toast } = useToast();

  useEffect(() => {
    const listScenarios = async () => {
      try {
        const scenariosData = await FeasibilityScenario.filter({ dealId: dealId }, "-created_at");
        setScenarios(scenariosData);
        if (scenariosData.length > 0) {
          setScenarioId(scenariosData[0].id);
        }
      } catch (error) {
        console.error("Failed to list scenarios:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Could not load scenarios."
        });
      }
    };
    if (dealId) {
      listScenarios();
    }
  }, [dealId, toast]);

  const handleGenerate = async () => {
    try {
      const { data: result } = await generatePack({ dealId, scenarioId, packType, inputs });
      if (result?.binderUrl) {
        window.open(result.binderUrl, "_blank");
        toast({
          title: "Success",
          description: "Pack generated successfully."
        });
      } else {
        throw new Error("Binder URL not returned.");
      }
    } catch (e) {
      toast({
        variant: "destructive",
        title: "Error",
        description: e?.message || "Failed to generate pack."
      });
    }
  };

  return (
    <div className="p-6 space-y-4 text-neutral-100">
      <h1 className="text-2xl font-semibold">Pack Center</h1>
      <Card className="p-4 bg-black/40 backdrop-blur-xl space-y-3">
        <div className="grid md:grid-cols-3 gap-3">
          <div>
            <div className="text-xs text-neutral-400">Scenario</div>
            <Select value={scenarioId} onValueChange={setScenarioId}>
              <SelectTrigger><SelectValue placeholder="Select scenario" /></SelectTrigger>
              <SelectContent>
                {scenarios.map((s) => <SelectItem key={s.id} value={s.id}>{new Date(s.created_at).toLocaleString()}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <div className="text-xs text-neutral-400">Pack Type</div>
            <Select value={packType} onValueChange={setPackType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(["BOARD", "INVESTMENT_COMMITTEE", "CREDIT_COMMITTEE", "VENDOR", "EXEC_SUMMARY", "POST_CLOSE"]).map(k => <SelectItem key={k} value={k}>{k.replace("_", " ")}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <div className="text-xs text-neutral-400">Site Plan URL (optional)</div>
            <Input value={inputs.site?.sitePlanUrl || ""} onChange={e => setInputs({ ...inputs, site: { ...(inputs.site || {}), sitePlanUrl: e.target.value } })} className="bg-neutral-900/60 border-neutral-800" />
          </div>
        </div>
        <div className="flex justify-end">
          <Button onClick={handleGenerate}>Generate</Button>
        </div>
      </Card>
    </div>
  );
}