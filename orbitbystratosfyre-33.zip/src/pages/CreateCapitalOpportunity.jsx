import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CapitalOpportunity } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';

export default function CreateCapitalOpportunity() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    type: 'Debt',
    stage: 'Prospecting',
    notes: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await CapitalOpportunity.create({
        ...formData,
        // In a real app, owner_user_id would come from the current user
        owner_user_id: 'system-user-placeholder', 
      });
      toast({ title: 'Success', description: 'Capital opportunity created.' });
      navigate(-1); // Go back to the previous page
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-2xl mx-auto">
      <Card className="orbit-card">
        <CardHeader>
          <CardTitle className="text-white">Create New Capital Opportunity</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">Opportunity Name</label>
              <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label htmlFor="type" className="block text-sm font-medium text-gray-300 mb-2">Type</label>
                <Select name="type" value={formData.type} onValueChange={(v) => handleSelectChange('type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Debt">Debt</SelectItem>
                    <SelectItem value="Equity">Equity</SelectItem>
                    <SelectItem value="SaleLeaseback">Sale & Leaseback</SelectItem>
                    <SelectItem value="Refinance">Refinance</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label htmlFor="stage" className="block text-sm font-medium text-gray-300 mb-2">Stage</label>
                <Select name="stage" value={formData.stage} onValueChange={(v) => handleSelectChange('stage', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Prospecting">Prospecting</SelectItem>
                    <SelectItem value="Teaser">Teaser</SelectItem>
                    <SelectItem value="IOIs">IOIs</SelectItem>
                    <SelectItem value="TermSheet">TermSheet</SelectItem>
                    <SelectItem value="Closing">Closing</SelectItem>
                    <SelectItem value="Closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-gray-300 mb-2">Notes</label>
              <Input id="notes" name="notes" value={formData.notes} onChange={handleInputChange} />
            </div>
            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => navigate(-1)} disabled={loading}>
                Cancel
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Create Opportunity
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}