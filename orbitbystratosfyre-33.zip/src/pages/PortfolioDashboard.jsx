import React, { useEffect, useMemo, useState } from "react";
import PageHeader from "@/components/ui/PageHeader";
import CriticalEvents from "@/components/portfolio/CriticalEvents";
import LiabilitiesPanel from "@/components/portfolio/LiabilitiesPanel";
import SitesMap from "@/components/portfolio/SitesMap";
import DocsPanel from "@/components/portfolio/DocsPanel";
import LeaseClausesPanel from "@/components/portfolio/LeaseClausesPanel";
import GeographicFilters from "@/components/portfolio/GeographicFilters";
import LeaseList from "@/components/portfolio/LeaseList";
import { buildLiabilitySeries, buildCriticalEvents } from "@/components/utils/portfolio/schedule";
import { Building } from "@/api/entities";
import { Lease } from "@/api/entities";
import { Company } from "@/api/entities";

export default function PortfolioDashboard() {
  const [buildings, setBuildings] = useState([]);
  const [leases, setLeases] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [activeCompanyId, setActiveCompanyId] = useState(null); // Can be null for "All"
  const [activeLeaseId, setActiveLeaseId] = useState(null);
  const [geographicFilters, setGeographicFilters] = useState({});

  useEffect(()=>{ (async ()=>{
    const [b, l, c] = await Promise.all([
        Building.list(),
        Lease.list(),
        Company.list()
    ]);
    setBuildings(b||[]);
    setLeases(l||[]);
    setCompanies(c||[]);
  })(); }, []); // Empty dependency array means this runs once on mount

  const handleCompanyChange = (companyId) => {
    setActiveCompanyId(companyId === 'all' ? null : companyId);
    setActiveLeaseId(null); // Reset active lease when company changes
  };

  // Enhanced filtering logic that includes geographic filters
  const filteredLeases = useMemo(() => {
    let filtered = leases;

    // Filter by company
    if (activeCompanyId) {
      filtered = filtered.filter(l => l.company_id === activeCompanyId);
    }

    // Filter by geographic criteria
    if (geographicFilters.country) {
      filtered = filtered.filter(l => l.country === geographicFilters.country);
    }
    if (geographicFilters.region) {
      filtered = filtered.filter(l => l.region === geographicFilters.region);
    }
    if (geographicFilters.state) {
      filtered = filtered.filter(l => l.state === geographicFilters.state);
    }
    if (geographicFilters.city) {
      filtered = filtered.filter(l => l.city === geographicFilters.city);
    }

    return filtered;
  }, [leases, activeCompanyId, geographicFilters]);

  const filteredBuildingIds = useMemo(() => new Set(filteredLeases.map(l => l.building_id)), [filteredLeases]);

  const filteredBuildings = useMemo(() => {
    if (!activeCompanyId && Object.keys(geographicFilters).length === 0) return buildings;
    return buildings.filter(b => filteredBuildingIds.has(b.id));
  }, [buildings, filteredBuildingIds, activeCompanyId, geographicFilters]);
  
  // Auto-select first lease if none is active
  useEffect(() => {
    if (!activeLeaseId && filteredLeases.length > 0) {
      setActiveLeaseId(filteredLeases[0].id);
    }
  }, [activeLeaseId, filteredLeases]);

  // Available location options for filters
  const availableLocations = useMemo(() => {
    const locations = {
      countries: [...new Set(leases.map(l => l.country).filter(Boolean))],
      regions: [...new Set(leases.map(l => l.region).filter(Boolean))],
      states: [...new Set(leases.map(l => l.state).filter(Boolean))],
      cities: [...new Set(leases.map(l => l.city).filter(Boolean))]
    };
    return locations;
  }, [leases]);

  const buildingsById = useMemo(()=> Object.fromEntries(buildings.map(x=>[x.id, x])), [buildings]);
  const companiesById = useMemo(()=> Object.fromEntries(companies.map(x=>[x.id, x])), [companies]);
  const series = useMemo(()=> buildLiabilitySeries({ leases: filteredLeases, months:12 }), [filteredLeases]);
  const events = useMemo(()=> buildCriticalEvents({ leases: filteredLeases, withinDays:120 }), [filteredLeases]);

  const clearGeographicFilters = () => {
    setGeographicFilters({});
  };

  return (
    <div className="space-y-4 max-w-[1200px] mx-auto px-3 md:px-4">
      <PageHeader title="Portfolio" subtitle="Manage your lease portfolio with geographic filtering and critical events tracking" />

      {/* Client Filter Dropdown */}
      <div className="surface p-2">
        <div className="flex items-center gap-3">
            <label htmlFor="client-filter" className="text-sm text-gray-400 ml-1">Filter by Client:</label>
            <select 
                id="client-filter"
                className="w-full max-w-xs rounded-md border border-white/10 bg-white/5 px-2 py-1 text-white"
                value={activeCompanyId || 'all'} 
                onChange={e=> handleCompanyChange(e.target.value)}
            >
              <option value="all">All Portfolios</option>
              {companies.map(c=>(
                <option key={c.id} value={c.id} className="bg-gray-800 text-white">
                  {c.name}
                </option>
              ))}
            </select>
        </div>
      </div>

      {/* Geographic Filters */}
      <GeographicFilters 
        filters={geographicFilters}
        onFiltersChange={setGeographicFilters}
        availableLocations={availableLocations}
        onClearFilters={clearGeographicFilters}
      />

      <div className="grid lg:grid-cols-3 gap-3">
        <div className="lg:col-span-2 space-y-3">
          <CriticalEvents events={events} buildingsById={buildingsById} />
          <LiabilitiesPanel series={series} />
          <SitesMap buildings={filteredBuildings} />
        </div>
        <div className="space-y-3">
          {/* Lease switcher (simple) */}
          <div className="surface p-2">
            <div className="text-xs text-gray-400 mb-1">Active Lease</div>
            <select className="w-full rounded-md border border-white/10 bg-white/5 px-2 py-1 text-white"
                    value={activeLeaseId || ''} onChange={e=>setActiveLeaseId(e.target.value)}>
              <option value="">Select a lease</option>
              {filteredLeases.map(l=>(
                <option key={l.id} value={l.id} className="bg-gray-800 text-white">
                  {buildingsById[l.building_id]?.name || 'Building'} — {fmt(l.start_date)} → {fmt(l.expiry_date)}
                </option>
              ))}
            </select>
          </div>

          {activeLeaseId && (
            <>
              <DocsPanel leaseId={activeLeaseId} />
              <LeaseClausesPanel leaseId={activeLeaseId} />
            </>
          )}
        </div>
      </div>

      {/* Lease List */}
      <LeaseList 
        leases={filteredLeases} 
        buildingsById={buildingsById}
        companiesById={companiesById}
      />
    </div>
  );
}
function fmt(dt){ try{ return new Date(dt).toLocaleDateString('en-AU'); }catch{ return String(dt||''); } }