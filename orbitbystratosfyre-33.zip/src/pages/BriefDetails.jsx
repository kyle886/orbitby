
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, Link, useNavigate } from 'react-router-dom';
import { TenantRequirement } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Check, Circle, ExternalLink, Loader2, Info, DollarSign, Edit } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import PageHeader from '@/components/ui/PageHeader';
import { createPageUrl } from '@/utils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";


const GATE_DEFINITIONS = [
  { key: 'requirements_ok', label: 'Requirements Defined' },
  { key: 'brief_ok', label: 'Brief PDF Generated' },
  { key: 'market_scan_ok', label: 'Market Scan Complete' },
  { key: 'boardpack_v1_ok', label: 'Board Pack v1 Issued' },
  { key: 'boardpack_v2_ok', label: 'Board Pack v2 Issued' },
  { key: 'rfp_ok', label: 'RFP Issued' },
  { key: 'offers_norm_ok', label: 'Offer Normalisation' },
  { key: 'hoa_ok', label: 'Heads of Agreement' },
  { key: 'lease_pack_ok', label: 'Lease Pack Complete' }];


export default function BriefDetails() {
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const briefId = searchParams.get('id');

  const [brief, setBrief] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadBrief = useCallback(async () => {
    if (!briefId) {
      setError("No brief ID provided.");
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const data = await TenantRequirement.get(briefId);
      setBrief(data);
    } catch (err) {
      console.error("Error loading brief:", err);
      setError("Failed to load brief details.");
      toast({ variant: "destructive", title: "Load Failed", description: "Could not fetch brief details." });
    } finally {
      setLoading(false);
    }
  }, [briefId, toast]);

  useEffect(() => {
    loadBrief();
  }, [loadBrief]);

  const handleFlipGate = async (gateName) => {
    if (!brief) return;

    const currentGateStatus = brief.gates ? brief.gates[gateName] : false;
    const newGates = { ...brief.gates, [gateName]: !currentGateStatus };

    try {
      await TenantRequirement.update(brief.id, { gates: newGates });
      setBrief((prev) => ({ ...prev, gates: newGates })); // Optimistic update
      toast({
        title: "Gate Updated",
        description: `${GATE_DEFINITIONS.find((g) => g.key === gateName)?.label} marked as ${!currentGateStatus ? 'complete' : 'incomplete'}.`
      });
    } catch (error) {
      toast({ variant: "destructive", title: "Update Failed", description: "Could not update the gate status." });
      setBrief((prev) => ({ ...prev, gates: { ...prev.gates, [gateName]: currentGateStatus } })); // Revert on failure
    }
  };

  const handleStatusChange = async (newStatus) => {
    if (!brief) return;

    try {
      await TenantRequirement.update(brief.id, { status: newStatus });
      setBrief((prev) => ({ ...prev, status: newStatus }));
      toast({
        title: "Status Updated",
        description: `Brief status changed to ${newStatus.replace(/_/g, ' ')}.`
      });
    } catch (error) {
      toast({ variant: "destructive", title: "Update Failed", description: "Could not update the brief status." });
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'draft': return 'bg-gray-700 text-gray-200';
      case 'awaiting_client_approval': return 'bg-yellow-800 text-yellow-200';
      case 'needs_revision': return 'bg-orange-800 text-orange-200';
      case 'active': return 'bg-green-800 text-green-200';
      case 'in_market': return 'bg-purple-800 text-purple-200';
      case 'completed': return 'bg-blue-800 text-blue-200';
      case 'cancelled': return 'bg-red-800 text-red-200';
      default: return 'bg-gray-700 text-gray-200';
    }
  };

  const formatCurrency = (amount) => {
    if (typeof amount !== 'number') return 'N/A';
    return new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-orange-400" /></div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-400">{error}</div>;
  }

  if (!brief) {
    return <div className="p-8 text-center text-gray-400">Brief not found.</div>;
  }

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-7xl mx-auto">
      <PageHeader
        title={brief.company_name}
        subtitle={`Brief Details & Engagement Gates (Ref: ${brief.brief_reference_code || 'N/A'})`}
        actions={
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => navigate(createPageUrl(`CreateBrief?id=${brief.id}`))}
            >
              <Edit className="w-4 h-4 mr-2" />
              Edit Brief
            </Button>
            <Select value={brief.status} onValueChange={handleStatusChange}>
              <SelectTrigger className={`w-[200px] orbit-input text-white ${getStatusBadge(brief.status)} border-0`}>
                <SelectValue placeholder="Set status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="awaiting_client_approval">Awaiting Client Approval</SelectItem>
                <SelectItem value="needs_revision">Needs Revision</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="in_market">In Market</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        } />


      <div className="mt-8 grid md:grid-cols-3 gap-8">
        {/* Left Column - Brief Summary */}
        <div className="md:col-span-1 space-y-6">
          <Card className="orbit-card">
            <CardHeader>
              <CardTitle>Brief Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Property Type</span>
                <span className="font-medium text-white capitalize">{brief.property_type || 'N/A'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Property Grade</span>
                <span className="font-medium text-white capitalize">{brief.property_grade || 'N/A'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Area (sqm)</span>
                <span className="font-medium text-white">{brief.min_floor_area || 'N/A'} - {brief.max_floor_area || 'N/A'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Locations</span>
                <span className="font-medium text-white text-right truncate">{(brief.preferred_suburbs || []).join(', ')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Required Date</span>
                <span className="font-medium text-white">{brief.required_date ? new Date(brief.required_date).toLocaleDateString() : 'N/A'}</span>
              </div>
              {brief.client_id &&
                <div className="pt-3 border-t border-white/10">
                  <Link to={createPageUrl(`ClientDetails?id=${brief.client_id}`)}>
                    <Button variant="outline" className="w-full">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      View Client Details
                    </Button>
                  </Link>
                </div>
              }
            </CardContent>
          </Card>

          {/* Fee Estimate Card */}
          {(brief.pipeline_value_aud || brief.estimated_fee_min_aud) &&
            <Card className="orbit-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-green-400" />
                  Fee Estimate
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                {brief.estimated_fee_min_aud && brief.estimated_fee_max_aud &&
                  <div className="flex justify-between">
                    <span className="text-gray-400">Estimated Fee Range</span>
                    <span className="font-medium text-white">
                      {formatCurrency(brief.estimated_fee_min_aud)} - {formatCurrency(brief.estimated_fee_max_aud)}
                    </span>
                  </div>
                }
                {brief.pipeline_value_aud &&
                  <div className="flex justify-between">
                    <span className="text-gray-400">Pipeline Value</span>
                    <span className="font-medium text-green-400">{formatCurrency(brief.pipeline_value_aud)}</span>
                  </div>
                }
                <div className="text-xs text-gray-500 pt-2 border-t border-white/10">
                  Based on {brief.property_grade} grade market rates
                </div>
              </CardContent>
            </Card>
          }

          <Card className="orbit-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Info className="w-5 h-5 text-orange-400" /> Additional Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <p className="text-gray-300">{brief.additional_notes || 'No additional notes provided.'}</p>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Engagement Gates */}
        <div className="md:col-span-2">
          <Card className="orbit-card">
            <CardHeader>
              <CardTitle>Engagement Gates</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-400 mb-6">Track the lifecycle of the engagement by marking gates as complete. This helps automate processes and provides a clear audit trail.</p>
              <div className="space-y-3">
                {GATE_DEFINITIONS.map((gate) => {
                  const isComplete = brief.gates && brief.gates[gate.key];
                  return (
                    <Button
                      key={gate.key}
                      variant={isComplete ? 'default' : 'outline'}
                      onClick={() => handleFlipGate(gate.key)}
                      className={`
                        inline-flex items-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-focus
                        disabled:pointer-events-none disabled:opacity-50
                        [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0
                        shadow px-4 w-full justify-start text-left h-auto py-3 transition-all duration-200
                        ${isComplete
                          ? 'bg-green-800/80 hover:bg-green-700/80 border-green-700 text-white'
                          : 'border-gray-700 hover:bg-gray-800 text-gray-300'
                        }
                      `}
                    >
                      {isComplete ?
                        <Check className="w-5 h-5 mr-3 flex-shrink-0 text-green-300" /> :
                        <Circle className="w-5 h-5 mr-3 flex-shrink-0 text-gray-500" />
                      }
                      <span className="font-medium">{gate.label}</span>
                    </Button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
