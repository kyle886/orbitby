import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Building as BuildingEntity } from '@/api/entities';
import { Tenancy } from '@/api/entities';
import { Loader2, ArrowLeft, Building as BuildingIcon, MapPin, Calendar, DollarSign, Upload, Plus, FileText, Maximize } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import TenancyManager from '@/components/building-database/TenancyManager';
import BuildingDocumentManager from '@/components/building-database/BuildingDocumentManager';
import StackPlan from '@/components/building-database/StackPlan';
import { useUnits } from '@/components/utils/units';

export default function BuildingDetails() {
    // Read building ID from query parameters instead of URL params
    const urlParams = new URLSearchParams(window.location.search);
    const buildingId = urlParams.get('id');
    
    const [building, setBuilding] = useState(null);
    const [tenancies, setTenancies] = useState([]);
    const [loading, setLoading] = useState(true);

    const loadData = useCallback(async () => {
        if (!buildingId) {
            setLoading(false);
            return;
        }
        setLoading(true);
        try {
            const [buildingData, tenancyData] = await Promise.all([
                BuildingEntity.get(buildingId),
                Tenancy.filter({ building_id: buildingId })
            ]);
            setBuilding(buildingData);
            setTenancies(tenancyData || []);
        } catch (error) {
            console.error("Error loading building details:", error);
        } finally {
            setLoading(false);
        }
    }, [buildingId]);

    useEffect(() => {
        loadData();
    }, [loadData]);

    if (loading) {
        return <div className="flex justify-center items-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-orange-400" /></div>;
    }

    if (!building) {
        return (
            <div className="text-center p-8 text-white">
                <div className="max-w-md mx-auto">
                    <BuildingIcon className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                    <h2 className="text-xl font-semibold mb-2">Building not found</h2>
                    <p className="text-gray-400 mb-4">
                        {buildingId ? 'The requested building could not be found.' : 'No building ID provided.'}
                    </p>
                    <Link to="/BuildingDatabase">
                        <Button variant="outline" className="text-white border-gray-600 hover:bg-gray-800">
                            <ArrowLeft className="w-4 h-4 mr-2" />
                            Back to Building Database
                        </Button>
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className="p-4 sm:p-6 lg:p-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1 space-y-6">
                    <div className="orbit-card p-6">
                        <img src={building.image_url || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/688244252a7b37f0b4a1bcf9/1947b198b_image.png'} alt={building.name} className="w-full h-56 object-cover rounded-lg mb-4" />
                        <h1 className="text-3xl font-bold text-white">{building.name}</h1>
                        <div className="flex items-center gap-2 text-gray-400 mt-2">
                            <MapPin className="w-4 h-4"/>
                            <p>{building.address}</p>
                        </div>
                    </div>
                     <div className="orbit-card p-6">
                        <h2 className="text-xl font-bold text-white mb-4">Building Details</h2>
                        <div className="space-y-3 text-sm">
                            <div className="flex justify-between"><span className="text-gray-400">Grade:</span> <span className="font-medium text-white">{building.grade}</span></div>
                            <div className="flex justify-between"><span className="text-gray-400">Type:</span> <span className="font-medium text-white">{building.type}</span></div>
                            <div className="flex justify-between"><span className="text-gray-400">Owner:</span> <span className="font-medium text-white">{building.owner || 'N/A'}</span></div>
                            <div className="flex justify-between"><span className="text-gray-400">NABERS:</span> <span className="font-medium text-white">{building.nabers_rating || 'N/A'}</span></div>
                            <div className="flex justify-between"><span className="text-gray-400">Leasing Agencies:</span> <span className="font-medium text-white text-right">{(building.leasing_agencies || []).join(', ')}</span></div>
                        </div>
                    </div>
                </div>
                <div className="lg:col-span-2">
                     <div className="orbit-card p-6">
                        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><BuildingIcon/> Stack Plan</h2>
                        <StackPlan tenancies={tenancies} />
                    </div>
                </div>
            </div>
        </div>
    );
}