
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { generateReport } from '@/api/functions';
import { Download, Loader2 } from 'lucide-react';

export default function ReportsCenter() {
  const [loading, setLoading] = useState('');
  const { toast } = useToast();

  const handleQuickDownload = async (type) => {
    setLoading(type);
    try {
      const { data } = await generateReport({ type });
      if (data.url) {
        window.open(data.url, '_blank');
        toast({
          title: "Report Downloaded",
          description: `${type} report with ${data.count} rows is ready.`,
        });
      } else {
        toast({
          variant: "default",
          title: "Report Empty",
          description: `No data found for the '${type}' report.`,
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Download Failed",
        description: error.message,
      });
    } finally {
      setLoading('');
    }
  };

  const handleDetailedReportGenerate = async (type) => {
    setLoading(type);
    try {
      const { data } = await generateReport({ type });
      if (data.url) {
        window.open(data.url, '_blank');
        toast({
          title: "Report Generated",
          description: `${type} report with ${data.count} rows is ready for download.`,
        });
      } else {
        toast({
          variant: "default",
          title: "Report Empty",
          description: `No data found for the '${type}' report.`,
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Report Failed",
        description: error.message,
      });
    } finally {
      setLoading('');
    }
  };

  const reports = [
    { id: 'deals', name: 'Deals Report' },
    { id: 'pipeline', name: 'Pipeline Report' },
    { id: 'listings-by-market', name: 'Listings by Market' },
  ];

  return (
    <div className="p-4 sm:p-6 md:p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-6">Reports Center</h1>

        <Card className="orbit-card mb-6">
          <CardHeader>
            <CardTitle className="text-white">Quick Downloads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 flex-wrap mb-4">
              <Button 
                onClick={() => handleQuickDownload('pipeline')}
                disabled={loading === 'pipeline'}
                className="orbit-button bg-blue-700 hover:bg-blue-600"
              >
                {loading === 'pipeline' ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
                Download Pipeline CSV
              </Button>
              <Button 
                onClick={() => handleQuickDownload('listings')}
                disabled={loading === 'listings'}
                className="orbit-button bg-green-700 hover:bg-green-600"
              >
                {loading === 'listings' ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
                Download Listings CSV
              </Button>
              <Button 
                onClick={() => handleQuickDownload('buildings')}
                disabled={loading === 'buildings'}
                className="orbit-button bg-purple-700 hover:bg-purple-600"
              >
                {loading === 'buildings' ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
                Download Buildings CSV
              </Button>
            </div>
            <p className="text-gray-400 text-sm">One-click CSV exports for key business data</p>
          </CardContent>
        </Card>

        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-white">Quick Reports</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-400">Generate and download CSV reports for key business areas.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {reports.map(report => (
                <Button 
                  key={report.id} 
                  onClick={() => handleDetailedReportGenerate(report.id)}
                  disabled={loading === report.id}
                  className="w-full justify-start text-left h-auto py-3 orbit-button bg-gray-700/50 hover:bg-gray-600/50"
                >
                  {loading === report.id ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4 mr-2" />
                  )}
                  <span className="flex-grow">{report.name}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
