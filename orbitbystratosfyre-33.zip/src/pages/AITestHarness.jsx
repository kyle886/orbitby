
import React, { useState, useEffect } from 'react';
import { AIProfile } from '@/api/entities';
import { AIJob } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, AlertTriangle, Loader2 } from 'lucide-react';
import { runJob } from '@/components/utils/runJob';
import { useToast } from "@/components/ui/use-toast";

export default function AITestHarness() {
  const [profiles, setProfiles] = useState([]);
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [testInput, setTestInput] = useState('');
  const [testResult, setTestResult] = useState(null);
  const [isRunning, setIsRunning] = useState(false);
  const [recentJobs, setRecentJobs] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [profilesData, jobsData] = await Promise.all([
        AIProfile.list(),
        AIJob.list('-created_date', 10)
      ]);
      setProfiles(profilesData || []);
      setRecentJobs(jobsData || []);
    } catch (error) {
      console.error('Failed to load AI test data:', error);
    }
  };

  const runTest = async () => {
    if (!selectedProfile || !testInput) return;

    setIsRunning(true);
    setTestResult(null);

    try {
      // Call AI with the profile's system prompt and schema
      const aiResponse = await InvokeLLM({
        prompt: `${selectedProfile.system_prompt}\n\nInput: ${testInput}`,
        response_json_schema: selectedProfile.json_schema
      });

      // Validate against schema (basic validation)
      let isValid = true;
      let validationError = '';
      
      try {
        // Simple validation - check required fields exist
        if (selectedProfile.json_schema.required) {
          for (const field of selectedProfile.json_schema.required) {
            if (!aiResponse || typeof aiResponse[field] === 'undefined') {
              isValid = false;
              validationError = `Missing required field: ${field}`;
              break;
            }
          }
        }
      } catch (validationErr) {
        isValid = false;
        validationError = validationErr.message;
      }

      // Create AIJob record
      const jobStatus = isValid ? 'success' : 'invalid_schema';
      await AIJob.create({
        profile_id: selectedProfile.id,
        input_summary: testInput.substring(0, 200),
        output_json: aiResponse,
        confidence: isValid ? 85 : 0,
        status: jobStatus,
        notes: isValid ? 'Schema validation passed' : `Schema validation failed: ${validationError}`
      });

      setTestResult({
        response: aiResponse,
        isValid,
        validationError,
        status: jobStatus
      });

    } catch (error) {
      console.error('AI test failed:', error);
      
      await AIJob.create({
        profile_id: selectedProfile.id,
        input_summary: testInput.substring(0, 200),
        output_json: {},
        confidence: 0,
        status: 'failed',
        notes: `AI call failed: ${error.message}`
      });

      setTestResult({
        response: null,
        isValid: false,
        validationError: error.message,
        status: 'failed'
      });
    } finally {
      setIsRunning(false);
      loadData(); // Refresh recent jobs
    }
  };

  return (
    <div className="p-4 sm:p-6 md:p-8 bg-void text-starlight min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">AI Test Harness</h1>
          <p className="text-gray-300">Test AI profiles with sample inputs and validate schema compliance.</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Test Interface */}
          <div className="space-y-6">
            <Card className="orbit-card">
              <CardHeader>
                <CardTitle className="text-white">Run Test</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm text-gray-300 mb-2 block">AI Profile</label>
                  <Select onValueChange={(value) => {
                    const profile = profiles.find(p => p.id === value);
                    setSelectedProfile(profile);
                    setTestResult(null);
                  }}>
                    <SelectTrigger className="orbit-input">
                      <SelectValue placeholder="Select AI profile to test" />
                    </SelectTrigger>
                    <SelectContent>
                      {profiles.map(profile => (
                        <SelectItem key={profile.id} value={profile.id}>
                          {profile.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedProfile && (
                  <div>
                    <label className="text-sm text-gray-300 mb-2 block">System Prompt</label>
                    <div className="p-3 bg-gray-800 rounded-lg text-sm text-gray-300 max-h-32 overflow-y-auto">
                      {selectedProfile.system_prompt}
                    </div>
                  </div>
                )}

                <div>
                  <label className="text-sm text-gray-300 mb-2 block">Test Input</label>
                  <Textarea
                    placeholder="Enter test input data (e.g., raw HTML for Parser, list of DD findings for Assessor)..."
                    value={testInput}
                    onChange={(e) => setTestInput(e.target.value)}
                    className="orbit-input h-32"
                  />
                </div>

                <Button
                  onClick={runTest}
                  disabled={!selectedProfile || !testInput || isRunning}
                  className="w-full orbit-button-active"
                >
                  {isRunning ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Running Test...</>
                  ) : (
                    'Run Test'
                  )}
                </Button>
              </CardContent>
            </Card>

            {testResult && (
              <Card className="orbit-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white">Test Results</CardTitle>
                    <Badge 
                      variant={testResult.status === 'success' ? 'default' : 'destructive'}
                      className={`${
                        testResult.status === 'success' ? 'bg-green-500/80 border-green-500' : 
                        testResult.status === 'invalid_schema' ? 'bg-yellow-500/80 border-yellow-500' : 'bg-red-500/80 border-red-500'
                      } text-white`}
                    >
                      <div className="flex items-center gap-1.5">
                        {testResult.status === 'success' ? <CheckCircle className="w-4 h-4" /> :
                         testResult.status === 'invalid_schema' ? <AlertTriangle className="w-4 h-4" /> :
                         <XCircle className="w-4 h-4" />}
                        {testResult.status.replace('_', ' ').toUpperCase()}
                      </div>
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {testResult.isValid ? (
                    <div>
                      <h4 className="text-sm font-semibold text-green-400 mb-2">✓ Schema Validation Passed</h4>
                      <div className="p-3 bg-gray-900/50 rounded-lg max-h-96 overflow-auto">
                        <pre className="text-sm text-gray-200 whitespace-pre-wrap">
                          {JSON.stringify(testResult.response, null, 2)}
                        </pre>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <h4 className="text-sm font-semibold text-red-400 mb-2">✗ Test Failed</h4>
                      <p className="text-sm text-red-300 mb-3">{testResult.validationError}</p>
                      {testResult.response && (
                        <div>
                          <label className="text-xs text-gray-400 mb-1 block">Raw AI Output:</label>
                          <div className="p-3 bg-gray-900/50 rounded-lg max-h-72 overflow-auto">
                            <pre className="text-sm text-gray-200 whitespace-pre-wrap">
                              {JSON.stringify(testResult.response, null, 2)}
                            </pre>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column - Recent Jobs */}
          <div className="space-y-6">
            <Card className="orbit-card">
              <CardHeader>
                <CardTitle className="text-white">Recent AI Jobs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-[600px] overflow-y-auto">
                  {recentJobs.length > 0 ? (
                    recentJobs.map(job => (
                      <div key={job.id} className="p-3 bg-gray-800/50 rounded-lg text-xs">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-white">
                            {profiles.find(p => p.id === job.profile_id)?.name || 'Unknown Profile'}
                          </span>
                          <Badge 
                            variant={job.status === 'success' ? 'default' : 'destructive'}
                            className={`text-xs ${
                              job.status === 'success' ? 'bg-green-600/70 border-green-600' : 
                              job.status === 'invalid_schema' ? 'bg-yellow-600/70 border-yellow-600' : 'bg-red-600/70 border-red-600'
                            } text-white`}
                          >
                            {job.status}
                          </Badge>
                        </div>
                        <p className="text-gray-400 mb-1 truncate">Input: {job.input_summary}</p>
                        {job.status !== 'success' && <p className="text-red-400 text-xs mt-1">Note: {job.notes}</p>}
                        <div className="text-gray-500 mt-1">
                          Confidence: {job.confidence}% &bull; {new Date(job.created_date).toLocaleString()}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-400 text-center py-8">No AI jobs run yet.</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {selectedProfile && (
              <Card className="orbit-card">
                <CardHeader>
                  <CardTitle className="text-white">Expected Schema</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-3 bg-gray-900/50 rounded-lg max-h-72 overflow-auto">
                    <pre className="text-sm text-gray-200 whitespace-pre-wrap">
                      {JSON.stringify(selectedProfile.json_schema, null, 2)}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
