
import React, { useState, useEffect } from "react";
import { Client } from "@/api/entities";
import { TenantRequirement } from "@/api/entities";
import { PropertySubmission } from "@/api/entities";
import { User } from "@/api/entities";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Building2, 
  Users, 
  Briefcase, 
  TrendingUp, 
  CheckCircle,
  Clock,
  ArrowRight,
  Search,
  FileText,
  Database
} from "lucide-react";

export default function LegacyDashboard() {
  const [dashboardData, setDashboardData] = useState({
    totalClients: 0,
    activeBriefs: 0,
    totalSubmissions: 0,
    recentActivity: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [clients, briefs, submissions] = await Promise.all([
        Client.list("-created_date", 100),
        TenantRequirement.list("-created_date", 100),
        PropertySubmission.list("-created_date", 50)
      ]);

      const activeBriefs = briefs.filter(b => 
        ['active', 'in_market', 'search_active'].includes(b.status)
      );

      const recentSubmissions = submissions.slice(0, 5);

      setDashboardData({
        totalClients: clients.length,
        activeBriefs: activeBriefs.length,
        totalSubmissions: submissions.length,
        recentActivity: recentSubmissions
      });
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  const StatCard = ({ title, value, icon: Icon, color, link }) => (
    <Link to={link} className="block stratos-card p-6 hover:scale-105 transition-all duration-200">
      <div className="flex items-center justify-between">
        <div>
          <p className="stratos-micro-label mb-1">{title}</p>
          <p className="text-3xl font-bold text-white metric-value">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </Link>
  );

  if (loading) {
    return (
      <div className="min-h-screen">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="stratos-card animate-pulse p-6 h-36">
                <div className="h-4 bg-gray-700 rounded mb-4 w-1/2"></div>
                <div className="h-8 bg-gray-700 rounded mb-2 w-3/4"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="stratos-h1 mb-2">Legacy Command Center</h1>
          <p className="stratos-body">
            Legacy view - <Link to={createPageUrl("CommandCentre")} className="text-orange-400 hover:underline">Switch to New Command Centre</Link>
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Active Clients"
            value={dashboardData.totalClients}
            icon={Users}
            color="bg-viz-secondary/80"
            link={createPageUrl("ClientManagement")}
          />
          <StatCard
            title="Live Briefs"
            value={dashboardData.activeBriefs}
            icon={Briefcase}
            color="bg-viz-tertiary/80"
            link={createPageUrl("Requirements")}
          />
          <StatCard
            title="New Submissions"
            value={dashboardData.totalSubmissions}
            icon={Building2}
            color="bg-viz-quaternary/80"
            link={createPageUrl("SubmissionManagement")}
          />
          <StatCard
            title="Database Size"
            value="500+"
            icon={Database}
            color="bg-viz-primary/80"
            link={createPageUrl("BuildingDatabase")}
          />
        </div>
      </div>
    </div>
  );
}
