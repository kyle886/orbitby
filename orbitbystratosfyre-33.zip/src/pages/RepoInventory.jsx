
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { repoInventoryToPDF } from '@/api/functions';
import { Loader2, FileText, Download, AlertTriangle, CheckCircle } from 'lucide-react';
// FIXED: Added missing Alert component imports
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";


export default function RepoInventory() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const { toast } = useToast();

  const handleRunInventory = async () => {
    setLoading(true);
    setResult(null);
    setError(null);
    try {
      const response = await repoInventoryToPDF();
      if (response && response.data && response.data.url) {
        setResult(response.data);
        toast({
          title: "Inventory Complete",
          description: `Found ${response.data.count} files and ${response.data.functions} functions.`,
        });
        // Automatically open the PDF in a new tab
        window.open(response.data.url, '_blank');
      } else {
        throw new Error("Invalid response from server.");
      }
    } catch (err) {
      const errorMessage = err.response?.data?.error || err.message || "An unknown error occurred.";
      setError(errorMessage);
      toast({
        variant: "destructive",
        title: "Inventory Failed",
        description: errorMessage,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 md:p-8 bg-gray-900 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">Repository Inventory</h1>
          <p className="text-gray-300">Generate a PDF report of the current application codebase.</p>
        </div>

        <div className="orbit-card p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="flex-grow">
              <h2 className="text-lg font-semibold text-white">Generate Codebase PDF</h2>
              <p className="text-gray-400 mt-1 text-sm">
                This tool will scan the repository, classify files, and generate a downloadable PDF.
                This is useful for providing context to external engineers or for auditing purposes.
              </p>
            </div>
            <Button
              onClick={handleRunInventory}
              disabled={loading}
              className="orbit-button bg-gradient-to-r from-orange-500 to-amber-500 text-white border-0 px-6 py-3 text-base w-full sm:w-auto"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <FileText className="mr-2 h-5 w-5" />
                  Run Inventory
                </>
              )}
            </Button>
          </div>

          {error && (
            <div className="mt-6">
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>
                  <pre className="text-xs whitespace-pre-wrap bg-red-900/20 p-2 rounded-md">{error}</pre>
                </AlertDescription>
              </Alert>
            </div>
          )}

          {result && (
            <div className="mt-6 p-4 rounded-lg bg-green-900/50 border border-green-700">
                <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-400 mr-3"/>
                    <div className="flex-grow">
                        <h3 className="font-semibold text-white">Report Generated Successfully</h3>
                        <p className="text-sm text-green-200">Found {result.count} files and {result.functions} functions.</p>
                    </div>
                    <Button
                        variant="outline"
                        onClick={() => window.open(result.url, '_blank')}
                        className="orbit-button text-gray-300 border-gray-600 hover:bg-gray-800 hover:text-white"
                    >
                        <Download className="mr-2 h-4 w-4" />
                        Open PDF
                    </Button>
                </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
