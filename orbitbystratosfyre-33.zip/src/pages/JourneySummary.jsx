import React, { useState, useEffect } from "react";
import { TenantRequirement } from "@/api/entities";
import { SourcedProperty } from "@/api/entities/SourcedProperty";
import { PropertySubmission } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Loader2, Printer, Settings, ArrowLeft } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import PDFReport from "../components/journey-summary/PDFReport";

export default function JourneySummary() {
  const navigate = useNavigate();
  const [brief, setBrief] = useState(null);
  const [sourcedProperties, setSourcedProperties] = useState([]);
  const [shortlistedProperties, setShortlistedProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [reportConfig, setReportConfig] = useState({
    includeAnalytics: true,
    includeShortlist: true,
    includeFitoutStatus: true,
    includeSizeAnalysis: true,
  });

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const briefId = urlParams.get('briefId');
    if (briefId) {
      fetchReportData(briefId);
    } else {
      setError("No brief ID provided.");
      setLoading(false);
    }
  }, []);

  const fetchReportData = async (briefId) => {
    setLoading(true);
    try {
      const requirements = await TenantRequirement.list();
      const briefData = requirements.find(r => r.id === briefId);
      if (!briefData) {
        throw new Error("Brief not found");
      }
      setBrief(briefData);

      const allSourced = await SourcedProperty.filter({ brief_reference_code: briefData.brief_reference_code });
      setSourcedProperties(allSourced);

      const allSubmissions = await PropertySubmission.filter({ client_id: briefData.client_id, status: "shortlisted" });
      setShortlistedProperties(allSubmissions);

    } catch (err) {
      console.error("Error fetching report data:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center text-red-600">
          <p>Error: {error}</p>
          <Button onClick={() => navigate(createPageUrl("Requirements"))}>Go Back</Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .no-print {
            display: none !important;
          }
          #pdf-report, #pdf-report * {
            visibility: visible;
          }
          #pdf-report {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            font-size: 10pt;
          }
          @page {
            size: A4;
            margin: 1cm;
          }
        }
      `}</style>
      <div className="bg-gray-100 min-h-screen">
        <header className="p-4 bg-white shadow-md no-print sticky top-0 z-10">
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <div>
              <Button variant="ghost" onClick={() => navigate(-1)}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <h1 className="text-xl font-bold text-gray-800 inline-block ml-4">Journey Summary Report</h1>
              <p className="text-sm text-gray-500 ml-4 inline-block">{brief.company_name} - {brief.brief_reference_code}</p>
            </div>
            <div className="flex items-center gap-4">
               {/* Configuration can be built out here */}
              <Button onClick={handlePrint} className="amplifyre-button bg-blue-600 text-white hover:bg-blue-700">
                <Printer className="w-4 h-4 mr-2" />
                Save as PDF
              </Button>
            </div>
          </div>
        </header>
        <main className="p-4 md:p-8">
          <div id="pdf-report" className="max-w-4xl mx-auto bg-white shadow-lg">
            <PDFReport 
              brief={brief}
              sourcedProperties={sourcedProperties}
              shortlistedProperties={shortlistedProperties}
              config={reportConfig}
            />
          </div>
        </main>
      </div>
    </>
  );
}