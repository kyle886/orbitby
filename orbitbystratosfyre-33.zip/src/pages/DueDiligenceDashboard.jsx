import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { DueDiligence, DDFinding, DDMeasure, DDDoc, DDProfile } from '@/api/entities';
import { Building, Option } from '@/api/entities'; // Assuming these exist
import { useSearchParams, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useToast } from '@/components/ui/use-toast';
import { PlusCircle, FileText, Loader2 } from 'lucide-react';

export default function DueDiligenceDashboard() {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const { toast } = useToast();

    const ddId = searchParams.get('ddId');
    const buildingId = searchParams.get('buildingId');
    const optionId = searchParams.get('optionId');

    const [dd, setDd] = useState(null);
    const [findings, setFindings] = useState([]);
    const [measures, setMeasures] = useState([]);
    const [docs, setDocs] = useState([]);
    const [profiles, setProfiles] = useState([]);
    
    const [loading, setLoading] = useState(true);
    
    // Form states
    const [selectedProfileId, setSelectedProfileId] = useState('');
    const [newFinding, setNewFinding] = useState({ category: '', description: '', severity: 3, likelihood: 3 });
    const [newMeasure, setNewMeasure] = useState({ metric: '', measured_value: '' });

    useEffect(() => {
        const loadInitialData = async () => {
            try {
                const profilesData = await DDProfile.list();
                setProfiles(profilesData || []);

                if (ddId) {
                    const [ddData, findingsData, measuresData, docsData] = await Promise.all([
                        DueDiligence.get(ddId),
                        DDFinding.filter({ dd_id: ddId }),
                        DDMeasure.filter({ dd_id: ddId }),
                        DDDoc.filter({ dd_id: ddId })
                    ]);
                    setDd(ddData);
                    setFindings(findingsData || []);
                    setMeasures(measuresData || []);
                    setDocs(docsData || []);
                }
            } catch (error) {
                console.error("Error loading DD data:", error);
                toast({ title: 'Error', description: 'Failed to load due diligence data.', variant: 'destructive' });
            } finally {
                setLoading(false);
            }
        };
        loadInitialData();
    }, [ddId, toast]);

    const handleStartDD = async () => {
        if (!selectedProfileId || !buildingId) {
            toast({ title: 'Missing Information', description: 'Please select a profile and ensure a building is linked.', variant: 'destructive'});
            return;
        }
        try {
            const newDD = await DueDiligence.create({
                profile_id: selectedProfileId,
                building_id: buildingId,
                option_id: optionId || null,
                started_at: new Date().toISOString(),
                status: 'active',
                assessor_id: 'current_user_id_placeholder' // Replace with actual user ID
            });
            toast({ title: 'Success', description: 'Due Diligence started.' });
            navigate(createPageUrl(`DueDiligenceDashboard?ddId=${newDD.id}`));
        } catch (error) {
            console.error("Error starting DD:", error);
            toast({ title: 'Error', description: 'Could not start Due Diligence.', variant: 'destructive' });
        }
    };

    const handleAddFinding = async () => {
        try {
            const riskScore = newFinding.severity * newFinding.likelihood * 4;
            await DDFinding.create({ ...newFinding, dd_id: ddId, risk_score: riskScore });
            // Re-fetch findings
            const findingsData = await DDFinding.filter({ dd_id: ddId });
            setFindings(findingsData || []);
            setNewFinding({ category: '', description: '', severity: 3, likelihood: 3 });
            toast({ title: 'Success', description: 'Finding added.'});
        } catch(error) {
            console.error("Error adding finding:", error);
            toast({ title: 'Error', description: 'Failed to add finding.', variant: 'destructive' });
        }
    };
    
    const handleAddMeasure = async () => {
        try {
            // Simplified spec check
            const profile = profiles.find(p => p.id === dd.profile_id);
            const spec = profile?.utilities_required_json || {};
            const key = `${newMeasure.metric}_min`;
            const withinSpec = spec[key] ? newMeasure.measured_value >= spec[key] : null;

            await DDMeasure.create({ ...newMeasure, dd_id: ddId, within_spec: withinSpec });
            const measuresData = await DDMeasure.filter({ dd_id: ddId });
            setMeasures(measuresData || []);
            setNewMeasure({ metric: '', measured_value: '' });
            toast({ title: 'Success', description: 'Measurement recorded.'});
        } catch (error) {
            console.error("Error recording measure:", error);
            toast({ title: 'Error', description: 'Failed to record measurement.', variant: 'destructive' });
        }
    };

    const handleGenerateReport = async () => {
        // This would generate a PDF and create a Document record
        toast({ title: 'Report Generated (simulated)', description: 'A DD report has been created and stored.' });
        // Update DD status
        await DueDiligence.update(dd.id, { status: 'complete', completed_at: new Date().toISOString(), pass_flag: true }); // Simplified pass logic
    };

    if (loading) {
        return <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-orange-400" /></div>;
    }

    if (!ddId) {
        return (
            <div className="p-8">
                <Card className="orbit-card max-w-lg mx-auto">
                    <CardHeader><CardTitle className="text-white">Start Due Diligence</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                        <p className="text-gray-300">Select a profile to begin the due diligence process for this building.</p>
                        <Select onValueChange={setSelectedProfileId}>
                            <SelectTrigger className="orbit-input"><SelectValue placeholder="Select a DD Profile..." /></SelectTrigger>
                            <SelectContent>
                                {profiles.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                        <Button onClick={handleStartDD} className="w-full orbit-button bg-blue-600 hover:bg-blue-700">Start DD</Button>
                    </CardContent>
                </Card>
            </div>
        );
    }
    
    return (
        <div className="p-8 space-y-8">
            <header className="flex justify-between items-center">
                <h1 className="text-3xl font-bold text-white">Due Diligence Dashboard</h1>
                <Button onClick={handleGenerateReport} className="orbit-button bg-green-600 hover:bg-green-700">
                    <FileText className="w-4 h-4 mr-2" />
                    Generate DD Report
                </Button>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                    {/* Add Finding */}
                    <Card className="orbit-card">
                         <CardHeader><CardTitle className="text-white">Add Finding</CardTitle></CardHeader>
                         <CardContent className="space-y-4">
                            <Select onValueChange={(v) => setNewFinding(prev => ({...prev, category: v}))}>
                                <SelectTrigger className="orbit-input"><SelectValue placeholder="Select Category..." /></SelectTrigger>
                                <SelectContent>{["Structure", "Fire", "MEP", "Electrical", "ICT", "VerticalTransport", "Envelope", "Water", "Security", "Compliance", "Environment", "Other"].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                            </Select>
                            <Textarea className="orbit-input" placeholder="Description of the finding..." value={newFinding.description} onChange={(e) => setNewFinding(prev => ({...prev, description: e.target.value}))} />
                            <div className="flex gap-4">
                                <Input type="number" placeholder="Severity (1-5)" className="orbit-input" value={newFinding.severity} onChange={e => setNewFinding(p => ({...p, severity: parseInt(e.target.value)}))} />
                                <Input type="number" placeholder="Likelihood (1-5)" className="orbit-input" value={newFinding.likelihood} onChange={e => setNewFinding(p => ({...p, likelihood: parseInt(e.target.value)}))} />
                            </div>
                            <Button onClick={handleAddFinding}><PlusCircle className="w-4 h-4 mr-2" />Add Finding</Button>
                         </CardContent>
                    </Card>
                    {/* Add Measurement */}
                     <Card className="orbit-card">
                         <CardHeader><CardTitle className="text-white">Record Measurement</CardTitle></CardHeader>
                         <CardContent className="space-y-4">
                             <div className="flex gap-4">
                                <Select onValueChange={(v) => setNewMeasure(prev => ({...prev, metric: v}))}>
                                    <SelectTrigger className="orbit-input"><SelectValue placeholder="Select Metric..." /></SelectTrigger>
                                    <SelectContent>{["power_kVA", "cooling_kWr", "genset_kVA", "UPS_kVA", "water_Lps", "gas_MJh", "floor_loading_kPa", "ceiling_height_m", "comms_feeds", "duct_risers"].map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                                </Select>
                                <Input placeholder="Measured Value" type="number" className="orbit-input" value={newMeasure.measured_value} onChange={e => setNewMeasure(p => ({...p, measured_value: parseFloat(e.target.value)}))} />
                            </div>
                            <Button onClick={handleAddMeasure}><PlusCircle className="w-4 h-4 mr-2"/>Record Measurement</Button>
                         </CardContent>
                    </Card>
                </div>
                <div className="space-y-6">
                    {/* Findings List */}
                    <Card className="orbit-card">
                        <CardHeader><CardTitle className="text-white">Findings ({findings.length})</CardTitle></CardHeader>
                        <CardContent>
                            {findings.map(f => <div key={f.id} className="p-2 border-b border-gray-700">{f.description} ({f.risk_score})</div>)}
                        </CardContent>
                    </Card>
                    {/* Measures List */}
                    <Card className="orbit-card">
                        <CardHeader><CardTitle className="text-white">Measurements ({measures.length})</CardTitle></CardHeader>
                        <CardContent>
                            {measures.map(m => <div key={m.id} className="p-2 border-b border-gray-700">{m.metric}: {m.measured_value}</div>)}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}