import React, { useState, useEffect } from 'react';
import { Tenancy } from '@/api/entities';
import { Building } from '@/api/entities';
import { Loader2, Archive, Calendar } from 'lucide-react';
import { format } from 'date-fns';

export default function LeasedPropertiesLog() {
  const [leasedTenancies, setLeasedTenancies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [tenancyData, buildingData] = await Promise.all([
          Tenancy.filter({ status: 'Occupied' }),
          Building.list()
        ]);
        
        const buildingMap = new Map((buildingData || []).map(b => [b.id, b]));
        
        const enriched = (tenancyData || [])
          .map(tenancy => ({
            ...tenancy,
            building: buildingMap.get(tenancy.building_id),
          }))
          .filter(t => t.building)
          .sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date)); // Sort by most recently updated
          
        setLeasedTenancies(enriched);
      } catch (error) {
        console.error("Error loading leased properties log:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full p-8">
        <Loader2 className="w-12 h-12 animate-spin text-orange-400" />
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 md:p-8">
      <div className="max-w-full mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-white">Leased & Delisted Property Log</h1>
          <p className="text-gray-400 mt-1">
            This log shows properties automatically marked as 'Occupied' when they were no longer found in live market scans.
          </p>
        </div>

        <div className="orbit-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm text-left">
              <thead className="bg-gray-800/50">
                <tr>
                  <th className="p-4 font-semibold text-white">Property</th>
                  <th className="p-4 font-semibold text-white">Suite / Floor</th>
                  <th className="p-4 font-semibold text-white">Size (sqm)</th>
                  <th className="p-4 font-semibold text-white">Date Leased / Delisted</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700/50">
                {leasedTenancies.map(tenancy => (
                  <tr key={tenancy.id} className="hover:bg-gray-800/50">
                    <td className="p-4">
                      <div className="font-medium text-white">{tenancy.building.name}</div>
                      <div className="text-gray-400">{tenancy.building.address}</div>
                    </td>
                    <td className="p-4 text-gray-300">{tenancy.suite || tenancy.floor || 'N/A'}</td>
                    <td className="p-4 text-gray-300">{tenancy.size_sqm || tenancy.area_m2 || 'N/A'}</td>
                    <td className="p-4 text-gray-300">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span>{format(new Date(tenancy.updated_date), 'dd MMM yyyy')}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {leasedTenancies.length === 0 && (
            <div className="text-center p-12 text-gray-500">
                <Archive className="w-12 h-12 mx-auto mb-3" />
                <h3 className="text-lg font-medium text-white">No Leased Properties Logged</h3>
                <p>When the AI scanner identifies delisted properties, they will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}