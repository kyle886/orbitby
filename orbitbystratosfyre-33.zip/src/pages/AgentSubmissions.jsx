
import React, { useState, useEffect } from "react";
import { PropertySubmission } from "@/api/entities";
import { User } from "@/api/entities";
import { Loader2, Building2, Calendar, Edit, Check } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { updateSubmissionAndSyncTenancy } from "@/api/functions";

export default function AgentSubmissions() {
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const user = await User.me();
      setCurrentUser(user);
      const allSubmissions = await PropertySubmission.list("-created_date");
      // Filter submissions by agent name or email matching current user
      const agentName = `${user.first_name || ''} ${user.last_name || ''}`.trim();
      const agentEmail = user.email;
      
      const submissionsArray = Array.isArray(allSubmissions) ? allSubmissions : [];
      const mySubmissions = submissionsArray.filter(s => 
        s.agent_name === agentName || 
        s.agent_email === agentEmail ||
        (s.agent_name && s.agent_name.toLowerCase().includes((user.first_name || '').toLowerCase())) ||
        (s.agent_name && s.agent_name.toLowerCase().includes((user.last_name || '').toLowerCase()))
      );
      setSubmissions(mySubmissions);
    } catch (error) {
      console.error("Error loading submissions:", error);
      setSubmissions([]);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (submissionId, newStatus) => {
    try {
      // Call the new backend function to handle the sync
      await updateSubmissionAndSyncTenancy({ submissionId, newStatus });
      
      // Update local state for immediate UI feedback
      setSubmissions(prev => 
        (prev || []).map(s => s.id === submissionId ? { ...s, availability_status: newStatus } : s)
      );
    } catch (error) {
      console.error("Error updating status:", error);
      alert("Failed to update status.");
    }
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'available': return 'text-green-400';
      case 'under_offer': return 'text-yellow-400';
      case 'leased': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getSubmissionStatusColor = (status) => {
    switch (status) {
      case 'shortlisted': return 'text-green-400';
      case 'under_review': return 'text-blue-400';
      case 'rejected': return 'text-red-400';
      case 'submitted': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  if (loading) return <div className="p-8 text-center"><Loader2 className="h-12 w-12 animate-spin text-amber-400 mx-auto" /></div>;

  const submissionsArray = Array.isArray(submissions) ? submissions : [];

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">My Property Submissions</h1>
          <p className="text-gray-300">Manage the status of properties you have submitted to Stratosfyre.</p>
        </div>

        <div className="orbit-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm text-gray-300">
              <thead className="bg-gray-800/50">
                <tr>
                  <th className="text-left font-semibold p-4">Property</th>
                  <th className="text-left font-semibold p-4">Size (sqm)</th>
                  <th className="text-left font-semibold p-4">Rent ($/sqm)</th>
                  <th className="text-left font-semibold p-4">Availability</th>
                  <th className="text-left font-semibold p-4">Property Status</th>
                  <th className="text-left font-semibold p-4">Review Status</th>
                  <th className="text-center font-semibold p-4">Update Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700/50">
                {submissionsArray.map(sub => (
                  <tr key={sub.id} className="hover:bg-gray-800/50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium text-white">{sub.property_title}</p>
                        <p className="text-sm text-gray-400">{sub.address}</p>
                      </div>
                    </td>
                    <td className="p-4">{sub.floor_area_sqm || 'N/A'}</td>
                    <td className="p-4">${sub.rental_rate_sqm || 'N/A'}</td>
                    <td className="p-4">{sub.availability_date ? new Date(sub.availability_date).toLocaleDateString() : 'Now'}</td>
                    <td className={`p-4 font-medium capitalize ${getStatusColor(sub.availability_status)}`}>
                      {(sub.availability_status || 'available').replace('_', ' ')}
                    </td>
                    <td className={`p-4 font-medium capitalize ${getSubmissionStatusColor(sub.status)}`}>
                      {(sub.status || 'submitted').replace('_', ' ')}
                    </td>
                    <td className="p-4 text-center">
                      <Select 
                        value={sub.availability_status || 'available'} 
                        onValueChange={(value) => handleStatusChange(sub.id, value)}
                      >
                        <SelectTrigger className="orbit-input w-40 mx-auto">
                          <SelectValue placeholder="Update status..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="available">Available</SelectItem>
                          <SelectItem value="under_offer">Under Offer</SelectItem>
                          <SelectItem value="leased">Leased</SelectItem>
                        </SelectContent>
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {submissionsArray.length === 0 && (
            <div className="text-center p-12 text-gray-500">
              <Building2 className="w-12 h-12 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-white">No Submissions Found</h3>
              <p>Properties you submit will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
