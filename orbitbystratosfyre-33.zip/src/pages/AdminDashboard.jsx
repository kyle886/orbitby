
import React, { useState, useEffect } from "react";
import { Client } from "@/api/entities";
import { TenantRequirement } from "@/api/entities";
import { PropertySubmission } from "@/api/entities";
import { User } from "@/api/entities";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Building2, 
  Users, 
  Briefcase, 
  TrendingUp, 
  CheckCircle,
  Clock,
  ArrowRight,
  Search,
  FileText,
  Database // Added Database icon import
} from "lucide-react";

export default function AdminDashboard() {
  const [dashboardData, setDashboardData] = useState({
    totalClients: 0,
    activeBriefs: 0,
    totalSubmissions: 0,
    recentActivity: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [clients, briefs, submissions] = await Promise.all([
        Client.list("-created_date", 100),
        TenantRequirement.list("-created_date", 100),
        PropertySubmission.list("-created_date", 50)
      ]);

      const activeBriefs = briefs.filter(b => 
        ['active', 'in_market', 'search_active'].includes(b.status)
      );

      const recentSubmissions = submissions.slice(0, 5);

      setDashboardData({
        totalClients: clients.length,
        activeBriefs: activeBriefs.length,
        totalSubmissions: submissions.length,
        recentActivity: recentSubmissions
      });
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  const StatCard = ({ title, value, icon: Icon, color, link }) => (
    <Link to={link} className="block stratos-card p-6 hover:scale-105 transition-all duration-200">
      <div className="flex items-center justify-between">
        <div>
          <p className="stratos-micro-label mb-1">{title}</p>
          <p className="text-3xl font-bold text-white metric-value">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </Link>
  );

  if (loading) {
    return (
      <div className="min-h-screen">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="stratos-card animate-pulse p-6 h-36">
                <div className="h-4 bg-gray-700 rounded mb-4 w-1/2"></div>
                <div className="h-8 bg-gray-700 rounded mb-2 w-3/4"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="stratos-h1 mb-2">Command Center</h1>
          <p className="stratos-body">
            Real-time operations and business intelligence
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Active Clients"
            value={dashboardData.totalClients}
            icon={Users}
            color="bg-viz-secondary/80"
            link={createPageUrl("ClientManagement")}
          />
          <StatCard
            title="Live Briefs"
            value={dashboardData.activeBriefs}
            icon={Briefcase}
            color="bg-viz-tertiary/80"
            link={createPageUrl("Requirements")}
          />
          <StatCard
            title="New Submissions"
            value={dashboardData.totalSubmissions}
            icon={Building2}
            color="bg-viz-quaternary/80"
            link={createPageUrl("SubmissionManagement")}
          />
          <StatCard
            title="Database Size"
            value="500+"
            icon={Database} // Changed icon from Building2 to Database
            color="bg-viz-primary/80"
            link={createPageUrl("BuildingDatabase")}
          />
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="stratos-card">
              <div className="stratos-card-header">
                <div className="stratos-card-header-label">Recent Activity</div>
                <Building2 className="stratos-card-header-icon" />
              </div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="stratos-h3">Latest Submissions</h3>
                <Link to={createPageUrl("SubmissionManagement")}>
                  <button className="stratos-button stratos-button-tertiary flex items-center gap-2">
                    View All
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </Link>
              </div>
              <div className="space-y-4">
                {dashboardData.recentActivity.map((submission) => (
                  <div key={submission.id} className="flex gap-4 p-4 bg-glass-subtle rounded-xl">
                    <div className="p-3 bg-glass-card rounded-lg h-fit">
                      <Building2 className="w-5 h-5 text-viz-quaternary" />
                    </div>
                    <div className="flex-1">
                      <h4 className="stratos-technical-label mb-1">{submission.property_title}</h4>
                      <p className="stratos-micro-copy mb-2">{submission.address}</p>
                      <div className="flex items-center gap-4 text-xs text-moonlight">
                        <span>{submission.floor_area_sqm} sqm</span>
                        <span>${submission.rental_rate_sqm}/sqm</span>
                        <span>{new Date(submission.created_date).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
                {dashboardData.recentActivity.length === 0 && (
                  <div className="text-center py-8 text-moonlight">
                    <FileText className="w-12 h-12 mx-auto mb-3 text-moonlight/40" />
                    <p className="stratos-technical-label">No recent activity</p>
                    <p className="stratos-micro-copy">New submissions will appear here</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="stratos-card">
              <div className="stratos-card-header">
                <div className="stratos-card-header-label">Quick Actions</div>
                <Search className="stratos-card-header-icon" />
              </div>
              <div className="space-y-3">
                <Link to={createPageUrl("Requirements")} className="block stratos-button stratos-button-secondary text-left p-4 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Briefcase className="w-5 h-5" />
                    <span className="stratos-technical-label">New Brief</span>
                  </div>
                </Link>
                <Link to={createPageUrl("ClientManagement")} className="block stratos-button stratos-button-secondary text-left p-4 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Users className="w-5 h-5" />
                    <span className="stratos-technical-label">Add Client</span>
                  </div>
                </Link>
                <Link to={createPageUrl("SubmitListing")} className="block stratos-button stratos-button-secondary text-left p-4 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Building2 className="w-5 h-5" />
                    <span className="stratos-technical-label">Submit Property</span>
                  </div>
                </Link>
                <Link to={createPageUrl("AgentConfiguration")} className="block stratos-button stratos-button-secondary text-left p-4 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Search className="w-5 h-5" />
                    <span className="stratos-technical-label">Run AI Scan</span>
                  </div>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
