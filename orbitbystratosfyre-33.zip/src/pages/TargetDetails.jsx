import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Target } from '@/api/entities';
import { Company } from '@/api/entities';
import { Signal } from '@/api/entities';
import { Contact } from '@/api/entities';
import { Lease } from '@/api/entities';
import { AppSettings } from '@/api/entities';
import { calculateScores } from '@/components/utils/scoringCalculations'; // Fixed import path
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TargetActions } from '@/components/actions/TargetActions';
import { Loader2, Building, TrendingUp, Users, Calendar, Star, Pin } from 'lucide-react';

export default function TargetDetails() {
  const [searchParams] = useSearchParams();
  const targetId = searchParams.get('id');
  
  const [target, setTarget] = useState(null);
  const [company, setCompany] = useState(null);
  const [signals, setSignals] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [lease, setLease] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadTargetData = useCallback(async () => {
    if (!targetId) {
      setLoading(false);
      setError('Target ID not provided.');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const [targetRawData, allSignals, allLeases, allCompanies, appSettingsList] = await Promise.all([
        Target.filter({ id: targetId }).then(targets => targets[0]).catch(() => null),
        Signal.list().catch(() => []),
        Lease.list().catch(() => []),
        Company.list().catch(() => []),
        AppSettings.list().then(s => s[0] || {}).catch(() => ({})),
      ]);

      if (!targetRawData) {
        setError('Target not found.');
        setLoading(false);
        return;
      }

      const settings = appSettingsList;

      // Get company info
      const currentCompany = allCompanies.find(c => c.id === targetRawData.company_id);
      if (!currentCompany) {
        setError('Company information for target not found.');
        setLoading(false);
        return;
      }
      
      // Get related data for the specific target's company
      const targetSignals = allSignals.filter(s => s.company_id === targetRawData.company_id);
      const targetLeases = allLeases.filter(l => l.company_id === targetRawData.company_id);
      const targetContacts = await Contact.filter({ company_id: targetRawData.company_id }).catch(() => []);

      // Create an enhanced target object for scoring calculation
      const enhancedTarget = { ...targetRawData, company: currentCompany };

      // Recalculate scores using the external utility function
      const calculatedScores = calculateScores(targetSignals, targetLeases, enhancedTarget, settings);

      // Update the target with fresh scores and the current company
      const updatedTarget = { ...targetRawData, ...calculatedScores, company: currentCompany };

      setTarget(updatedTarget);
      setCompany(currentCompany);
      setSignals(targetSignals);
      setContacts(targetContacts);
      setLease(targetLeases[0] || null);
      
      console.log('Target loaded with scores:', updatedTarget);
      
    } catch (err) {
      console.error('Error loading target data:', err);
      setError(err.message || 'An unexpected error occurred while loading target details.');
    } finally {
      setLoading(false);
    }
  }, [targetId]);

  useEffect(() => {
    if (targetId) {
      loadTargetData();
    }
  }, [targetId, loadTargetData]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full p-8">
        <Loader2 className="w-12 h-12 animate-spin text-orange-400" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 text-center">
        <h1 className="text-2xl font-bold text-white">Error</h1>
        <p className="text-gray-400">{error}</p>
      </div>
    );
  }

  if (!target || !company) {
    return (
      <div className="p-8 text-center">
        <h1 className="text-2xl font-bold text-white">Target Not Found</h1>
        <p className="text-gray-400">The requested target could not be loaded or does not exist.</p>
      </div>
    );
  }

  const getScoreColor = (score) => {
    if (score >= 75) return 'text-green-400';
    if (score >= 50) return 'text-yellow-400';
    if (score >= 25) return 'text-orange-400';
    return 'text-red-400';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'prospect': return 'bg-orange-500/20 text-orange-300';
      case 'working': return 'bg-blue-500/20 text-blue-300';
      case 'won': return 'bg-green-500/20 text-green-300';
      case 'disqualified': return 'bg-red-500/20 text-red-300';
      default: return 'bg-gray-500/20 text-gray-300';
    }
  };

  return (
    <div className="p-4 sm:p-6 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold text-white">{company.name}</h1>
              {target.is_top_20 && (
                <div className="flex items-center gap-1 bg-amber-500/20 text-amber-300 px-2 py-1 rounded-full">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="text-xs font-medium">Top 20</span>
                </div>
              )}
              {target.pinned && (
                <div className="flex items-center gap-1 bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full">
                  <Pin className="w-4 h-4" />
                  <span className="text-xs font-medium">Pinned</span>
                </div>
              )}
            </div>
            <p className="text-gray-400">{company.sector} • {company.hq_city}</p>
            <p className="text-gray-500 text-sm">{company.employees_est} employees • {company.website}</p>
          </div>
          <div className="text-right">
            <Badge className={getStatusColor(target.status)}>{target.status}</Badge>
            <div className="mt-2">
              <span className="text-sm text-gray-400">Priority Score</span>
              <div className={`text-3xl font-bold ${getScoreColor(target.priority_score)}`}>
                {target.priority_score}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Score Breakdown */}
          <Card className="orbit-card">
            <CardHeader>
              <CardTitle className="text-white">Score Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-400">Funding Momentum</span>
                    <span className="text-sm font-medium text-white">{target.funding_momentum_score || 0}</span>
                  </div>
                  <Progress value={target.funding_momentum_score || 0} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-400">Lease Expiry</span>
                    <span className="text-sm font-medium text-white">{target.lease_expiry_proximity_score || 0}</span>
                  </div>
                  <Progress value={target.lease_expiry_proximity_score || 0} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-400">Building Leverage</span>
                    <span className="text-sm font-medium text-white">{target.building_leverage_score || 0}</span>
                  </div>
                  <Progress value={target.building_leverage_score || 0} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-400">Sector Fit</span>
                    <span className="text-sm font-medium text-white">{target.sector_fit_score || 0}</span>
                  </div>
                  <Progress value={target.sector_fit_score || 0} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-400">Hiring Signal</span>
                    <span className="text-sm font-medium text-white">{target.hiring_signal_score || 0}</span>
                  </div>
                  <Progress value={target.hiring_signal_score || 0} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-400">News Heat</span>
                    <span className="text-sm font-medium text-white">{target.news_heat_score || 0}</span>
                  </div>
                  <Progress value={target.news_heat_score || 0} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tabs for detailed information */}
          <Tabs defaultValue="signals" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="signals">Signals ({signals.length})</TabsTrigger>
              <TabsTrigger value="contacts">Contacts ({contacts.length})</TabsTrigger>
              <TabsTrigger value="lease">Lease Info</TabsTrigger>
            </TabsList>

            <TabsContent value="signals">
              <Card className="orbit-card">
                <CardHeader>
                  <CardTitle className="text-white">Recent Signals</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {signals.length > 0 ? signals.slice(0, 10).map((signal) => (
                      <div key={signal.id} className="border-b border-gray-700/50 pb-3 last:border-0">
                        <div className="flex justify-between items-start mb-1">
                          <h4 className="font-medium text-white">{signal.title}</h4>
                          <Badge variant="outline" className="text-xs">
                            {signal.type}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-400 mb-2">
                          {new Date(signal.date).toLocaleDateString()} • {signal.source}
                        </p>
                        {signal.amount_aud && (
                          <p className="text-sm text-green-400 font-medium">
                            ${signal.amount_aud.toLocaleString()} AUD
                          </p>
                        )}
                      </div>
                    )) : (
                      <p className="text-gray-400 text-center py-4">No signals found</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="contacts">
              <Card className="orbit-card">
                <CardHeader>
                  <CardTitle className="text-white">Decision Makers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {contacts.length > 0 ? contacts.map((contact) => (
                      <div key={contact.id} className="border-b border-gray-700/50 pb-3 last:border-0">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium text-white">{contact.name}</h4>
                            <p className="text-sm text-gray-400">{contact.role}</p>
                            {contact.email && (
                              <p className="text-sm text-gray-500">{contact.email}</p>
                            )}
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {contact.decision_level}
                          </Badge>
                        </div>
                      </div>
                    )) : (
                      <p className="text-gray-400 text-center py-4">No contacts identified</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="lease">
              <Card className="orbit-card">
                <CardHeader>
                  <CardTitle className="text-white">Lease Information</CardTitle>
                </CardHeader>
                <CardContent>
                  {lease ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-400">Area:</span>
                          <span className="ml-2 text-white font-medium">{lease.area_m2} sqm</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Start Date:</span>
                          <span className="ml-2 text-white">{new Date(lease.start_date).toLocaleDateString()}</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Expiry:</span>
                          <span className="ml-2 text-white">{lease.expiry_date ? new Date(lease.expiry_date).toLocaleDateString() : 'Unknown'}</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Source:</span>
                          <span className="ml-2 text-white capitalize">{lease.source}</span>
                        </div>
                      </div>
                      {lease.notes && (
                        <div className="mt-3 p-3 bg-gray-800/50 rounded-lg">
                          <p className="text-sm text-gray-300">{lease.notes}</p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-gray-400 text-center py-4">No lease information available</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar Actions */}
        <div className="space-y-6">
          {/* Status Actions */}
          <Card className="orbit-card">
            <CardHeader>
              <CardTitle className="text-white">Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <TargetActions target={target} onUpdate={loadTargetData} />
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="orbit-card">
            <CardHeader>
              <CardTitle className="text-white">Quick Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Owner:</span>
                <span className="text-white">{target.owner_email || 'Unassigned'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Created:</span>
                <span className="text-white">{new Date(target.created_date).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Last Updated:</span>
                <span className="text-white">{new Date(target.updated_date).toLocaleDateString()}</span>
              </div>
              {target.next_action_at && (
                <div className="flex justify-between">
                  <span className="text-gray-400">Next Action:</span>
                  <span className="text-white">{new Date(target.next_action_at).toLocaleDateString()}</span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}