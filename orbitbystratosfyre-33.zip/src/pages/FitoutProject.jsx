import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { TenantRequirement } from '@/api/entities';
import { ProjectRisk } from '@/api/entities';
import { PMTask } from '@/api/entities';
import { Subcontractor } from '@/api/entities';
import { ClientUpdate } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Calendar, AlertTriangle, Users, FileText, BarChart2, DollarSign } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import GanttChart from '@/components/pm/Gantt';

const OverviewCard = ({ title, icon: Icon, children }) => (
  <Card className="orbit-card h-full">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium text-gray-300">{title}</CardTitle>
      <Icon className="h-4 w-4 text-gray-400" />
    </CardHeader>
    <CardContent>{children}</CardContent>
  </Card>
);

const RiskRegisterTab = ({ risks }) => (
  <Card className="orbit-card">
    <CardHeader>
      <CardTitle>Risk Register</CardTitle>
      <CardDescription>All identified project risks.</CardDescription>
    </CardHeader>
    <CardContent>
      <div className="space-y-4">
        {risks.length > 0 ? risks.map(risk => (
          <div key={risk.id} className="p-3 bg-gray-800/50 rounded-lg">
            <div className="flex justify-between items-start">
              <h4 className="font-semibold text-white">{risk.title}</h4>
              <span className={`px-2 py-1 text-xs rounded-full ${
                risk.severity === 'High' || risk.severity === 'Critical' ? 'bg-red-500/20 text-red-300' :
                risk.severity === 'Medium' ? 'bg-yellow-500/20 text-yellow-300' : 'bg-green-500/20 text-green-300'
              }`}>{risk.severity}</span>
            </div>
            <p className="text-sm text-gray-400 mt-1">{risk.mitigation_strategy || 'No mitigation strategy defined.'}</p>
          </div>
        )) : <p className="text-gray-400">No risks have been logged for this project.</p>}
      </div>
    </CardContent>
  </Card>
);

export default function FitoutProject() {
  const [searchParams] = useSearchParams();
  const projectId = searchParams.get('id');
  const { toast } = useToast();

  const [project, setProject] = useState(null);
  const [risks, setRisks] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [subcontractors, setSubcontractors] = useState([]);
  const [communications, setCommunications] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    if (!projectId) {
      toast({ variant: 'destructive', title: 'Error', description: 'No project ID provided.' });
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      // Step 1: Fetch the main project
      const projData = await TenantRequirement.get(projectId);
      setProject(projData);

      if (projData) {
        // Step 2: Fetch related data using the project's ID and client ID
        const [riskData, taskData, subData, commsData] = await Promise.all([
          ProjectRisk.filter({ project_id: projectId }),
          PMTask.filter({ project_id: projectId }),
          Subcontractor.filter({ project_id: projectId }),
          ClientUpdate.filter({ client_id: projData.client_id })
        ]);
        setRisks(riskData || []);
        setTasks(taskData || []);
        setSubcontractors(subData || []);
        setCommunications(commsData || []);
      }
    } catch (error) {
      console.error("Error loading project data:", error);
      toast({ variant: "destructive", title: "Failed to load project", description: error.message });
    } finally {
      setLoading(false);
    }
  }, [projectId, toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  if (loading) {
    return <div className="flex h-screen items-center justify-center"><Loader2 className="h-12 w-12 animate-spin text-orange-400" /></div>;
  }

  if (!project) {
    return (
        <div className="flex h-screen items-center justify-center p-8">
            <Card className="orbit-card max-w-lg text-center">
                <CardHeader>
                    <CardTitle className="text-red-400">Project Not Found</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-gray-300">The requested project could not be found. It may have been deleted or you may not have permission to view it.</p>
                </CardContent>
            </Card>
        </div>
    );
  }
  
  const scheduleVariance = project.baseline_completion_date && project.forecast_completion_date ? 
    (new Date(project.forecast_completion_date) - new Date(project.baseline_completion_date)) / (1000 * 60 * 60 * 24) : 0;
  
  const budget = project.budget_aud || 0;
  const spent = project.spent_aud || 0;
  
  const financialForecast = budget > 0 && spent > 0 ? spent * 1.02 : budget;
  const financialVariance = financialForecast - budget;

  const OverviewDashboard = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <OverviewCard title="Project Overview" icon={BarChart2}>
        <ul className="space-y-2 text-sm text-gray-300">
          <li><strong>Project Name:</strong> {project.company_name} Fitout</li>
          <li><strong>Status:</strong> {project.status?.replace('_',' ')}</li>
          <li><strong>Phase:</strong> {project.project_phase}</li>
          <li><strong>Completion:</strong> {project.completion_pct || 0}%</li>
        </ul>
      </OverviewCard>
      <OverviewCard title="Schedule" icon={Calendar}>
        <ul className="space-y-2 text-sm text-gray-300">
            <li><strong>Baseline Completion:</strong> {project.baseline_completion_date ? new Date(project.baseline_completion_date).toLocaleDateString() : 'N/A'}</li>
            <li><strong>Forecast Completion:</strong> {project.forecast_completion_date ? new Date(project.forecast_completion_date).toLocaleDateString() : 'N/A'}</li>
            <li><strong>Variance:</strong> <span className={scheduleVariance > 0 ? 'text-red-400' : 'text-green-400'}>{scheduleVariance} days</span></li>
        </ul>
      </OverviewCard>
      <OverviewCard title="Risks" icon={AlertTriangle}>
        <ul className="space-y-1 text-sm text-gray-300">
          {risks.slice(0, 3).map(r => <li key={r.id}>{r.title} ({r.severity})</li>)}
          {risks.length === 0 && <li>No open risks.</li>}
        </ul>
      </OverviewCard>
       <OverviewCard title="Subcontractor Management" icon={Users}>
        <ul className="space-y-2 text-sm text-gray-300">
            <li><strong>Active Subcontractors:</strong> {subcontractors.length}</li>
            <li><strong>Tasks On Track:</strong> 85%</li>
            <li><strong>Compliance Docs Outstanding:</strong> 2</li>
        </ul>
      </OverviewCard>
      <OverviewCard title="Client Communication" icon={FileText}>
        <ul className="space-y-2 text-sm text-gray-300">
          <li><strong>Weekly Report:</strong> {communications[0] ? new Date(communications[0].created_date).toLocaleDateString() : 'N/A'}</li>
          <li><strong>Next Meeting:</strong> {new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString()}</li>
          <li><strong>Client Queries:</strong> 2 pending</li>
        </ul>
      </OverviewCard>
      <OverviewCard title="Financials" icon={DollarSign}>
        <ul className="space-y-2 text-sm text-gray-300">
            <li><strong>Budget:</strong> A${budget.toLocaleString()}</li>
            <li><strong>Spent:</strong> A${spent.toLocaleString()}</li>
            <li><strong>Forecast:</strong> A${financialForecast.toLocaleString()} ({financialVariance >= 0 ? '+' : ''}{((financialVariance / (budget || 1)) * 100).toFixed(0)}%)</li>
        </ul>
      </OverviewCard>
    </div>
  );

  return (
    <div className="p-4 sm:p-6 md:p-8">
      <header className="mb-8">
        <div className="flex flex-col sm:flex-row justify-between sm:items-start gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white">{project.company_name} - Project Delivery</h1>
            <p className="text-gray-300">AI-driven fitout project management dashboard.</p>
          </div>
          <div className="text-left sm:text-right flex-shrink-0">
              <span className="text-sm text-gray-500 font-medium tracking-wider uppercase">Project Code</span>
              <p className="font-mono text-lg text-orange-400 bg-gray-800/50 px-3 py-1 rounded-md mt-1">
                {project.brief_reference_code || 'N/A'}
              </p>
          </div>
        </div>
      </header>
      
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-md">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="risks">Risk Register</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="mt-4">
          <OverviewDashboard />
        </TabsContent>
        <TabsContent value="schedule" className="mt-4">
          <GanttChart tasks={tasks} />
        </TabsContent>
        <TabsContent value="risks" className="mt-4">
          <RiskRegisterTab risks={risks} />
        </TabsContent>
      </Tabs>
    </div>
  );
}