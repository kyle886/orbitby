import React, { useState, useEffect, useCallback } from 'react';
import _ from 'lodash';
import { MarketIntelligence } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, TrendingUp, Sparkles, Building, BarChart, FileText, ExternalLink, History, Calendar, Upload, Trash2 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart as RechartsBarChart, Bar } from 'recharts';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import ManualReportUpload from "../components/market-intelligence/ManualReportUpload";
import AustraliaMap from "../components/market-intelligence/AustraliaMap";
import StateMarketView from "../components/market-intelligence/StateMarketView";
import { useToast } from "@/components/ui/use-toast";

export default function MarketIntelligencePage() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const [filters, setFilters] = useState({ state: 'all', sector: 'all' });
  const [activeTab, setActiveTab] = useState('map');
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [selectedStateData, setSelectedStateData] = useState(null);
  const [selectedStateName, setSelectedStateName] = useState('');
  const { toast } = useToast();

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const reportsData = await MarketIntelligence.list("-report_date");
      setReports(reportsData || []);
    } catch (error) {
      console.error("Error loading market intelligence data:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleDelete = async (report) => {
    const confirmDelete = window.confirm(`Are you sure you want to delete the report "${report.report_title}"?`);
    if (confirmDelete) {
      try {
        await MarketIntelligence.delete(report.id);
        setReports(prev => prev.filter(r => r.id !== report.id));
        toast({ title: "Report Deleted", description: `"${report.report_title}" has been removed.` });
      } catch (error) {
        console.error("Error deleting report:", error);
        toast({ variant: "destructive", title: "Deletion Failed", description: "The report could not be deleted." });
      }
    }
  };

  const handleScan = async () => {
    setIsScanning(true);
    toast({ title: "Scan Initiated", description: "AI agent is now scanning for new market reports..." });
    try {
      const reportSchema = {
        type: "object",
        properties: {
          reports: {
            type: "array",
            items: {
              type: "object",
              properties: {
                report_source: { type: "string", enum: ["knight_frank", "cbre", "colliers", "cushman_wakefield", "jll", "savills", "other"] },
                report_title: { type: "string" },
                report_date: { type: "string", format: "date" },
                state: { type: "string", enum: ["NSW", "VIC", "QLD", "WA", "SA", "TAS", "ACT", "NT", "National"] },
                market: { type: "string" },
                sector: { type: "string", enum: ["Office", "Industrial", "Retail", "Mixed Use"] },
                rent_data: { type: "object", properties: { prime_rent_sqm: { type: "number" }, secondary_rent_sqm: { type: "number" } } },
                vacancy_data: { type: "object", properties: { total_vacancy_percent: { type: "number" }, prime_vacancy_percent: { type: "number" }, secondary_vacancy_percent: { type: "number" } } },
                incentive_data: { type: "object", properties: { prime_incentive_percent: { type: "number" }, secondary_incentive_percent: { type: "number" } } },
                key_insights: { type: "array", items: { type: "string" } },
                market_outlook: { type: "string", enum: ["Positive", "Stable", "Cautious", "Negative"] },
                report_url: { type: "string" }
              },
              required: ["report_source", "report_title", "report_date", "state", "market", "sector"]
            }
          }
        },
        required: ["reports"]
      };

      const prompt = `You are an expert real estate market analyst. Find the latest market research reports for Australia from major sources like Knight Frank, CBRE, Colliers, Cushman & Wakefield, JLL, and Savills. Focus on Office and Industrial sectors in major markets. Extract key data points accurately.`;

      const response = await InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: reportSchema,
      });

      const newReports = response?.reports || [];

      if (newReports && Array.isArray(newReports) && newReports.length > 0) {
        const existingReportUrls = new Set(reports.map(r => r.report_url).filter(Boolean));
        const uniqueNewReports = newReports.filter(nr => nr.report_url && !existingReportUrls.has(nr.report_url));
        
        if (uniqueNewReports.length > 0) {
          await MarketIntelligence.bulkCreate(uniqueNewReports);
          toast({
            title: "Scan Successful!",
            description: `Found and saved ${uniqueNewReports.length} new market reports.`,
          });
        } else {
          toast({ title: "Scan Complete", description: "No new reports found." });
        }
        loadData();
      } else {
        toast({ title: "Scan Complete", description: "No new reports found." });
      }
    } catch (error) {
      console.error("Failed to scan for market intelligence:", error);
      toast({
        variant: "destructive",
        title: "Scan Failed",
        description: "An error occurred during the scan. Please try again.",
      });
    } finally {
      setIsScanning(false);
    }
  };

  const handleStateSelect = (stateName, stateData) => {
    setSelectedStateName(stateName);
    setSelectedStateData(stateData);
    setActiveTab('state-detail');
  };

  const handleBackToMap = () => {
    setActiveTab('map');
    setSelectedStateData(null);
    setSelectedStateName('');
  };

  const onDragEnd = async (result) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;
    if (destination.droppableId === source.droppableId && destination.index === source.index) return; 

    const reportId = draggableId;
    const report = reports.find(r => r.id === reportId);
    if (!report) return;

    let newState = report.state;
    let newSector = report.sector;
    let newMarket = report.market;

    if (destination.droppableId === "national-reports") {
      newState = 'National';
      newSector = report.sector;
      newMarket = 'Australia Wide';
    } else {
      const [destType, destState, destSector] = destination.droppableId.split('-');
      if (destType === 'state') {
        newState = destState;
        newSector = destSector;
        if (report.state === 'National') {
            newMarket = null; 
        } else {
            newMarket = report.market;
        }
      }
    }
    
    if (newState !== report.state || newSector !== report.sector || newMarket !== report.market) {
      try {
        const updatedReport = {
          ...report,
          state: newState,
          sector: newSector,
          market: newMarket,
        };

        await MarketIntelligence.update(reportId, updatedReport);
        setReports(prev => prev.map(r => r.id === reportId ? updatedReport : r));
        
      } catch (error) {
        console.error("Error updating report:", error);
        alert("Failed to move report. Please try again.");
      }
    }
  };

  const getLatestReports = () => {
    if (!reports || reports.length === 0) return [];
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    
    return reports.filter(report => {
      if (!report.report_date) return false;
      const reportDate = new Date(report.report_date);
      return !isNaN(reportDate.getTime()) && reportDate >= sixMonthsAgo;
    });
  };

  const getTrendData = (state, market, sector, metric) => {
    return reports
      .filter(r => r.state === state && r.market === market && r.sector === sector && r.report_date)
      .sort((a, b) => new Date(a.report_date) - new Date(b.report_date))
      .map(report => ({
        date: report.report_date,
        quarter: getQuarter(report.report_date),
        author: _.startCase(report.report_source),
        value: getMetricValue(report, metric),
        report_source: report.report_source
      }))
      .filter(d => d.value !== null && d.value !== undefined);
  };

  const getQuarter = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A';
    const quarter = Math.floor(date.getMonth() / 3) + 1;
    return `Q${quarter} ${date.getFullYear()}`;
  };

  const getMetricValue = (report, metric) => {
    switch (metric) {
      case 'total_vacancy': return report.vacancy_data?.total_vacancy_percent;
      case 'prime_vacancy': return report.vacancy_data?.prime_vacancy_percent;
      case 'prime_rent': return report.rent_data?.prime_rent_sqm;
      case 'secondary_rent': return report.rent_data?.secondary_rent_sqm;
      case 'prime_incentive': return report.incentive_data?.prime_incentive_percent;
      default: return null;
    }
  };

  const latestReports = getLatestReports();
  const filteredReports = latestReports.filter(r => 
    (filters.state === 'all' || r.state === filters.state) &&
    (filters.sector === 'all' || r.sector === filters.sector) &&
    r.state && r.market
  );

  const nationalReports = filteredReports.filter(r => r.state === 'National');
  const stateReports = filteredReports.filter(r => r.state !== 'National');
  const groupedByState = _.groupBy(stateReports, 'state');

  const states = [...new Set(reports.map(r => r.state))].filter(Boolean).filter(s => s !== 'National');
  const sectors = [...new Set(reports.map(r => r.sector))].filter(Boolean);

  const getLatestYear = () => {
    if (!reports || reports.length === 0) return '-';
    const validDates = reports
      .map(r => new Date(r.report_date))
      .filter(date => !isNaN(date.getTime()));
    
    if (validDates.length === 0) return '-';
    return new Date(Math.max(...validDates)).getFullYear();
  };

  const uniqueMarkets = [...new Set(reports.map(r => r.market))].filter(Boolean);
  const uniqueSources = [...new Set(reports.map(r => r.report_source))].filter(Boolean);

  const HistoricalTrends = () => {
    const [selectedState, setSelectedState] = useState(states[0] || 'NSW');
    const [selectedMarket, setSelectedMarket] = useState('Sydney CBD');
    const [selectedSector, setSelectedSector] = useState('Office');
    const [selectedMetric, setSelectedMetric] = useState('total_vacancy');

    const availableMarkets = React.useMemo(() => 
      [...new Set(reports.filter(r => r.state === selectedState && r.market).map(r => r.market))]
    , [selectedState]);

    useEffect(() => {
        if (availableMarkets.length > 0 && !availableMarkets.includes(selectedMarket)) {
            setSelectedMarket(availableMarkets[0]);
        }
    }, [selectedState, availableMarkets, selectedMarket]);

    const trendData = getTrendData(selectedState, selectedMarket, selectedSector, selectedMetric);
    const authorComparison = _.groupBy(trendData, 'report_source');
    const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#00C49F'];

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Select value={selectedState} onValueChange={setSelectedState}>
            <SelectTrigger className="orbit-input text-white h-12">
              <SelectValue placeholder="Select State" />
            </SelectTrigger>
            <SelectContent>
              {states.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={selectedMarket} onValueChange={setSelectedMarket}>
            <SelectTrigger className="orbit-input text-white h-12">
              <SelectValue placeholder="Select Market" />
            </SelectTrigger>
            <SelectContent>
              {availableMarkets.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={selectedSector} onValueChange={setSelectedSector}>
            <SelectTrigger className="orbit-input text-white h-12">
              <SelectValue placeholder="Select Sector" />
            </SelectTrigger>
            <SelectContent>
              {sectors.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={selectedMetric} onValueChange={setSelectedMetric}>
            <SelectTrigger className="orbit-input text-white h-12">
              <SelectValue placeholder="Select Metric" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="total_vacancy">Total Vacancy %</SelectItem>
              <SelectItem value="prime_vacancy">Prime Vacancy %</SelectItem>
              <SelectItem value="prime_rent">Prime Rent $/sqm</SelectItem>
              <SelectItem value="secondary_rent">Secondary Rent $/sqm</SelectItem>
              <SelectItem value="prime_incentive">Prime Incentive %</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {trendData.length > 0 ? (
          <div className="grid lg:grid-cols-2 gap-8">
            <div className="orbit-card p-6">
              <h3 className="text-xl font-semibold text-white mb-4">
                {selectedMetric.replace('_', ' ').toUpperCase()} - {selectedMarket}, {selectedState}
              </h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="quarter" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }} 
                    labelStyle={{ color: '#F3F4F6' }} 
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#8884d8" 
                    strokeWidth={2} 
                    dot={{ r: 4 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="orbit-card p-6">
              <h3 className="text-xl font-semibold text-white mb-4">Latest Readings by Author</h3>
              <div className="space-y-4">
                {Object.entries(authorComparison).map(([author, data], index) => {
                  const latestData = data[data.length - 1];
                  return (
                    <div key={author} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded-full" 
                          style={{ backgroundColor: colors[index % colors.length] }}
                        />
                        <span className="text-white font-medium">{_.startCase(author)}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-white font-bold">
                          {latestData?.value?.toFixed(1) || 'N/A'}
                        </span>
                        <p className="text-xs text-gray-400">{latestData?.quarter}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          <div className="orbit-card p-12 text-center">
            <BarChart className="w-12 h-12 mx-auto mb-3 text-gray-500" />
            <h3 className="text-lg font-medium text-white">No Historical Data</h3>
            <p className="text-gray-400">No trend data available for the selected combination.</p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="p-4 sm:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">Market Intelligence</h1>
            <p className="text-gray-300">Interactive market research and trend analysis across Australia.</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => setShowUploadDialog(true)}
              className="orbit-button bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 px-6 py-3"
            >
              <Upload className="w-5 h-5 mr-2" />
              Upload Report
            </Button>
            <Button
              onClick={handleScan}
              disabled={isScanning}
              className="orbit-button bg-gradient-to-r from-orange-500 to-amber-500 text-white border-0 px-6 py-3"
            >
              {isScanning ? (
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              ) : (
                <Sparkles className="w-5 h-5 mr-2" />
              )}
              {isScanning ? 'Scanning...' : 'Scan for New Reports'}
            </Button>
          </div>
        </div>

        <ManualReportUpload 
          isOpen={showUploadDialog}
          onClose={() => setShowUploadDialog(false)}
          onSuccess={loadData}
        />

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6 bg-gray-800/50">
            <TabsTrigger 
              value="map" 
              className="data-[state=active]:bg-orange-500 data-[state=active]:text-white flex items-center gap-2"
            >
              <Building className="w-4 h-4" />
              Australia Map
            </TabsTrigger>
            <TabsTrigger 
              value="current" 
              className="data-[state=active]:bg-orange-500 data-[state=active]:text-white flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              Current Reports
            </TabsTrigger>
            <TabsTrigger 
              value="trends" 
              className="data-[state=active]:bg-orange-500 data-[state=active]:text-white flex items-center gap-2"
            >
              <History className="w-4 h-4" />
              Historical Trends
            </TabsTrigger>
            <TabsTrigger 
              value="state-detail" 
              disabled={!selectedStateData}
              className="data-[state=active]:bg-orange-500 data-[state=active]:text-white flex items-center gap-2 disabled:opacity-50"
            >
              <TrendingUp className="w-4 h-4" />
              {selectedStateName || 'State Detail'}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="map" className="space-y-6">
            {loading ? (
              <div className="text-center p-8">
                <Loader2 className="w-8 h-8 animate-spin text-orange-400 mx-auto" />
                <p className="text-gray-300 mt-2">Loading market data...</p>
              </div>
            ) : (
              <div className="orbit-card p-8">
                <div className="text-center mb-6">
                  <h2 className="text-xl font-bold text-white mb-2">Australian Commercial Real Estate Markets</h2>
                  <p className="text-gray-300">Click on any state to view consolidated market intelligence</p>
                </div>
                <AustraliaMap reports={reports} onStateSelect={handleStateSelect} />
                <div className="mt-8 text-center">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
                    <div className="orbit-card p-4">
                      <p className="text-2xl font-bold text-white">{reports.length}</p>
                      <p className="text-sm text-gray-400">Total Reports</p>
                    </div>
                    <div className="orbit-card p-4">
                      <p className="text-2xl font-bold text-white">{uniqueMarkets.length}</p>
                      <p className="text-sm text-gray-400">Markets</p>
                    </div>
                    <div className="orbit-card p-4">
                      <p className="text-2xl font-bold text-white">{uniqueSources.length}</p>
                      <p className="text-sm text-gray-400">Sources</p>
                    </div>
                    <div className="orbit-card p-4">
                      <p className="text-2xl font-bold text-white">{getLatestYear()}</p>
                      <p className="text-sm text-gray-400">Latest Year</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="state-detail">
            <StateMarketView 
              stateName={selectedStateName}
              stateData={selectedStateData}
              onBack={handleBackToMap}
            />
          </TabsContent>

          <TabsContent value="current" className="space-y-6">
            <div className="orbit-card p-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Select value={filters.state} onValueChange={(v) => setFilters(prev => ({...prev, state: v}))}>
                  <SelectTrigger className="orbit-input text-white h-12">
                    <SelectValue placeholder="All States" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All States</SelectItem>
                    <SelectItem value="National">National Reports</SelectItem>
                    {states.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Select value={filters.sector} onValueChange={(v) => setFilters(prev => ({...prev, sector: v}))}>
                  <SelectTrigger className="orbit-input text-white h-12">
                    <SelectValue placeholder="All Sectors" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sectors</SelectItem>
                    {sectors.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {loading ? (
              <div className="text-center p-8">
                <Loader2 className="w-8 h-8 animate-spin text-orange-400 mx-auto" />
              </div>
            ) : (
              <DragDropContext onDragEnd={onDragEnd}>
                <div className="space-y-8">
                  <div>
                    <h2 className="text-2xl font-bold text-white mb-4 border-b-2 border-orange-500/50 pb-2">
                      National Reports
                    </h2>
                    <Droppable droppableId="national-reports" direction="horizontal">
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.droppableProps}
                          className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4 rounded-lg transition-colors min-h-[200px] ${
                            snapshot.isDraggingOver ? 'bg-blue-500/10 border-2 border-blue-500/30' : 'bg-gray-800/20'
                          }`}
                        >
                          {nationalReports.map((report, index) => (
                            <Draggable key={report.id} draggableId={report.id} index={index}>
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  className={`transition-all ${snapshot.isDragging ? 'rotate-2 scale-105' : ''}`}
                                >
                                  <ReportCard report={report} onDelete={handleDelete} />
                                </div>
                              )}
                            </Draggable>
                          ))}
                          {provided.placeholder}
                        </div>
                      )}
                    </Droppable>
                  </div>

                  {Object.keys(groupedByState).sort().map(state => {
                    const stateReportsData = groupedByState[state];
                    const officeReports = stateReportsData.filter(r => r.sector === 'Office');
                    const industrialReports = stateReportsData.filter(r => r.sector === 'Industrial');

                    return (
                      <div key={state}>
                        <h2 className="text-2xl font-bold text-white mb-6 border-b-2 border-orange-500/50 pb-2">
                          {state}
                        </h2>
                        
                        <div className="grid lg:grid-cols-2 gap-6">
                          <div>
                            <div className="flex items-center gap-2 mb-4">
                              <div className="w-3 h-3 rounded-full bg-green-500"></div>
                              <h3 className="text-lg font-semibold text-white">Office</h3>
                            </div>
                            <Droppable droppableId={`state-${state}-Office`}>
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.droppableProps}
                                  className={`min-h-[200px] p-4 rounded-lg border-2 border-dashed transition-colors ${
                                    snapshot.isDraggingOver 
                                      ? 'border-green-500/50 bg-green-500/10' 
                                      : 'border-gray-600/50 bg-gray-800/20'
                                  }`}
                                >
                                  <div className="space-y-4">
                                    {officeReports.map((report, index) => (
                                      <Draggable key={report.id} draggableId={report.id} index={index}>
                                        {(provided, snapshot) => (
                                          <div
                                            ref={provided.innerRef}
                                            {...provided.draggableProps}
                                            {...provided.dragHandleProps}
                                            className={`transition-all ${snapshot.isDragging ? 'rotate-1 scale-105 z-10' : ''}`}
                                          >
                                            <ReportCard report={report} onDelete={handleDelete} />
                                          </div>
                                        )}
                                      </Draggable>
                                    ))}
                                  </div>
                                  {provided.placeholder}
                                </div>
                              )}
                            </Droppable>
                          </div>

                          <div>
                            <div className="flex items-center gap-2 mb-4">
                              <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                              <h3 className="text-lg font-semibold text-white">Industrial</h3>
                            </div>
                            <Droppable droppableId={`state-${state}-Industrial`}>
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.droppableProps}
                                  className={`min-h-[200px] p-4 rounded-lg border-2 border-dashed transition-colors ${
                                    snapshot.isDraggingOver 
                                      ? 'border-yellow-500/50 bg-yellow-500/10' 
                                      : 'border-gray-600/50 bg-gray-800/20'
                                  }`}
                                >
                                  <div className="space-y-4">
                                    {industrialReports.map((report, index) => (
                                      <Draggable key={report.id} draggableId={report.id} index={index}>
                                        {(provided, snapshot) => (
                                          <div
                                            ref={provided.innerRef}
                                            {...provided.draggableProps}
                                            {...provided.dragHandleProps}
                                            className={`transition-all ${snapshot.isDragging ? 'rotate-1 scale-105 z-10' : ''}`}
                                          >
                                            <ReportCard report={report} onDelete={handleDelete} />
                                          </div>
                                        )}
                                      </Draggable>
                                    ))}
                                  </div>
                                  {provided.placeholder}
                                </div>
                              )}
                            </Droppable>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </DragDropContext>
            )}
          </TabsContent>

          <TabsContent value="trends">
            <HistoricalTrends />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

const ReportCard = ({ report, onDelete }) => {
  const OutlookIndicator = ({ outlook }) => {
    const styles = {
      Positive: "bg-green-500",
      Stable: "bg-blue-500",
      Cautious: "bg-yellow-500",
      Negative: "bg-red-500"
    };
    return <div className={`w-3 h-3 rounded-full ${styles[outlook] || 'bg-gray-500'}`} title={`Outlook: ${outlook}`}></div>;
  };

  const StatItem = ({ label, value, unit }) => (
    <div className="bg-gray-700/50 p-2 rounded-lg text-center">
      <p className="text-xs text-gray-400 truncate">{label}</p>
      <p className="font-bold text-white text-sm">
        {value === null || value === undefined ? '-' : `${value}${unit}`}
      </p>
    </div>
  );

  const formatDate = (dateString) => {
    if (!dateString || isNaN(new Date(dateString).getTime())) {
        return 'N/A';
    }
    return new Date(dateString).toLocaleDateString('en-AU', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
  };

  const getSectorColor = (sector) => {
    switch(sector) {
      case 'Office': return 'bg-green-500';
      case 'Industrial': return 'bg-yellow-500';
      case 'Retail': return 'bg-purple-500';
      case 'Mixed Use': return 'bg-teal-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="bg-gray-800/50 p-4 rounded-xl flex flex-col h-full border border-gray-700/50 hover:border-gray-600/50 transition-colors cursor-move">
      <div className="flex justify-between items-start mb-3">
        <h4 className="text-lg font-bold text-white flex-grow pr-2 leading-tight">{report.report_title}</h4>
        <div className="flex items-center gap-2 flex-shrink-0">
          <OutlookIndicator outlook={report.market_outlook} />
          <div className={`w-3 h-3 rounded-full ${getSectorColor(report.sector)}`} title={report.sector}></div>
          <div className="px-2 py-0.5 rounded-full text-xs font-medium bg-gray-700 text-gray-200">{report.sector}</div>
          <Button
            variant="ghost"
            size="icon"
            className="text-gray-500 hover:text-red-400 hover:bg-red-500/10 w-7 h-7 rounded-full"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(report);
            }}
            title="Delete Report"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="text-xs text-gray-400 mb-4 space-y-1">
          <p><strong>Author:</strong> {_.startCase(report.report_source)}</p>
          <p><strong>Published:</strong> {formatDate(report.report_date)}</p>
      </div>
      
      <div className="space-y-3 mb-4 flex-grow">
        <div>
          <p className="text-sm font-semibold text-gray-300 mb-2">Vacancy</p>
          <div className="grid grid-cols-3 gap-2">
            <StatItem label="Total" value={report.vacancy_data?.total_vacancy_percent} unit="%" />
            <StatItem label="Prime" value={report.vacancy_data?.prime_vacancy_percent} unit="%" />
            <StatItem label="Secondary" value={report.vacancy_data?.secondary_vacancy_percent} unit="%" />
          </div>
        </div>
        <div>
          <p className="text-sm font-semibold text-gray-300 mb-2">Net Face Rents</p>
          <div className="grid grid-cols-2 gap-2">
            <StatItem label="Prime" value={report.rent_data?.prime_rent_sqm} unit="/sqm" />
            <StatItem label="Secondary" value={report.rent_data?.secondary_rent_sqm} unit="/sqm" />
          </div>
        </div>
        <div>
          <p className="text-sm font-semibold text-gray-300 mb-2">Incentives</p>
          <div className="grid grid-cols-2 gap-2">
            <StatItem label="Prime" value={report.incentive_data?.prime_incentive_percent} unit="%" />
            <StatItem label="Secondary" value={report.incentive_data?.secondary_incentive_percent} unit="%" />
          </div>
        </div>
      </div>

      {report.report_url && (
        <a href={report.report_url} target="_blank" rel="noopener noreferrer" className="mt-auto" onClick={(e) => e.stopPropagation()}>
          <Button variant="outline" className="w-full orbit-button bg-white border-gray-300 text-black hover:bg-gray-100 text-sm py-2">
              <ExternalLink className="w-3 h-3 mr-2" /> Read Report
          </Button>
        </a>
      )}
    </div>
  );
};