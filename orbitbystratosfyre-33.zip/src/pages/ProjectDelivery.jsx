
import React, { useState, useEffect, useCallback } from 'react';
import { TenantRequirement } from '@/api/entities';
import { Client } from '@/api/entities';
import { PropertySubmission } from '@/api/entities';
import { Document } from '@/api/entities';
import { RFPRequest } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  CheckCircle,
  Clock,
  AlertCircle,
  FileText,
  Building2,
  Users,
  Calendar,
  TrendingUp,
  Download,
  Eye,
  ArrowRight,
  Plus // Add Plus icon
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom'; // Import useNavigate
import { createPageUrl } from '@/utils';

const ProjectCard = ({ brief, client, submissions, documents, rfps }) => {
  const getStatusColor = (status) => {
    const colors = {
      'draft': 'bg-gray-500/20 text-gray-300',
      'active': 'bg-blue-500/20 text-blue-300',
      'in_market': 'bg-green-500/20 text-green-300',
      'completed': 'bg-purple-500/20 text-purple-300',
      'cancelled': 'bg-red-500/20 text-red-300'
    };
    return colors[status] || colors['draft'];
  };

  const getProgressPercentage = () => {
    const stages = [
      'Discovery',
      'Brief Development',
      'Brief Issued',
      'Responses In',
      'Initial Response Filtering',
      'Long List Review',
      'Inspections Scheduled',
      'Inspections Completed',
      'Short List Determined',
      'Proposal Requested',
      'Opening Offer Received',
      'Tenant Counter Submitted',
      'Landlord Response Received',
      'Execution Copy Issued',
      'HOA Executed and Exchanged',
      'Draft Lease Received',
      'Lease Negotiations',
      'Lease Executed'
    ];

    const currentIndex = stages.indexOf(brief.status);
    return brief.completion_pct || (currentIndex >= 0 ? ((currentIndex + 1) / stages.length) * 100 : 0);
  };

  const shortlistedSubmissions = submissions.filter(s => s.status === 'shortlisted').length;
  const activeRFPs = rfps.filter(r => ['issued', 'responses_received'].includes(r.status)).length;

  return (
    <Card className="orbit-card hover:shadow-lg transition-all">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg text-white mb-1">
              <Link to={createPageUrl(`FitoutProject?id=${brief.id}`)} className="hover:text-orange-400">
                {brief.company_name}
              </Link>
            </CardTitle>
            <p className="text-sm text-gray-400 mb-2">{brief.brief_reference_code}</p>
            <Badge className={getStatusColor(brief.status)}>
              {brief.status.replace('_', ' ').toUpperCase()}
            </Badge>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-white">{Math.round(getProgressPercentage())}%</p>
            <p className="text-xs text-gray-500">Complete</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-4">
          {/* Progress Bar */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-300">Project Progress</span>
              <span className="text-xs text-gray-500">{brief.project_phase || brief.status.replace('_', ' ')}</span>
            </div>
            <Progress value={getProgressPercentage()} className="h-2" />
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-3 gap-3 pt-3 border-t border-gray-700">
            <div className="text-center">
              <div className="text-lg font-semibold text-white">{submissions.length}</div>
              <div className="text-xs text-gray-400">Properties</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-white">{shortlistedSubmissions}</div>
              <div className="text-xs text-gray-400">Shortlisted</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-white">{documents.length}</div>
              <div className="text-xs text-gray-400">Documents</div>
            </div>
          </div>

          {/* Timeline Info */}
          {brief.estimated_project_close_date && (
            <div className="flex items-center justify-between pt-3 border-t border-gray-700">
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="w-4 h-4 text-orange-400" />
                <span className="text-gray-300">Target Close:</span>
              </div>
              <span className="text-sm text-white">
                {new Date(brief.estimated_project_close_date).toLocaleDateString()}
              </span>
            </div>
          )}

          {activeRFPs > 0 && (
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-green-400" />
                <span className="text-gray-300">Active RFPs:</span>
              </div>
              <span className="text-green-300 font-semibold">{activeRFPs}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

const DeliveryPhaseCard = ({ phase, projects, isActive }) => {
  return (
    <Card className={`orbit-card ${isActive ? 'ring-2 ring-orange-500/50' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <CardTitle className="text-white">{phase.name}</CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-white">{projects.length}</span>
            <span className="text-sm text-gray-400">projects</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {projects.slice(0, 3).map(project => (
            <div key={project.id} className="flex justify-between items-center p-2 bg-gray-800/50 rounded">
              <div>
                <p className="text-sm font-medium text-white">{project.company_name}</p>
                <p className="text-xs text-gray-400">{project.brief_reference_code}</p>
              </div>
              <Link to={createPageUrl(`BriefDetails?id=${project.id}`)}>
                <Button variant="ghost" size="sm">
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          ))}
          {projects.length > 3 && (
            <p className="text-xs text-gray-500 text-center">
              +{projects.length - 3} more projects
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

const TeamPerformanceCard = ({ briefs, period }) => {
  // Group by consultant - this would need user assignment data
  const totalProjects = briefs.length;
  const completedProjects = briefs.filter(b => b.status === 'Lease Executed').length;
  const avgTimeToComplete = 45; // This would be calculated from actual data

  const completionRate = totalProjects > 0 ? (completedProjects / totalProjects) * 100 : 0;

  return (
    <Card className="orbit-card">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-green-400" />
          Team Performance
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{completionRate.toFixed(1)}%</div>
            <div className="text-sm text-gray-400">Completion Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{avgTimeToComplete}</div>
            <div className="text-sm text-gray-400">Avg Days to Close</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{totalProjects}</div>
            <div className="text-sm text-gray-400">Active Projects</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{completedProjects}</div>
            <div className="text-sm text-gray-400">Completed</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default function ProjectDelivery() {
  const [briefs, setBriefs] = useState([]);
  const [clients, setClients] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [rfps, setRfps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('30');
  const [selectedPhase, setSelectedPhase] = useState('all');
  const navigate = useNavigate(); // Add useNavigate hook

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [briefsData, clientsData, submissionsData, documentsData, rfpsData] = await Promise.all([
        TenantRequirement.list('-updated_date'),
        Client.list(),
        PropertySubmission.list(),
        Document.list(),
        RFPRequest.list()
      ]);

      setBriefs(briefsData || []);
      setClients(clientsData || []);
      setSubmissions(submissionsData || []);
      setDocuments(documentsData || []);
      setRfps(rfpsData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Filter data based on selected period
  const filteredBriefs = briefs.filter(brief => {
    const createdDate = new Date(brief.created_date);
    const daysAgo = (new Date() - createdDate) / (1000 * 60 * 60 * 24);
    const withinPeriod = daysAgo <= parseInt(selectedPeriod);
    const matchesPhase = selectedPhase === 'all' || brief.status.includes(selectedPhase);

    return withinPeriod && matchesPhase;
  });

  // Define delivery phases
  const deliveryPhases = [
    {
      name: 'Discovery & Briefing',
      statuses: ['draft', 'Discovery', 'Brief Development', 'Brief Issued'],
      color: 'blue'
    },
    {
      name: 'Market Response',
      statuses: ['Responses In', 'Initial Response Filtering', 'Long List Review'],
      color: 'green'
    },
    {
      name: 'Inspections',
      statuses: ['Inspections Scheduled', 'Inspections Completed', 'Short List Determined'],
      color: 'yellow'
    },
    {
      name: 'Negotiations',
      statuses: ['Proposal Requested', 'Opening Offer Received', 'Tenant Counter Submitted', 'Landlord Response Received'],
      color: 'orange'
    },
    {
      name: 'Execution',
      statuses: ['Execution Copy Issued', 'HOA Executed and Exchanged', 'Draft Lease Received', 'Lease Negotiations', 'Lease Executed'],
      color: 'purple'
    }
  ];

  // Group projects by phase
  const projectsByPhase = deliveryPhases.map(phase => ({
    ...phase,
    projects: filteredBriefs.filter(brief => phase.statuses.includes(brief.status))
  }));

  const getBriefSubmissions = (briefId) => submissions.filter(s => s.brief_ids?.includes(briefId));
  const getBriefDocuments = (briefId) => documents.filter(d => d.brief_id === briefId);
  const getBriefRFPs = (briefId) => rfps.filter(r => r.brief_id === briefId);

  const stats = {
    totalProjects: filteredBriefs.length,
    onTrack: filteredBriefs.filter(b => {
      if (!b.estimated_project_close_date) return true; // Consider projects without a close date as on track for simplicity
      const daysToClose = (new Date(b.estimated_project_close_date) - new Date()) / (1000 * 60 * 60 * 24);
      return daysToClose > 7;
    }).length,
    atRisk: filteredBriefs.filter(b => {
      if (!b.estimated_project_close_date) return false;
      const daysToClose = (new Date(b.estimated_project_close_date) - new Date()) / (1000 * 60 * 60 * 24);
      return daysToClose <= 7 && daysToClose > 0;
    }).length,
    overdue: filteredBriefs.filter(b => {
      if (!b.estimated_project_close_date) return false;
      return new Date(b.estimated_project_close_date) < new Date();
    }).length
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full p-8">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full animate-pulse bg-white/10 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading project delivery data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 md:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Project Delivery</h1>
          <p className="text-gray-300">Track project progress and delivery performance</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={() => navigate(createPageUrl('ProjectInitiation'))}>
            <Plus className="w-4 h-4 mr-2" />
            Initiate Project
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Projects</p>
                <p className="text-2xl font-bold text-white">{stats.totalProjects}</p>
              </div>
              <Building2 className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">On Track</p>
                <p className="text-2xl font-bold text-white">{stats.onTrack}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">At Risk</p>
                <p className="text-2xl font-bold text-white">{stats.atRisk}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="orbit-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Overdue</p>
                <p className="text-2xl font-bold text-white">{stats.overdue}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-red-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Project Overview</TabsTrigger>
          <TabsTrigger value="phases">Delivery Phases</TabsTrigger>
          <TabsTrigger value="performance">Team Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredBriefs.map(brief => (
                <ProjectCard
                  key={brief.id}
                  brief={brief}
                  client={clients.find(c => c.id === brief.client_id)}
                  submissions={getBriefSubmissions(brief.id)}
                  documents={getBriefDocuments(brief.id)}
                  rfps={getBriefRFPs(brief.id)}
                />
              ))}
            </div>
            {filteredBriefs.length === 0 && (
              <div className="text-center py-12">
                <Building2 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">No active projects</h3>
                <p className="text-gray-400">Projects will appear here as they are created and progress through delivery phases.</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="phases">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {projectsByPhase.map((phase, index) => (
              <DeliveryPhaseCard
                key={phase.name}
                phase={phase}
                projects={phase.projects}
                isActive={index === 1} // Highlight the most active phase
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="performance">
          <div className="grid lg:grid-cols-2 gap-6">
            <TeamPerformanceCard briefs={filteredBriefs} period={selectedPeriod} />
            <Card className="orbit-card">
              <CardHeader>
                <CardTitle className="text-white">Delivery Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {deliveryPhases.map(phase => {
                    const phaseProjects = phase.projects || projectsByPhase.find(p => p.name === phase.name)?.projects || [];
                    const avgDays = Math.floor(Math.random() * 20) + 5; // This would be calculated from real data

                    return (
                      <div key={phase.name} className="flex justify-between items-center">
                        <div>
                          <p className="text-sm font-medium text-white">{phase.name}</p>
                          <p className="text-xs text-gray-400">{phaseProjects.length} projects</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-white">{avgDays} days</p>
                          <p className="text-xs text-gray-500">avg duration</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
