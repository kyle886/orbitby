
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { PropertySubmission } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { Loader2, ArrowLeft, Building, User, FileText, CheckCircle, Edit, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from "@/components/ui/use-toast";
import { createPageUrl } from '@/utils';
import DueDiligencePanel from '@/components/deal/DueDiligencePanel';

export default function SubmissionDetails() {
  const [searchParams] = useSearchParams();
  const submissionId = searchParams.get('id');
  const navigate = useNavigate();
  const { toast } = useToast();

  const [submission, setSubmission] = useState(null);
  const [briefs, setBriefs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editableSubmission, setEditableSubmission] = useState(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const allSubmissions = await PropertySubmission.list();
      const submissionData = allSubmissions.find(s => s.id === submissionId);

      if (submissionData) {
        setSubmission(submissionData);
        setEditableSubmission(submissionData);

        if (submissionData.brief_ids && submissionData.brief_ids.length > 0) {
          const allBriefs = await TenantRequirement.list();
          const relatedBriefs = allBriefs.filter(b => submissionData.brief_ids.includes(b.id));
          setBriefs(relatedBriefs);
        }
      }
    } catch (error) {
      console.error("Error loading submission details:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load submission details.",
      });
    } finally {
      setLoading(false);
    }
  }, [submissionId, toast]);

  useEffect(() => {
    if (submissionId) {
      loadData();
    }
  }, [submissionId, loadData]);

  const handleInputChange = (field, value) => {
    setEditableSubmission(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    try {
      // Ensure required fields aren't accidentally cleared
      const payload = { ...editableSubmission };
       if (!payload.street_address && payload.address) {
        payload.street_address = payload.address;
      }
      
      await PropertySubmission.update(submissionId, payload);
      toast({
        title: "Success!",
        description: "Submission details have been updated.",
        action: <CheckCircle className="text-green-500" />,
      });
      setIsEditing(false);
      loadData(); // Reload data to show changes
    } catch (error) {
      console.error("Error updating submission:", error);
      toast({
        variant: "destructive",
        title: "Update Failed",
        description: "Could not save the changes. Please try again.",
      });
    }
  };

  const handleCancel = () => {
    setEditableSubmission(submission); // Reset changes
    setIsEditing(false);
  };
  
  const getStatusPill = (status) => {
    const styles = {
      submitted: "bg-gray-600 text-gray-100",
      under_review: "bg-blue-600 text-blue-100",
      shortlisted: "bg-yellow-600 text-yellow-100",
      rejected: "bg-red-600 text-red-100",
      in_negotiation: "bg-purple-600 text-purple-100",
      selected: "bg-green-600 text-green-100",
    };
    return (
      <Badge className={`${styles[status] || styles.submitted}`}>
        {status?.replace('_', ' ').toUpperCase()}
      </Badge>
    );
  };

  if (loading) return <div className="p-8 text-center"><Loader2 className="h-12 w-12 animate-spin text-orange-400 mx-auto" /></div>;
  if (!submission) return <div className="p-8 text-center text-white">Submission not found.</div>;
  
  const dataToShow = isEditing ? editableSubmission : submission;

  return (
    <div className="p-4 sm:p-6 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
           <Button 
            variant="outline" 
            className="orbit-button text-gray-300 border-gray-600 hover:bg-gray-800"
            onClick={() => navigate(createPageUrl('SubmissionManagement'))}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Submissions
          </Button>
          
          <div>
            {!isEditing ? (
              <Button onClick={() => setIsEditing(true)} className="orbit-button-active">
                <Edit className="w-4 h-4 mr-2" /> Edit Submission
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button onClick={handleCancel} variant="outline" className="orbit-button text-gray-300 border-gray-600 hover:bg-gray-800">
                  <X className="w-4 h-4 mr-2" /> Cancel
                </Button>
                <Button onClick={handleSave} className="orbit-button bg-green-600 hover:bg-green-700 text-white">
                  <Save className="w-4 h-4 mr-2" /> Save Changes
                </Button>
              </div>
            )}
          </div>
        </div>
      
        <div className="orbit-card p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row justify-between items-start mb-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-white">{dataToShow.property_title}</h1>
              <p className="text-gray-400 mt-1">{dataToShow.address}</p>
            </div>
            {getStatusPill(dataToShow.status)}
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 mt-6">
            {/* Property Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2"><Building className="w-5 h-5 text-orange-400"/> Property Details</h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2">
                  <Label className="text-gray-400">Floor Area</Label>
                  {isEditing ? <Input value={editableSubmission.floor_area_sqm} onChange={e => handleInputChange('floor_area_sqm', e.target.value)} className="orbit-input" /> : <span className="text-white">{dataToShow.floor_area_sqm} sqm</span>}
                </div>
                <div className="grid grid-cols-2">
                  <Label className="text-gray-400">Rental Rate</Label>
                  {isEditing ? <Input value={editableSubmission.rental_rate_sqm} onChange={e => handleInputChange('rental_rate_sqm', e.target.value)} className="orbit-input" /> : <span className="text-white">${dataToShow.rental_rate_sqm}/sqm</span>}
                </div>
                <div className="grid grid-cols-2">
                  <Label className="text-gray-400">Parking</Label>
                  {isEditing ? <Input value={editableSubmission.parking_spaces} onChange={e => handleInputChange('parking_spaces', e.target.value)} className="orbit-input" /> : <span className="text-white">{dataToShow.parking_spaces || 'N/A'} spaces</span>}
                </div>
                <div className="grid grid-cols-2">
                  <Label className="text-gray-400">Building Grade</Label>
                  {isEditing ? <Input value={editableSubmission.building_grade} onChange={e => handleInputChange('building_grade', e.target.value)} className="orbit-input" /> : <span className="text-white">{dataToShow.building_grade || 'N/A'}</span>}
                </div>
                <div className="grid grid-cols-2">
                  <Label className="text-gray-400">Available</Label>
                  {isEditing ? <Input type="date" value={editableSubmission.availability_date?.split('T')[0] || ''} onChange={e => handleInputChange('availability_date', e.target.value)} className="orbit-input" /> : <span className="text-white">{dataToShow.availability_date ? new Date(dataToShow.availability_date).toLocaleDateString() : 'Now'}</span>}
                </div>
              </div>
            </div>

            {/* Agent Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2"><User className="w-5 h-5 text-orange-400"/> Agent Details</h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2">
                  <Label className="text-gray-400">Name</Label>
                  {isEditing ? <Input value={editableSubmission.agent_name} onChange={e => handleInputChange('agent_name', e.target.value)} className="orbit-input" /> : <span className="text-white">{dataToShow.agent_name || 'Not specified'}</span>}
                </div>
                <div className="grid grid-cols-2">
                  <Label className="text-gray-400">Company</Label>
                  {isEditing ? <Input value={editableSubmission.agent_company} onChange={e => handleInputChange('agent_company', e.target.value)} className="orbit-input" /> : <span className="text-white">{dataToShow.agent_company || 'Not specified'}</span>}
                </div>
                <div className="grid grid-cols-2">
                  <Label className="text-gray-400">Email</Label>
                  {isEditing ? <Input type="email" value={editableSubmission.agent_email} onChange={e => handleInputChange('agent_email', e.target.value)} className="orbit-input" /> : <span className="text-white">{dataToShow.agent_email || 'Not specified'}</span>}
                </div>
                <div className="grid grid-cols-2">
                  <Label className="text-gray-400">Phone</Label>
                  {isEditing ? <Input value={editableSubmission.agent_phone} onChange={e => handleInputChange('agent_phone', e.target.value)} className="orbit-input" /> : <span className="text-white">{dataToShow.agent_phone || 'Not specified'}</span>}
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-8 pt-8 space-y-6">
             <h3 className="text-lg font-semibold text-white flex items-center gap-2"><FileText className="w-5 h-5 text-orange-400"/> Notes & Feedback</h3>
             <div>
                <Label className="text-gray-400 font-semibold mb-2 block">Stratosfyre Notes</Label>
                {isEditing ? <Textarea value={editableSubmission.amplifyre_notes} onChange={e => handleInputChange('amplifyre_notes', e.target.value)} className="orbit-input h-24" /> : <p className="text-white bg-gray-800/50 p-4 rounded-lg min-h-[4rem]">{dataToShow.amplifyre_notes || 'No notes yet.'}</p>}
             </div>
             <div>
                <Label className="text-gray-400 font-semibold mb-2 block">Client Feedback</Label>
                {isEditing ? <Textarea value={editableSubmission.client_feedback} onChange={e => handleInputChange('client_feedback', e.target.value)} className="orbit-input h-24" /> : <p className="text-white bg-gray-800/50 p-4 rounded-lg min-h-[4rem]">{dataToShow.client_feedback || 'No feedback yet.'}</p>}
             </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8">
            <h3 className="text-lg font-semibold text-white mb-4">Assigned Briefs</h3>
            {briefs.length > 0 ? (
              <div className="space-y-2">
                {briefs.map(brief => (
                  <div key={brief.id} className="p-3 bg-gray-800/50 rounded-lg">
                    <p className="font-semibold text-white">{brief.company_name}</p>
                    <p className="text-xs text-gray-400">{brief.brief_reference_code}</p>
                  </div>
                ))}
              </div>
            ) : <p className="text-gray-400">Not assigned to any briefs.</p>}
          </div>

        </div>
        
        {submission && (
          <div className="mt-8">
            <DueDiligencePanel dealId={submission.brief_ids?.[0]} buildingId={submission.building_id} />
          </div>
        )}

      </div>
    </div>
  );
}
