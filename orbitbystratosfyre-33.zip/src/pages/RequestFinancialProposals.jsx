
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { TenantRequirement } from '@/api/entities';
import { PropertySubmission } from '@/api/entities';
import { RFPRequest } from '@/api/entities';
import { Document } from '@/api/entities';
import { Loader2, FileText, Send, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from "@/components/ui/use-toast";
import { createPageUrl } from '@/utils';

export default function RequestFinancialProposals() {
    const [brief, setBrief] = useState(null);
    const [submissions, setSubmissions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [rfpData, setRfpData] = useState({
        terms: {
            lease_commencement_date: '',
            lease_term_years: '',
        },
        requested_supplementary_info: {
            floorplans: { enabled: true, as_built: true, proposed_fitout: true },
            tenancy_images: { enabled: true, as_built_images: true, proposed_renders: false },
            building_im: true,
            building_images: { enabled: true, lobby: true, eot_facilities: true },
            fitout_guide: false,
            esg_info: true,
        },
        response_deadline: '',
    });
    const location = useLocation();
    const navigate = useNavigate();
    const { toast } = useToast();

    useEffect(() => {
        const loadData = async () => {
            setLoading(true);
            const params = new URLSearchParams(location.search);
            const submissionIdsParam = params.get('submission_ids');
            
            console.log("URL search params:", location.search);
            console.log("submission_ids param:", submissionIdsParam);
            
            const submissionIds = submissionIdsParam ? submissionIdsParam.split(',').filter(Boolean) : [];
            
            console.log("Parsed submission IDs:", submissionIds);

            if (!submissionIds || submissionIds.length === 0) {
                console.log("No submission IDs found in URL");
                toast({
                    variant: "destructive",
                    title: "No Properties Selected",
                    description: "Please select properties before creating an RFP."
                });
                navigate(createPageUrl('SubmissionManagement'));
                return;
            }

            try {
                // Load submissions first
                console.log("Loading all submissions...");
                const allSubmissions = await PropertySubmission.list();
                console.log("Total submissions loaded:", allSubmissions?.length || 0);
                
                const selectedSubmissions = submissionIds
                    .map(id => {
                        const found = allSubmissions.find(s => s.id === id);
                        console.log(`Looking for submission ${id}:`, found ? 'Found' : 'Not found');
                        return found;
                    })
                    .filter(Boolean);
                
                console.log("Selected submissions found:", selectedSubmissions.length);
                setSubmissions(selectedSubmissions);

                if (selectedSubmissions.length === 0) {
                    throw new Error("No valid submissions found with the provided IDs");
                }

                // Get brief from first submission's brief_ids
                const firstSubmission = selectedSubmissions[0];
                console.log("First submission brief_ids:", firstSubmission.brief_ids);
                
                if (!firstSubmission.brief_ids || firstSubmission.brief_ids.length === 0) {
                    throw new Error("Selected submissions are not linked to any brief");
                }

                const briefId = firstSubmission.brief_ids[0];
                console.log("Looking for brief with ID:", briefId);
                
                const allBriefs = await TenantRequirement.list();
                console.log("Total briefs loaded:", allBriefs?.length || 0);
                
                const briefData = allBriefs.find(b => b.id === briefId);
                console.log("Brief found:", briefData ? briefData.company_name : 'Not found');
                
                if (!briefData) {
                    throw new Error(`Could not find brief with ID: ${briefId}`);
                }

                setBrief(briefData);

                // Pre-fill form from brief
                setRfpData(prev => ({
                    ...prev,
                    terms: {
                        lease_commencement_date: briefData.required_date || '',
                        lease_term_years: briefData.lease_term_years ? briefData.lease_term_years.toString() : '',
                    }
                }));

                console.log("RFP data loading completed successfully");

            } catch (error) {
                console.error("Error loading RFP data:", error);
                toast({
                    variant: "destructive",
                    title: "Loading Error",
                    description: error.message || "Failed to load RFP data. Please try again."
                });
            } finally {
                setLoading(false);
            }
        };
        loadData();
    }, [location.search, navigate, toast]);

    const handleInputChange = (section, field, value) => {
        setRfpData(prev => ({
            ...prev,
            [section]: { ...prev[section], [field]: value }
        }));
    };
    
    const handleCheckboxChange = (section, field, subfield, value) => {
        setRfpData(prev => ({
            ...prev,
            [section]: {
                ...prev[section],
                [field]: typeof prev[section][field] === 'object' 
                    ? { ...prev[section][field], [subfield]: value }
                    : value
            }
        }));
    };

    const handleSubmit = async () => {
        if (!brief) {
            toast({
                variant: "destructive",
                title: "Missing Brief",
                description: "Brief information is required to create an RFP."
            });
            return;
        }

        if (!brief.client_id) {
            toast({
                variant: "destructive",
                title: "Missing Client",
                description: "Brief must be associated with a client to create an RFP."
            });
            return;
        }

        setIsSubmitting(true);
        try {
            const payload = {
                brief_id: brief.id,
                client_id: brief.client_id,
                property_submissions: submissions.map(s => s.id),
                terms: {
                    lease_commencement_date: rfpData.terms.lease_commencement_date || null,
                    lease_term_years: rfpData.terms.lease_term_years ? parseFloat(rfpData.terms.lease_term_years) : null,
                },
                requested_supplementary_info: rfpData.requested_supplementary_info,
                response_deadline: rfpData.response_deadline || null,
                status: 'issued',
                issued_date: new Date().toISOString(),
            };

            console.log("Submitting RFP with payload:", payload);
            
            const newRFP = await RFPRequest.create(payload);
            
            // Create a document record for this RFP
            await Document.create({
                client_id: brief.client_id,
                brief_id: brief.id,
                rfp_id: newRFP.id,
                document_name: `RFP for ${brief.company_name} - ${new Date().toLocaleDateString()}`,
                document_type: 'lease_proposal',
                document_topic: 'Financial Analysis',
                file_url: 'generated_in_system',
                uploaded_by: 'system',
                is_client_visible: false,
                description: `Request for Proposal issued to ${submissions.length} properties.`,
            });
            
            toast({ 
                title: "RFP Issued Successfully!", 
                description: "Agents have been notified to submit their proposals." 
            });
            navigate(createPageUrl(`BriefDetails?id=${brief.id}`));

        } catch (error) {
            console.error("Error creating RFP:", error);
            toast({ 
                variant: "destructive", 
                title: "RFP Creation Failed",
                description: error.message || "Please try again or contact support."
            });
        } finally {
            setIsSubmitting(false);
        }
    };

    if (loading) return (
        <div className="flex items-center justify-center h-screen">
            <Loader2 className="w-12 h-12 animate-spin text-orange-400" />
        </div>
    );

    if (!brief) {
        return (
            <div className="p-8 min-h-screen">
                <div className="max-w-4xl mx-auto">
                    <div className="orbit-card p-12 text-center">
                        <h3 className="text-xl font-medium text-white mb-2">Unable to Load Brief</h3>
                        <p className="text-gray-400 mb-4">
                            The selected properties are not properly linked to a client brief.
                        </p>
                        <Button onClick={() => navigate(createPageUrl('SubmissionManagement'))}>
                            Return to Submissions
                        </Button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="p-8 min-h-screen">
            <div className="max-w-4xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-white mb-2">Request for Financial Proposals (RFP)</h1>
                    <p className="text-gray-300">
                        For brief: <span className="font-semibold text-amber-400">
                            {brief.brief_reference_code} - {brief.company_name}
                        </span>
                    </p>
                </div>

                <div className="space-y-6">
                    {/* Included Properties */}
                    <div className="orbit-card p-6">
                        <h3 className="text-lg font-semibold text-white mb-4">Included Properties ({submissions.length})</h3>
                        <div className="space-y-3">
                            {submissions.map(s => (
                                <div key={s.id} className="p-4 bg-gray-800/50 rounded-lg">
                                    <p className="font-semibold text-white">{s.property_title}</p>
                                    <p className="text-sm text-gray-400">{s.address || s.street_address}</p>
                                    <div className="flex gap-4 mt-2 text-xs text-gray-500">
                                        <span>{s.floor_area_sqm} sqm</span>
                                        <span>${s.rental_rate_sqm}/sqm</span>
                                        <span>{s.agent_company}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Commercial Terms */}
                    <div className="orbit-card p-6">
                        <h3 className="text-lg font-semibold text-white mb-4">Proposed Commercial Terms</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <Label>Lease Commencement Date</Label>
                                <Input 
                                    type="date" 
                                    value={rfpData.terms.lease_commencement_date} 
                                    onChange={e => handleInputChange('terms', 'lease_commencement_date', e.target.value)} 
                                    className="orbit-input"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Lease Term (Years)</Label>
                                <Input 
                                    type="number" 
                                    step="0.5"
                                    value={rfpData.terms.lease_term_years} 
                                    onChange={e => handleInputChange('terms', 'lease_term_years', e.target.value)} 
                                    className="orbit-input"
                                    placeholder="e.g. 5"
                                />
                            </div>
                            <div className="space-y-2 md:col-span-2">
                                <Label>Response Deadline</Label>
                                <Input 
                                    type="date" 
                                    value={rfpData.response_deadline} 
                                    onChange={e => setRfpData({...rfpData, response_deadline: e.target.value})} 
                                    className="orbit-input"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Supplementary Info */}
                    <div className="orbit-card p-6">
                        <h3 className="text-lg font-semibold text-white mb-4">Requested Supplementary Information</h3>
                        <div className="space-y-4">
                            <div className="flex items-center gap-4 p-3 rounded-lg bg-gray-800/50">
                               <Checkbox 
                                   id="building_im" 
                                   checked={rfpData.requested_supplementary_info.building_im} 
                                   onCheckedChange={c => handleCheckboxChange('requested_supplementary_info', 'building_im', null, c)} 
                               />
                               <Label htmlFor="building_im">Building Information Memorandum</Label>
                            </div>
                            <div className="flex items-center gap-4 p-3 rounded-lg bg-gray-800/50">
                               <Checkbox 
                                   id="esg_info" 
                                   checked={rfpData.requested_supplementary_info.esg_info} 
                                   onCheckedChange={c => handleCheckboxChange('requested_supplementary_info', 'esg_info', null, c)} 
                               />
                               <Label htmlFor="esg_info">Building ESG Information</Label>
                            </div>
                             <div className="p-3 rounded-lg bg-gray-800/50">
                                <div className="flex items-center gap-4">
                                   <Checkbox 
                                       id="floorplans" 
                                       checked={rfpData.requested_supplementary_info.floorplans.enabled} 
                                       onCheckedChange={c => handleCheckboxChange('requested_supplementary_info', 'floorplans', 'enabled', c)} 
                                   />
                                   <Label htmlFor="floorplans">Floorplans</Label>
                                </div>
                                {rfpData.requested_supplementary_info.floorplans.enabled && (
                                    <div className="pl-8 mt-2 space-y-2">
                                        <div className="flex items-center gap-3">
                                            <Checkbox 
                                                id="fp_asbuilt" 
                                                checked={rfpData.requested_supplementary_info.floorplans.as_built} 
                                                onCheckedChange={c => handleCheckboxChange('requested_supplementary_info', 'floorplans', 'as_built', c)}
                                            />
                                            <Label htmlFor="fp_asbuilt" className="font-normal">As-Built Plans</Label>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <Checkbox 
                                                id="fp_proposed" 
                                                checked={rfpData.requested_supplementary_info.floorplans.proposed_fitout} 
                                                onCheckedChange={c => handleCheckboxChange('requested_supplementary_info', 'floorplans', 'proposed_fitout', c)}
                                            />
                                            <Label htmlFor="fp_proposed" className="font-normal">Proposed Fitout Plans</Label>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end">
                        <Button onClick={handleSubmit} disabled={isSubmitting} className="orbit-button-active text-lg py-3 px-8">
                            {isSubmitting ? <Loader2 className="animate-spin" /> : <><Send className="w-5 h-5 mr-2" /> Issue RFP</>}
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}
