import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { DebtFacility } from '@/api/entities';
import { CapitalOpportunity } from '@/api/entities';
import { Lender } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';

export default function CreateDebtFacility() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [opportunities, setOpportunities] = useState([]);
  const [lenders, setLenders] = useState([]);
  const [formData, setFormData] = useState({
    opportunity_id: '',
    lender_id: '',
    amount_aud: '',
    rate_pct: '',
    status: 'drafting',
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [opps, allLenders] = await Promise.all([
          CapitalOpportunity.list(),
          Lender.list()
        ]);
        setOpportunities(opps || []);
        setLenders(allLenders || []);
      } catch (error) {
        toast({ variant: 'destructive', title: 'Error', description: 'Failed to load opportunities and lenders.' });
      }
    };
    fetchData();
  }, [toast]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await DebtFacility.create({
        ...formData,
        amount_aud: parseFloat(formData.amount_aud),
        rate_pct: parseFloat(formData.rate_pct),
      });
      toast({ title: 'Success', description: 'Debt facility created.' });
      navigate(-1);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-2xl mx-auto">
      <Card className="orbit-card">
        <CardHeader>
          <CardTitle className="text-white">Add New Debt Facility / Offer</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label htmlFor="opportunity_id" className="block text-sm font-medium text-gray-300 mb-2">Capital Opportunity</label>
                <Select name="opportunity_id" value={formData.opportunity_id} onValueChange={(v) => handleSelectChange('opportunity_id', v)} required>
                  <SelectTrigger><SelectValue placeholder="Select Opportunity..." /></SelectTrigger>
                  <SelectContent>
                    {opportunities.map(opp => <SelectItem key={opp.id} value={opp.id}>{opp.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label htmlFor="lender_id" className="block text-sm font-medium text-gray-300 mb-2">Lender</label>
                <Select name="lender_id" value={formData.lender_id} onValueChange={(v) => handleSelectChange('lender_id', v)} required>
                  <SelectTrigger><SelectValue placeholder="Select Lender..." /></SelectTrigger>
                  <SelectContent>
                    {lenders.map(lender => <SelectItem key={lender.id} value={lender.id}>{lender.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label htmlFor="amount_aud" className="block text-sm font-medium text-gray-300 mb-2">Amount (AUD)</label>
                <Input id="amount_aud" name="amount_aud" type="number" value={formData.amount_aud} onChange={handleInputChange} required />
              </div>
              <div>
                <label htmlFor="rate_pct" className="block text-sm font-medium text-gray-300 mb-2">Interest Rate (%)</label>
                <Input id="rate_pct" name="rate_pct" type="number" step="0.01" value={formData.rate_pct} onChange={handleInputChange} required />
              </div>
            </div>
             <div>
                <label htmlFor="status" className="block text-sm font-medium text-gray-300 mb-2">Status</label>
                <Select name="status" value={formData.status} onValueChange={(v) => handleSelectChange('status', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="drafting">Drafting</SelectItem>
                    <SelectItem value="offered">Offered</SelectItem>
                    <SelectItem value="accepted">Accepted</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => navigate(-1)} disabled={loading}>
                Cancel
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Create Facility
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}