
import React, { useState, useEffect, useCallback } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { RFPRequest } from "@/api/entities";
import { RFPResponse } from "@/api/entities";
import { PropertySubmission } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Loader2, Building, Mail, FileText, CheckCircle, Clock, ChevronRight } from "lucide-react";
import HOAEditor from '@/components/hoa-editor/HOAEditor';
import NegotiationCoachPanel from '@/components/negotiation/NegotiationCoachPanel';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast"; // Assuming this is where useToast comes from
import DueDiligencePanel from "@/components/deal/DueDiligencePanel";

export default function RFPReview() {
    const [searchParams] = useSearchParams();
    const rfpId = searchParams.get('rfpId');

    const [rfpRequest, setRfpRequest] = useState(null);
    const [responses, setResponses] = useState([]);
    const [properties, setProperties] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [activeTab, setActiveTab] = useState("overview"); // New state for active tab
    const [selectedResponse, setSelectedResponse] = useState(null); // New state for selected response

    const { toast } = useToast();

    const loadData = useCallback(async () => {
        if (!rfpId) {
            setError("No RFP Request ID provided.");
            setLoading(false);
            return;
        }
        try {
            const [reqData, resData] = await Promise.all([
                RFPRequest.get(rfpId),
                RFPResponse.filter({ rfp_request_id: rfpId })
            ]);
            
            setRfpRequest(reqData);
            setResponses(resData);

            if (resData.length > 0) {
                const propIds = [...new Set(resData.map(r => r.property_submission_id))];
                const propData = await Promise.all(propIds.map(id => PropertySubmission.get(id)));
                const propsMap = propData.reduce((acc, prop) => {
                    acc[prop.id] = prop;
                    return acc;
                }, {});
                setProperties(propsMap);

                // If a response was previously selected, try to re-select it after data refresh
                if (selectedResponse) {
                    const updatedSelectedResponse = resData.find(r => r.id === selectedResponse.id);
                    if (updatedSelectedResponse) {
                        setSelectedResponse(updatedSelectedResponse);
                    } else {
                        setSelectedResponse(null); // Deselect if it no longer exists
                    }
                }
            } else {
                setProperties({});
                setSelectedResponse(null);
            }

        } catch (err) {
            setError("Failed to load RFP responses.");
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, [rfpId, selectedResponse]); // Added selectedResponse to dependency array to correctly re-select

    useEffect(() => {
        loadData();
    }, [loadData]);

    const handleSelectResponse = (response) => {
        setSelectedResponse(response);
        setActiveTab("negotiation");
    };

    const updateResponseHOA = async (hoaData) => {
        if (!selectedResponse) return;
        try {
            await RFPResponse.update(selectedResponse.id, {
                heads_of_agreement_text: hoaData.heads_of_agreement_text,
                ai_suggestions: hoaData.ai_suggestions
            });
            toast({ 
                title: "Heads of Agreement saved", 
                description: "The HOA document has been updated." 
            });
            loadData(); // Refresh data to get the updated response
        } catch (error) {
            console.error('Failed to update HOA:', error);
            toast({ 
                title: "Error saving HOA", 
                description: "There was a problem updating the Heads of Agreement.",
                variant: "destructive"
            });
            throw error;
        }
    };

    const approveResponse = async (approvalData) => {
        if (!selectedResponse) return;
        try {
            await RFPResponse.update(selectedResponse.id, {
                status: 'accepted',
                heads_of_agreement_text: approvalData.heads_of_agreement_text,
                consultant_comments: `Approved with changes: ${approvalData.changes?.length || 0} modifications made`
            });
            
            // Create lease record or move to next workflow step
            toast({ 
                title: "Response approved", 
                description: "Moving to lease execution phase" 
            });
            
            loadData(); // Refresh data to get the updated status
        } catch (error) {
            console.error('Failed to approve response:', error);
            toast({ 
                title: "Error approving response", 
                description: "There was a problem approving the response.",
                variant: "destructive"
            });
            throw error;
        }
    };

    const updateNegotiationStrategy = async (strategyData) => {
        if (!selectedResponse) return;
        try {
            await RFPResponse.update(selectedResponse.id, {
                consultant_comments: strategyData.negotiation_strategy,
                ai_analysis: strategyData.coaching_data
            });
            toast({ 
                title: "Negotiation strategy updated", 
                description: "The negotiation strategy and coaching data have been saved." 
            });
            loadData(); // Refresh data to get the updated fields
        } catch (error) {
            console.error('Failed to update strategy:', error);
            toast({ 
                title: "Error updating strategy", 
                description: "There was a problem saving the negotiation strategy.",
                variant: "destructive"
            });
            throw error;
        }
    };

    if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-12 h-12 text-amber-400 animate-spin" /></div>;
    if (error) return <div className="min-h-screen flex items-center justify-center text-center text-white p-8">{error}</div>;

    // Assuming rfpRequest might contain a deal_id once a deal is initiated from this RFP
    const dealId = rfpRequest?.deal_id;

    return (
        <div className="p-6">
            <div className="max-w-6xl mx-auto space-y-6">
                <header className="mb-8">
                    <h1 className="text-3xl font-bold text-white">RFP Review: {rfpRequest?.rfp_reference_code}</h1>
                    <p className="text-gray-300">Manage and review proposals for this Request for Proposal.</p>
                </header>
                
                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                    <TabsList className="bg-gray-800 border border-gray-700">
                        <TabsTrigger value="overview">Overview</TabsTrigger>
                        <TabsTrigger value="responses">Responses ({responses.length})</TabsTrigger>
                        <TabsTrigger value="negotiation">Negotiation</TabsTrigger>
                        <TabsTrigger value="documents">Documents</TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview">
                        <div className="orbit-card p-6">
                            <h2 className="text-2xl font-semibold text-white mb-4">RFP Details</h2>
                            <div className="space-y-3 text-gray-300">
                                <p><strong>Title:</strong> {rfpRequest?.title}</p>
                                <p><strong>Description:</strong> {rfpRequest?.description}</p>
                                <p><strong>Due Date:</strong> {rfpRequest?.due_date ? new Date(rfpRequest.due_date).toLocaleDateString() : 'N/A'}</p>
                                {/* Add more RFP details here as needed */}
                            </div>
                        </div>
                    </TabsContent>

                    <TabsContent value="responses">
                        <div className="space-y-6">
                            {responses.length > 0 ? responses.map(response => {
                                const property = properties[response.property_submission_id];
                                return (
                                    <div key={response.id} className="orbit-card p-6 flex flex-col sm:flex-row justify-between items-start gap-4">
                                        <div className="flex-grow">
                                            <h3 className="text-xl font-semibold text-white flex items-center gap-2 mb-2">
                                                <Building className="text-amber-400" />
                                                {property?.property_title || 'Loading Property...'}
                                            </h3>
                                            <p className="text-sm text-gray-400 mb-2">{property?.address}</p>
                                            <p className="text-sm text-gray-300 flex items-center gap-2">
                                                <Mail className="w-4 h-4" />
                                                Response from: {response.agent_email}
                                            </p>
                                        </div>
                                        <div className="flex-shrink-0 flex flex-col items-start sm:items-end gap-2 w-full sm:w-auto">
                                            <div className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-2 ${response.status === 'submitted' ? 'bg-green-600/20 text-green-300' : response.status === 'accepted' ? 'bg-blue-600/20 text-blue-300' : 'bg-gray-600/20 text-gray-300'}`}>
                                                {response.status === 'submitted' ? <CheckCircle className="w-4 h-4" /> : response.status === 'accepted' ? <CheckCircle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                                                {response.status.replace('_', ' ').toUpperCase()}
                                            </div>
                                            <p className="text-xs text-gray-500">
                                                Submitted: {new Date(response.submitted_date).toLocaleString()}
                                            </p>
                                            <div className="flex gap-2">
                                                <Button 
                                                    variant="outline" 
                                                    className="orbit-button-secondary w-full sm:w-auto"
                                                    onClick={() => handleSelectResponse(response)}
                                                >
                                                    Select Response
                                                    <ChevronRight className="w-4 h-4 ml-2"/>
                                                </Button>
                                                <Link to={createPageUrl(`RFPResponseDetails?responseId=${response.id}`)}>
                                                    <Button className="orbit-button-active w-full sm:w-auto">
                                                        <FileText className="w-4 h-4 mr-2"/>
                                                        Review Proposal
                                                    </Button>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                );
                            }) : (
                                <div className="orbit-card text-center p-12">
                                    <h3 className="text-lg text-white">No responses received yet.</h3>
                                    <p className="text-gray-400">Check back later or follow up with the agents.</p>
                                </div>
                            )}
                        </div>
                    </TabsContent>

                    <TabsContent value="negotiation">
                        {selectedResponse && rfpRequest ? (
                            <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
                                <div className="xl:col-span-3">
                                    <HOAEditor
                                        rfpResponse={selectedResponse}
                                        onSave={updateResponseHOA}
                                        onApprove={approveResponse}
                                    />
                                </div>
                                <div className="xl:col-span-1">
                                    <NegotiationCoachPanel
                                        rfpResponse={selectedResponse}
                                        brief={rfpRequest}
                                        onUpdateStrategy={updateNegotiationStrategy}
                                    />
                                </div>
                            </div>
                        ) : (
                            <Card className="orbit-card p-12 text-center shadow-elevated">
                                <CardContent className="p-0"> {/* Remove default CardContent padding */}
                                    <FileText className="w-16 h-16 mx-auto text-gray-500 mb-4" />
                                    <h3 className="text-xl font-semibold text-white mb-2">Select a Response</h3>
                                    <p className="text-gray-400">Choose a response from the "Responses" tab to begin negotiation</p>
                                </CardContent>
                            </Card>
                        )}
                    </TabsContent>

                    <TabsContent value="documents">
                        <Card className="orbit-card p-12 text-center shadow-elevated">
                            <CardContent className="p-0">
                                <FileText className="w-16 h-16 mx-auto text-gray-500 mb-4" />
                                <h3 className="text-xl font-semibold text-white mb-2">Documents Tab (Coming Soon)</h3>
                                <p className="text-gray-400">Here you will manage all associated documents for this RFP.</p>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
                
                <section className="orbit-card p-4 mt-6"> {/* Added orbit-card class for consistent styling */}
                    <h3 className="text-lg font-semibold mb-4 text-white">Technical Due Diligence</h3>
                    <DueDiligencePanel dealId={dealId} />
                </section>
            </div>
        </div>
    );
}
