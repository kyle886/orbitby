import React, { useState, useEffect } from "react";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import { TenantRequirement } from "@/api/entities";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus, Eye, MoreHorizontal } from "lucide-react";

export default function Requirements() {
  const navigate = useNavigate();
  const [briefs, setBriefs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBriefs = async () => {
      try {
        const fetchedBriefs = await TenantRequirement.list("-created_date");
        setBriefs(fetchedBriefs);
      } catch (error) {
        console.error("Error fetching briefs:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchBriefs();
  }, []);

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case "active":
      case "in_market":
        return "bg-green-700 text-green-100";
      case "completed":
        return "bg-blue-700 text-blue-100";
      case "cancelled":
        return "bg-red-700 text-red-100";
      default:
        return "bg-gray-600 text-gray-200";
    }
  };

  const BriefCard = ({ brief }) => (
    <Card className="orbit-card flex flex-col h-full">
      <CardHeader>
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-bold text-white pr-2">{brief.company_name}</h3>
          <Badge className={getStatusBadgeVariant(brief.status)}>
            {brief.status?.replace("_", " ")}
          </Badge>
        </div>
        <p className="text-xs text-gray-400">Ref: {brief.brief_reference_code || "N/A"}</p>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col">
        <div className="flex-grow space-y-2 text-sm text-gray-300">
          <p>
            <strong>Type:</strong>{" "}
            <span className="capitalize">{brief.property_type?.replace("_", " ")}</span>
          </p>
          <p>
            <strong>Locations:</strong> {(brief.preferred_suburbs || []).join(", ")}
          </p>
          <p>
            <strong>Size:</strong> {brief.min_floor_area} - {brief.max_floor_area} sqm
          </p>
        </div>
        <div className="mt-4 pt-4 border-t border-white/10">
          <Button
            className="w-full"
            variant="outline"
            onClick={() => navigate(createPageUrl(`BriefDetails?id=${brief.id}`))}
          >
            <Eye className="w-4 h-4 mr-2" />
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Client Briefs</h1>
            <p className="text-gray-300">
              Manage all active and past client requirements.
            </p>
          </div>
          <Button
            onClick={() => navigate(createPageUrl("CreateBrief"))}
            className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-white font-bold px-6 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
          >
            <Plus className="mr-2 h-5 w-5" />
            Create New Brief
          </Button>
        </div>

        {loading ? (
          <p className="text-center text-gray-400">Loading briefs...</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {briefs.map((brief) => (
              <BriefCard key={brief.id} brief={brief} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}