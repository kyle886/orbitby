import React, { useState, useEffect, useCallback } from 'react';
import { BDKPI } from '@/api/entities';
import { Target } from '@/api/entities';
import { Pitch } from '@/api/entities';
import { Event } from '@/api/entities';
import { InboundRecommendation } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { TrendingUp, TrendingDown, Users, Target as TargetIcon, Presentation, Calendar, RefreshCw, Download } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { runJob } from '@/components/utils/runJob';

const KPICard = ({ title, value, previousValue, unit = '', icon: Icon, color = 'blue' }) => {
  const trend = previousValue ? ((value - previousValue) / previousValue * 100) : 0;
  const isPositive = trend >= 0;
  
  return (
    <Card className="orbit-card">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-400">{title}</p>
            <p className="text-3xl font-bold text-white">{value}{unit}</p>
            {previousValue && (
              <div className={`flex items-center mt-2 text-sm ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                {isPositive ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
                <span>{Math.abs(trend).toFixed(1)}%</span>
              </div>
            )}
          </div>
          <div className={`p-3 rounded-lg bg-${color}-500/20`}>
            <Icon className={`w-6 h-6 text-${color}-400`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default function BDKPIPage() {
  const [kpiData, setKpiData] = useState([]);
  const [currentKPIs, setCurrentKPIs] = useState({});
  const [previousKPIs, setPreviousKPIs] = useState({});
  const [selectedPeriod, setSelectedPeriod] = useState('6'); // 6 months default
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { toast } = useToast();

  const loadKPIData = useCallback(async () => {
    setLoading(true);
    try {
      // Get KPI data for the selected period
      const kpis = await BDKPI.list('-period_month', parseInt(selectedPeriod));
      setKpiData(kpis || []);
      
      if (kpis && kpis.length > 0) {
        setCurrentKPIs(kpis[0]);
        if (kpis.length > 1) {
          setPreviousKPIs(kpis[1]);
        }
      }
    } catch (error) {
      console.error('Error loading KPI data:', error);
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to load KPI data.' });
    } finally {
      setLoading(false);
    }
  }, [selectedPeriod, toast]);

  useEffect(() => {
    loadKPIData();
  }, [loadKPIData]);

  const handleRefreshKPIs = async () => {
    setIsRefreshing(true);
    toast({ title: 'Refreshing KPIs', description: 'Calculating latest performance metrics...' });
    
    await runJob('Refresh BD KPIs', async () => {
      const currentMonth = new Date().toISOString().slice(0, 7) + '-01';
      
      // Get raw data for calculations
      const [targets, pitches, events, inboundRecs] = await Promise.all([
        Target.list(),
        Pitch.list(),
        Event.list(), 
        InboundRecommendation.list()
      ]);

      // Calculate current month KPIs
      const currentMonthStart = new Date(currentMonth);
      const currentMonthEnd = new Date(currentMonthStart.getFullYear(), currentMonthStart.getMonth() + 1, 0);
      
      // Filter data for current month
      const thisMonthTargets = targets.filter(t => 
        new Date(t.created_date) >= currentMonthStart && new Date(t.created_date) <= currentMonthEnd
      );
      
      const thisMonthPitches = pitches.filter(p => 
        p.meeting_dt && new Date(p.meeting_dt) >= currentMonthStart && new Date(p.meeting_dt) <= currentMonthEnd
      );
      
      const thisMonthWins = targets.filter(t => 
        t.status === 'won' && t.updated_date && 
        new Date(t.updated_date) >= currentMonthStart && new Date(t.updated_date) <= currentMonthEnd
      );

      const thisMonthInboundActions = inboundRecs.filter(r => 
        r.status === 'done' && r.created_date &&
        new Date(r.created_date) >= currentMonthStart && new Date(r.created_date) <= currentMonthEnd
      );

      const thisMonthApprovedActions = inboundRecs.filter(r => 
        r.status === 'approved' && r.created_date &&
        new Date(r.created_date) >= currentMonthStart && new Date(r.created_date) <= currentMonthEnd
      );

      // Calculate metrics
      const kpiCalculations = {
        period_month: currentMonth,
        leads_created: thisMonthTargets.length,
        meetings_set: thisMonthPitches.filter(p => p.status === 'scheduled').length,
        pitches_issued: thisMonthPitches.filter(p => p.status === 'issued').length,
        wins: thisMonthWins.length,
        avg_priority_score: Math.round(
          targets.filter(t => t.priority_score > 0).reduce((sum, t) => sum + t.priority_score, 0) / 
          Math.max(targets.filter(t => t.priority_score > 0).length, 1)
        ),
        top20_filled_pct: Math.round(
          (targets.filter(t => t.is_top_20).length / 20) * 100
        ),
        avg_cycle_days: 30, // Would need more sophisticated calculation
        inbound_actions_approved: thisMonthApprovedActions.length,
        inbound_actions_done: thisMonthInboundActions.length,
        inbound_leads: thisMonthInboundActions.filter(r => r.type === 'inbound').length,
        meetings_from_inbound: thisMonthPitches.filter(p => 
          p.recommendations && p.recommendations.source === 'inbound'
        ).length,
        pitches_from_inbound: thisMonthPitches.filter(p => 
          p.recommendations && p.recommendations.source === 'inbound' && p.status === 'issued'
        ).length,
        wins_from_inbound: thisMonthWins.filter(t => 
          t.reason && t.reason.includes('inbound')
        ).length
      };

      // Check if KPI record exists for current month
      const existingKPIs = await BDKPI.filter({ period_month: currentMonth });
      
      if (existingKPIs.length > 0) {
        await BDKPI.update(existingKPIs[0].id, kpiCalculations);
      } else {
        await BDKPI.create(kpiCalculations);
      }

      return {
        rows_affected: 1,
        notes: `KPIs calculated for ${currentMonth}. ${kpiCalculations.leads_created} leads, ${kpiCalculations.wins} wins.`
      };
    }, {});

    setIsRefreshing(false);
    loadKPIData();
    toast({ title: 'KPIs Refreshed', description: 'Performance metrics updated successfully.' });
  };

  const exportKPIData = () => {
    const csvContent = [
      ['Period', 'Leads Created', 'Meetings Set', 'Pitches Issued', 'Wins', 'Conversion Rate %'].join(','),
      ...kpiData.map(kpi => [
        kpi.period_month,
        kpi.leads_created || 0,
        kpi.meetings_set || 0,
        kpi.pitches_issued || 0,
        kpi.wins || 0,
        ((kpi.wins / Math.max(kpi.leads_created, 1)) * 100).toFixed(1)
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bd-kpis-${new Date().toISOString().slice(0, 7)}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full p-8">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full animate-pulse bg-white/10 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading BD performance metrics...</p>
        </div>
      </div>
    );
  }

  const chartData = kpiData.map(kpi => ({
    month: new Date(kpi.period_month).toLocaleDateString('en-US', { month: 'short', year: '2-digit' }),
    leads: kpi.leads_created || 0,
    meetings: kpi.meetings_set || 0,
    pitches: kpi.pitches_issued || 0,
    wins: kpi.wins || 0,
    conversion: ((kpi.wins / Math.max(kpi.leads_created, 1)) * 100).toFixed(1)
  }));

  return (
    <div className="p-4 sm:p-6 md:p-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">BD Performance Dashboard</h1>
          <p className="text-gray-300">Track key business development metrics and trends</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="3">Last 3 months</SelectItem>
              <SelectItem value="6">Last 6 months</SelectItem>
              <SelectItem value="12">Last 12 months</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={exportKPIData}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button onClick={handleRefreshKPIs} disabled={isRefreshing}>
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? 'Refreshing...' : 'Refresh KPIs'}
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <KPICard
          title="Leads Created"
          value={currentKPIs.leads_created || 0}
          previousValue={previousKPIs.leads_created}
          icon={TargetIcon}
          color="blue"
        />
        <KPICard
          title="Meetings Set"
          value={currentKPIs.meetings_set || 0}
          previousValue={previousKPIs.meetings_set}
          icon={Users}
          color="green"
        />
        <KPICard
          title="Pitches Delivered"
          value={currentKPIs.pitches_issued || 0}
          previousValue={previousKPIs.pitches_issued}
          icon={Presentation}
          color="purple"
        />
        <KPICard
          title="Wins"
          value={currentKPIs.wins || 0}
          previousValue={previousKPIs.wins}
          icon={Calendar}
          color="orange"
        />
      </div>

      {/* Inbound Marketing Performance */}
      <div className="grid lg:grid-cols-2 gap-6 mb-8">
        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-white">Inbound Marketing Impact</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-400">{currentKPIs.inbound_actions_done || 0}</div>
                <div className="text-sm text-gray-400">Actions Completed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">{currentKPIs.meetings_from_inbound || 0}</div>
                <div className="text-sm text-gray-400">Meetings Generated</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">{currentKPIs.pitches_from_inbound || 0}</div>
                <div className="text-sm text-gray-400">Pitches from Inbound</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-400">{currentKPIs.wins_from_inbound || 0}</div>
                <div className="text-sm text-gray-400">Inbound Wins</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-white">Performance Quality</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Average Priority Score</span>
                <Badge variant="outline" className="text-white">
                  {currentKPIs.avg_priority_score || 0}/100
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Top 20 Fill Rate</span>
                <Badge variant="outline" className="text-white">
                  {currentKPIs.top20_filled_pct || 0}%
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Lead → Win Conversion</span>
                <Badge variant="outline" className="text-white">
                  {currentKPIs.leads_created > 0 ? 
                    ((currentKPIs.wins / currentKPIs.leads_created) * 100).toFixed(1) : 0}%
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Average Cycle Time</span>
                <Badge variant="outline" className="text-white">
                  {currentKPIs.avg_cycle_days || 0} days
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-white">Performance Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }}
                />
                <Line type="monotone" dataKey="leads" stroke="#3B82F6" strokeWidth={2} name="Leads" />
                <Line type="monotone" dataKey="meetings" stroke="#10B981" strokeWidth={2} name="Meetings" />
                <Line type="monotone" dataKey="pitches" stroke="#8B5CF6" strokeWidth={2} name="Pitches" />
                <Line type="monotone" dataKey="wins" stroke="#F59E0B" strokeWidth={2} name="Wins" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-white">Conversion Funnel</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="leads" fill="#3B82F6" name="Leads" />
                <Bar dataKey="meetings" fill="#10B981" name="Meetings" />
                <Bar dataKey="pitches" fill="#8B5CF6" name="Pitches" />
                <Bar dataKey="wins" fill="#F59E0B" name="Wins" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}