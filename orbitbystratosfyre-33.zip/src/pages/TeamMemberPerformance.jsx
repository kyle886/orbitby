
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { User } from '@/api/entities';
import { Client } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { ClientUpdate } from '@/api/entities';
import { DealEvidence } from '@/api/entities';
import { Loader2, Briefcase, DollarSign, Activity, CheckCircle, AlertTriangle, XCircle, User as UserIcon, MessageSquare, ArrowRight, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LabelList, Legend } from 'recharts';

const AVERAGE_RENT_PER_SQM = 850;

export default function TeamMemberPerformance() {
  const [searchParams] = useSearchParams();
  const userId = searchParams.get('userId');
  
  const [consultant, setConsultant] = useState(null);
  const [briefs, setBriefs] = useState([]);
  const [updates, setUpdates] = useState([]);
  const [benchmarks, setBenchmarks] = useState(null);
  const [loading, setLoading] = useState(true);

  const calculateBenchmarks = useCallback((allBriefs, allDealEvidence) => {
    const completedBriefs = allBriefs.filter(b => b.status === 'completed');
    if (completedBriefs.length === 0) return { teamCycleTime: 0, marketRent: 0 };
    
    const totalCycleTime = completedBriefs.reduce((acc, brief) => {
      const startTime = new Date(brief.created_date);
      // This is a placeholder; a 'completed_date' field would be ideal
      const endTime = new Date(brief.updated_date); 
      return acc + (endTime - startTime);
    }, 0);
    
    const teamCycleTime = totalCycleTime / completedBriefs.length / (1000 * 3600 * 24);

    const marketRent = allDealEvidence.length > 0 ? allDealEvidence.reduce((acc, deal) => acc + (deal.net_effective_rent_sqm || 0), 0) / allDealEvidence.length : AVERAGE_RENT_PER_SQM;
    
    return { teamCycleTime, marketRent };
  }, []);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    const loadData = async () => {
      setLoading(true);
      try {
        const [consultantData, allClients, allBriefs, allUpdates, allDealEvidence] = await Promise.all([
          User.get(userId),
          Client.list(),
          TenantRequirement.list(),
          ClientUpdate.list(),
          DealEvidence.list()
        ]);
        
        setConsultant(consultantData);
        
        const consultantClientIds = allClients
          .filter(c => (c.stratosfyre_consultants || []).some(con => con.id === userId))
          .map(c => c.id);
          
        const consultantBriefs = allBriefs.filter(b => consultantClientIds.includes(b.client_id));
        setBriefs(consultantBriefs);

        const consultantUpdates = allUpdates.filter(u => consultantClientIds.includes(u.client_id) && u.created_by === consultantData.email);
        setUpdates(consultantUpdates.sort((a,b) => new Date(b.created_date) - new Date(a.created_date)));
        
        const benchmarkData = calculateBenchmarks(allBriefs, allDealEvidence);
        setBenchmarks(benchmarkData);

      } catch (error) {
        console.error("Error loading performance details:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [userId, calculateBenchmarks]);

  const getBriefPacing = (brief) => {
    const daysSinceUpdate = (new Date() - new Date(brief.updated_date)) / (1000 * 3600 * 24);
    if (daysSinceUpdate > 60) return { status: 'At Risk', color: 'text-red-400' };
    if (daysSinceUpdate > 30) return { status: 'Needs Monitoring', color: 'text-yellow-400' };
    return { status: 'On Track', color: 'text-green-400' };
  };

  if (loading) {
    return <div className="p-8 text-center"><Loader2 className="h-12 w-12 animate-spin text-orange-400 mx-auto" /></div>;
  }

  if (!consultant) {
    return <div className="p-8 text-center text-white">Consultant not found.</div>;
  }

  const activeBriefs = briefs.filter(b => b.status !== 'completed' && b.status !== 'cancelled');
  const pipelineValue = activeBriefs.reduce((acc, brief) => acc + ((brief.max_floor_area || 0) * AVERAGE_RENT_PER_SQM), 0);
  const consultantCycleTime = briefs.filter(b => b.status === 'completed').reduce((acc, b) => acc + ((new Date(b.updated_date) - new Date(b.created_date)) / (1000 * 3600 * 24)), 0) / (briefs.filter(b => b.status === 'completed').length || 1);

  const benchmarkChartData = benchmarks ? [
    { name: 'Avg. Deal Cycle (days)', [consultant.first_name]: consultantCycleTime.toFixed(0), 'Team Avg.': benchmarks.teamCycleTime.toFixed(0) },
  ] : [];

  return (
    <div className="p-4 sm:p-6 lg:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-4">
            <UserIcon className="w-12 h-12 text-amber-400"/>
            <div>
              <h1 className="text-3xl font-bold text-white">{consultant.first_name} {consultant.last_name}</h1>
              <p className="text-gray-300">{consultant.title || 'Consultant'}</p>
            </div>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="orbit-card"><CardContent className="p-6"><Briefcase className="w-6 h-6 text-amber-400 mb-2" /><h4 className="text-gray-300 text-sm">Active Briefs</h4><p className="text-3xl font-bold text-white">{activeBriefs.length}</p></CardContent></Card>
          <Card className="orbit-card"><CardContent className="p-6"><DollarSign className="w-6 h-6 text-amber-400 mb-2" /><h4 className="text-gray-300 text-sm">Est. Pipeline</h4><p className="text-3xl font-bold text-white">${(pipelineValue/1_000_000).toFixed(1)}M</p></CardContent></Card>
          <Card className="orbit-card"><CardContent className="p-6"><TrendingUp className="w-6 h-6 text-amber-400 mb-2" /><h4 className="text-gray-300 text-sm">Completed Deals</h4><p className="text-3xl font-bold text-white">{briefs.filter(b => b.status === 'completed').length}</p></CardContent></Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="orbit-card">
              <CardHeader><CardTitle className="text-white">Active Briefs</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeBriefs.map(brief => (
                    <div key={brief.id} className="p-4 bg-gray-800/50 rounded-lg flex justify-between items-center">
                      <div>
                        <p className="font-bold text-white">{brief.company_name}</p>
                        <p className="text-sm text-gray-400">{brief.brief_reference_code}</p>
                        <p className={`text-xs mt-1 font-medium ${getBriefPacing(brief).color}`}>{getBriefPacing(brief).status}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-300 capitalize">{brief.status?.replace('_', ' ')}</p>
                        <p className="text-xs text-gray-500">{(brief.max_floor_area || 0)} sqm</p>
                      </div>
                    </div>
                  ))}
                  {activeBriefs.length === 0 && <p className="text-gray-400 text-center py-4">No active briefs.</p>}
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            {benchmarks && (
              <Card className="orbit-card mb-8">
                <CardHeader><CardTitle className="text-white">Performance Benchmarks</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={benchmarkChartData} layout="vertical" margin={{ left: 20, right: 30 }}>
                      <XAxis type="number" stroke="#9ca3af" />
                      <YAxis type="category" dataKey="name" stroke="#9ca3af" width={80} tick={{ fontSize: 12 }} />
                      <Tooltip cursor={{ fill: 'rgba(255,255,255,0.1)' }} contentStyle={{ backgroundColor: '#1f2937', border: 'none' }}/>
                      <Legend />
                      <Bar dataKey={consultant.first_name} fill="#f97316" radius={[0, 4, 4, 0]}>
                        <LabelList dataKey={consultant.first_name} position="right" style={{ fill: '#f3f4f6' }} />
                      </Bar>
                      <Bar dataKey="Team Avg." fill="#4b5563" radius={[0, 4, 4, 0]}>
                        <LabelList dataKey="Team Avg." position="right" style={{ fill: '#f3f4f6' }} />
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}
            
            <Card className="orbit-card">
              <CardHeader><CardTitle className="text-white">Recent Communications</CardTitle></CardHeader>
              <CardContent className="max-h-60 overflow-y-auto">
                <div className="space-y-4">
                  {updates.slice(0, 5).map(update => (
                    <div key={update.id} className="text-sm">
                      <p className="font-medium text-white">{update.title}</p>
                      <p className="text-xs text-gray-400">{new Date(update.created_date).toLocaleDateString()}</p>
                    </div>
                  ))}
                   {updates.length === 0 && <p className="text-gray-400 text-center py-4">No communications sent.</p>}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
