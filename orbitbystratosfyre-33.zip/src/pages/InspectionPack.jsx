import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import MapLite from "@/components/inspection/MapLite";
import FloorplanAnnotator from "@/components/inspection/FloorplanAnnotator";
import { downloadICS, makeICS } from "@/components/utils/ics";
import { toast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Copy, Send, Calendar, Upload, MapPin, Users, Clock, Eye } from "lucide-react";

export default function InspectionPack() {
  const { packId } = useParams();
  const [pack, setPack] = useState(null);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState([]);
  const [route, setRoute] = useState(null);

  useEffect(() => {
    async function loadPack() {
      setLoading(true);
      try {
        const { data } = await window.base44.functions.getInspectionPack({ id: packId });
        setPack(data);
        
        // Load feedback
        const feedbackResult = await window.base44.functions.listInspectionFeedback({ id: packId });
        setFeedback(feedbackResult.items || []);
        
        // Load route
        const props = (data.stops || []).filter(s => s.type === "property");
        const pts = props.map(p => ({ lat: p.lat, lng: p.lng }));
        if (pts.length >= 2) {
          const routeResult = await fetch(`https://router.project-osrm.org/route/v1/driving/${pts.map(p => `${p.lng},${p.lat}`).join(";")}?overview=full&geometries=geojson`);
          if (routeResult.ok) {
            const routeData = await routeResult.json();
            setRoute(routeData.routes?.[0]?.geometry || null);
          }
        }
      } catch (e) {
        toast({ variant: "destructive", title: "Error", description: "Could not load inspection pack." });
      } finally {
        setLoading(false);
      }
    }
    loadPack();
  }, [packId]);

  async function saveStopPatch(stopId, patch) {
    const next = { ...pack };
    next.stops = next.stops.map(st => st.id === stopId ? { ...st, ...patch } : st);
    setPack(next);
    await window.base44.functions.saveInspectionPack({
      id: pack.id,
      title: pack.title,
      startISO: pack.startISO,
      stops: next.stops,
      attendees: pack.attendees,
      criteria: pack.criteria
    });
  }

  function sendPlaceholder() {
    const ics = makeICS({
      title: pack.title || "Inspection",
      start: new Date(pack.startISO),
      end: new Date(pack.stops[pack.stops.length - 1]?.depart || pack.startISO),
      location: pack.stops.find(s => s.type === "property")?.title || "TBD",
      organizer: { name: pack.createdByName || "Organizer", email: pack.createdByEmail || "" },
      attendees: (pack.attendees || []).map(a => ({ name: a.name, email: a.email })),
      uid: `orbit-inspection-${pack.id}`
    });
    downloadICS(`${pack.title || "inspection"}.ics`, ics);
    toast({ title: "Placeholder invite downloaded" });
  }

  async function sendFinalPack() {
    try {
      const { data: r } = await window.base44.functions.sendInspectionInvite({ id: pack.id });
      if (r?.url) window.open(r.url, "_blank");
      toast({ title: "Invite emailed", description: "ICS link sent to attendees" });
    } catch (e) {
      toast({ variant: "destructive", title: "Failed to send pack", description: e.message });
    }
  }

  const shareUrl = `${window.location.origin}/inspection/shared/${pack?.id}?token=${pack?.shareToken}`;

  const copyShareLink = () => {
    navigator.clipboard.writeText(shareUrl);
    toast({ title: "Link Copied!" });
  }

  if (loading) return <div className="p-6 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto text-white" /></div>;
  if (!pack) return <div className="p-6 text-center text-red-400">Inspection pack not found.</div>;

  const stops = pack.stops || [];
  const props = stops.filter(s => s.type === "property");

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-white">{pack.title}</h2>
          <div className="flex items-center gap-4 mt-2">
            <Badge className="bg-blue-600">
              <MapPin className="w-3 h-3 mr-1" />
              {props.length} Properties
            </Badge>
            <Badge className="bg-green-600">
              <Users className="w-3 h-3 mr-1" />
              {pack.attendees?.length || 0} Attendees
            </Badge>
            <Badge className="bg-purple-600">
              <Clock className="w-3 h-3 mr-1" />
              {new Date(pack.startISO).toLocaleDateString()}
            </Badge>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" className="orbit-button" onClick={sendPlaceholder}>
            <Calendar className="mr-2 h-4 w-4" />📥 Download Placeholder ICS
          </Button>
          <Button variant="outline" className="orbit-button" onClick={sendFinalPack}>
            <Send className="mr-2 h-4 w-4" />📧 Email Placeholder Invite
          </Button>
          <Button className="orbit-button-primary" onClick={copyShareLink}>
            <Copy className="mr-2 h-4 w-4" />Copy Attendee Link
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-[2fr_1fr] gap-6">
        <Card className="card p-4 space-y-3">
          <MapLite points={props.map(p => ({ lat: p.lat, lng: p.lng, label: p.title }))} route={route} />
          <div className="space-y-2">
            {stops.map((s, idx) => (
              <div key={s.id} className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded bg-white/5 border border-white/10">
                  <div className="text-sm text-white">
                    <b>{idx + 1}.</b> {s.title} {s.type === "break" && " (Break)"}
                    {s.arrival && (
                      <span className="text-xs text-gray-400 ml-2">
                        • {new Date(s.arrival).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} → {new Date(s.depart).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    )}
                  </div>
                  {s.travelSecFromPrev > 0 && (
                    <div className="text-xs text-gray-400">{Math.round(s.travelSecFromPrev / 60)} min travel</div>
                  )}
                </div>

                {s.type === "property" && (
                  <div className="ml-6 space-y-2 p-3 bg-gray-800/30 rounded border border-gray-700">
                    <div className="flex items-center gap-2">
                      <Upload className="w-4 h-4 text-gray-400" />
                      <input
                        type="file"
                        accept="image/*,application/pdf"
                        onChange={async (e) => {
                          const f = e.target.files?.[0];
                          if (!f) return;
                          try {
                            const b64 = await f.arrayBuffer().then(buf => `data:${f.type};base64,${btoa(String.fromCharCode(...new Uint8Array(buf)))}`);
                            const r = await window.base44.functions.saveInspectionAsset({
                              id: pack.id,
                              stopId: s.id,
                              filename: f.name,
                              dataUrl: b64,
                              contentType: f.type
                            });
                            await saveStopPatch(s.id, { floorplanUrl: r.url });
                            toast({ title: "File uploaded successfully" });
                          } catch (error) {
                            toast({ variant: "destructive", title: "Upload failed", description: error.message });
                          }
                        }}
                        className="text-sm text-gray-300"
                      />
                    </div>

                    {s.floorplanUrl?.match(/\.(png|jpe?g)$/i) && (
                      <div className="border border-gray-600 rounded">
                        <FloorplanAnnotator
                          imageUrl={s.floorplanUrl}
                          onExport={async (png) => {
                            try {
                              const r = await window.base44.functions.saveInspectionAsset({
                                id: pack.id,
                                stopId: s.id,
                                filename: "annotated.png",
                                dataUrl: png,
                                contentType: "image/png"
                              });
                              await saveStopPatch(s.id, { annotatedPlanUrl: r.url });
                              toast({ title: "Annotated plan saved" });
                            } catch (error) {
                              toast({ variant: "destructive", title: "Save failed", description: error.message });
                            }
                          }}
                        />
                      </div>
                    )}

                    <div className="text-xs text-neutral-400">
                      <div className="font-medium mb-1">Feedback:</div>
                      {(feedback || []).filter(f => f.stopId === s.id).slice(0, 5).map(f => (
                        <div key={f.key} className="mb-1">
                          • <span className="text-white">{f.attendeeName || f.attendeeEmail}:</span> {f.feedback || f.questions}
                        </div>
                      ))}
                      {(feedback || []).filter(f => f.stopId === s.id).length === 0 && (
                        <div className="text-gray-500">No feedback yet</div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </Card>

        <Card className="card p-4 space-y-3">
          <div>
            <h3 className="text-sm font-medium text-gray-300 mb-2">Attendees</h3>
            <div className="space-y-1">
              {(pack.attendees || []).map((a, i) => (
                <div key={i} className="text-sm text-white">
                  {a.name || a.email} — {a.email}
                </div>
              ))}
              {(!pack.attendees || pack.attendees.length === 0) && (
                <div className="text-sm text-gray-500">No attendees added</div>
              )}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-medium text-gray-300 mb-2">Inspection Criteria</h3>
            <div className="space-y-1">
              {(pack.criteria || []).map((c, i) => (
                <div key={i} className="text-sm text-white flex items-start">
                  <span className="text-orange-400 mr-2">•</span>
                  {c}
                </div>
              ))}
              {(!pack.criteria || pack.criteria.length === 0) && (
                <div className="text-sm text-gray-500">No criteria specified</div>
              )}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-medium text-gray-300 mb-2">Quick Stats</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-gray-800/50 p-2 rounded">
                <div className="text-gray-400">Total Feedback</div>
                <div className="text-white font-medium">{feedback.length}</div>
              </div>
              <div className="bg-gray-800/50 p-2 rounded">
                <div className="text-gray-400">Duration</div>
                <div className="text-white font-medium">
                  {Math.round((new Date(pack.stops[pack.stops.length - 1]?.depart || pack.startISO) - new Date(pack.startISO)) / (1000 * 60))} min
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}