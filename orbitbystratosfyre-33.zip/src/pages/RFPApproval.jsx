
import React, { useState, useEffect, useCallback } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { RFPRequest } from "@/api/entities";
import { PropertySubmission } from "@/api/entities";
import { Client } from "@/api/entities";
import { SendEmail } from "@/api/integrations";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Loader2, CheckCircle, Edit, FileText, Building2, DollarSign, Send, Share2, ClipboardCopy, AlertTriangle } from "lucide-react";

export default function RFPApproval() {
    const [searchParams] = useSearchParams();
    const rfpId = searchParams.get('id');
    const token = searchParams.get('token');
    
    const [rfp, setRfp] = useState(null);
    const [client, setClient] = useState(null);
    const [submissions, setSubmissions] = useState([]);
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showRevisionDialog, setShowRevisionDialog] = useState(false);
    const [revisionNotes, setRevisionNotes] = useState("");

    const loadRfpData = useCallback(async () => {
        setLoading(true);
        try {
            const rfpData = await RFPRequest.get(rfpId);
            
            // Security check: if a token is present, it must match
            if (token && rfpData.share_token !== token) {
                setError("Invalid or expired link.");
                return;
            }

            setRfp(rfpData);

            const [clientData, submissionsData] = await Promise.all([
                Client.get(rfpData.client_id),
                Promise.all(rfpData.property_submissions.map(id => PropertySubmission.get(id)))
            ]);
            setClient(clientData);
            setSubmissions(submissionsData);

        } catch (err) {
            setError("Could not find the specified RFP request. The link may be invalid or expired.");
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, [rfpId, token]);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
            } catch (e) {
                setUser(null);
            }
        }
        fetchUser();
        if (rfpId) {
            loadRfpData();
        } else {
            setError("No RFP ID provided.");
            setLoading(false);
        }
    }, [rfpId, loadRfpData]);

    const handleApprove = async () => {
        setIsSubmitting(true);
        try {
            await RFPRequest.update(rfpId, { status: 'approved' });
            loadRfpData(); // Refresh data
        } catch (err) {
            alert("An error occurred while approving the RFP.");
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const handleRequestRevision = async () => {
        if (!revisionNotes.trim()) {
            alert("Please provide your feedback.");
            return;
        }
        setIsSubmitting(true);
        try {
            await RFPRequest.update(rfpId, { 
                status: 'needs_revision',
                client_approval_notes: revisionNotes
            });
            loadRfpData(); // Refresh data
            setShowRevisionDialog(false);
        } catch (err) {
            alert("An error occurred while submitting your revisions.");
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const handleIssueToAgents = async () => {
        if (!rfp || !submissions.length) return;
        
        setIsSubmitting(true);
        try {
            const agentEmails = [...new Set(submissions.map(s => s.agent_email).filter(Boolean))];
            
            // For now, send a generic email. This can be enhanced later.
            const subject = `Request for Proposal: ${client.company_name} Requirement`;
            const body = `Dear Agent,

We are seeking proposals for a property requirement on behalf of our client, ${client.company_name}.

Please review the attached information and submit your proposal by ${new Date(rfp.response_deadline).toLocaleDateString()}.

Further details on the specific properties we are requesting proposals for will be sent separately or can be accessed via our portal.

Thank you,
The Stratosfyre Team`;

            for (const email of agentEmails) {
                await SendEmail({ to: email, subject, body, from_name: "Stratosfyre ORBIT" });
            }

            await RFPRequest.update(rfpId, { status: 'issued', issued_date: new Date().toISOString() });
            loadRfpData(); // Refresh data
            alert("RFP has been issued to all relevant agents.");
        } catch(err) {
            alert("Failed to issue RFP to agents.");
            console.error(err);
        } finally {
            setIsSubmitting(false);
        }
    };

    const copyShareLink = () => {
        const link = `${window.location.origin}${createPageUrl(`RFPApproval?id=${rfpId}&token=${rfp.share_token}`)}`;
        navigator.clipboard.writeText(link);
        alert("Client approval link copied to clipboard!");
    };
    
    const canTakeAction = user?.user_type !== 'stratosfyre_admin' && (rfp?.status === 'pending_client_approval');
    const canIssue = user?.user_type === 'stratosfyre_admin' && rfp?.status === 'approved';

    if (loading) return <div className="min-h-screen bg-gray-900 flex items-center justify-center"><Loader2 className="w-12 h-12 text-amber-400 animate-spin" /></div>;
    if (error) return <div className="min-h-screen bg-gray-900 flex items-center justify-center text-center text-white p-8 orbit-card max-w-lg mx-auto">{error}</div>;

    const renderSupplementaryInfo = (info) => {
        const requestedItems = [];
        if (!info) return "None";
        Object.keys(info).forEach(key => {
            const section = info[key];
            if (typeof section === 'boolean' && section) {
                requestedItems.push(key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()));
            } else if (typeof section === 'object' && section?.enabled) {
                const subItems = Object.keys(section).filter(subKey => subKey !== 'enabled' && section[subKey]).map(sk => sk.replace(/_/g, ' '));
                requestedItems.push(`${key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}: ${subItems.join(', ')}`);
            }
        });
        return requestedItems.length > 0 ? (
            <ul className="list-disc list-inside text-sm text-gray-300">
                {requestedItems.map((item, i) => <li key={i}>{item}</li>)}
            </ul>
        ) : "None specified";
    };

    return (
        <div className="min-h-screen bg-gray-900 text-gray-200 p-4 sm:p-8">
            <div className="max-w-5xl mx-auto">
                <header className="text-center mb-8">
                    <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/688244252a7b37f0b4a1bcf9/9234d12f9_image.png" alt="ORBIT by Stratosfyre" className="w-48 mx-auto mb-4"/>
                    <h1 className="text-3xl font-bold text-white">Request for Proposal Review</h1>
                    <p className="text-gray-400">For: {client?.company_name}</p>
                </header>
                
                {/* Status Banner */}
                <div className="orbit-card bg-gray-800/60 p-4 text-center mb-8">
                    <h3 className="text-lg font-bold text-white">Status: <span className="text-amber-400">{rfp?.status.replace(/_/g, ' ').toUpperCase()}</span></h3>
                    {rfp?.status === 'needs_revision' && <p className="text-red-300 mt-2">Client has requested changes. Please review their notes and create a new RFP.</p>}
                </div>
                
                {/* Consultant View: Share Link */}
                {user?.user_type === 'stratosfyre_admin' && rfp?.status === 'pending_client_approval' && (
                    <div className="orbit-card p-6 mb-8 text-center">
                        <h3 className="text-xl font-semibold text-white mb-4">Share with Client</h3>
                        <p className="text-gray-300 mb-4">Send the following link to the client for their approval.</p>
                        <Button onClick={copyShareLink} className="orbit-button-active w-full sm:w-auto">
                            <ClipboardCopy className="w-4 h-4 mr-2" />
                            Copy Client Approval Link
                        </Button>
                    </div>
                )}
                
                {/* RFP Details */}
                <div className="space-y-6">
                    {submissions.map(sub => (
                        <div key={sub.id} className="orbit-card p-6">
                            <h3 className="text-xl font-semibold text-white mb-6 border-b border-gray-700 pb-3 flex items-center gap-3">
                                <Building2 className="text-amber-400"/> {sub.property_title}
                            </h3>
                            <p className="text-sm text-gray-400 mb-4">{sub.address}</p>
                            
                            <div className="grid md:grid-cols-2 gap-6">
                                <div>
                                    <h4 className="font-semibold text-white mb-2">Proposed Terms</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li className="flex gap-2"><span className="text-gray-400 w-32">Lease Term:</span> <span className="text-white">{rfp.terms.lease_term_years} years</span></li>
                                        <li className="flex gap-2"><span className="text-gray-400 w-32">Commencement:</span> <span className="text-white">{new Date(rfp.terms.lease_commencement_date).toLocaleDateString()}</span></li>
                                        <li className="flex gap-2"><span className="text-gray-400 w-32">Budget:</span> <span className="text-white">${rfp.terms.rental_budget_min?.toLocaleString()} - ${rfp.terms.rental_budget_max?.toLocaleString()}</span></li>
                                        <li className="flex gap-2"><span className="text-gray-400 w-32">Response By:</span> <span className="text-white">{new Date(rfp.response_deadline).toLocaleDateString()}</span></li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-white mb-2">Requested Information</h4>
                                    {renderSupplementaryInfo(rfp.requested_supplementary_info)}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Action Buttons */}
                <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
                    {canTakeAction && (
                        <>
                            <Dialog open={showRevisionDialog} onOpenChange={setShowRevisionDialog}>
                                <DialogTrigger asChild>
                                    <Button variant="outline" className="orbit-button text-gray-300 border-gray-600 hover:bg-gray-800 flex-grow sm:flex-grow-0" disabled={isSubmitting}>
                                        <Edit className="w-4 h-4 mr-2" />
                                        Request Revisions
                                    </Button>
                                </DialogTrigger>
                                <DialogContent className="orbit-card text-white">
                                    <DialogHeader>
                                        <DialogTitle>Request Revisions</DialogTitle>
                                    </DialogHeader>
                                    <div className="space-y-4">
                                        <Label>Please provide your feedback or requested changes below.</Label>
                                        <Textarea 
                                            value={revisionNotes}
                                            onChange={e => setRevisionNotes(e.target.value)}
                                            className="orbit-input h-40"
                                            placeholder="e.g., 'For 123 Main St, can we request a shorter lease term?'"
                                        />
                                    </div>
                                    <DialogFooter>
                                        <Button type="button" variant="ghost" onClick={() => setShowRevisionDialog(false)}>Cancel</Button>
                                        <Button onClick={handleRequestRevision} disabled={isSubmitting} className="bg-orange-500 hover:bg-orange-600 text-white">
                                            {isSubmitting ? <Loader2 className="animate-spin mr-2" /> : null}
                                            Submit Feedback
                                        </Button>
                                    </DialogFooter>
                                </DialogContent>
                            </Dialog>
                            <Button onClick={handleApprove} className="orbit-button-active flex-grow sm:flex-grow-0" disabled={isSubmitting}>
                                {isSubmitting ? <Loader2 className="animate-spin mr-2" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                                Approve RFP
                            </Button>
                        </>
                    )}
                    {canIssue && (
                        <Button onClick={handleIssueToAgents} className="orbit-button-active flex-grow sm:flex-grow-0 bg-green-600 hover:bg-green-700" disabled={isSubmitting}>
                           {isSubmitting ? <Loader2 className="animate-spin mr-2" /> : <Send className="w-4 h-4 mr-2" />}
                           Issue RFP to Agents
                       </Button>
                    )}
                </div>
            </div>
        </div>
    );
}
