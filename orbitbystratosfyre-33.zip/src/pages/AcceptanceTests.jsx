
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/components/ui/use-toast';
import { CheckCircle, XCircle, Play, Loader2, AlertTriangle, Target, Building, FileText, DollarSign, Users, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// Corrected Entity Imports
import { UserUnitPreference } from '@/api/entities';
import { UnitSettings } from '@/api/entities';
import { User } from '@/api/entities';
import { Building as BuildingEntity } from '@/api/entities';
import { Listing } from '@/api/entities';
import { ExtractedRecord } from '@/api/entities';
import { DueDiligence } from '@/api/entities';
import { DDProfile } from '@/api/entities';
import { DDMeasure } from '@/api/entities';
import { DevCase } from '@/api/entities';
import { Company } from '@/api/entities';
import { Scenario } from '@/api/entities';
import { CapitalOpportunity } from '@/api/entities';
import { DebtFacility } from '@/api/entities';
import { Engagement } from '@/api/entities';
import { Requirement } from '@/api/entities';
import { JobRun } from '@/api/entities';
import ContrastAuditor from '@/components/dev/ContrastAuditor';

const TestSuite = ({ title, icon: Icon, tests, onRunAll }) => {
  const [runningTests, setRunningTests] = useState(new Set());
  const [testResults, setTestResults] = useState({});

  const runTest = async (testId, testFn) => {
    setRunningTests(prev => new Set(prev.add(testId)));
    try {
      const result = await testFn();
      setTestResults(prev => ({ ...prev, [testId]: { success: true, message: result.message, data: result.data } }));
    } catch (error) {
      setTestResults(prev => ({ ...prev, [testId]: { success: false, message: error.message } }));
    } finally {
      setRunningTests(prev => {
        const newSet = new Set(prev);
        newSet.delete(testId);
        return newSet;
      });
    }
  };

  const runAllTests = async () => {
    for (const test of tests) {
      // Only run tests that have a testFn
      if (test.testFn) {
        await runTest(test.id, test.testFn);
      }
    }
    if (onRunAll) onRunAll();
  };

  return (
    <Card className="orbit-card">
      <CardHeader>
        <CardTitle className="flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <Icon className="w-5 h-5 text-orange-400" />
            {title}
          </div>
          <Button onClick={runAllTests} size="sm" className="orbit-button">
            <Play className="w-4 h-4 mr-2" />
            Run All
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {tests.map(test => (
          <div key={test.id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
            <div className="flex-1">
              <h4 className="text-white font-medium">{test.name}</h4>
              <p className="text-gray-400 text-sm">{test.description}</p>
              {testResults[test.id] && (
                <p className={`text-sm mt-1 ${testResults[test.id].success ? 'text-green-400' : 'text-red-400'}`}>
                  {testResults[test.id].message}
                </p>
              )}
            </div>
            <div className="flex items-center gap-2">
              {testResults[test.id] && (
                testResults[test.id].success ? 
                  <CheckCircle className="w-5 h-5 text-green-400" /> :
                  <XCircle className="w-5 h-5 text-red-400" />
              )}
              {test.testFn && ( // Only show run button for tests with testFn
                <Button 
                  onClick={() => runTest(test.id, test.testFn)}
                  disabled={runningTests.has(test.id)}
                  size="sm"
                  variant="outline"
                >
                  {runningTests.has(test.id) ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Play className="w-4 h-4" />
                  )}
                </Button>
              )}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default function AcceptanceTests() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [overallStatus, setOverallStatus] = useState('idle'); // idle, running, complete
  const [testSummary, setTestSummary] = useState({ passed: 0, failed: 0, total: 0 });

  // Test Suite 1: Units System
  const unitsTests = [
    {
      id: 'units-switch',
      name: 'Switch to USD/ft²/month',
      description: 'Change units and verify system-wide update',
      testFn: async () => {
        const user = await User.me();
        
        // Update user preferences to USD/ft²/month
        const [userPref] = await UserUnitPreference.filter({ user_id: user.id });
        if (userPref) {
          await UserUnitPreference.update(userPref.id, {
            currency: 'USD',
            area_unit: 'ft2',
            rent_unit: 'USD_per_ft2_pm'
          });
        } else {
          await UserUnitPreference.create({
            user_id: user.id,
            currency: 'USD',
            area_unit: 'ft2',
            rent_unit: 'USD_per_ft2_pm'
          });
        }
        
        return { 
          message: 'Units switched to USD/ft²/month successfully', 
          data: { currency: 'USD', area_unit: 'ft2', rent_unit: 'USD_per_ft2_pm' } 
        };
      }
    },
    {
      id: 'units-display',
      name: 'Verify Listings Display in New Units',
      description: 'Check that listings show converted values',
      testFn: async () => {
        const listings = await Listing.list();
        if (listings.length === 0) {
          throw new Error('No listings found to test unit conversion');
        }
        
        // Listings should now display in USD/ft²/month when rendered
        return { 
          message: `Found ${listings.length} listings that will display in new units`,
          data: { listingsCount: listings.length }
        };
      }
    }
  ];

  // Test Suite 2: PBLD (Property-Based Listing Database)
  const pbldTests = [
    {
      id: 'pbld-ingest',
      name: 'Ingest Source Data',
      description: 'Test source ingestion creates ExtractedRecords',
      testFn: async () => {
        // Simulate source ingestion
        const mockRecord = await ExtractedRecord.create({
            source_id: 'test-source',
            url: 'https://example.com/listing/123',
            fetched_at: new Date().toISOString(),
            raw_html: '<div>Test Property - 100sqm - $50/sqm</div>',
            title: 'Test Property',
            body_text: 'Test property description'
          });
        
        return { 
          message: 'Source data ingested successfully',
          data: { recordId: mockRecord.id }
        };
      }
    },
    {
      id: 'pbld-parse',
      name: 'Parse Extracted Records',
      description: 'Test AI parsing of raw HTML to structured data',
      testFn: async () => {
        const records = await ExtractedRecord.list();
        
        if (records.length === 0) {
          throw new Error('No extracted records to parse');
        }
        
        // Mock parsing result
        const record = records[0];
        await ExtractedRecord.update(record.id, {
          parsed_json: {
            address: "123 Test Street, Sydney NSW",
            area_sqm: 100,
            rent_pa: 5000,
            agent: "Test Agent"
          },
          extraction_confidence: 85
        });
        
        return { 
          message: 'Extracted records parsed successfully',
          data: { parsedCount: 1, confidence: 85 }
        };
      }
    },
    {
      id: 'pbld-buildings',
      name: 'Create Buildings from Parsed Data',
      description: 'Test building creation and photo assignment',
      testFn: async () => {
        const building = await BuildingEntity.create({
          canonical_name: 'Test Building',
          name: 'Test Building',
          address: '123 Test Street, Sydney NSW',
          suburb: 'Sydney',
          type: 'Office',
          grade: 'A',
          image_url: 'https://example.com/building.jpg'
        });
        
        return { 
          message: 'Building created successfully with photo',
          data: { buildingId: building.id }
        };
      }
    }
  ];

  // Test Suite 3: Due Diligence
  const ddTests = [
    {
      id: 'dd-create',
      name: 'Create DD Assessment',
      description: 'Test DD creation for PowerIntensive profile',
      testFn: async () => {
        const user = await User.me();
        
        // Find or create PowerIntensive profile
        let profile = (await DDProfile.list()).find(p => p.name === 'PowerIntensive');
        if (!profile) {
          profile = await DDProfile.create({
            name: 'PowerIntensive',
            checklist_json: {
              items: [
                { category: 'Electrical', description: 'Power capacity check', severity_weight: 5 }
              ]
            },
            utilities_required_json: { power_kVA_min: 500 }
          });
        }
        
        const buildings = await BuildingEntity.list();
        if (buildings.length === 0) {
          throw new Error('No buildings available for DD assessment');
        }
        
        const dd = await DueDiligence.create({
          building_id: buildings[0].id,
          profile_id: profile.id,
          assessor_id: user.id,
          started_at: new Date().toISOString(),
          status: 'active'
        });
        
        return { 
          message: 'DD assessment created for PowerIntensive profile',
          data: { ddId: dd.id, profile: 'PowerIntensive' }
        };
      }
    },
    {
      id: 'dd-measures',
      name: 'Record DD Measures',
      description: 'Test recording of technical measurements',
      testFn: async () => {
        const ddList = await DueDiligence.list();
        
        if (ddList.length === 0) {
          throw new Error('No DD assessments found');
        }
        
        const dd = ddList[0];
        const measure = await DDMeasure.create({
          dd_id: dd.id,
          metric: 'power_kVA',
          measured_value: 750,
          unit: 'kVA',
          within_spec: true
        });
        
        return { 
          message: 'DD measures recorded successfully',
          data: { measureId: measure.id, value: 750, unit: 'kVA' }
        };
      }
    }
  ];

  // Test Suite 4: Development Cases
  const devTests = [
    {
      id: 'dev-create',
      name: 'Create DevCase',
      description: 'Test development case creation',
      testFn: async () => {
        const user = await User.me();
        const companies = await Company.list();
        
        let company;
        if (companies.length === 0) {
          company = await Company.create({
            name: 'Test Development Company',
            sector: 'Other'
          });
        } else {
          company = companies[0];
        }
        
        const devCase = await DevCase.create({
          company_id: company.id,
          name: 'Test Development Case',
          owner_user_id: user.id,
          state: 'Analysis'
        });
        
        return { 
          message: 'DevCase created successfully',
          data: { devCaseId: devCase.id, state: 'Analysis' }
        };
      }
    },
    {
      id: 'dev-scenarios',
      name: 'Add Lease/Buy/Develop Scenarios',
      description: 'Test adding multiple scenarios for comparison',
      testFn: async () => {
        const devCases = await DevCase.list();
        if (devCases.length === 0) {
          throw new Error('No DevCases found');
        }
        
        const devCase = devCases[0];
        
        // Create three scenarios with correct field names
        const scenarios = await Promise.all([
          Scenario.create({
            devcase_id: devCase.id,
            type: 'Lease',
            name: 'Lease Scenario',
            inputs_json: {
              area_m2: 1000,
              rent_aud_per_m2_pa: 500,
              term_years: 5,
              fitout_capex_aud: 200000
            }
          }),
          Scenario.create({
            devcase_id: devCase.id,
            type: 'Buy',
            name: 'Buy Scenario',
            inputs_json: {
              price_aud: 2000000,
              fitout_capex_aud: 200000,
              holding_years: 10
            }
          }),
          Scenario.create({
            devcase_id: devCase.id,
            type: 'Develop',
            name: 'Develop Scenario',
            inputs_json: {
              land_cost_aud: 1000000,
              hard_cost_aud: 1500000,
              construction_months: 18
            }
          })
        ]);
        
        return { 
          message: 'All three scenarios created successfully',
          data: { scenarioCount: scenarios.length, types: ['Lease', 'Buy', 'Develop'] }
        };
      }
    }
  ];

  // Test Suite 5: Finance & Capital Markets
  const financeTests = [
    {
      id: 'finance-opportunity',
      name: 'Create Capital Opportunity',
      description: 'Test capital opportunity creation',
      testFn: async () => {
        const user = await User.me();
        const devCases = await DevCase.list();
        
        if (devCases.length === 0) {
          throw new Error('No DevCases found for finance opportunity');
        }
        
        const opportunity = await CapitalOpportunity.create({
          devcase_id: devCases[0].id,
          name: 'Test Capital Raise',
          type: 'Debt',
          owner_user_id: user.id,
          stage: 'Prospecting'
        });
        
        return { 
          message: 'Capital opportunity created successfully',
          data: { opportunityId: opportunity.id, type: 'Debt' }
        };
      }
    },
    {
      id: 'finance-debt-sizing',
      name: 'Compute Debt Sizing',
      description: 'Test automated debt sizing calculation',
      testFn: async () => {
        const opportunities = await CapitalOpportunity.list();
        if (opportunities.length === 0) {
          throw new Error('No capital opportunities found');
        }
        
        const opportunity = opportunities[0];
        
        // Create debt facility with calculated sizing
        const facility = await DebtFacility.create({
          opportunity_id: opportunity.id,
          amount_aud: 1500000,
          rate_pct: 5.5,
          ltv_max: 0.70,
          dscr_min: 1.25,
          status: 'drafting'
        });
        
        return { 
          message: 'Debt sizing computed and facility created',
          data: { facilityId: facility.id, amount: 1500000, ltv: 0.70 }
        };
      }
    }
  ];

  // Test Suite 6: Engagement Spine
  const spineTests = [
    {
      id: 'spine-engagement',
      name: 'Create Fast-Track Engagement',
      description: 'Test engagement creation with fast_track bypass',
      testFn: async () => {
        const user = await User.me();
        const companies = await Company.list();
        
        let company;
        if (companies.length === 0) {
          company = await Company.create({
            name: 'Test Engagement Company',
            sector: 'SaaS'
          });
        } else {
          company = companies[0];
        }
        
        const engagement = await Engagement.create({
          company_id: company.id,
          owner_user_id: user.id,
          sector: 'SaaS',
          state: 'Qualified',
          fast_track: true,
          last_state_change: new Date().toISOString(),
          gates: {
            requirements_ok: false,
            brief_ok: false,
            market_scan_ok: false,
            boardpack_v1_ok: false,
            boardpack_v2_ok: false,
            rfp_ok: false,
            offers_norm_ok: false,
            hoa_ok: false,
            lease_pack_ok: false
          }
        });
        
        return { 
          message: 'Fast-track engagement created successfully',
          data: { engagementId: engagement.id, fastTrack: true }
        };
      }
    },
    {
      id: 'spine-requirements',
      name: 'Create Requirements Document',
      description: 'Test requirements creation and gate activation',
      testFn: async () => {
        const engagements = await Engagement.list();
        if (engagements.length === 0) {
          throw new Error('No engagements found');
        }
        
        const engagement = engagements[0];
        
        const requirement = await Requirement.create({
          engagement_id: engagement.id,
          area_need_m2: 1000,
          timing_quarter: 'Q2 2024',
          location_preferences: ['Sydney CBD', 'North Sydney'],
          building_grade: ['A', 'Premium'],
          budget_max_aud_per_m2_pa: 600,
          lease_term_years: 5
        });
        
        // Update engagement gate
        await Engagement.update(engagement.id, {
          gates: {
            ...engagement.gates,
            requirements_ok: true
          }
        });
        
        return { 
          message: 'Requirements created and gate activated',
          data: { requirementId: requirement.id, gateOpen: true }
        };
      }
    }
  ];

  // Test Suite 7: Admin Console
  const adminTests = [
    {
      id: 'admin-job-run',
      name: 'Verify Job Logging',
      description: 'Test JobRun creation and logging',
      testFn: async () => {
        const jobs = await JobRun.list('-started_at', 5);
        
        if (jobs.length === 0) {
          throw new Error('No job runs found - run some jobs from Admin Console first');
        }
        
        const latestJob = jobs[0];
        
        return { 
          message: `Found ${jobs.length} job runs, latest: ${latestJob.job_name}`,
          data: { jobCount: jobs.length, latestJob: latestJob.job_name, status: latestJob.status }
        };
      }
    },
    {
      id: 'admin-data-quality',
      name: 'Data Quality Validation',
      description: 'Test data quality checks and validation',
      testFn: async () => {
        const buildings = await BuildingEntity.list();
        const duplicates = buildings.filter((building, index, arr) => 
          arr.findIndex(b => b.address?.toLowerCase() === building.address?.toLowerCase()) !== index
        ).length;
        
        const withoutImages = buildings.filter(b => !b.image_url).length;
        
        return { 
          message: `Data quality check: ${duplicates} duplicates, ${withoutImages} missing images`,
          data: { duplicates, missingImages: withoutImages, totalBuildings: buildings.length }
        };
      }
    }
  ];

  // Define the contrast audit test component
  const contrastTest = {
    id: 'ui-contrast-audit', // Added an ID for consistency if ever used in a list
    name: "Contrast Compliance Audit",
    description: "Scan for WCAG AA contrast ratio compliance issues across the current page.",
    component: ContrastAuditor
  };

  // This `allTests` variable was specified in the outline, though its usage is not fully defined
  // in the context of the existing `allTestSuites` structure. For now, it holds the `contrastTest`.
  const allTests = [
    contrastTest
  ];

  const allTestSuites = [
    { title: 'Units System', icon: DollarSign, tests: unitsTests },
    { title: 'PBLD Pipeline', icon: Building, tests: pbldTests },
    { title: 'Due Diligence', icon: FileText, tests: ddTests },
    { title: 'Development Cases', icon: Target, tests: devTests },
    { title: 'Finance & Capital', icon: DollarSign, tests: financeTests },
    { title: 'Engagement Spine', icon: Users, tests: spineTests },
    { title: 'Admin Console', icon: Zap, tests: adminTests }
  ];

  const runAllTests = async () => {
    setOverallStatus('running');
    let passed = 0;
    let failed = 0;
    let total = 0;

    for (const suite of allTestSuites) {
      for (const test of suite.tests) {
        // Only run tests that have a testFn
        if (test.testFn) {
          total++;
          try {
            await test.testFn();
            passed++;
          } catch (error) {
            failed++;
            console.error(`Test failed: ${test.name}`, error);
          }
        }
      }
    }

    setTestSummary({ passed, failed, total });
    setOverallStatus('complete');
    
    toast({
      title: 'Acceptance Tests Complete',
      description: `${passed}/${total} tests passed`,
      variant: passed === total ? 'default' : 'destructive'
    });
  };

  return (
    <div className="p-4 sm:p-8 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">ORBIT Acceptance Tests</h1>
          <p className="text-gray-300 mb-4">
            End-to-end validation of all system components and workflows.
          </p>
          
          <div className="flex items-center gap-4 mb-6">
            <Button onClick={runAllTests} disabled={overallStatus === 'running'} className="orbit-button bg-orange-500 hover:bg-orange-600">
              {overallStatus === 'running' ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Play className="w-4 h-4 mr-2" />
              )}
              Run All Tests
            </Button>
            
            {overallStatus === 'complete' && (
              <div className="flex items-center gap-2">
                {testSummary.failed === 0 ? (
                  <CheckCircle className="w-5 h-5 text-green-400" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-yellow-400" />
                )}
                <span className="text-white font-medium">
                  {testSummary.passed}/{testSummary.total} tests passed
                </span>
              </div>
            )}
          </div>

          <Alert className="mb-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              These tests validate the integration between all ORBIT modules. Run them after deploying changes to ensure system integrity.
              Some tests require existing data or previous test completion to function correctly.
            </AlertDescription>
          </Alert>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {allTestSuites.map((suite, index) => (
            <TestSuite
              key={index}
              title={suite.title}
              icon={suite.icon}
              tests={suite.tests}
            />
          ))}
        </div>

        {/* New: Contrast Audit Section */}
        {allTests.map((testItem) => (
          testItem.component && (
            <Card key={testItem.id} className="orbit-card mt-8">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Zap className="w-5 h-5 text-purple-400" /> 
                    {testItem.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300 space-y-4">
                <p>{testItem.description}</p>
                {/* Render the component for audit */}
                <testItem.component />
              </CardContent>
            </Card>
          )
        ))}

        {/* Test Documentation */}
        <Card className="orbit-card mt-8">
          <CardHeader>
            <CardTitle className="text-white">Test Documentation</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-4">
            <div>
              <h4 className="font-semibold text-white mb-2">Prerequisites:</h4>
              <ul className="list-disc list-inside text-sm space-y-1">
                <li>User must be logged in as stratosfyre_admin</li>
                <li>AI service must be available for parsing tests</li>
                <li>Some tests depend on data created by previous tests</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-2">Expected Results:</h4>
              <ul className="list-disc list-inside text-sm space-y-1">
                <li><strong>Units:</strong> All financial displays should update to show USD/ft²/month</li>
                <li><strong>PBLD:</strong> Buildings and listings should appear with photos after ingestion</li>
                <li><strong>DD:</strong> Due diligence assessments should generate pass/fail badges</li>
                <li><strong>Dev:</strong> Scenarios should rank by NPV/IRR in decision matrix</li>
                <li><strong>Finance:</strong> Debt sizing should respect LTV/DSCR constraints</li>
                <li><strong>Spine:</strong> Each gate should enforce proper document creation</li>
                <li><strong>Admin:</strong> All jobs should create JobRun records with proper status</li>
                <li><strong>Contrast Audit:</strong> The Contrast Auditor component will scan the page and display WCAG AA compliance issues interactively.</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
