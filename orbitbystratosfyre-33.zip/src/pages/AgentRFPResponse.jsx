import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { RFPRequest } from '@/api/entities';
import { RFPResponse } from '@/api/entities';
import { PropertySubmission } from '@/api/entities';
import { Document } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Loader2, Upload, FileText, Send, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from "@/components/ui/use-toast";

export default function AgentRFPResponse() {
    const [rfp, setRfp] = useState(null);
    const [property, setProperty] = useState(null);
    const [response, setResponse] = useState({ headline_terms: {} });
    const [hoaFile, setHoaFile] = useState(null);
    const [loading, setLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const location = useLocation();
    const { toast } = useToast();

    useEffect(() => {
        const loadData = async () => {
            const params = new URLSearchParams(location.search);
            const rfpId = params.get('rfpId');
            const subId = params.get('subId'); // PropertySubmission ID
            if (!rfpId || !subId) {
                setLoading(false);
                return;
            }
            try {
                const rfpData = await RFPRequest.get(rfpId);
                setRfp(rfpData);
                const propertyData = await PropertySubmission.get(subId);
                setProperty(propertyData);
            } catch (error) {
                console.error("Error loading RFP data:", error);
            } finally {
                setLoading(false);
            }
        };
        loadData();
    }, [location.search]);

    const handleInputChange = (field, value) => {
        setResponse(prev => ({
            ...prev,
            headline_terms: { ...prev.headline_terms, [field]: value }
        }));
    };

    const handleFileChange = (e) => {
        setHoaFile(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!hoaFile) {
            toast({ variant: 'destructive', title: "Please upload the Heads of Agreement." });
            return;
        }
        setIsSubmitting(true);
        try {
            const { file_url } = await UploadFile({ file: hoaFile });
            
            // Create a document record for the HOA
            const hoaDoc = await Document.create({
                client_id: rfp.client_id,
                brief_id: rfp.brief_id,
                rfp_id: rfp.id,
                document_name: `HOA - ${property.property_title} - ${new Date().toLocaleDateString()}`,
                document_type: 'heads_of_agreement',
                file_url: file_url,
                uploaded_by: property.agent_email || 'agent',
                is_client_visible: false, // Internal first
                description: `Heads of Agreement submitted by ${property.agent_name}.`,
            });
            
            await RFPResponse.create({
                rfp_request_id: rfp.id,
                property_submission_id: property.id,
                agent_email: property.agent_email,
                headline_terms: response.headline_terms,
                heads_of_agreement_url: file_url,
                heads_of_agreement_document_id: hoaDoc.id, // Link to the document
                status: 'submitted',
                submitted_date: new Date().toISOString(),
            });

            setSubmitted(true);
        } catch (error) {
            console.error("Error submitting response:", error);
            toast({ variant: "destructive", title: "Submission Failed" });
        } finally {
            setIsSubmitting(false);
        }
    };
    
    if (loading) return <div className="flex items-center justify-center h-screen bg-gray-900"><Loader2 className="w-12 h-12 animate-spin text-orange-400" /></div>;
    if (!rfp || !property) return <div className="flex items-center justify-center h-screen bg-gray-900 text-red-500 p-8 text-center">Invalid RFP link. Please contact the sender.</div>;

    if (submitted) {
        return (
            <div className="flex items-center justify-center h-screen bg-gray-900 text-white">
                <div className="text-center p-12 orbit-card max-w-lg">
                    <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                    <h1 className="text-2xl font-bold">Response Submitted Successfully</h1>
                    <p className="text-gray-300 mt-2">Thank you for your proposal for {property.property_title}. The Stratosfyre team will be in touch shortly.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="bg-gray-900 min-h-screen text-white p-8">
            <div className="max-w-3xl mx-auto">
                <header className="text-center mb-8">
                    <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/688244252a7b37f0b4a1bcf9/9234d12f9_image.png" alt="ORBIT by Stratosfyre" className="w-40 mx-auto mb-4"/>
                    <h1 className="text-3xl font-bold">RFP Response</h1>
                    <p className="text-gray-300">For: {property.property_title}</p>
                </header>
                <form onSubmit={handleSubmit} className="space-y-6 orbit-card p-8">
                    <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Headline Commercial Terms</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2"><Label>Net Face Rent ($/sqm)</Label><Input type="number" onChange={e => handleInputChange('net_face_rent', e.target.value)} required className="orbit-input"/></div>
                            <div className="space-y-2"><Label>Outgoings ($/sqm)</Label><Input type="number" onChange={e => handleInputChange('outgoings', e.target.value)} required className="orbit-input"/></div>
                            <div className="space-y-2"><Label>Incentive (%)</Label><Input type="number" onChange={e => handleInputChange('incentive_percentage', e.target.value)} required className="orbit-input"/></div>
                            <div className="space-y-2"><Label>Lease Term (Years)</Label><Input type="number" onChange={e => handleInputChange('lease_term', e.target.value)} required className="orbit-input"/></div>
                        </div>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Upload Heads of Agreement</h3>
                         <Label htmlFor="hoa-upload" className="flex flex-col items-center justify-center w-full h-40 border-2 border-gray-600 border-dashed rounded-lg cursor-pointer bg-gray-800/50 hover:bg-gray-800">
                            <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                <Upload className="w-8 h-8 mb-4 text-gray-400"/>
                                <p className="mb-2 text-sm text-gray-400"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                                <p className="text-xs text-gray-500">PDF, DOCX (MAX. 10MB)</p>
                            </div>
                            <Input id="hoa-upload" type="file" className="hidden" onChange={handleFileChange} accept=".pdf,.doc,.docx"/>
                        </Label>
                        {hoaFile && <p className="mt-2 text-sm text-green-400 flex items-center gap-2"><FileText className="w-4 h-4"/>{hoaFile.name}</p>}
                    </div>
                     <Button type="submit" disabled={isSubmitting} className="w-full orbit-button-active text-lg py-3">
                        {isSubmitting ? <Loader2 className="animate-spin" /> : <><Send className="w-5 h-5 mr-2" /> Submit Response</>}
                    </Button>
                </form>
            </div>
        </div>
    );
}