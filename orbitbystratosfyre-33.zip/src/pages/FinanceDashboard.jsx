
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, PlusCircle, BarChart2, FileText, Landmark, Banknote, AlertTriangle, CalendarCheck } from 'lucide-react';
import { CapitalOpportunity } from '@/api/entities';
import { DebtFacility } from '@/api/entities';
import { Drawdown } from '@/api/entities';
import { Scenario } from '@/api/entities';
import { runJob } from '@/components/utils/runJob';
import { UnitsBar } from '@/components/ui/UnitsBar';
import { useToast } from '@/components/ui/use-toast';
import { createPageUrl } from '@/utils';
import { useNavigate } from 'react-router-dom';

const STAGES = ["Prospecting", "Teaser", "IOIs", "TermSheet", "Closing", "Closed"];

const FinanceDashboard = () => {
    const { toast } = useToast();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [opportunities, setOpportunities] = useState([]); // Initialize as empty to show empty state on first load
    const [facilities, setFacilities] = useState([]);
    const [drawdowns, setDrawdowns] = useState([]);

    // Function to load all dashboard data
    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const [fetchedOpportunities, fetchedFacilities, fetchedDrawdowns] = await Promise.all([
                CapitalOpportunity.list('-created_date'),
                DebtFacility.list('-created_date'),
                Drawdown.list('-date')
            ]);
            setOpportunities(fetchedOpportunities || []);
            setFacilities(fetchedFacilities || []);
            setDrawdowns(fetchedDrawdowns || []);
        } catch (error) {
            console.error("Failed to load dashboard data:", error);
            toast({
                variant: "destructive",
                title: "Data Load Failed",
                description: "Could not load dashboard data."
            });
        } finally {
            setLoading(false);
        }
    }, [toast]); // `toast` is stable but ESLint might want it here.

    // Initial data load on component mount
    useEffect(() => {
        loadData();
    }, [loadData]); // `loadData` is now a stable function due to useCallback

    // Helper function for computing sizing for a single scenario
    const computeSizing = useCallback(async (scenario) => {
        // This logic should be moved to a backend job for production
        // For now, it runs client-side within a runJob wrapper for consistency
        const logic = async (payload) => {
            const { scenario: currentScenario } = payload;
            
            // Simplified example - replace with your detailed financial models
            const exit_cap_rate_pct = 5.0; // 5% exit cap rate
            const minDSCR = 1.5;           // Minimum Debt Service Coverage Ratio
            const maxLTV = 0.6;            // Maximum Loan-to-Value
            const maxLTC = 0.7;            // Maximum Loan-to-Cost
            const rate = 0.06;             // 6% interest rate for DSCR calculation
            
            const { inputs_json = {}, outputs_json = {} } = currentScenario;
            const totalCost = inputs_json.total_project_cost || 50000000; // Default total cost if not specified
            
            let NOI = 0;
            // Determine NOI based on scenario type or default
            if (currentScenario.type === 'Lease') {
                NOI = (inputs_json.rent_per_sqm || 800) * (inputs_json.area_sqm || 5000);
            } else { // 'Buy' or 'Develop' or other types
                NOI = (inputs_json.stabilized_noi || 3500000); // Default stabilized NOI
            }
            
            const value = NOI / (exit_cap_rate_pct / 100);
            const sizeByDSCR = NOI / minDSCR / rate;
            const sizeByLTV = value * maxLTV;
            const sizeByLTC = totalCost * maxLTC;
            
            const recommendedFacility = Math.min(sizeByDSCR, sizeByLTV, sizeByLTC);

            // Update the scenario with computed sizing outputs
            await Scenario.update(currentScenario.id, { 
                outputs_json: {
                    ...outputs_json, // Preserve existing outputs
                    facility_size_dscr: sizeByDSCR,
                    facility_size_ltv: sizeByLTV,
                    facility_size_ltc: sizeByLTC,
                    recommended_facility: recommendedFacility,
                    estimated_value: value,
                    noi: NOI,
                }
            });
            return { rows_affected: 1, notes: `Sized facility at $${Math.round(recommendedFacility/1000000)}M for ${currentScenario.name}` };
        };
        
        await runJob(`Compute Sizing: ${scenario.name}`, logic, { scenario });
    }, []); // Scenario.update and runJob are stable imports, no need to add to dependencies

    const handleComputeSizing = useCallback(async () => {
        setLoading(true); // Indicate overall loading for the operation
        try {
            // Fetch all scenarios to compute sizing for
            const scenarios = await Scenario.list(); 
            
            if (scenarios.length === 0) {
                toast({
                    title: "No Scenarios Found",
                    description: "Please create development scenarios before computing sizing.",
                    variant: "destructive"
                });
                return;
            }

            // Run sizing for each scenario concurrently
            const sizingPromises = scenarios.map(scenario => computeSizing(scenario));
            await Promise.all(sizingPromises); 
            
            toast({
                title: "Sizing Complete",
                description: `Computed debt sizing for ${scenarios.length} scenarios.`,
                variant: "default"
            });
            
            loadData(); // Refresh dashboard data to potentially reflect changes (e.g., if any UI elements depend on scenario outputs)
            
        } catch (error) {
            console.error('Sizing calculation failed:', error);
            toast({
                variant: "destructive",
                title: "Sizing Failed",
                description: `Unable to compute debt sizing. Error: ${error.message}`
            });
        } finally {
            setLoading(false); // End overall loading
        }
    }, [computeSizing, toast, loadData]); // Add all functions and props used inside to dependencies

    const handleActionClick = (actionName) => {
        if (actionName === 'Compute Sizing') {
            handleComputeSizing();
        } else if (actionName === 'Add Opportunity') {
            navigate(createPageUrl('CreateCapitalOpportunity'));
        } else if (actionName === 'Add Facility/Offer') {
            navigate(createPageUrl('CreateDebtFacility'));
        } else if (actionName === 'Export Finance Pack') {
            runJob('Export Finance Pack', async () => {
                const csvData = opportunities.map(opp => ({
                    ID: opp.id,
                    Name: opp.name,
                    Type: opp.type,
                    Stage: opp.stage,
                    Created: opp.created_date ? new Date(opp.created_date).toLocaleDateString() : 'N/A'
                }));
                
                const headers = Object.keys(csvData[0] || {}).join(',');
                const rows = csvData.map(row => Object.values(row).map(val => `"${String(val).replace(/"/g, '""')}"`).join(',')).join('\n'); // Safely quote and escape
                const csvString = `${headers}\n${rows}`;
                
                const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
                const link = document.createElement("a");
                const url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", "finance_pack.csv");
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url); // Clean up
                
                return { rows_affected: csvData.length, notes: 'Exported finance pack to CSV.' };
            });
            toast({ title: 'Exporting...', description: 'Finance pack is being generated.' });
        } else {
            toast({
                title: 'Action Triggered',
                description: `${actionName} has been initiated.`,
            });
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen">
                <UnitsBar />
                <div className="flex justify-center p-8">
                    <div className="space-y-4 w-full max-w-6xl">
                        <div className="h-8 bg-gray-800/50 animate-pulse rounded-lg w-1/3"></div>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <div className="h-64 bg-gray-800/50 animate-pulse rounded-lg"></div>
                            <div className="h-64 bg-gray-800/50 animate-pulse rounded-lg"></div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
    
    return (
        <div className="p-4 sm:p-6 md:p-8 min-h-screen"> {/* Added min-h-screen */}
            <UnitsBar />
            <div className="max-w-7xl mx-auto"> {/* Added max-w-7xl mx-auto wrapper */}
                <header className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-8"> {/* Added mb-8 */}
                    <h1 className="text-3xl font-bold text-white">Finance Dashboard</h1>
                    <div className="flex flex-wrap gap-2">
                        <Button variant="outline" className="orbit-button border-gray-600 text-gray-300" onClick={() => handleActionClick('Add Opportunity')}>
                            <PlusCircle className="w-4 h-4 mr-2" />Add Opportunity
                        </Button>
                        <Button variant="outline" className="orbit-button border-gray-600 text-gray-300" onClick={() => handleActionClick('Add Facility/Offer')}>
                            <Landmark className="w-4 h-4 mr-2" />Add Facility/Offer
                        </Button>
                        <Button className="orbit-button bg-blue-600 hover:bg-blue-700" onClick={() => handleActionClick('Compute Sizing')}>
                            <BarChart2 className="w-4 h-4 mr-2" />Compute Sizing
                        </Button>
                        <Button variant="outline" className="orbit-button border-green-600 text-green-300" onClick={() => handleActionClick('Export Finance Pack')}>
                            <FileText className="w-4 h-4 mr-2" />Export Finance Pack
                        </Button>
                    </div>
                </header>

                {/* Empty State Example */}
                {opportunities.length === 0 && !loading && (
                    <Card className="orbit-card">
                        <CardContent className="py-16">
                            <div className="text-center">
                                <div className="text-sm text-gray-400 p-6 border border-dashed border-gray-700 rounded-lg max-w-md mx-auto">
                                    <Landmark className="w-12 h-12 mx-auto text-gray-500 mb-4"/>
                                    <h3 className="text-xl font-semibold text-white mb-2">No Finance Opportunities</h3>
                                    <p className="mb-4">Start by adding your first capital opportunity.</p>
                                    <Button onClick={() => handleActionClick('Add Opportunity')} className="orbit-button bg-blue-600 hover:bg-blue-700">
                                        <PlusCircle className="w-4 h-4 mr-2" />Add Opportunity
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}

                {opportunities.length > 0 && (
                    <>
                        <Card className="orbit-card mb-8"> {/* Added mb-8 */}
                            <CardHeader><CardTitle className="text-white">Capital Opportunities Pipeline</CardTitle></CardHeader>
                            <CardContent>
                                <div className="flex space-x-2 overflow-x-auto p-2">
                                    {STAGES.map(stage => (
                                        <div key={stage} className="flex-shrink-0 w-64 bg-gray-800/50 rounded-lg p-3">
                                            <h3 className="font-semibold text-gray-300 mb-3">{stage}</h3>
                                            <div className="space-y-2">
                                                {opportunities.filter(op => op.stage === stage).map(op => (
                                                    <div key={op.id} className="bg-gray-900/70 p-3 rounded-lg shadow">
                                                        <p className="font-semibold text-sm text-white">{op.name}</p>
                                                        <Badge variant="secondary" className="mt-1 text-xs">{op.type}</Badge>
                                                    </div>
                                                ))}
                                                {opportunities.filter(op => op.stage === stage).length === 0 && (
                                                    <div className="text-xs text-center text-gray-500 py-4">Empty</div>
                                                )}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        <div className="grid md:grid-cols-2 gap-8">
                            <Card className="orbit-card">
                                <CardHeader><CardTitle className="text-white">Facilities & Covenant Watchlist</CardTitle></CardHeader>
                                <CardContent className="space-y-4">
                                    {facilities.map(fac => (
                                        <div key={fac.id} className="bg-gray-800/50 p-4 rounded-lg">
                                            <h4 className="font-bold text-white">{fac.name || 'Unnamed Facility'}</h4>
                                            <div className="flex gap-2 mt-2">
                                                {(fac.covenants || []).map((cov, i) => (
                                                    <Badge key={i} variant={cov.status === 'watch' ? 'destructive' : 'default'} className={cov.status === 'ok' ? 'bg-green-500/80' : ''}>
                                                        {cov.status === 'watch' && <AlertTriangle className="w-3 h-3 mr-1" />}
                                                        {cov.metric}: {cov.status}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                    {facilities.length === 0 && (
                                        <p className="text-gray-400 text-sm text-center py-4">No facilities currently monitored.</p>
                                    )}
                                </CardContent>
                            </Card>

                            <Card className="orbit-card">
                                <CardHeader><CardTitle className="text-white">Upcoming CPs & Drawdowns</CardTitle></CardHeader>
                                <CardContent className="space-y-3">
                                    {drawdowns.map(draw => (
                                        <div key={draw.id} className="flex items-center justify-between bg-gray-800/50 p-3 rounded-lg">
                                            <div>
                                                <p className="font-semibold text-white">{draw.name || `Tranche ${draw.tranche_no}`}</p>
                                                <p className="text-sm text-gray-400">A${(draw.amount_aud / 1000000).toFixed(1)}M</p>
                                            </div>
                                            <div className="flex items-center gap-2 text-sm text-gray-300">
                                                <CalendarCheck className="w-4 h-4"/>
                                                <span>{new Date(draw.date).toLocaleDateString()}</span>
                                            </div>
                                        </div>
                                    ))}
                                    {drawdowns.length === 0 && (
                                        <p className="text-gray-400 text-sm text-center py-4">No upcoming drawdowns or CPs.</p>
                                    )}
                                </CardContent>
                            </Card>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default FinanceDashboard;
