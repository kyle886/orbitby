
import React, { useState, useEffect, useCallback } from 'react';
import { InboundRecommendation } from '@/api/entities';
import { InboundCampaign } from '@/api/entities';
import { ContentIdea } from '@/api/entities';
import { SocialPost } from '@/api/entities';
import { User } from '@/api/entities';
import { callAIGuarded } from "@/components/utils/ai/aiGuard";
import { runJob } from '@/components/utils/runJob';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Loader2, Lightbulb, Calendar, Target, Zap, TrendingUp, Users, CheckCircle, Clock, AlertTriangle, FileText, Share2
} from 'lucide-react';
import { PlaybookAction } from '@/api/entities';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription } from '@/components/ui/alert';


const RecommendationCard = ({ recommendation, onStatusChange, onViewContent, onCreateDraft }) => {
  const [showScheduleDialog, setShowScheduleDialog] = useState(false);
  const [showComplianceDialog, setShowComplianceDialog] = useState(false);
  const [scheduledDateTime, setScheduledDateTime] = useState('');
  const [selectedChannel, setSelectedChannel] = useState('');
  const [sanitisationChecked, setSanitisationChecked] = useState(false);
  const [complianceNote, setComplianceNote] = useState('');

  const getStatusColor = (status) => {
    const colors = {
      draft: 'bg-gray-500/20 text-gray-300',
      approved: 'bg-green-500/20 text-green-300',
      scheduled: 'bg-blue-500/20 text-blue-300',
      done: 'bg-purple-500/20 text-purple-300',
      discarded: 'bg-red-500/20 text-red-300'
    };
    return colors[status] || colors.draft;
  };

  const getEffortIcon = (effort) => {
    if (effort === 'low') return <Zap className="w-3 h-3 text-green-400" />;
    if (effort === 'med') return <Clock className="w-3 h-3 text-yellow-400" />;
    return <Clock className="w-3 h-3 text-red-400" />;
  };

  const getBadges = (rec) => {
    const badges = [];
    if (rec.effort === 'low') badges.push({ text: 'LOW EFFORT', color: 'bg-green-500/20 text-green-300' });
    if (rec.source_refs?.event_id) badges.push({ text: 'EVENT TIE-IN', color: 'bg-blue-500/20 text-blue-300' });
    if (rec.source_refs?.target_overlap > 0.7) badges.push({ text: 'TOP-20 MATCH', color: 'bg-orange-500/20 text-orange-300' });
    if (rec.source_refs?.lease_ids?.length > 0) badges.push({ text: 'LEASE CLUSTER', color: 'bg-purple-500/20 text-purple-300' });
    return badges;
  };

  const handleApprove = async () => {
    if (recommendation.status === 'draft') {
      // Check if compliance review is needed
      const needsCompliance = recommendation.source_refs?.brief_ids?.length > 0 ||
        recommendation.source_refs?.lease_ids?.length > 0 ||
        recommendation.source_refs?.building_ids?.length > 0;

      if (needsCompliance) {
        setShowComplianceDialog(true);
      } else {
        setShowScheduleDialog(true);
      }
    } else {
      onStatusChange(recommendation.id, 'approved');
    }
  };

  const handleComplianceApproval = () => {
    if (!sanitisationChecked) {
      return; // Block if sanitisation not confirmed
    }

    // Update recommendation with compliance note
    onStatusChange(recommendation.id, 'approved', {
      compliance_note: complianceNote,
      sanitised_ok: true
    });
    setShowComplianceDialog(false);
    setShowScheduleDialog(true);
  };

  const handleSchedule = () => {
    if (!scheduledDateTime || !selectedChannel) return;

    onStatusChange(recommendation.id, 'scheduled', {
      scheduled_dt: scheduledDateTime,
      channel: selectedChannel
    });
    setShowScheduleDialog(false);
  };

  return (
    <>
      <Card className="orbit-card mb-4 hover:border-orange-400/50 transition-all">
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start mb-2">
            <CardTitle className="text-gray-900 text-sm font-bold tracking-tight line-clamp-2">
              {recommendation.title}
            </CardTitle>
            <div className="flex items-center gap-2 ml-2">
              <Badge className="text-xs font-bold bg-gradient-to-r from-orange-500 to-amber-500 text-white">
                {recommendation.score}
              </Badge>
              {getEffortIcon(recommendation.effort)}
            </div>
          </div>

          <div className="flex flex-wrap gap-1 mb-3">
            {getBadges(recommendation).map((badge, idx) =>
              <Badge key={idx} className={`text-xs ${badge.color}`}>
                {badge.text}
              </Badge>
            )}
          </div>

          <Badge className={`text-xs w-fit ${getStatusColor(recommendation.status)}`}>
            {recommendation.status.toUpperCase()}
          </Badge>
        </CardHeader>

        <CardContent className="pt-0">
          <p className="text-sm text-gray-400 mb-3 line-clamp-2">
            {recommendation.summary}
          </p>

          <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
            <div className="flex items-center gap-1">
              <Users className="w-3 h-3" />
              <span>{recommendation.owner_user?.split('@')[0] || 'Unassigned'}</span>
            </div>
            <div className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              <span>{new Date(recommendation.due_dt).toLocaleDateString()}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => onViewContent(recommendation)}
              className="text-xs orbit-button">

              <FileText className="w-3 h-3 mr-1" />
              Open Idea
            </Button>

            <Button
              size="sm"
              variant="outline"
              onClick={() => onCreateDraft(recommendation)}
              className="text-xs orbit-button">

              <Share2 className="w-3 h-3 mr-1" />
              Create Draft
            </Button>

            {recommendation.status === 'draft' &&
              <>
                <Button
                  size="sm"
                  onClick={handleApprove}
                  className="text-xs bg-green-600 hover:bg-green-700 text-white">

                  <CheckCircle className="w-3 h-3 mr-1" />
                  Approve
                </Button>

                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => onStatusChange(recommendation.id, 'discarded')}
                  className="text-xs">

                  <AlertTriangle className="w-3 h-3 mr-1" />
                  Discard
                </Button>
              </>
            }

            {recommendation.status === 'approved' &&
              <Button
                size="sm"
                onClick={() => setShowScheduleDialog(true)}
                className="text-xs col-span-2 bg-blue-600 hover:bg-blue-700 text-white">

                <Calendar className="w-3 h-3 mr-1" />
                Schedule
              </Button>
            }

            {recommendation.status === 'scheduled' &&
              <Button
                size="sm"
                onClick={() => onStatusChange(recommendation.id, 'done')}
                className="text-xs col-span-2 bg-purple-600 hover:bg-purple-700 text-white">

                <CheckCircle className="w-3 h-3 mr-1" />
                Mark Done
              </Button>
            }
          </div>
        </CardContent>
      </Card>

      {/* Compliance Dialog */}
      <Dialog open={showComplianceDialog} onOpenChange={setShowComplianceDialog}>
        <DialogContent className="orbit-card text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              Compliance Review Required
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <Alert className="bg-amber-900/30 border-amber-700/50">
              <AlertTriangle className="h-4 w-4 text-amber-400" />
              <AlertDescription className="text-amber-200">
                This recommendation references confidential client data (briefs, leases, or buildings) and requires sanitisation review.
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-gray-300 mb-2 block">
                  Compliance Notes (what was redacted/anonymised)
                </label>
                <textarea
                  value={complianceNote}
                  onChange={(e) => setComplianceNote(e.target.value)}
                  placeholder="e.g., Removed client name, anonymised building address, redacted specific deal terms..."
                  className="w-full h-24 px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white text-sm resize-none" />

              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="sanitisation-check"
                  checked={sanitisationChecked}
                  onCheckedChange={setSanitisationChecked} />

                <label htmlFor="sanitisation-check" className="text-sm text-white">
                  I confirm all confidential client information has been sanitised or anonymised
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setShowComplianceDialog(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleComplianceApproval}
                disabled={!sanitisationChecked}
                className="bg-green-600 hover:bg-green-700">

                <CheckCircle className="w-4 h-4 mr-2" />
                Approve & Continue
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showScheduleDialog} onOpenChange={setShowScheduleDialog}>
        <DialogContent className="orbit-card text-white">
          <DialogHeader>
            <DialogTitle>Schedule Recommendation</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">
                Schedule Date & Time
              </label>
              <Input
                type="datetime-local"
                value={scheduledDateTime}
                onChange={(e) => setScheduledDateTime(e.target.value)}
                className="orbit-input" />

            </div>
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">
                Channel
              </label>
              <Select value={selectedChannel} onValueChange={setSelectedChannel}>
                <SelectTrigger className="orbit-input">
                  <SelectValue placeholder="Select channel" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="linkedin">LinkedIn</SelectItem>
                  <SelectItem value="twitter">Twitter</SelectItem>
                  <SelectItem value="blog">Blog</SelectItem>
                  <SelectItem value="newsletter">Newsletter</SelectItem>
                  <SelectItem value="event">Event</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setShowScheduleDialog(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleSchedule}
                disabled={!scheduledDateTime || !selectedChannel}
                className="bg-blue-600 hover:bg-blue-700">

                Schedule
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

const ContentIdeaDialog = ({ recommendation, contentIdea, isOpen, onClose }) => {
  if (!contentIdea) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="orbit-card text-white max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-orange-400" />
            Content Idea: {contentIdea.topic}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div>
            <h4 className="font-semibold text-orange-400 mb-2">Topic & Angle</h4>
            <p className="text-white font-medium mb-1">{contentIdea.topic}</p>
            <p className="text-gray-300 text-sm">{contentIdea.angle}</p>
          </div>

          {contentIdea.proof_points &&
            <div>
              <h4 className="font-semibold text-orange-400 mb-2">Proof Points Available</h4>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(contentIdea.proof_points).map(([key, value]) =>
                  <div key={key} className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${value ? 'bg-green-400' : 'bg-gray-600'}`} />
                    <span className="text-sm capitalize">{key.replace('_', ' ')}</span>
                  </div>
                )}
              </div>
            </div>
          }

          {contentIdea.target_sectors?.length > 0 &&
            <div>
              <h4 className="font-semibold text-orange-400 mb-2">Target Sectors</h4>
              <div className="flex flex-wrap gap-2">
                {contentIdea.target_sectors.map((sector, idx) =>
                  <Badge key={idx} variant="secondary" className="text-xs">
                    {sector}
                  </Badge>
                )}
              </div>
            </div>
          }

          <div>
            <h4 className="font-semibold text-orange-400 mb-2">Recommendation Details</h4>
            <div className="bg-gray-800/50 p-4 rounded-lg space-y-2">
              <p><span className="text-gray-400">Summary:</span> {recommendation.summary}</p>
              <p><span className="text-gray-400">Rationale:</span> {recommendation.rationale}</p>
              <p><span className="text-gray-400">CTA:</span> {recommendation.cta}</p>
              <div className="flex gap-2">
                <span className="text-gray-400">Channels:</span>
                {recommendation.channels?.map((channel, idx) =>
                  <Badge key={idx} variant="outline" className="text-xs">
                    {channel}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default function InboundGenie() {
  const [campaigns, setCampaigns] = useState([]);
  const [selectedWeek, setSelectedWeek] = useState(getThisMonday());
  const [recommendations, setRecommendations] = useState([]);
  const [contentIdeas, setContentIdeas] = useState([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [selectedContent, setSelectedContent] = useState(null);
  const [contentDialogOpen, setContentDialogOpen] = useState(false);
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    User.me().then(setCurrentUser).catch(() => setCurrentUser(null));
  }, []);

  function getThisMonday() {
    const today = new Date();
    const monday = new Date(today);
    const day = today.getDay();
    const diff = today.getDate() - day + (day === 0 ? -6 : 1);
    monday.setDate(diff);
    return monday.toISOString().split('T')[0];
  }

  const loadCampaignData = useCallback(async () => {
    setLoading(true);
    try {
      // Load campaigns
      const campaignData = await InboundCampaign.list('-week_of');
      setCampaigns(campaignData);

      // Load recommendations for selected week
      const campaign = campaignData.find((c) => c.week_of === selectedWeek);
      if (campaign) {
        const [recData, ideaData] = await Promise.all([
          InboundRecommendation.filter({ campaign: campaign.id }),
          ContentIdea.list()
        ]);
        setRecommendations(recData);
        setContentIdeas(ideaData);
      } else {
        setRecommendations([]);
        setContentIdeas([]);
      }
    } catch (error) {
      console.error('Error loading campaign data:', error);
      toast({ variant: 'destructive', title: 'Failed to load campaign data' });
    } finally {
      setLoading(false);
    }
  }, [selectedWeek, toast]);

  useEffect(() => {
    loadCampaignData();
  }, [loadCampaignData]);

  const runGenie = async () => {
    setGenerating(true);
    toast({ title: "Generating Inbound Plan", description: "Analyzing signals and creating recommendations..." });

    try {
      // Helper function to build context for the AI
      const buildContext = async () => {
        // This is where a more sophisticated "Document Binder System" would fetch structured data
        // For now, it provides basic context.
        const existingCampaignsForWeek = await InboundCampaign.list({ week_of: selectedWeek });
        const currentCampaign = existingCampaignsForWeek.find(c => c.week_of === selectedWeek);
        const existingContentIdeas = await ContentIdea.list(); // Or filter by relevance

        return {
          selectedWeek: selectedWeek,
          userProfile: currentUser ? { id: currentUser.id, name: currentUser.name, email: currentUser.email, role: currentUser.role } : null,
          existingCampaignContext: currentCampaign ? { id: currentCampaign.id, name: currentCampaign.name, status: currentCampaign.status } : null,
          existingContentIdeas: existingContentIdeas.map(idea => ({ id: idea.id, topic: idea.topic, angle: idea.angle, status: idea.status })),
          // Add other relevant business signals, recent performance, industry trends etc.
          // This would be the "Document Binder System" in action.
        };
      };

      // Helper function to persist AI generated recommendations
      const persistRecommendations = async (aiOutput) => {
        let campaign = campaigns.find((c) => c.week_of === selectedWeek);
        if (!campaign) {
          campaign = await InboundCampaign.create({
            week_of: selectedWeek,
            name: `Inbound Plan Week of ${selectedWeek}`,
            status: 'draft',
            notes: 'AI-generated plan',
          });
          // Update local campaigns state to include the new campaign
          setCampaigns(prev => [...prev, campaign]);
        }

        const allRecsToCreate = [];
        const types = ['credibility', 'visibility', 'inbound'];
        for (const type of types) {
          if (aiOutput[type] && Array.isArray(aiOutput[type])) {
            for (const recData of aiOutput[type]) {
              allRecsToCreate.push({
                ...recData,
                campaign: campaign.id,
                type: type, // Set the type based on the key ('credibility', 'visibility', 'inbound')
                status: 'draft',
                owner_user: currentUser?.id || null, // Assign current user as owner
                due_dt: new Date(selectedWeek).toISOString(), // Using start of week as due date
              });
            }
          }
        }

        await Promise.all(allRecsToCreate.map(rec => InboundRecommendation.create(rec)));

        // After creating recommendations, reload all data to ensure UI is updated
        await loadCampaignData();
      };

      // Mock InvokeLLM function - in a real scenario, this would be an API call to an actual LLM service
      // The callAIGuarded function takes this as an argument, so no explicit import needed for "InvokeLLM".
      const mockInvokeLLM = async ({ prompt, response_json_schema }) => {
        console.log("Mock LLM called with prompt:", prompt);
        console.log("Mock LLM called with schema:", response_json_schema);
        // Simulate LLM response based on schema
        // This mock provides valid data matching the schema for demonstration.
        await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API delay
        const mockResponse = {
          credibility: [
            { title: "Develop a Thought Leadership Article on Q3 Market Trends", summary: "Create an in-depth analysis of Q3 commercial real estate market trends, leveraging internal data and expert insights.", rationale: "Positions company as a knowledge leader, attracting high-value clients.", cta: "Download Q3 Market Report", channels: ["blog", "linkedin"], score: 9, effort: "high", source_refs: { brief_ids: ["brief_123"] } },
            { title: "Client Success Story: Major Lease Deal", summary: "Publish a success story detailing a recent complex lease negotiation for a high-profile client, focusing on the problem, solution, and outcome.", rationale: "Builds trust and demonstrates problem-solving capabilities to potential clients.", cta: "Read the Case Study", channels: ["linkedin", "newsletter"], score: 8, effort: "med", source_refs: { lease_ids: ["lease_456"], building_ids: ["building_789"] } }
          ],
          visibility: [
            { title: "LinkedIn Poll: Future of Hybrid Work", summary: "Launch an interactive LinkedIn poll asking followers for their predictions on hybrid work models in commercial real estate.", rationale: "Increases engagement and expands reach within the industry network.", cta: "Vote in Our Poll", channels: ["linkedin"], score: 7, effort: "low" },
            { title: "Co-Host Webinar with Industry Partner: Sustainable Buildings", summary: "Collaborate with a green technology firm to host a webinar on sustainable building practices and their impact on property value.", rationale: "Taps into new audiences and strengthens industry partnerships.", cta: "Register for Webinar", channels: ["event", "linkedin", "email"], score: 8, effort: "high", source_refs: { event_id: "event_101" } }
          ],
          inbound: [
            { title: "Guide: Top 5 Commercial Real Estate Investment Opportunities", summary: "Create a downloadable guide highlighting emerging investment opportunities in key regions/sectors, tailored for high-net-worth investors.", rationale: "Generates qualified leads by offering valuable, gated content.", cta: "Download Your Free Guide", channels: ["blog", "newsletter", "linkedin"], score: 9, effort: "high" },
            { title: "Targeted Ad Campaign: Small Business Office Space", summary: "Launch a geo-targeted digital ad campaign on Google and social media platforms for small businesses seeking office space in specific city districts.", rationale: "Drives direct traffic and inquiries from a niche market segment.", cta: "Find Your Ideal Office", channels: ["twitter"], score: 8, effort: "med", source_refs: { target_overlap: 0.8 } }
          ],
        };
        return mockResponse;
      };


      const res = await callAIGuarded(
        "InboundGenie",
        async (input, profile) => await mockInvokeLLM({
          prompt: `Generate inbound marketing recommendations based on this context: ${JSON.stringify(input)}`,
          response_json_schema: profile?.json_schema || {
            type: "object",
            properties: {
              credibility: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    title: { type: "string", description: "Concise, engaging title for the recommendation.", minLength: 5 },
                    summary: { type: "string", description: "Brief summary of the recommendation's content or action.", minLength: 10 },
                    rationale: { type: "string", description: "Explanation of why this recommendation is valuable.", minLength: 20 },
                    cta: { type: "string", description: "Call to action for the recommendation (e.g., 'Learn more', 'Download guide').", minLength: 3 },
                    channels: { type: "array", items: { type: "string" }, description: "Suggested channels for distribution (e.g., 'linkedin', 'blog', 'twitter').", minItems: 1 },
                    score: { type: "number", minimum: 1, maximum: 10, description: "A score from 1-10 indicating the potential impact/quality." },
                    effort: { type: "string", enum: ["low", "med", "high"], description: "Estimated effort to execute (low, med, high)." },
                    source_refs: {
                      type: "object",
                      properties: {
                        event_id: { type: "string", "x-nullable": true, description: "ID of an internal event if tied to one." },
                        target_overlap: { type: "number", "x-nullable": true, description: "Score indicating overlap with top target accounts." },
                        lease_ids: { type: "array", items: { type: "string" }, "x-nullable": true, description: "List of related lease IDs for context." },
                        brief_ids: { type: "array", items: { type: "string" }, "x-nullable": true, description: "List of related brief IDs for context." },
                        building_ids: { type: "array", items: { type: "string" }, "x-nullable": true, description: "List of related building IDs for context." },
                      },
                      "x-nullable": true,
                      description: "References to internal data that informed the recommendation."
                    }
                  },
                  required: ["title", "summary", "rationale", "cta", "channels", "score", "effort"]
                }
              },
              visibility: { type: "array", items: { $ref: "#/properties/credibility/items" } },
              inbound: { type: "array", items: { $ref: "#/properties/credibility/items" } }
            },
            required: ["credibility", "visibility", "inbound"]
          }
        }),
        await buildContext(),
        { currentUser }
      );

      if (!res.ok) {
        toast({
          variant: "destructive",
          title: "AI Output Rejected",
          description: res.error
        });
        return;
      }

      await persistRecommendations(res.data);
      toast({
        title: "Inbound Genie Ready",
        description: "Marketing recommendations have been generated and are ready for review."
      });

    } catch (error) {
      console.error('Error generating plan:', error);
      toast({ variant: 'destructive', title: 'Generation Failed', description: error.message || 'An unexpected error occurred.' });
    } finally {
      setGenerating(false);
    }
  };

  const handleStatusChange = async (recommendationId, newStatus, metadata = {}) => {
    try {
      await InboundRecommendation.update(recommendationId, {
        status: newStatus,
        ...metadata
      });
      toast({ title: "Status Updated", description: `Recommendation moved to ${newStatus}` });
      loadCampaignData();
    } catch (error) {
      console.error('Error updating status:', error);
      toast({ variant: 'destructive', title: 'Update Failed' });
    }
  };

  const handleViewContent = (recommendation) => {
    const idea = contentIdeas.find((i) => i.derived_from?.recommendation_id === recommendation.id);
    setSelectedContent({ recommendation, contentIdea: idea });
    setContentDialogOpen(true);
  };

  const handleCreateDraft = (recommendation) => {
    // This would open a social post drafting interface
    toast({ title: "Draft Creation", description: "Social post drafting interface would open here" });
  };

  const currentCampaign = campaigns.find((c) => c.week_of === selectedWeek);
  const credibilityRecs = recommendations.filter((r) => r.type === 'credibility');
  const visibilityRecs = recommendations.filter((r) => r.type === 'visibility');
  const inboundRecs = recommendations.filter((r) => r.type === 'inbound');

  return (
    <div className="p-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Inbound Genie</h1>
            <p className="text-gray-300">AI-powered marketing recommendations based on your business signals</p>
          </div>

          <div className="flex items-center gap-4">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Week of</label>
              <Input
                type="date"
                value={selectedWeek}
                onChange={(e) => setSelectedWeek(e.target.value)}
                className="orbit-input w-40" />

            </div>

            <Button
              onClick={runGenie}
              disabled={generating}
              className="bg-gradient-to-r from-purple-600 to-orange-500 hover:from-purple-700 hover:to-orange-600 text-white mt-6">

              {generating ?
                <Loader2 className="w-4 h-4 mr-2 animate-spin" /> :

                <Lightbulb className="w-4 h-4 mr-2" />
              }
              Generate Plan
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Three Recommendation Columns */}
          <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Credibility Column */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-5 h-5 text-blue-400" />
                <h2 className="text-lg font-bold text-white">Credibility Boosters</h2>
                <Badge variant="secondary" className="text-xs">{credibilityRecs.length}</Badge>
              </div>

              {loading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) =>
                    <Card key={i} className="orbit-card animate-pulse">
                      <CardContent className="h-48 bg-gray-700/20 rounded"></CardContent>
                    </Card>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  {credibilityRecs.map((rec) =>
                    <RecommendationCard
                      key={rec.id}
                      recommendation={rec}
                      onStatusChange={handleStatusChange}
                      onViewContent={handleViewContent}
                      onCreateDraft={handleCreateDraft} />

                  )}
                </div>
              )}
            </div>

            {/* Visibility Column */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Users className="w-5 h-5 text-green-400" />
                <h2 className="text-lg font-bold text-white">Visibility Boosters</h2>
                <Badge variant="secondary" className="text-xs">{visibilityRecs.length}</Badge>
              </div>

              {loading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) =>
                    <Card key={i} className="orbit-card animate-pulse">
                      <CardContent className="h-48 bg-gray-700/20 rounded"></CardContent>
                    </Card>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  {visibilityRecs.map((rec) =>
                    <RecommendationCard
                      key={rec.id}
                      recommendation={rec}
                      onStatusChange={handleStatusChange}
                      onViewContent={handleViewContent}
                      onCreateDraft={handleCreateDraft} />

                  )}
                </div>
              )}
            </div>

            {/* Inbound Column */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Target className="w-5 h-5 text-purple-400" />
                <h2 className="text-lg font-bold text-white">Inbound Boosters</h2>
                <Badge variant="secondary" className="text-xs">{inboundRecs.length}</Badge>
              </div>

              {loading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) =>
                    <Card key={i} className="orbit-card animate-pulse">
                      <CardContent className="h-48 bg-gray-700/20 rounded"></CardContent>
                    </Card>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  {inboundRecs.map((rec) =>
                    <RecommendationCard
                      key={rec.id}
                      recommendation={rec}
                      onStatusChange={handleStatusChange}
                      onViewContent={handleViewContent}
                      onCreateDraft={handleCreateDraft} />

                  )}
                </div>
              )}
            </div>
          </div>

          {/* Right Rail */}
          <div className="space-y-6">
            {/* Campaign Info */}
            {currentCampaign && (
              <Card className="orbit-card">
                <CardHeader>
                  <CardTitle className="text-white text-sm">Weekly Plan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm text-gray-300">
                    <div className="font-medium">{currentCampaign.name}</div>
                    <div className="text-xs text-gray-500 mt-1">{currentCampaign.notes}</div>
                  </div>

                  {currentCampaign.totals_json && (
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="text-gray-400">Total: <span className="text-white font-medium">{currentCampaign.totals_json.total_recommendations}</span></div>
                      <div className="text-gray-400">Avg Score: <span className="text-white font-medium">{currentCampaign.totals_json.avg_score}</span></div>
                    </div>
                  )}

                  {currentCampaign.plan_pdf_url && (
                    <Button size="sm" variant="outline" className="w-full text-xs orbit-button">
                      <Share2 className="w-3 h-3 mr-1" />
                      Download PDF Plan
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Export Options */}
            <Card className="orbit-card">
              <CardHeader>
                <CardTitle className="text-white text-sm">Export & Share</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button size="sm" variant="outline" className="w-full text-xs orbit-button">
                  <Share2 className="w-3 h-3 mr-1" />
                  Export to Notion
                </Button>
                <Button size="sm" variant="outline" className="w-full text-xs orbit-button">
                  <Share2 className="w-3 h-3 mr-1" />
                  Export to Drive
                </Button>
              </CardContent>
            </Card>

            {/* Stats Summary */}
            {recommendations.length > 0 && (
              <Card className="orbit-card">
                <CardHeader>
                  <CardTitle className="text-white text-sm">This Week</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-1 gap-2 text-xs">
                    {['draft', 'approved', 'scheduled', 'done'].map((status) => {
                      const count = recommendations.filter((r) => r.status === status).length;
                      return (
                        <div key={status} className="flex justify-between">
                          <span className="text-gray-400 capitalize">{status}:</span>
                          <span className="text-white font-medium">{count}</span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Empty State */}
        {!loading && recommendations.length === 0 && (
          <Card className="orbit-card text-center py-12">
            <Lightbulb className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-white mb-2">No recommendations yet</h3>
            <p className="text-gray-400 mb-6">Generate your first inbound marketing plan for the selected week.</p>
            <Button onClick={runGenie} disabled={generating} className="bg-gradient-to-r from-purple-600 to-orange-500 hover:from-purple-700 hover:to-orange-600">
              <Lightbulb className="w-4 h-4 mr-2" />
              Generate Plan
            </Button>
          </Card>
        )}

        {/* Content Idea Dialog */}
        {selectedContent && (
          <ContentIdeaDialog
            recommendation={selectedContent.recommendation}
            contentIdea={selectedContent.contentIdea}
            isOpen={contentDialogOpen}
            onClose={() => setContentDialogOpen(false)}
          />
        )}
      </div>
    </div>
  );
}
