
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Option, Building, DueDiligence } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Building2, CheckCircle, AlertCircle } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { UnitsBar } from '@/components/ui/UnitsBar';
import { useUnits } from '@/components/utils/units';

export default function OptionDetails() {
    const { id: optionId } = useParams();
    const navigate = useNavigate();
    const { convertEconomics, loading: unitsLoading } = useUnits();

    const [option, setOption] = useState(null);
    const [building, setBuilding] = useState(null);
    const [dd, setDd] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!optionId) return;
        const loadData = async () => {
            try {
                const optionData = await Option.get(optionId);
                setOption(optionData);

                if (optionData?.building_id) {
                    const buildingData = await Building.get(optionData.building_id);
                    setBuilding(buildingData);
                }

                const [ddData] = await DueDiligence.filter({ option_id: optionId });
                setDd(ddData);

            } catch (error) {
                console.error("Failed to load option details:", error);
            } finally {
                setLoading(false);
            }
        };
        loadData();
    }, [optionId]);

    const handleRunDD = () => {
        navigate(createPageUrl(`DueDiligenceDashboard?buildingId=${option.building_id}&optionId=${option.id}`));
    };

    if (loading) {
        return (
            <div className="min-h-screen">
                <UnitsBar />
                <div className="flex justify-center p-8">
                    <Loader2 className="w-8 h-8 animate-spin text-orange-400" />
                </div>
            </div>
        );
    }

    if (!option) {
        return (
            <div className="min-h-screen">
                <UnitsBar />
                <div className="text-center py-16">
                    <p className="text-gray-400">Option not found</p>
                </div>
            </div>
        );
    }

    const economics = convertEconomics({
      area_m2: option.area_sqm,
      rent_aud_per_m2_pa: option.rent_sqm_pa
    });

    return (
        <div className="min-h-screen">
            <UnitsBar />
            <div className="max-w-6xl mx-auto p-4 sm:p-6 md:p-8">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-white mb-2">Option Details</h1>
                    <p className="text-gray-300">Comprehensive option analysis and due diligence</p>
                </div>

                {/* Building details and DD action/status */}
                <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center space-x-2">
                        <Building2 className="w-6 h-6 text-orange-400" />
                        <h2 className="text-xl font-semibold text-white">{building?.name || 'Building Not Found'}</h2>
                        <p className="text-gray-400 ml-2">{building?.address}</p>
                    </div>
                    {dd ? (
                        <Badge variant={dd.pass_flag ? 'default' : 'destructive'} className="h-fit">
                            {dd.pass_flag ? <CheckCircle className="w-4 h-4 mr-2" /> : <AlertCircle className="w-4 h-4 mr-2" />}
                            DD {dd.status}
                        </Badge>
                    ) : (
                        <Button onClick={handleRunDD} className="orbit-button bg-blue-600 hover:bg-blue-700">Run Due Diligence</Button>
                    )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Option Overview */}
                    <Card className="orbit-card lg:col-span-2">
                        <CardHeader>
                            <CardTitle className="text-white">Option Summary</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-sm text-gray-400">Area</label>
                                    <p className="text-lg font-semibold text-white">
                                        {economics.area?.value} {economics.area?.unit}
                                    </p>
                                </div>
                                <div>
                                    <label className="text-sm text-gray-400">Rent</label>
                                    <p className="text-lg font-semibold text-white">
                                        {economics.rent ? `$${economics.rent.value}` : 'N/A'}
                                        <span className="text-gray-400 ml-1">{economics.rent?.unit}</span>
                                    </p>
                                </div>
                                <div>
                                    <label className="text-sm text-gray-400">Lease Term</label>
                                    <p className="text-lg font-semibold text-white">{option.lease_term_years} years</p>
                                </div>
                                <div>
                                    <label className="text-sm text-gray-400">Incentive</label>
                                    <p className="text-lg font-semibold text-white">{option.incentive_months} months</p>
                                </div>
                            </div>

                            {option.notes && (
                                <div>
                                    <label className="text-sm text-gray-400">Notes</label>
                                    <p className="text-white mt-1">{option.notes}</p>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    {/* Quick Stats */}
                    <Card className="orbit-card">
                        <CardHeader>
                            <CardTitle className="text-white">Quick Stats</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <div className="flex justify-between">
                                <span className="text-gray-400">TCO NPV</span>
                                <span className="text-white font-semibold">
                                    ${option.tco_npv_aud?.toLocaleString() || 'TBD'}
                                </span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-400">Risk Score</span>
                                <div className="flex items-center gap-2">
                                    <span className="text-white font-semibold">{option.risk_score}/100</span>
                                    <div className="w-16 h-2 bg-gray-700 rounded-full">
                                        <div
                                            className="h-2 bg-orange-400 rounded-full"
                                            style={{ width: `${option.risk_score}%` }}
                                        ></div>
                                    </div>
                                </div>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-400">Shortlisted</span>
                                <Badge variant={option.shortlist_bool ? 'default' : 'outline'}>
                                    {option.shortlist_bool ? 'Yes' : 'No'}
                                </Badge>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Due Diligence Summary - adapted from original code */}
                    {dd && (
                        <Card className="orbit-card lg:col-span-3"> {/* Taking full width for DD summary if it exists */}
                            <CardHeader>
                                <CardTitle className="text-white">Due Diligence Summary</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-2">
                                <p>Status: <span className="capitalize text-white">{dd.status}</span></p>
                                <p>Findings Score: <span className="text-white">{dd.findings_score}</span></p>
                                <p className="text-sm text-gray-400">{dd.exec_summary}</p>
                            </CardContent>
                        </Card>
                    )}
                </div>
            </div>
        </div>
    );
}
