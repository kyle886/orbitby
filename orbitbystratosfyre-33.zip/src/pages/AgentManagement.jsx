import React, { useState, useEffect, useCallback } from "react";
import { PropertyScanJob } from "@/api/entities";
import { ScannedProperty } from "@/api/entities";
import { PropertySubmission } from "@/api/entities";
import { Client } from "@/api/entities";
import { TenantRequirement } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, Play, Pause, Bot, FileText, Activity, AlertTriangle, CheckCircle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

export default function AgentManagement() {
  const [jobs, setJobs] = useState([]);
  const [clients, setClients] = useState([]);
  const [briefs, setBriefs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [jobStates, setJobStates] = useState({});

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [jobsData, clientsData, briefsData] = await Promise.all([
        PropertyScanJob.list("-created_date"),
        Client.list(),
        TenantRequirement.list()
      ]);
      setJobs(jobsData || []);
      setClients(clientsData || []);
      setBriefs(briefsData || []);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const addLog = async (jobId, message) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;

    const newLog = { timestamp: new Date().toISOString(), message };
    const updatedLogs = [...(job.logs || []), newLog].slice(-20); // Keep last 20 logs

    try {
      await PropertyScanJob.update(jobId, { logs: updatedLogs });
      // Optimistically update local state
      setJobs(prev => prev.map(j => j.id === jobId ? { ...j, logs: updatedLogs } : j));
    } catch (error) {
      console.error("Failed to add log:", error);
    }
  };

  const runJob = async (job) => {
    setJobStates(prev => ({ ...prev, [job.id]: { running: true, message: "Initializing agent..." } }));
    await addLog(job.id, "Agent run triggered manually.");
    
    await PropertyScanJob.update(job.id, { last_run_started: new Date().toISOString() });

    try {
      const brief = briefs.find(b => b.id === job.brief_id);
      if (!brief) throw new Error("Associated brief not found.");

      setJobStates(prev => ({ ...prev, [job.id]: { running: true, message: "Analyzing past feedback..." } }));
      await addLog(job.id, "Analyzing past feedback for learning...");

      // --- LEARNING FROM FEEDBACK ---
      const submissions = await PropertySubmission.filter({ brief_ids: { "$in": [job.brief_id] } });
      const approved = submissions.filter(s => ['shortlisted', 'selected'].includes(s.status));
      const rejected = submissions.filter(s => s.status === 'rejected');

      let feedbackContext = "";
      if (approved.length > 0) {
        feedbackContext += `The client has previously APPROVED properties like these (use these as a strong positive signal): ${approved.map(s => `Address: ${s.address}, Size: ${s.floor_area_sqm}sqm, Notes: ${s.amplifyre_notes || 'N/A'}`).join('; ')}\n`;
      }
      if (rejected.length > 0) {
        feedbackContext += `The client has previously REJECTED properties like these (use these as a strong negative signal): ${rejected.map(s => `Address: ${s.address}, Reason: ${s.rejection_reason || 'N/A'}`).join('; ')}\n`;
      }
      if (!feedbackContext) {
        feedbackContext = "No specific feedback history available yet. Rely solely on the brief criteria.";
      }
      await addLog(job.id, "Feedback analysis complete.");
      // -----------------------------

      setJobStates(prev => ({ ...prev, [job.id]: { running: true, message: "Scanning property portals..." } }));
      await addLog(job.id, "Contacting property portals...");

      const prompt = `
        You are an elite AI agent for Stratosfyre, a commercial real estate firm. Your task is to find property listings that precisely match a client's brief, learning from their past feedback.
        
        Client Brief:
        - Property Type: '${brief.property_type}'
        - Location/Suburbs: '${(brief.preferred_suburbs || []).join(', ')}'
        - Size Range: ${brief.min_floor_area} sqm to ${brief.max_floor_area} sqm

        Historical Feedback (CRITICAL for learning):
        ${feedbackContext}

        Instructions:
        1. Search ONLY realcommercial.com.au and commercialrealestate.com.au.
        2. Find up to 5 NEW listings that are the best possible match, considering both the brief and the historical feedback.
        3. Prioritize properties that are similar to previously approved ones and avoid properties similar to rejected ones.
        4. Extract the requested information. Do not invent data. If info is unavailable, use null.
        5. Return a JSON object.
      `;

      const responseSchema = {
        type: "array",
        items: {
          type: "object",
          properties: {
            source_portal: { type: "string" },
            property_title: { type: "string" },
            address: { type: "string" },
            floor_area_sqm: { type: "number" },
            rental_rate_sqm: { type: "number" },
            agent_name: { type: "string" },
            agent_company: { type: "string" },
            external_url: { type: "string" },
          },
          required: ["source_portal", "property_title", "address", "external_url"]
        }
      };

      const results = await InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: responseSchema
      });

      if (!results || !Array.isArray(results) || results.length === 0) {
        await addLog(job.id, "Scan complete. No new properties found.");
        await PropertyScanJob.update(job.id, { 
          last_run_finished: new Date().toISOString(),
          last_run_status: 'no_new_properties'
        });
        setJobStates(prev => ({ ...prev, [job.id]: { running: false, message: "Finished: No new properties." } }));
        return;
      }
      
      await addLog(job.id, `Found ${results.length} potential listings. Deduplicating...`);
      const existingProperties = await ScannedProperty.list();
      const existingUrls = new Set(existingProperties.map(p => p.external_url));
      const newProperties = results.filter(p => p.external_url && !existingUrls.has(p.external_url));

      if (newProperties.length === 0) {
        await addLog(job.id, "All found properties were already in the database.");
        await PropertyScanJob.update(job.id, { 
          last_run_finished: new Date().toISOString(),
          last_run_status: 'no_new_properties'
        });
        setJobStates(prev => ({ ...prev, [job.id]: { running: false, message: "Finished: No new properties." } }));
        return;
      }

      await addLog(job.id, `Identified ${newProperties.length} new unique properties. Saving...`);
      const propertiesToCreate = newProperties.map(p => ({
        client_id: job.client_id,
        source_portal: p.source_portal,
        property_title: p.property_title,
        address: p.address,
        floor_area_sqm: p.floor_area_sqm,
        rental_rate_sqm: p.rental_rate_sqm,
        agent_name: p.agent_name,
        agent_company: p.agent_company,
        external_url: p.external_url,
        discovered_date: new Date().toISOString(),
        scan_status: 'new'
      }));
      
      await ScannedProperty.bulkCreate(propertiesToCreate);
      
      const finalUpdate = {
        last_run_finished: new Date().toISOString(),
        last_run_status: 'success',
        properties_found_count: (job.properties_found_count || 0) + newProperties.length
      };
      await PropertyScanJob.update(job.id, finalUpdate);
      setJobs(prev => prev.map(j => j.id === job.id ? {...j, ...finalUpdate} : j));

      await addLog(job.id, `Successfully saved ${newProperties.length} new properties to database. Run complete.`);
      setJobStates(prev => ({ ...prev, [job.id]: { running: false, message: `Success! Found ${newProperties.length} new properties.` } }));

    } catch (error) {
      console.error("Error running agent:", error);
      const errorMessage = `Error: ${error.message}`;
      await addLog(job.id, errorMessage);
      await PropertyScanJob.update(job.id, {
        last_run_finished: new Date().toISOString(),
        last_run_status: 'error',
        status: 'error'
      });
      setJobStates(prev => ({ ...prev, [job.id]: { running: false, message: errorMessage } }));
    }
  };

  const toggleJobStatus = async (job) => {
    const newStatus = job.status === 'active' ? 'paused' : 'active';
    await PropertyScanJob.update(job.id, { status: newStatus });
    await addLog(job.id, `Agent status changed to ${newStatus}.`);
    setJobs(prev => prev.map(j => j.id === job.id ? { ...j, status: newStatus } : j));
  };

  const CreateJobDialog = () => {
    const [selectedClient, setSelectedClient] = useState("");
    const [selectedBrief, setSelectedBrief] = useState("");
    const [selectedSchedule, setSelectedSchedule] = useState("daily");
    const [isCreating, setIsCreating] = useState(false);
    const availableBriefs = briefs.filter(b => b.client_id === selectedClient);

    const handleCreate = async () => {
      if (!selectedClient || !selectedBrief) {
        alert("Please select a client and a brief.");
        return;
      }
      setIsCreating(true);
      try {
        await PropertyScanJob.create({
          client_id: selectedClient,
          brief_id: selectedBrief,
          schedule: selectedSchedule,
          status: 'active',
          logs: [{ timestamp: new Date().toISOString(), message: "Agent created." }]
        });
        setShowCreateDialog(false);
        loadData();
      } catch (error) {
        console.error("Error creating job:", error);
        alert("Failed to create agent.");
      } finally {
        setIsCreating(false);
      }
    };

    return (
      <DialogContent className="orbit-card text-white">
        <DialogHeader><DialogTitle>Create AI Scan Agent</DialogTitle></DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label>Client</Label>
            <Select onValueChange={setSelectedClient}>
              <SelectTrigger className="orbit-input"><SelectValue placeholder="Select a client..." /></SelectTrigger>
              <SelectContent>{clients.map(c => <SelectItem key={c.id} value={c.id}>{c.company_name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          {selectedClient && (
            <div>
              <Label>Client Brief</Label>
              <Select onValueChange={setSelectedBrief} disabled={availableBriefs.length === 0}>
                <SelectTrigger className="orbit-input"><SelectValue placeholder={availableBriefs.length > 0 ? "Select a brief..." : "No active briefs for this client"} /></SelectTrigger>
                <SelectContent>{availableBriefs.map(b => <SelectItem key={b.id} value={b.id}>{b.brief_reference_code || `Brief for ${b.property_type}`}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          )}
          <div>
            <Label>Run Schedule</Label>
            <Select defaultValue="daily" onValueChange={setSelectedSchedule}>
              <SelectTrigger className="orbit-input"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setShowCreateDialog(false)}>Cancel</Button>
          <Button onClick={handleCreate} disabled={isCreating} className="bg-orange-500 hover:bg-orange-600 text-white">{isCreating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : "Create Agent"}</Button>
        </DialogFooter>
      </DialogContent>
    );
  };
  
  const JobCard = ({ job }) => {
    const client = clients.find(c => c.id === job.client_id);
    const brief = briefs.find(b => b.id === job.brief_id);
    const state = jobStates[job.id] || {};
    
    const getStatusIcon = () => {
      switch (job.status) {
        case 'active': return <CheckCircle className="w-4 h-4 text-green-400" />;
        case 'paused': return <Pause className="w-4 h-4 text-yellow-400" />;
        case 'error': return <AlertTriangle className="w-4 h-4 text-red-400" />;
        default: return <Activity className="w-4 h-4 text-gray-400"/>;
      }
    };

    return (
      <div className="orbit-card p-6 flex flex-col">
        <div className="flex justify-between items-start mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Bot className="w-6 h-6 text-orange-400" />
              <h3 className="text-xl font-bold text-white">{client?.company_name || 'Unknown Client'}</h3>
            </div>
            <p className="text-sm text-gray-400">Brief: {brief?.brief_reference_code || 'N/A'}</p>
          </div>
          <div className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 capitalize bg-gray-800`}>
            {getStatusIcon()}
            {job.status}
          </div>
        </div>
        
        <div className="text-xs text-gray-300 space-y-1 mb-4">
            <p><strong>Schedule:</strong> <span className="capitalize">{job.schedule}</span></p>
            <p><strong>Last Run:</strong> {job.last_run_finished ? new Date(job.last_run_finished).toLocaleString() : 'Never'}</p>
            <p><strong>Last Status:</strong> <span className="capitalize">{job.last_run_status?.replace(/_/g, ' ') || 'N/A'}</span></p>
            <p><strong>Total Found:</strong> {job.properties_found_count || 0}</p>
        </div>

        <div className="bg-gray-900/50 p-3 rounded-lg text-xs font-mono h-24 overflow-y-auto mb-4 border border-gray-700">
          <p className="text-gray-400 mb-1">&gt; Agent Logs:</p>
          {(job.logs || []).slice().reverse().map((log, i) => (
            <p key={i} className="whitespace-nowrap overflow-hidden text-ellipsis">{new Date(log.timestamp).toLocaleTimeString()}: {log.message}</p>
          ))}
        </div>

        <div className="mt-auto flex gap-2">
          <Button variant="outline" size="sm" className="orbit-button text-white w-full" onClick={() => runJob(job)} disabled={state.running}>
            {state.running ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Play className="w-4 h-4 mr-2" />}
            {state.running ? 'Running...' : 'Run Now'}
          </Button>
          <Button variant="outline" size="sm" className="orbit-button text-white w-full" onClick={() => toggleJobStatus(job)}>
            {job.status === 'active' ? <><Pause className="w-4 h-4 mr-2" />Pause</> : <><Play className="w-4 h-4 mr-2" />Resume</>}
          </Button>
        </div>
        {state.message && <p className="text-xs text-center mt-2 text-gray-400">{state.message}</p>}
      </div>
    );
  };

  return (
    <div className="p-4 sm:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">AI Agent Management</h1>
            <p className="text-gray-300">Deploy and monitor autonomous agents to scan the market.</p>
          </div>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="orbit-button bg-gradient-to-r from-orange-500 to-amber-500 text-white border-0 px-6 py-3">
                <Plus className="w-5 h-5 mr-2" />
                Create AI Agent
              </Button>
            </DialogTrigger>
            <CreateJobDialog />
          </Dialog>
        </div>

        {loading ? <div className="text-center p-8"><Loader2 className="h-8 w-8 mx-auto animate-spin text-amber-400"/></div> : 
        jobs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {jobs.map(job => <JobCard key={job.id} job={job} />)}
          </div>
        ) : (
          <div className="text-center orbit-card p-12">
            <Bot className="w-12 h-12 mx-auto text-gray-500 mb-4" />
            <h3 className="text-xl font-medium text-white mb-2">No AI Agents Deployed</h3>
            <p className="text-gray-400 mb-4">Create your first agent to start automating your property scans.</p>
            <Button variant="outline" onClick={() => setShowCreateDialog(true)}>Create AI Agent</Button>
          </div>
        )}
      </div>
    </div>
  );
}