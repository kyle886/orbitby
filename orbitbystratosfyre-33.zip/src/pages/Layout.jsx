

import React, { useState, useEffect, useCallback } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { initCosmic } from "@/components/utils/theme/cosmic";
import ErrorBoundary from "@/components/system/ErrorBoundary";
import {
  Building2,
  LayoutDashboard,
  Users,
  FileText,
  Search,
  Upload,
  BarChart3,
  LogOut,
  Menu,
  X,
  Compass,
  Building,
  TrendingUp,
  Briefcase,
  Bot,
  Sparkles,
  MessageSquare,
  ChevronDown,
  ChevronRight,
  UserCog,
  Database,
  Brain,
  Settings,
  Activity,
  Target,
  DownloadCloud,
  Zap,
  Terminal,
  Bell,
  HelpCircle,
  RefreshCw,
  Landmark,
  LineChart,
  CheckCircle,
  GaugeCircle,
  FolderOpen,
  Archive,
  HeartPulse // <-- Add HeartPulse icon
} from "lucide-react";
import { CommandPalette, useCommandPalette } from '@/components/ui/command-palette';
import { UnitProvider } from '@/components/utils/units';
import { cn } from "@/lib/utils";
import SatelliteEasterEgg from '@/components/fun/SatelliteEasterEgg';
import CosmicBadge from "@/components/fun/CosmicBadge";
import { ViewAsToggle, ViewAsProvider } from '@/components/ui/ViewAs';
import { setCosmic } from '@/components/utils/theme/cosmic';
import Toaster from '@/components/system/Toaster';
import { InspectionPackProvider } from '@/components/state/InspectionPackContext';

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [sidebarExpanded, setSidebarExpanded] = useState(false);
  const [searchExpanded, setSearchExpanded] = useState(false);
  const [expandedSections, setExpandedSections] = useState({
    'client-engagements': false,
    'property-database': false,
    'intelligence-ai': false,
    'admin-reporting': false,
    'business-development': false,
    'capital-markets': false
  });
  const { open: commandPaletteOpen, setOpen: setCommandPaletteOpen } = useCommandPalette();

  const loadUser = useCallback(async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.error("User not authenticated, redirecting to login:", error);
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  useEffect(() => {
    initCosmic();
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileMenuOpen(false);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isMobileMenuOpen]);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const handleLogout = async () => {
    await User.logout();
    window.location.reload();
  };

  const toggleSection = (sectionKey) => {
    if (sidebarExpanded) {
      setExpandedSections(prev => ({
        ...prev,
        [sectionKey]: !prev[sectionKey]
      }));
    }
  };

  const collapseAllSections = () => {
    setExpandedSections({
      'client-engagements': false,
      'property-database': false,
      'intelligence-ai': false,
      'admin-reporting': false,
      'business-development': false,
      'capital-markets': false
    });
  };

  const getNavigationStructure = () => {
    if (!user || !user.user_type) {
      return [
        {
          title: "Account Setup",
          url: createPageUrl("UpdateUserType"),
          icon: Users,
          standalone: true
        }
      ];
    }

    if (user.user_type === 'stratosfyre_admin') {
      return [
        {
          title: "Command Centre",
          url: createPageUrl("CommandCentre"),
          icon: LayoutDashboard,
          standalone: true
        },
        {
          title: "Business Development",
          key: "business-development",
          icon: Target,
          isSection: true,
          items: [
            { title: "BD Dashboard", url: createPageUrl("BusinessDevelopmentDashboard"), icon: BarChart3 },
            { title: "Inbound Genie", url: createPageUrl("InboundGenie"), icon: Sparkles },
            { title: "Targets Wizard", url: createPageUrl("TargetsWizard"), icon: Users },
            { title: "Events Manager", url: createPageUrl("EventsMan"), icon: Compass },
            { title: "Pitch Master", url: createPageUrl("PitchMaster"), icon: FileText },
            { title: "BD Performance", url: createPageUrl("BDKPIPage"), icon: Activity }
          ]
        },
        {
          title: "Client Engagements",
          key: "client-engagements",
          icon: Users,
          isSection: true,
          items: [
            { title: "Active Clients", url: createPageUrl("ClientManagement"), icon: Users },
            { title: "Active Briefs", url: createPageUrl("Requirements"), icon: Compass },
            { title: "Property Submissions", url: createPageUrl("SubmissionManagement"), icon: Search },
            { title: "Inspection Insights", url: createPageUrl("InspectionInsights"), icon: MessageSquare },
            { title: "Client Communications", url: createPageUrl("ClientCommunications"), icon: MessageSquare },
            { title: "Project Delivery", url: createPageUrl("ProjectDelivery"), icon: Building2 }
          ]
        },
        {
          title: "Portfolio",
          url: createPageUrl("PortfolioDashboard"),
          icon: FolderOpen,
          standalone: true
        },
        {
          title: "Capital Markets",
          key: "capital-markets",
          icon: Landmark,
          isSection: true,
          items: [
            { title: "Finance Dashboard", url: createPageUrl("FinanceDashboard"), icon: LineChart },
            { title: "Development Feasibility", url: createPageUrl("DevFeasibilityModule"), icon: Target },
          ]
        },
        {
          title: "Property Intelligence",
          key: "property-database",
          icon: Database,
          isSection: true,
          items: [
            { title: "Property Listings", url: createPageUrl("Listings"), icon: Briefcase },
            { title: "Leased Property Log", url: createPageUrl("LeasedPropertiesLog"), icon: Archive },
            { title: "Building Database", url: createPageUrl("BuildingDatabase"), icon: Building },
            { title: "Submit Property", url: createPageUrl("SubmitListing"), icon: Upload }
          ]
        },
        {
          title: "AI & Analytics",
          key: "intelligence-ai",
          icon: Brain,
          isSection: true,
          items: [
            { title: "Market Intelligence", url: createPageUrl("MarketIntelligence"), icon: TrendingUp },
            { title: "AI Market Scanning", url: createPageUrl("AgentConfiguration"), icon: Bot },
            { title: "Property Reviews", url: createPageUrl("AIPropertyReviews"), icon: Sparkles },
            { title: "AI Test Harness", url: createPageUrl("AITestHarness"), icon: Brain }
          ]
        },
        {
          title: "System Administration",
          key: "admin-reporting",
          icon: Settings,
          isSection: true,
          items: [
            { title: "Team Performance", url: createPageUrl("TeamPerformance"), icon: Activity },
            { title: "Document Management", url: createPageUrl("DocumentManagement"), icon: FileText },
            { title: "User Management", url: createPageUrl("UserManagement"), icon: UserCog },
            { title: "Process Automation", url: createPageUrl("AutomationsManager"), icon: Zap },
            { title: "Data Ingestion", url: createPageUrl("DataIngestion"), icon: DownloadCloud },
            { title: "Admin Console", url: createPageUrl("BDAdminConsole"), icon: Terminal },
            { title: "Job Control Center", url: createPageUrl("JobControlCenter"), icon: GaugeCircle },
            { title: "Duplicate Review", url: createPageUrl("DuplicateReview"), icon: RefreshCw },
            { title: "System Reports", url: createPageUrl("SystemReports"), icon: HeartPulse }, // <-- Added System Reports
            { title: "Reports Center", url: createPageUrl("ReportsCenter"), icon: BarChart3 },
            { title: "Performance Analytics", url: createPageUrl("Analytics"), icon: BarChart3 },
            { title: "Acceptance Tests", url: createPageUrl("AcceptanceTests"), icon: CheckCircle }
          ]
        }
      ];
    } else if (user.user_type === 'client') {
      return [
        { title: "Dashboard", url: createPageUrl("TenantDashboard"), icon: LayoutDashboard, standalone: true },
        { title: "Property Options", url: createPageUrl("ClientProperties"), icon: Building2, standalone: true },
        { title: "Document Library", url: createPageUrl("ClientDocuments"), icon: FileText, standalone: true },
        { title: "Project Updates", url: createPageUrl("ClientUpdates"), icon: Upload, standalone: true },
        { title: "Account Settings", url: createPageUrl("UpdateUserType"), icon: Users, standalone: true },
      ];
    } else if (user.user_type === 'agent_landlord') {
      return [
        { title: "Submit Property", url: createPageUrl("SubmitListing"), icon: Upload, standalone: true },
        { title: "My Submissions", url: createPageUrl("AgentSubmissions"), icon: Building2, standalone: true },
        { title: "Account Settings", url: createPageUrl("UpdateUserType"), icon: Users, standalone: true },
      ];
    }

    return [
      { title: "Account Setup", url: createPageUrl("UpdateUserType"), icon: Users, standalone: true },
    ];
  };

  const isActive = (url) => location.pathname === url;
  const isSectionActive = (section) => {
    if (!section.items) return false;
    return section.items.some(item => isActive(item.url));
  };

  const getUserTypeDisplay = () => {
    if (!user.user_type) return 'Setup Required';

    switch (user.user_type) {
      case 'stratosfyre_admin': return 'Stratosfyre Team';
      case 'client': return 'Client';
      case 'agent_landlord': return 'Agent/Landlord';
      default: return 'Unknown';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{background: 'linear-gradient(180deg, #0A0E14 0%, #0F1722 60%, #0E4C88 90%)'}}>
        <div className="p-8" style={{
          background: 'rgba(255,255,255,0.03)',
          border: '1px solid rgba(255,255,255,0.06)',
          borderRadius: '12px',
          backdropFilter: 'blur(8px)'
        }}>
          <div className="w-8 h-8 rounded-full mx-auto animate-pulse" style={{background: 'rgba(255,255,255,0.1)'}}></div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{background: 'linear-gradient(180deg, #0A0E14 0%, #0F1722 60%, #0E4C88 90%)'}}>
        <div className="max-w-md w-full mx-auto p-6 sm:p-8 md:p-12" style={{
          background: 'rgba(255,255,255,0.03)',
          border: '1px solid rgba(255,255,255,0.06)',
          borderRadius: '12px',
          backdropFilter: 'blur(8px)'
        }}>
          <div className="text-center">
            <img src="/images/orbit_logo_full.png" alt="ORBIT by Stratosfyre" className="w-32 sm:w-40 md:w-48 mx-auto mb-6 sm:mb-8"/>
            <button
              onClick={() => User.login()}
              style={{
                background: 'var(--horizon-orange)',
                color: 'var(--horizon-orange-text)',
                border: 'none',
                borderRadius: '12px',
                padding: '12px 24px',
                fontSize: '16px',
                fontWeight: '700',
                width: '100%',
                marginBottom: '16px',
                cursor: 'pointer'
              }}
            >
              Sign In to ORBIT
            </button>
            <div className="text-center">
              <p style={{fontSize: '12px', color: 'var(--onDark-mute)'}}>
                Need access? Contact your Stratosfyre consultant or{' '}
                <a href="mailto:support@stratosfyre.com" style={{color: 'var(--orbit-teal)', textDecoration: 'underline'}}>
                  request an invitation
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const getHomeUrl = () => {
    if (!user || !user.user_type) return createPageUrl("UpdateUserType");

    if (user.user_type === 'stratosfyre_admin') return createPageUrl("CommandCentre");
    if (user.user_type === 'client') return createPageUrl("TenantDashboard");
    if (user.user_type === 'agent_landlord') return createPageUrl("SubmitListing");

    return createPageUrl("UpdateUserType");
  };

  const homeUrl = getHomeUrl();

  const NavLinks = ({ isCompact = false }) => {
    const navigationStructure = getNavigationStructure();

    return (
      <nav className="space-y-1 px-3">
        {navigationStructure.map((item) => {
          if (item.standalone) {
            return (
              <Link
                key={item.title}
                to={item.url}
                onClick={() => isMobileMenuOpen && setIsMobileMenuOpen(false)}
                className={cn(
                  "group flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200",
                  isActive(item.url)
                    ? "text-white bg-white/10 border border-white/10"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
                title={!sidebarExpanded ? item.title : undefined}
              >
                <item.icon className="w-5 h-5 flex-shrink-0 opacity-80 group-hover:opacity-100" />
                <span className={`transition-opacity duration-200 ${sidebarExpanded ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'}`}>
                  {item.title}
                </span>
              </Link>
            );
          }

          if (item.isSection) {
            const isExpanded = expandedSections[item.key] && sidebarExpanded;
            const sectionActive = isSectionActive(item); 

            return (
              <div key={item.key} className="space-y-1">
                <button
                  onClick={() => toggleSection(item.key)}
                  className={cn(
                    "flex items-center w-full gap-3 px-3 py-2 rounded-lg text-xs font-semibold tracking-wide uppercase transition-all duration-200",
                    sectionActive 
                      ? "text-white bg-white/5 border border-white/10" 
                      : "text-gray-400 hover:text-white hover:bg-white/5"
                  )}
                  title={!sidebarExpanded ? item.title : undefined}
                >
                  <item.icon className="w-4 h-4 flex-shrink-0 opacity-70" />
                  <span className={`transition-opacity duration-200 ${sidebarExpanded ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'}`}>
                    {item.title}
                  </span>
                  <ChevronRight className={cn(
                    "ml-auto w-3.5 h-3.5 transition-all duration-200", 
                    isExpanded && "rotate-90",
                    !sidebarExpanded && "opacity-0 w-0"
                  )} />
                </button>

                {isExpanded && (
                  <div className="ml-6 space-y-1 animate-in slide-in-from-top-2 duration-200">
                    {item.items.map((subItem) => (
                      <Link
                        key={subItem.title}
                        to={subItem.url}
                        onClick={() => isMobileMenuOpen && setIsMobileMenuOpen(false)}
                        className={cn(
                          "flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200",
                          isActive(subItem.url)
                            ? "text-white bg-white/10 border border-white/10"
                            : "text-gray-400 hover:text-white hover:bg-white/5"
                        )}
                      >
                        <subItem.icon className="w-4 h-4 opacity-70 flex-shrink-0" />
                        <span>{subItem.title}</span>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            );
          }

          return null;
        })}
      </nav>
    );
  };

  return (
    <ViewAsProvider>
      <UnitProvider>
        <InspectionPackProvider>
          <ErrorBoundary>
            <style>{`
            /* ORBIT Design System - Global Styles with WCAG AA Compliant Colors */
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

            :root {
              --bg: #0A0E14;
              --onDark-strong: #FFFFFF;
              --onDark-mid: #E5E7EB;
              --onDark-mute: #D1D5DB;
              --onLight-strong: #1F2937;
              --onLight-mid: #374151;
              --onLight-mute: #6B7280;
              --horizon-orange: #EA580C;
              --horizon-orange-text: #FFFFFF;
              --orbit-teal: #0891B2;
              --stratos-gradient: linear-gradient(180deg, #0A0E14 0%, #0F1722 60%, #0E4C88 90%);
              --space-gradient: linear-gradient(180deg, #0a0e1a 0%, #1a1f3a 30%, #2d1b69 60%, #EA580C 100%);
              --starlight: #FFFFFF;
              --divider: rgba(255,255,255,0.06);
            }

            body {
              font-family: 'Inter', system-ui, sans-serif;
              background: var(--stratos-gradient);
              background-attachment: fixed;
              -webkit-font-smoothing: antialiased;
              -moz-osx-font-smoothing: grayscale;
              color: var(--starlight);
              margin: 0;
              padding: 0;
            }

            /* Specific text color override for Tailwind's text-teal-400 to use our design system teal */
            .text-teal-400 {
              color: var(--orbit-teal) !important;
            }

            /* Ensure all text within space-header is starlight for contrast against its complex gradient */
            .space-header * {
              color: var(--starlight) !important;
            }

            /* Sidebar contrast */
            .stratos-sidebar {
              width: 64px;
              background: rgba(15,23,34,0.95);
              border-right: 1px solid rgba(255,255,255,0.06);
              backdrop-filter: blur(12px);
              transition: width 300ms cubic-bezier(0.4, 0, 0.2, 1);
              color: var(--starlight);
            }

            .stratos-sidebar:hover,
            .stratos-sidebar.expanded {
              width: 280px;
            }

            .stratos-sidebar-mobile {
              width: 280px;
              background: rgba(15,23,34,0.98);
              backdrop-filter: blur(12px);
              color: var(--starlight);
            }

            .stratos-topbar {
              height: 64px;
              backdrop-filter: blur(12px);
              color: var(--starlight);
            }

            .stratos-search {
              width: 280px;
              transition: width 180ms ease;
            }

            .stratos-search.expanded {
              width: 400px;
            }
            
            .orbit-input {
              background: rgba(255,255,255,0.03);
              border: 1px solid rgba(255,255,255,0.1);
              color: var(--starlight);
            }

            .orbit-button {
              transition: all 180ms ease;
            }

            /* Custom scrollbar for webkit browsers */
            .scroll-slim::-webkit-scrollbar {
              width: 6px;
            }
            .scroll-slim::-webkit-scrollbar-track {
              background: rgba(255, 255, 255, 0.05);
              border-radius: 10px;
            }
            .scroll-slim::-webkit-scrollbar-thumb {
              background-color: rgba(255, 255, 255, 0.15);
              border-radius: 10px;
              border: 1px solid rgba(255, 255, 255, 0.1);
            }
            .scroll-slim::-webkit-scrollbar-thumb:hover {
              background-color: rgba(255, 255, 255, 0.25);
            }

            /* Satellite Easter Egg Animation - FIXED */
            @keyframes satellite-drift {
              0%   { transform: translateX(-100px) translateY(0) rotate(0deg); opacity: 1; }
              5%   { opacity: 1; }
              50%  { transform: translateX(calc(50vw - 14px)) translateY(-2px) rotate(3deg); opacity: 1; }
              95%  { opacity: 1; }
              100% { transform: translateX(calc(100vw + 100px)) translateY(0) rotate(0deg); opacity: 1; }
            }

            @keyframes satellite-bob {
              0%,100% { transform: translateY(0); }
              50%     { transform: translateY(-3px); }
            }

            .satellite-track { 
              position: absolute; 
              top: 0;
              left: 0;
              width: 100vw;
              height: 100%;
              pointer-events: none; 
              overflow: visible;
              z-index: 50;
            }

            .satellite-btn {
              position: absolute; 
              top: 20px; 
              left: 0;
              pointer-events: auto; 
              cursor: pointer;
              z-index: 51;
              animation: satellite-drift var(--satellite-speed, 25s) linear infinite;
              will-change: transform;
            }

            .satellite-icon {
              width: 32px; 
              height: 32px; 
              display: block;
              filter: drop-shadow(0 2px 4px rgba(0,0,0,.4));
              transition: transform 0.2s ease;
            }

            .satellite-btn:hover .satellite-icon { 
              transform: scale(1.1); 
            }

            .satellite-spark { 
              animation: satellite-bob 2.8s ease-in-out infinite; 
            }

            /* Starfield for easter egg */
            .starfield {
              position: fixed; 
              inset: 0; 
              pointer-events: none; 
              z-index: 60;
              background: radial-gradient(1200px 800px at 20% -20%, rgba(99,102,241,.10), transparent 50%);
              animation: fade-in-out 6s ease both;
            }
            
            .starfield .star {
              position: absolute; 
              width: 2px; 
              height: 2px; 
              border-radius: 9999px; 
              background: #fff; 
              opacity: .9;
              animation: twinkle var(--twinkle, 2.6s) ease-in-out infinite;
              box-shadow: 0 0 6px rgba(255,255,255,.65);
            }

            @keyframes fade-in-out {
              0% { opacity: 0; } 
              10% { opacity: 1; } 
              90% { opacity: 1; } 
              100% { opacity: 0; }
            }
          `}</style>

            <div className="flex h-screen" style={{background: 'var(--stratos-gradient)', color: 'var(--starlight)'}}>
              {/* Desktop Sidebar - Icon-based with Hover Expansion */}
              <div
                className="stratos-sidebar hidden lg:flex flex-col flex-shrink-0 group"
                onMouseEnter={() => {
                  setSidebarExpanded(true);
                }}
                onMouseLeave={() => {
                  setSidebarExpanded(false);
                  collapseAllSections();
                }}
              >
                <div className="flex flex-col h-full">
                  {/* Logo Section */}
                  <Link to={homeUrl} className="flex items-center gap-3 p-4 min-h-[80px]" style={{borderBottom: '1px solid rgba(255,255,255,0.1)'}}>
                    <img 
                      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/688244252a7b37f0b4a1bcf9/654b94ac8_OrbitLogocopy.png" 
                      alt="ORBIT" 
                      className="w-8 h-8 flex-shrink-0 object-contain"
                      onError={(e) => {
                        e.target.style.display = 'none';
                        e.target.nextSibling.style.display = 'flex';
                      }}
                    />
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-orange-500 to-amber-500 items-center justify-center flex-shrink-0 hidden">
                      <span className="text-white font-bold text-sm">O</span>
                    </div>
                    <div className={`transition-opacity duration-300 overflow-hidden ${sidebarExpanded ? 'opacity-100 w-auto' : 'opacity-0 w-0'}`}>
                      <h1 className="text-sm font-semibold text-white whitespace-nowrap">ORBIT</h1>
                      <p className="text-xs text-teal-400 uppercase tracking-wide">by Stratosfyre</p>
                    </div>
                  </Link>

                  {/* Navigation */}
                  <div className="flex-grow overflow-y-auto py-4 scroll-slim">
                    <NavLinks isCompact={true} />
                  </div>

                  {/* User Section */}
                  <div className="p-4 min-h-[100px]" style={{borderTop: '1px solid rgba(255,255,255,0.1)'}}>
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{background: 'var(--horizon-orange)'}}>
                        <span className="text-xs font-semibold text-white">
                          {user?.first_name?.[0]}{user?.last_name?.[0]}
                        </span>
                      </div>
                      <div className={`transition-opacity duration-300 overflow-hidden ${sidebarExpanded ? 'opacity-100 w-auto' : 'opacity-0 w-0'}`}>
                        <div className="text-xs text-white font-medium truncate">
                          {user?.first_name} {user?.last_name}
                        </div>
                        <div className="text-xs text-gray-400 truncate">{getUserTypeDisplay()}</div>
                      </div>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center justify-center gap-2 p-2 rounded-lg transition-colors hover:bg-white/5"
                      style={{background: 'rgba(255,255,255,0.02)'}}
                      title="Sign Out"
                    >
                      <LogOut className="w-4 h-4 text-gray-400 flex-shrink-0" />
                      <span className={`text-sm text-gray-400 transition-opacity duration-300 ${sidebarExpanded ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'}`}>
                        Sign Out
                      </span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Mobile Menu Overlay */}
              {isMobileMenuOpen && (
                <div className="fixed inset-0 z-50 flex lg:hidden">
                  <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setIsMobileMenuOpen(false)}></div>
                  <div className="stratos-sidebar-mobile relative flex flex-col flex-shrink-0 h-full">
                    <div className="p-6 flex-grow flex flex-col">
                      <Link to={homeUrl} className="flex items-center gap-3 mb-8 group cursor-pointer" onClick={() => setIsMobileMenuOpen(false)}>
                        <img 
                          src="/images/orbit_logo_icon.png" 
                          alt="ORBIT" 
                          className="w-12 h-12"
                          onError={(e) => {
                            e.target.style.display = 'none';
                            e.target.nextSibling.style.display = 'flex';
                          }}
                        />
                        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-orange-500 to-amber-500 items-center justify-center hidden">
                          <span className="text-white font-bold text-lg">O</span>
                        </div>
                        <div>
                          <h1 className="text-xl font-bold text-white">ORBIT</h1>
                          <p className="text-xs text-teal-400 uppercase tracking-wide">by Stratosfyre</p>
                        </div>
                      </Link>
                      <div className="flex-grow overflow-y-auto">
                        <NavLinks />
                      </div>
                      <div className="mt-auto">
                        <div className="p-3 sm:p-4 mb-3 sm:mb-4" style={{
                          background: 'rgba(255,255,255,0.03)',
                          border: '1px solid rgba(255,255,255,0.06)',
                          borderRadius: '12px'
                        }}>
                          <p className="font-semibold text-white">{user?.first_name} {user?.last_name}</p>
                          <p className="text-sm text-gray-400 break-words">{user?.company || user?.email}</p>
                          <p className="text-xs text-teal-400 uppercase tracking-wide mt-1">
                            {getUserTypeDisplay()}
                          </p>
                        </div>
                        <button
                          onClick={handleLogout}
                          className="w-full flex items-center gap-3 px-3 sm:px-4 py-2.5 sm:py-3 font-medium min-h-[44px]"
                          style={{
                            background: 'rgba(255,255,255,0.06)',
                            color: 'var(--starlight)',
                            border: '1px solid rgba(255,255,255,0.14)',
                            borderRadius: '8px'
                          }}
                        >
                          <LogOut className="w-4 h-4 sm:w-5 sm:h-5" />
                          <span>Sign Out</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Main Content Area */}
              <div className="flex-1 flex flex-col overflow-hidden">
                {/* Top Bar (Desktop) - Space themed */}
                <header className="space-header stratos-topbar lg:flex items-center justify-between px-6 hidden relative" style={{ overflow: 'visible' }}>
                  
                  <div className="flex-1">
                    {/* This space can be used for contextual controls if needed */}
                  </div>

                  {/* Right Cluster */}
                  <div className="flex items-center gap-4">
                    <ViewAsToggle />
                    <button
                      onClick={() => { const on = !document.body.classList.contains('cosmic'); setCosmic(on); }}
                      className="p-2 rounded-lg text-sm text-gray-400 hover:text-white transition-colors"
                      style={{background: 'rgba(255,255,255,0.02)'}}
                    >
                      Cosmic
                    </button>
                    {/* Search */}
                    <div
                      className={`stratos-search ${searchExpanded ? 'expanded' : ''}`}
                      onFocus={() => setSearchExpanded(true)}
                      onBlur={() => setSearchExpanded(false)}
                    >
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                          type="text"
                          placeholder="Search..."
                          className="w-full h-9 pl-10 pr-12 rounded-lg text-sm text-white placeholder-gray-400 focus:outline-none"
                          style={{
                            background: 'rgba(255,255,255,0.03)',
                            border: '1px solid rgba(255,255,255,0.1)'
                          }}
                          onFocus={() => setCommandPaletteOpen(true)}
                          readOnly
                        />
                        <kbd className="absolute right-3 top-1/2 -translate-y-1/2 px-1.5 py-0.5 rounded text-xs text-gray-400" style={{
                          background: 'rgba(255,255,255,0.02)',
                          border: '1px solid rgba(255,255,255,0.1)'
                        }}>
                          ⌘K
                        </kbd>
                      </div>
                    </div>

                    {/* Notifications */}
                    <button className="p-2 rounded-lg transition-colors" style={{background: 'rgba(255,255,255,0.02)'}}>
                      <Bell className="w-5 h-5 text-gray-400" />
                    </button>

                    {/* Help */}
                    <button className="p-2 rounded-lg transition-colors" style={{background: 'rgba(255,255,255,0.02)'}}>
                      <HelpCircle className="w-5 h-5 text-gray-400" />
                    </button>

                    {/* Profile */}
                    <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{background: 'var(--horizon-orange)'}}>
                      <span className="text-sm font-semibold text-white">
                        {user?.first_name?.[0]}{user?.last_name?.[0]}
                      </span>
                    </div>
                  </div>
                </header>

                {/* Mobile Header - Space themed */}
                <header className="lg:hidden p-4 flex flex-col gap-4 min-h-[60px] space-header relative" style={{ overflow: 'visible' }}>
                  
                  <div className="flex items-center justify-between">
                      <Link to={getHomeUrl()} className="flex items-center gap-2">
                        <img 
                          src="/images/orbit_logo_icon.png" 
                          alt="ORBIT" 
                          className="w-8 h-8"
                          onError={(e) => {
                            e.target.style.display = 'none';
                            e.target.nextSibling.style.display = 'flex';
                          }}
                        />
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-orange-500 to-amber-500 items-center justify-center hidden">
                          <span className="text-white font-bold text-sm">O</span>
                        </div>
                        <span className="text-lg font-bold text-white">ORBIT</span>
                      </Link>
                      <button
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                        className="p-2 min-h-[44px] min-w-[44px] flex items-center justify-center"
                        style={{
                          background: 'rgba(255,255,255,0.06)',
                          color: 'var(--starlight)',
                          border: '1px solid rgba(255,255,255,0.14)',
                          borderRadius: '8px'
                        }}
                        aria-label="Toggle menu"
                      >
                        {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                      </button>
                  </div>
                </header>

                {/* Main Content */}
                <main className="flex-1 overflow-y-auto relative">
                  <div className="max-w-full mx-auto">
                    {children}
                  </div>
                  <CosmicBadge />
                </main>
              </div>
            </div>
            
            <SatelliteEasterEgg />
            <CommandPalette open={commandPaletteOpen} onOpenChange={setCommandPaletteOpen} />
            <Toaster />
          </ErrorBoundary>
        </InspectionPackProvider>
      </UnitProvider>
    </ViewAsProvider>
  );
}

