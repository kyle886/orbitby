
import React from "react";
import registry from "@/components/admin/registry";
import { applySuggestedIndexes } from "@/api/functions";
// --- Adding all missing function imports below ---
import { system_geoCoverageReport } from "@/api/functions";
import { system_imageCompletenessReport } from "@/api/functions";
import { system_indexAdvisor } from "@/api/functions";
import { system_errorTrendReport } from "@/api/functions";
import { system_chartShapeReport } from "@/api/functions";
import { system_storageUsageReport } from "@/api/functions";
import { system_testDataCount } from "@/api/functions";
import { system_integrityReport } from "@/api/functions";
import { backfillBuildingGeocodes } from "@/api/functions";
import { repairListingPhotos } from "@/api/functions";
import { dedupeSitePages } from "@/api/functions";
import { purgeTestData } from "@/api/functions";

// Bundle imported functions into a single object for easy lookup
const availableFunctions = {
  applySuggestedIndexes,
  system_geoCoverageReport,
  system_imageCompletenessReport,
  system_indexAdvisor,
  system_errorTrendReport,
  system_chartShapeReport,
  system_storageUsageReport,
  system_testDataCount,
  system_integrityReport,
  backfillBuildingGeocodes,
  repairListingPhotos,
  dedupeSitePages,
  purgeTestData,
};

function Toast({ kind, title, msg, onDone }) {
  React.useEffect(()=>{ const t=setTimeout(onDone, 3800); return ()=>clearTimeout(t); },[onDone]);
  return (
    <div className={`pointer-events-auto rounded-xl p-3 mb-2 border ${kind==="error" ? "border-red-500/30 bg-red-500/10" : "border-emerald-500/30 bg-emerald-500/10"}`}>
      <div className="text-sm font-medium">{title}</div>
      {msg ? <div className="text-xs opacity-80 mt-1">{msg}</div> : null}
    </div>
  );
}
function useToasts(){
  const [items,setItems]=React.useState([]);
  const push=(t)=>setItems(x=>[...x,{id:crypto.randomUUID?.()||Math.random().toString(36).slice(2),...t}]);
  const remove=(id)=>setItems(x=>x.filter(i=>i.id!==id));
  const view=(<div className="fixed right-4 bottom-4 z-50 flex flex-col items-end pointer-events-none">{items.map(t=><Toast key={t.id}{...t} onDone={()=>remove(t.id)}/>)}</div>);
  return {push,view};
}
function summarize(obj, keys=[]) {
  try{
    if (!obj || typeof obj!=="object") return "";
    const flat={};
    const walk=(o,p="",d=0)=>{ if(d>2)return; for(const[k,v]of Object.entries(o)){ const key=p?`${p}.${k}`:k; if(["number","boolean","string"].includes(typeof v)) flat[key]=v; else if(v&&typeof v==="object") walk(v,key,d+1);} };
    walk(obj);
    const pick = keys.length ? keys : Object.keys(flat).filter(k=>/ok|count|total|missing|failed|updated|url|duration/i.test(k));
    return pick.map(k=>flat[k]!=null?`${k}: ${String(flat[k]).slice(0,120)}`:null).filter(Boolean).slice(0,5).join(" • ");
  }catch{ return ""; }
}

/**
 * Local smart button (no external deps).
 * It will prefer to use the `runAndLogAction` wrapper if available,
 * otherwise it will fall back to calling the function directly.
 * It also supports a `clientRun` for frontend-only actions.
 */
function TileButton({ action, availableFns, pushToast }) {
  const [busy,setBusy]=React.useState(false);
  const globalFns = window.base44?.functions || {}; // These are global helpers or backend-registered functions
  const wrapperOk = !!globalFns.runAndLogAction;

  // Determine if the action's primaryFn exists in either global or locally imported functions
  const primaryFnIsGlobal = !!(action.primaryFn && globalFns[action.primaryFn]);
  const primaryFnIsLocal = !!(action.primaryFn && availableFns[action.primaryFn]);

  // A function is "present" if it can be run via global, local, or clientRun
  const present = primaryFnIsGlobal || primaryFnIsLocal || action.clientRun;
  const disabled = busy || !present;

  async function run(){
    if (action.confirm) {
      const phrase = prompt(`Type ${action.confirm} to confirm`);
      if (phrase !== action.confirm) return;
    }
    setBusy(true);
    const t0 = performance.now();
    try{
      let result;
      if (wrapperOk && primaryFnIsGlobal) {
        // If runAndLogAction wrapper is available AND the primaryFn is registered globally
        // use the global wrapper, which typically resolves the function by name on the backend.
        result = await globalFns.runAndLogAction({ key: action.key, label: action.label, fn: action.primaryFn, args: action.args||{}, sampleKeys: action.sampleKeys||[] });
      } else if (primaryFnIsGlobal) {
        // If primaryFn is registered globally but no runAndLogAction wrapper, call it directly.
        result = await globalFns[action.primaryFn](action.args||{});
        await globalFns.logOpsEvent?.({ key: action.key, label: action.label, result: { ...(result||{}), durationMs: Math.round(performance.now()-t0) } });
      } else if (primaryFnIsLocal) {
        // If primaryFn is one of our locally imported functions, call it directly.
        // We don't use runAndLogAction for these as it implies a server-side call.
        result = await availableFns[action.primaryFn](action.args||{});
        await globalFns.logOpsEvent?.({ key: action.key, label: action.label, result: { ...(result||{}), durationMs: Math.round(performance.now()-t0) } });
      } else if (action.clientRun) {
        // If it's a purely client-side function defined within the action itself
        result = await action.clientRun();
        await globalFns.logOpsEvent?.({ key: action.key, label: action.label, result: { ...(result||{}), durationMs: Math.round(performance.now()-t0) } });
      } else {
        throw new Error("No runner available for this action.");
      }
      const summary = summarize(result, action.sampleKeys);
      pushToast({ kind:"ok", title: action.label, msg: summary || "Success" });
      if (result?.url) window.open(result.url, "_blank");
    }catch(e){
      pushToast({ kind:"error", title: action.label, msg: e?.message || String(e) });
      await globalFns.logOpsEvent?.({ key: action.key, label: action.label, error: e?.message || String(e) });
    }finally{ setBusy(false); }
  }

  return (
    <button
      className={`px-4 py-2 rounded-lg border ${present? "hover:border-white/30":"opacity-50 cursor-not-allowed"} border-white/10 bg-white/5`}
      onClick={run} disabled={disabled} title={!present?"Function not available":""}
    >
      {busy ? "Running…" : action.label}
    </button>
  );
}

function Section({ title, children }) {
  return (
    <section className="space-y-3">
      <div className="text-xs uppercase tracking-wide text-neutral-400">{title}</div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">{children}</div>
    </section>
  );
}

export default function SystemReports(){
  const { push, view } = useToasts();
  const globalFns = window.base44?.functions || {};
  const wrapper = !!globalFns.runAndLogAction; // Check for wrapper availability

  return (
    <div className="p-6 space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">System Reports &amp; Tests</h2>
        <div className="text-xs text-neutral-400">Wrapper: {wrapper ? "available" : "not found"}</div>
      </div>

      {registry.map(group => (
        <div key={group.title} className="card p-4 space-y-3">
          <Section title={group.title}>
            {group.items.map(action => (
              <TileButton key={action.key} action={action} availableFns={availableFunctions} pushToast={push} />
            ))}
          </Section>
        </div>
      ))}

      {view}
    </div>
  );
}
