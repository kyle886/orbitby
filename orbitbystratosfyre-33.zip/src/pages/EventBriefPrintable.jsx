import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Event } from '@/api/entities';
import { EventROI } from '@/api/entities';
import { BDEventAttendance } from '@/api/entities';
import { Loader2, Calendar, MapPin, Users, BarChart2, CheckCircle, Target, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function EventBriefPrintable() {
    const [event, setEvent] = useState(null);
    const [roi, setRoi] = useState(null);
    const [attendees, setAttendees] = useState([]);
    const [loading, setLoading] = useState(true);
    const location = useLocation();

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const eventId = params.get('id');
        if (eventId) {
            loadData(eventId);
        } else {
            setLoading(false);
        }
    }, [location.search]);

    const loadData = async (eventId) => {
        try {
            const [eventData, roiData, attendanceData] = await Promise.all([
                Event.get(eventId),
                EventROI.filter({ event_id: eventId }),
                BDEventAttendance.filter({ event_id: eventId })
            ]);
            setEvent(eventData);
            setRoi(roiData[0] || null);
            setAttendees(attendanceData || []);
        } catch (error) {
            console.error("Error loading printable brief data:", error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-gray-800" /></div>;
    }

    if (!event) {
        return <div className="text-center p-8">Event not found. Please check the ID.</div>;
    }

    return (
        <div className="bg-white text-gray-800 p-8 font-sans">
            <style>
                {`
                    @media print {
                        .no-print { display: none; }
                        body { -webkit-print-color-adjust: exact; }
                    }
                `}
            </style>
            
            <div className="no-print mb-8 flex justify-end gap-4">
                <Button onClick={() => window.print()}>Print or Save as PDF</Button>
            </div>

            <div className="max-w-4xl mx-auto">
                <header className="border-b-2 border-gray-200 pb-4 mb-8">
                    <h1 className="text-4xl font-bold text-gray-900">{event.event_name}</h1>
                    <p className="text-lg text-gray-600">{new Date(event.event_date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                </header>

                <main className="grid grid-cols-3 gap-8">
                    <div className="col-span-2 space-y-8">
                        <section>
                            <h2 className="text-2xl font-semibold text-gray-800 border-b pb-2 mb-4">Event Details</h2>
                            <div className="space-y-2">
                                <p><strong className="w-32 inline-block">Location:</strong> {event.location}</p>
                                <p><strong className="w-32 inline-block">Type:</strong> {event.type}</p>
                                <p><strong className="w-32 inline-block">Description:</strong> {event.description}</p>
                            </div>
                        </section>

                        <section>
                            <h2 className="text-2xl font-semibold text-gray-800 border-b pb-2 mb-4">ROI Analysis</h2>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="bg-gray-100 p-4 rounded-lg">
                                    <p className="text-sm text-gray-600">ROI Score</p>
                                    <p className="text-3xl font-bold">{roi?.roi_score || 'N/A'}</p>
                                </div>
                                <div className="bg-gray-100 p-4 rounded-lg">
                                    <p className="text-sm text-gray-600">Recommendation</p>
                                    <p className="text-3xl font-bold capitalize">{roi?.sponsor_rec || 'N/A'}</p>
                                </div>
                                <div className="bg-gray-100 p-4 rounded-lg">
                                    <p className="text-sm text-gray-600">Target Overlap</p>
                                    <p className="text-3xl font-bold">{roi?.target_overlap_pct || 0}%</p>
                                </div>
                                <div className="bg-gray-100 p-4 rounded-lg">
                                    <p className="text-sm text-gray-600">Expected Value</p>
                                    <p className="text-3xl font-bold">${(roi?.expected_value_aud || 0).toLocaleString()}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <aside className="col-span-1 bg-gray-50 p-6 rounded-lg">
                        <h2 className="text-2xl font-semibold text-gray-800 border-b pb-2 mb-4">Attendance Plan</h2>
                        <div>
                            <h3 className="font-bold mb-2">Assigned Team:</h3>
                            <ul className="list-disc list-inside space-y-1">
                                {attendees.length > 0 ? (
                                    attendees.map(att => <li key={att.id}>{att.user_email}</li>)
                                ) : (
                                    <li>No attendees assigned.</li>
                                )}
                            </ul>
                        </div>
                    </aside>
                </main>
            </div>
        </div>
    );
}