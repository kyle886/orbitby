
import React, { useState, useEffect, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import { TenantRequirement } from "@/api/entities";
import { Client } from "@/api/entities";
import { SendEmail } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, XCircle, FileText, Building, MapPin, Calendar } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function ClientBriefApproval() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const briefId = searchParams.get('briefId');
  
  const [brief, setBrief] = useState(null);
  const [client, setClient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [decision, setDecision] = useState("");
  const { toast } = useToast();

  const loadBriefData = useCallback(async () => {
    if (!briefId) {
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const briefData = await TenantRequirement.get(briefId);
      setBrief(briefData);

      if (briefData.client_id) {
        const clientData = await Client.get(briefData.client_id);
        setClient(clientData);
      }
    } catch (error) {
      console.error("Error loading brief:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load brief details."
      });
    } finally {
      setLoading(false);
    }
  }, [briefId, toast]); // Dependencies for useCallback

  useEffect(() => {
    loadBriefData();
  }, [loadBriefData]); // Dependency for useEffect

  const handleApproval = async (approved) => {
    setSubmitting(true);
    setDecision(approved ? 'approved' : 'needs_revision');

    try {
      const updateData = {
        status: approved ? 'active' : 'needs_revision',
        client_approval_notes: feedback || (approved ? 'Approved by client' : 'Client requested revisions')
      };

      await TenantRequirement.update(briefId, updateData);

      // Send notification to Stratosfyre team
      await SendEmail({
        to: "team@stratosfyre.com", // Replace with actual team email
        subject: `Brief ${approved ? 'Approved' : 'Requires Revision'}: ${brief.company_name}`,
        body: `The client ${client?.company_name || 'Unknown'} has ${approved ? 'approved' : 'requested revisions to'} their brief.

Brief Reference: ${brief.brief_reference_code}
Company: ${brief.company_name}
Contact: ${brief.contact_name} (${brief.contact_email})

${feedback ? `Client Feedback: ${feedback}` : ''}

${approved ? 
  'The brief is now active and ready to go to market.' : 
  'Please review the client feedback and make necessary revisions before resubmitting for approval.'}

View full brief details in ORBIT.`,
        from_name: "ORBIT Platform"
      });

      toast({
        title: approved ? "Brief Approved" : "Feedback Submitted",
        description: approved ? 
          "Your brief has been approved and we'll begin the search process." :
          "Your feedback has been submitted. We'll review and make revisions."
      });

    } catch (error) {
      console.error("Error submitting approval:", error);
      toast({
        variant: "destructive",
        title: "Submission Failed",
        description: "Failed to submit your response. Please try again."
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="orbit-card p-8">
          <Loader2 className="w-8 h-8 animate-spin text-orange-400 mx-auto" />
        </div>
      </div>
    );
  }

  if (!brief) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="orbit-card p-8 max-w-md text-center">
          <XCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-white mb-2">Brief Not Found</h3>
          <p className="text-gray-400">The brief you're looking for could not be found or the approval link has expired.</p>
        </div>
      </div>
    );
  }

  if (decision) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="orbit-card p-8 max-w-md text-center">
          <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-white mb-2">
            {decision === 'approved' ? 'Brief Approved!' : 'Feedback Submitted'}
          </h3>
          <p className="text-gray-400">
            {decision === 'approved' ? 
              'Thank you for approving your brief. We will begin the property search process and keep you updated.' :
              'Thank you for your feedback. We will review your comments and make the necessary revisions.'
            }
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/688244252a7b37f0b4a1bcf9/9234d12f6_image.png" 
            alt="ORBIT by Stratosfyre" 
            className="w-48 mx-auto mb-6"
          />
          <h1 className="text-3xl font-bold text-white mb-2">Brief Approval Required</h1>
          <p className="text-gray-300">Please review your property brief and let us know if you'd like to proceed.</p>
        </div>

        {/* Brief Details */}
        <Card className="orbit-card mb-8">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-white">{brief.company_name}</CardTitle>
                <p className="text-gray-400">Brief Reference: {brief.brief_reference_code}</p>
              </div>
              <Badge className="bg-yellow-500/20 text-yellow-300">
                Awaiting Approval
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Building className="w-4 h-4" />
                  Property Requirements
                </h4>
                <div className="space-y-2 text-sm">
                  <p className="text-gray-300">
                    <span className="text-gray-500">Type:</span> {brief.property_type}
                  </p>
                  <p className="text-gray-300">
                    <span className="text-gray-500">Size:</span> {brief.min_floor_area} - {brief.max_floor_area || '∞'} sqm
                  </p>
                  <p className="text-gray-300">
                    <span className="text-gray-500">Lease Term:</span> {brief.lease_term_years} years
                  </p>
                  {brief.building_grade && (
                    <p className="text-gray-300">
                      <span className="text-gray-500">Building Grade:</span> {brief.building_grade.join(', ')}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Location & Timing
                </h4>
                <div className="space-y-2 text-sm">
                  <p className="text-gray-300">
                    <span className="text-gray-500">Preferred Areas:</span> {brief.preferred_suburbs?.join(', ') || 'Flexible'}
                  </p>
                  <p className="text-gray-300">
                    <span className="text-gray-500">Required Date:</span> {new Date(brief.required_date).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </div>

            {brief.required_amenities && brief.required_amenities.length > 0 && (
              <div>
                <h4 className="text-white font-medium mb-3">Required Amenities</h4>
                <div className="flex flex-wrap gap-2">
                  {brief.required_amenities.map((amenity, index) => (
                    <Badge key={index} variant="outline" className="border-gray-600 text-gray-300">
                      {amenity}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {brief.additional_notes && (
              <div>
                <h4 className="text-white font-medium mb-3">Additional Notes</h4>
                <p className="text-gray-300 text-sm bg-gray-800/50 p-4 rounded-lg">
                  {brief.additional_notes}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Approval Section */}
        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-white">Your Response</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">
                Feedback or Comments (Optional)
              </label>
              <Textarea
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                placeholder="Let us know if you'd like any changes or have additional requirements..."
                className="orbit-input text-white min-h-[100px]"
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => handleApproval(false)}
                disabled={submitting}
                variant="outline"
                className="flex-1 orbit-button text-gray-300 border-gray-600 hover:bg-gray-800"
              >
                {submitting && decision === 'needs_revision' ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <XCircle className="w-4 h-4 mr-2" />
                )}
                Request Revisions
              </Button>
              
              <Button
                onClick={() => handleApproval(true)}
                disabled={submitting}
                className="flex-1 orbit-button bg-gradient-to-r from-green-500 to-green-600 text-white border-0"
              >
                {submitting && decision === 'approved' ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <CheckCircle className="w-4 h-4 mr-2" />
                )}
                Approve Brief
              </Button>
            </div>

            <p className="text-xs text-gray-500 text-center">
              By approving this brief, you confirm that all details are accurate and authorize us to begin the property search process.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
