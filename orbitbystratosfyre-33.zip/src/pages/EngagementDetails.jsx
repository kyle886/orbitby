
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Engagement, User } from '@/api/entities';
import { Badge } from "@/components/ui/badge";
import { useToast } from '@/components/ui/use-toast';
import NegotiationCoachPanel from "@/components/negotiation/NegotiationCoachPanel";

export default function EngagementDetails() {
  const { id } = useParams();
  const { toast } = useToast();

  const [eng, setEng] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const e = await Engagement.get(id);
        setEng(e);
        const u = await User.me();
        setCurrentUser(u);
      } catch (error) {
        console.error("Failed to load engagement data:", error);
        toast({ variant: "destructive", title: "Error", description: "Failed to load engagement data" });
      }
    };
    load();
  }, [id, toast]);

  if (!eng) {
    return (
      <div className="p-8 max-w-4xl mx-auto text-white">
        <div>Loading...</div>
      </div>
    );
  }

  const gates = eng.gates || {};

  return (
    <div className="p-8 max-w-4xl mx-auto text-white">
      <h1 className="text-3xl font-bold mb-2">{eng.company_name} Engagement</h1>
      <div className="text-lg text-gray-400 mb-6">State: <Badge>{eng.state}</Badge></div>

      <div className="flex flex-wrap gap-2">
        {Object.entries(gates).map(([key, value]) => (
            <Badge key={key} variant={value ? "default" : "outline"} className="text-xs">
                {key.replace(/_/g, ' ').replace(' ok', '')}
            </Badge>
        ))}
      </div>
      
      {/* Show coach starting from RFP stage */}
      {['RFP','HOA','LeaseExecute','Handover'].includes(eng.state) && (
        <div className="mt-6">
          <NegotiationCoachPanel engagementId={eng.id} currentUser={currentUser} />
        </div>
      )}

      <pre className="mt-8 bg-gray-800 p-4 rounded-lg overflow-x-auto text-xs">
        {JSON.stringify(eng, null, 2)}
      </pre>
    </div>
  );
}
