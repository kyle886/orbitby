
import React, { useState, useEffect, useCallback } from 'react';
import { AgentConfiguration as AgentConfigEntity } from '@/api/entities';
import { Property } from '@/api/entities';
import { Building } from '@/api/entities';
import { Tenancy } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Loader2, Play, Plus, Trash2, Bot, Globe, Clock } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";
import { Badge } from "@/components/ui/badge";
import { PropertySubmission } from '@/api/entities'; // Added import

// Define the expected sources OUTSIDE the component for a stable reference
const expectedDefaultSources = [
  {
    source_name: "RealCommercial",
    website_url: "https://www.realcommercial.com.au/for-lease/sydney-cbd-nsw/offices/?includePropertiesWithin=includesurrounding"
  },
  {
    source_name: "CommercialRealEstate.com.au",
    website_url: "https://www.commercialrealestate.com.au/for-lease/sydney-region-nsw/offices/"
  },
  {
    source_name: "Colliers",
    website_url: "https://www.colliers.com.au/en-au/properties#sort=relevancy&f:listingtype=[For%20Lease]&f:propertytype=[Office]&f:location=New%20South%20Wales%20%3E%20Sydney"
  },
  {
    source_name: "JLL",
    website_url: "https://property.jll.com.au/search?tenureTypes=rent&propertyTypes=office&orderBy=desc&cities=Sydney&regions=New%20South%20Wales&sortBy=dateModifiedAtSource"
  },
  {
    source_name: "CBRE",
    website_url: "https://www.cbre.com.au/properties/offices?Common.ActualAddress.Common.PostalAddresses.Common.Region=NSW"
  },
  {
    source_name: "Cadigal",
    website_url: "https://www.cadigal.com.au/offices-for-lease?regions=Sydney+CBD"
  },
  {
    source_name: "Cushman & Wakefield",
    website_url: "https://www.cushmanwakefield.com/en/australia/properties/lease/lease-property-search-page#f:PropertyType=[Offices]&f:StateProvince=[NSW]&f:City=[Sydney]"
  },
  {
    source_name: "Knight Frank",
    website_url: "https://www.knightfrank.com.au/properties/commercial/to-let/australia-nsw-sydney/office/min-max-sqm"
  },
  {
    source_name: "Ray White Commercial",
    website_url: "https://www.raywhitecommercial.com/listing?type=lease&address=Sydney%2C+NSW+2000&location=130d0d1006080907120f0b0f100c0f120a0b0a12706d69&category=OFF"
  }
];


export default function AgentConfiguration() {
  const [configs, setConfigs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [runningScans, setRunningScans] = useState({});
  const { toast } = useToast();

  const loadConfigs = useCallback(async () => {
    setLoading(true);
    try {
      const data = await AgentConfigEntity.list();
      setConfigs(data || []);
    } catch (error) {
      console.error("Error loading agent configurations:", error);
      toast({ variant: "destructive", title: "Failed to load configurations." });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadConfigs();
  }, [loadConfigs]);

  // Effect to create/update the default config
  useEffect(() => {
    const ensureDefaultConfig = async () => {
      // Only run once configs are loaded
      if (!loading) {
        let defaultAgentConfig = configs.find((c) => c.agent_name === "Default Sydney Office Scan");

        // Check if sources match the expected ones
        const isSourcesMatch = defaultAgentConfig &&
          Array.isArray(defaultAgentConfig.target_sources) &&
          defaultAgentConfig.target_sources.length === expectedDefaultSources.length &&
          defaultAgentConfig.target_sources.every((src, i) =>
            expectedDefaultSources[i] &&
            src.source_name === expectedDefaultSources[i].source_name &&
            src.website_url === expectedDefaultSources[i].website_url
          );

        const needsUpdate = !defaultAgentConfig || !isSourcesMatch;

        if (needsUpdate) {
          toast({ title: "Configuration Mismatch", description: "Updating default agent to latest version." });
          const newOrUpdatedConfig = {
            agent_name: "Default Sydney Office Scan",
            agent_type: "property_scan",
            target_sources: expectedDefaultSources,
            is_active: true,
            schedule: "daily"
          };

          try {
            if (defaultAgentConfig) {
              await AgentConfigEntity.update(defaultAgentConfig.id, newOrUpdatedConfig);
            } else {
              await AgentConfigEntity.create(newOrUpdatedConfig);
            }
            await loadConfigs(); // Reload to show the updated config
          } catch (error) {
            console.error("Failed to update default config:", error);
            toast({ variant: "destructive", title: "Config Update Failed" });
          }
        }
      }
    };
    ensureDefaultConfig();
  }, [loading, configs, loadConfigs, toast]);

  // AI Property Analysis Function - Fixed
  const runAIPropertyAnalysis = async (properties, activeBriefs) => {
    if (!properties || properties.length === 0 || !activeBriefs || activeBriefs.length === 0) return;

    try {
      const { AIPropertyReview } = await import('@/api/entities');

      let totalAnalyses = 0;
      let createdSubmissions = [];

      for (const property of properties) {
        for (const brief of activeBriefs) {
          try {
            // First create a PropertySubmission record for this property-brief combination
            const submissionData = {
              brief_ids: [brief.id],
              client_id: brief.client_id,
              property_title: property.title,
              street_address: property.address,
              address: property.address, // Legacy field
              suburb: property.suburb || 'Unknown',
              floor_area_sqm: property.floor_area_sqm,
              rental_rate_sqm: property.rental_rate_sqm,
              agent_name: property.agents?.[0]?.name || 'Unknown',
              agent_company: property.agents?.[0]?.company || 'Unknown',
              agent_email: property.agents?.[0]?.email || '',
              agent_phone: property.agents?.[0]?.phone || '',
              status: 'submitted',
              brief_match_status: 'partial_match' // Will be updated by AI
            };

            const submission = await PropertySubmission.create(submissionData);
            createdSubmissions.push(submission);

            // Now analyze this submission against the brief
            const analysisPrompt = `Analyze this property against the client brief and provide a detailed assessment:

PROPERTY:
- Title: ${property.title}
- Address: ${property.address}
- Size: ${property.floor_area_sqm} sqm
- Rental Rate: $${property.rental_rate_sqm}/sqm/annum
- Description: ${property.description}

CLIENT BRIEF:
- Company: ${brief.company_name}
- Required Size: ${brief.min_floor_area} - ${brief.max_floor_area || 'unlimited'} sqm
- Max Budget: $${brief.max_rental_total || 'not specified'}/annum total
- Preferred Suburbs: ${brief.preferred_suburbs?.join(', ') || 'not specified'}
- Required Amenities: ${brief.required_amenities?.join(', ') || 'none specified'}
- Building Grade Preference: ${brief.building_grade?.join(', ') || 'not specified'}

Please provide:
1. An overall match score (0-100)
2. Individual scores for location, size, budget, timing, and amenities (0-10 each)
3. Your recommendation (shortlist, reject, or backup)
4. Detailed reasoning for your recommendation
5. Market positioning assessment (Below Market, At Market, Above Market)`;

            const aiAnalysis = await InvokeLLM({
              prompt: analysisPrompt,
              response_json_schema: {
                type: "object",
                properties: {
                  match_score: { type: "number", minimum: 0, maximum: 100 },
                  recommendation: { type: "string", enum: ["shortlist", "reject", "backup"] },
                  reasoning: { type: "string" },
                  location_score: { type: "number", minimum: 0, maximum: 10 },
                  size_score: { type: "number", minimum: 0, maximum: 10 },
                  budget_score: { type: "number", minimum: 0, maximum: 10 },
                  timing_score: { type: "number", minimum: 0, maximum: 10 },
                  amenities_score: { type: "number", minimum: 0, maximum: 10 },
                  market_positioning: { type: "string", enum: ["Below Market", "At Market", "Above Market"] }
                },
                required: ["match_score", "recommendation", "reasoning", "location_score", "size_score", "budget_score", "timing_score", "amenities_score", "market_positioning"]
              }
            });

            // Create AI review record
            await AIPropertyReview.create({
              submission_id: submission.id,
              brief_id: brief.id,
              ai_recommendation: aiAnalysis.recommendation,
              match_score: aiAnalysis.match_score,
              criteria_scores: {
                location_score: aiAnalysis.location_score,
                size_score: aiAnalysis.size_score,
                budget_score: aiAnalysis.budget_score,
                timing_score: aiAnalysis.timing_score,
                amenities_score: aiAnalysis.amenities_score
              },
              ai_reasoning: aiAnalysis.reasoning,
              deal_prediction: {
                market_positioning: aiAnalysis.market_positioning,
                confidence_level: aiAnalysis.match_score > 80 ? "High" : aiAnalysis.match_score > 60 ? "Medium" : "Low"
              }
            });

            // Update the submission with AI results
            await PropertySubmission.update(submission.id, {
              brief_match_status: aiAnalysis.recommendation === 'shortlist' ? 'on_brief' :
                aiAnalysis.recommendation === 'backup' ? 'partial_match' : 'off_brief',
              match_score: aiAnalysis.match_score,
              status: aiAnalysis.recommendation === 'shortlist' ? 'shortlisted' : 'under_review', // Fixed syntax and logic
              amplifyre_notes: `AI Analysis: ${(aiAnalysis.reasoning || '').substring(0, 200)}...`
            });

            totalAnalyses++;
          } catch (error) {
            console.error(`Failed to analyze property ${property.title} against brief ${brief.brief_reference_code}:`, error);
          }
        }
      }

      toast({
        title: "AI Analysis Complete",
        description: `Created ${createdSubmissions.length} submissions and completed ${totalAnalyses} property-brief analyses.`
      });

    } catch (error) {
      console.error("AI analysis failed:", error);
      toast({
        variant: "destructive",
        title: "AI Analysis Failed",
        description: "Property analysis could not be completed."
      });
    }
  };

  // Smart image filtering function
  const filterPropertyImages = (imageUrls, baseUrl = '') => {
    if (!Array.isArray(imageUrls)) return [];

    const uniqueUrls = new Set();
    const filteredImages = [];

    for (const url of imageUrls) {
      if (!url || typeof url !== 'string') continue;

      const urlLower = url.toLowerCase();

      // Filter out obvious non-property images and common branding
      const excludePatterns = [
        'logo', 'icon', 'sprite', 'button', 'arrow', 'banner', 'header', 'footer',
        'nav', 'menu', 'social', 'facebook', 'twitter', 'linkedin', 'instagram',
        'colliers', 'cbre', 'jll', 'knight', 'frank', 'cushman', 'wakefield',
        'realcommercial', 'commercialrealestate', 'cadigal', 'raywhite',
        'favicon', 'thumb', 'avatar', 'profile', 'user', 'badge', 'watermark',
        'ad', 'advertisement', 'promo', 'marketing', 'brand',
        'agency', 'agent', 'staff', 'team', 'person', 'portrait'
      ];

      // Check if URL contains any exclude patterns
      if (excludePatterns.some(pattern => urlLower.includes(pattern))) {
        continue;
      }

      // Filter out very small images (likely icons/logos)
      const sizeMatch = url.match(/(\d+)x(\d+)|w=(\d+)|h=(\d+)|width=(\d+)|height=(\d+)/i); // Added more patterns for width/height
      let width = 0;
      let height = 0;
      if (sizeMatch) {
          width = parseInt(sizeMatch[1] || sizeMatch[3] || sizeMatch[5] || '0');
          height = parseInt(sizeMatch[2] || sizeMatch[4] || sizeMatch[6] || '0');
          // Heuristic: If one dimension is small and the other isn't specified or is also small
          if ((width > 0 && width < 200) || (height > 0 && height < 150)) {
              continue;
          }
      }

      // Prefer images with property-related keywords
      const propertyKeywords = [
        'building', 'property', 'exterior', 'facade', 'office', 'commercial',
        'floor', 'level', 'suite', 'lobby', 'entrance', 'view', 'photo', 'interior',
        'room', 'space', 'hall', 'reception', 'kitchen', 'amenity', 'lift', 'park',
        'street', 'address', 'aerial'
      ];

      const hasPropertyKeywords = propertyKeywords.some(keyword => urlLower.includes(keyword));

      // If no strong property keywords, but also no strong exclude patterns, keep it as a potential.
      // Prioritize images that either have property keywords OR don't have *any* exclude patterns
      const isClean = !excludePatterns.some(pattern => urlLower.includes(pattern));

      if (!hasPropertyKeywords && !isClean) {
        continue;
      }

      // Deduplicate - normalize URL by removing common tracking params
      let cleanUrl = url.split('?')[0].split('#')[0];
      if (uniqueUrls.has(cleanUrl)) {
          continue;
      }

      uniqueUrls.add(cleanUrl);
      filteredImages.push(url);
    }
    return filteredImages;
  };

  const runScan = async (config) => {
    setRunningScans((prev) => ({ ...prev, [config.id]: true }));
    toast({ title: "Scan Started", description: `Agent '${config.agent_name}' is now scanning sources.` });

    try {
      let allNewProperties = [];
      let failedSources = [];
      let successfulSources = []; // Added

      for (const source of config.target_sources) {
        toast({ title: `Scanning ${source.source_name}...` });
        
        try {
          // Add timeout and retry logic
          const scrapedData = await Promise.race([
            InvokeLLM({
              prompt: `Please search this property listing website and extract office property listings for lease in Sydney:

${source.website_url}

Extract information for each property listing you find:
- Property title/name (required)
- Full street address (required - normalize to consistent format)
- Suburb (if available, or extract from address)
- Floor area in square meters (required - return as number, use 0 if not available)
- Rental rate per sqm per annum (return as number, use 0 if not specified)
- Agent company name (required - use "Unknown" if not available)
- Agent name (if available, use "Not specified" if not available)
- Agent phone (if available, use "Not specified" if not available)
- Agent email (if available, use "Not specified" if not available)
- Property description (brief summary if available)
- Availability date (if mentioned)
- Lease term options (if specified)
- Number of parking spaces (if mentioned)
- Building grade (A, B, C, or D if specified)
- Available amenities/features

IMAGES — IMPORTANT: Only extract BUILDING/PROPERTY images, NOT logos, icons, or branding:

Return:
images: {
  main: string | null,               // PRIMARY building exterior photo only
  gallery: string[],                 // additional BUILDING photos only (max 8)
  floorplans: string[]               // floorplan images only
}

CRITICAL IMAGE RULES:
- ONLY extract images that show the actual building, property interior, or floor plans
- EXCLUDE: company logos, agent photos, icons, navigation elements, advertisements
- Look for images with keywords like: building, exterior, facade, office, lobby, floor, suite, view, interior, room, space, hall, reception, kitchen, amenity, lift, park, street, address, aerial
- AVOID images with: logo, icon, agent, brand, header, footer, nav, button, social, favicon, thumb, avatar, profile, user, badge, watermark, ad, advertisement, promo, marketing, team, person, portrait
- Prefer larger images (avoid thumbnails under 200px width or 150px height)
- For srcset attributes, pick the largest resolution
- Convert relative URLs to absolute using the website's base URL
- Maximum 1 main image, 8 gallery images, 5 floorplan images per property

CRITICAL INSTRUCTIONS:
1. ALWAYS return valid JSON in the exact format specified
2. For numeric fields (floor_area_sqm, rental_rate_sqm, parking_spaces), ONLY use actual numbers, never strings
3. If data is missing, use the default values specified above
4. Focus only on office properties currently available for lease in the Sydney area
5. Return a maximum of 15 properties per source to avoid response size issues
6. Ensure all addresses are complete and specific (include street number, street name, suburb)`,
              add_context_from_internet: true,
              response_json_schema: {
                type: "object",
                properties: {
                  properties: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        address: { type: "string" },
                        suburb: { type: "string" },
                        floor_area_sqm: { type: "number" },
                        rental_rate_sqm: { type: "number" },
                        agent_company: { type: "string" },
                        agent_name: { type: "string" },
                        agent_phone: { type: "string" },
                        agent_email: { type: "string" },
                        description: { type: "string" },
                        availability_date: { type: ["string", "null"], format: "date" },
                        lease_term_options: { type: "string" },
                        parking_spaces: { type: "number" },
                        building_grade: { type: ["string", "null"] },
                        amenities: { type: "array", items: { type: "string" } },
                        images: {
                          type: "object",
                          properties: {
                            main: { type: ["string", "null"] },
                            gallery: { type: "array", items: { type: "string" } },
                            floorplans: { type: "array", items: { type: "string" } }
                          },
                          required: ["main", "gallery", "floorplans"]
                        }
                      },
                      required: ["title", "address", "floor_area_sqm", "agent_company"]
                    }
                  }
                },
                required: ["properties"]
              }
            }),
            // 60 second timeout
            new Promise((_, reject) => 
              setTimeout(() => reject(new Error('Request timeout after 60 seconds')), 60000)
            )
          ]);

          if (scrapedData?.properties && scrapedData.properties.length > 0) {
            // Validate, clean, and enhance the data before adding
            const validProperties = scrapedData.properties.filter((prop) => {
              return prop.title && prop.address &&
                typeof prop.floor_area_sqm === 'number' &&
                prop.floor_area_sqm > 0;
            }).map((prop) => {
              // Clean and filter images
              let cleanImages = { main: null, gallery: [], floorplans: [] };

              if (prop.images) {
                // Filter main image
                if (prop.images.main) {
                  const filtered = filterPropertyImages([prop.images.main], source.website_url);
                  cleanImages.main = filtered.length > 0 ? filtered[0] : null;
                }

                // Filter gallery images
                if (Array.isArray(prop.images.gallery)) {
                  cleanImages.gallery = filterPropertyImages(prop.images.gallery, source.website_url).slice(0, 8);
                }

                // Filter floorplan images
                if (Array.isArray(prop.images.floorplans)) {
                  cleanImages.floorplans = filterPropertyImages(prop.images.floorplans, source.website_url).slice(0, 5);
                }
              }

              return {
                ...prop,
                // Ensure all required fields have fallback values
                suburb: prop.suburb || 'Unknown',
                rental_rate_sqm: typeof prop.rental_rate_sqm === 'number' ? prop.rental_rate_sqm : 0,
                agent_name: prop.agent_name || 'Not specified',
                agent_phone: prop.agent_phone || 'Not specified',
                agent_email: prop.agent_email || 'Not specified',
                description: prop.description || '',
                availability_date: prop.availability_date || null,
                lease_term_options: prop.lease_term_options || '',
                parking_spaces: typeof prop.parking_spaces === 'number' ? prop.parking_spaces : 0,
                building_grade: prop.building_grade || null,
                amenities: Array.isArray(prop.amenities) ? prop.amenities : [],
                source_portal: source.source_name,
                images: cleanImages
              };
            });

            allNewProperties.push(...validProperties);
            successfulSources.push(source.source_name);
            toast({ title: `Success: ${source.source_name}`, description: `Found ${validProperties.length} valid listings.` });
          } else {
            toast({ title: `Finished: ${source.source_name}`, description: `No listings found.` });
            successfulSources.push(source.source_name);
          }

        } catch (error) {
          console.error(`Failed to scan source ${source.source_name}:`, error);
          failedSources.push(source.source_name);

          // Handle specific error types with better messaging
          if (error.message && (error.message.includes('Network Error') || error.message.includes('fetch'))) {
            toast({
              variant: "destructive",
              title: `Network Error: ${source.source_name}`,
              description: "AI service is temporarily unavailable. This source will be skipped."
            });
          } else if (error.message && error.message.includes('timeout')) {
            toast({
              variant: "destructive",
              title: `Timeout: ${source.source_name}`,
              description: "Source took too long to respond. This source will be skipped."
            });
          } else {
            toast({
              variant: "destructive",
              title: `Error scanning ${source.source_name}`,
              description: "This source will be skipped. Please try again later."
            });
          }
        }

        // Add a small delay between sources to avoid overwhelming the AI service
        await new Promise(resolve => setTimeout(resolve, 2000));
      }

      // Show summary of what worked and what didn't
      const summaryMessage = `Scan completed: ${successfulSources.length} sources successful, ${failedSources.length} sources failed.`;
      
      if (allNewProperties.length === 0) {
        toast({ 
          title: "Scan Complete", 
          description: failedSources.length > 0 
            ? `No new properties found. ${failedSources.length} sources failed due to network issues.`
            : "No new properties found across all sources."
        });
        setRunningScans((prev) => ({ ...prev, [config.id]: false }));
        return;
      }

      // --- RECONCILIATION & DATA PROCESSING ---
      toast({ title: "Processing Data", description: `Reconciling ${allNewProperties.length} scraped listings with database.` });

      // Step 1: Create a set of addresses for all currently live listings from the scrape
      const liveListingAddresses = new Set(
        allNewProperties.map(p => p.address?.toLowerCase().trim()).filter(Boolean)
      );

      // Step 2: Get existing properties and tenancies to check for delisted items
      const [existingProperties, existingTenancies, existingBuildings] = await Promise.all([
        Property.list(),
        Tenancy.list(),
        Building.list()
      ]);

      const vacantTenancies = existingTenancies.filter(t => t.status === 'Vacant');
      const buildingMapById = new Map(existingBuildings.map(b => [b.id, b]));

      let delistedCount = 0;
      for (const tenancy of vacantTenancies) {
        const building = buildingMapById.get(tenancy.building_id);
        if (building && building.address) {
          const normalizedAddress = building.address.toLowerCase().trim();
          // If a vacant tenancy's building address is NOT in the live scrape, it's been delisted.
          if (!liveListingAddresses.has(normalizedAddress)) {
            await Tenancy.update(tenancy.id, { status: 'Occupied' }); // Mark as Occupied
            delistedCount++;
          }
        }
      }

      if (delistedCount > 0) {
        toast({ title: "Reconciliation Complete", description: `Marked ${delistedCount} previously available tenancies as occupied.` });
      }

      // Step 3: Filter out properties that already exist to avoid re-processing
      const existingPropertyAddresses = new Set(
        existingProperties.map(p => p.address?.toLowerCase().trim()).filter(Boolean)
      );

      const uniqueNewProperties = allNewProperties.filter(prop =>
        !existingPropertyAddresses.has(prop.address?.toLowerCase().trim())
      );

      if (uniqueNewProperties.length === 0) {
        toast({ title: "Processing Complete", description: "No new unique properties to add. Database is up-to-date." });
        setRunningScans((prev) => ({ ...prev, [config.id]: false }));
        return;
      }

      toast({ title: "Processing New Properties", description: `Found ${uniqueNewProperties.length} unique new listings to add.` });

      // Step 4: Process and create records for unique new properties
      try {
        const buildingMapByName = new Map(existingBuildings.map((b) => [b.address?.toLowerCase().trim(), b]));

        let propertiesToCreate = [];
        let buildingsToCreate = [];
        let tenanciesToCreate = [];

        // Process uniqueNewProperties
        for (const prop of uniqueNewProperties) {
          if (!prop.address || !prop.title) continue;

          // Validate and sanitize numeric fields early
          const floorAreaSqm = parseFloat(prop.floor_area_sqm);
          const rentalRateSqm = parseFloat(prop.rental_rate_sqm);

          // Skip properties with invalid size data
          if (isNaN(floorAreaSqm) || floorAreaSqm <= 0) {
            console.warn(`Skipping property ${prop.title} - invalid floor area: ${prop.floor_area_sqm}`);
            continue;
          }

          const normalizedAddress = prop.address.toLowerCase().trim();
          const newAgent = {
            name: prop.agent_name || 'Unknown',
            company: prop.agent_company || 'Unknown',
            email: prop.agent_email || '',
            phone: prop.agent_phone || ''
          };

          // Create new property
          propertiesToCreate.push({
            title: prop.title,
            address: prop.address,
            suburb: prop.suburb || 'Unknown',
            city: 'Sydney',
            type: 'office',
            floor_area_sqm: floorAreaSqm,
            rental_rate_sqm: isNaN(rentalRateSqm) ? 0 : rentalRateSqm,
            description: prop.description || '',
            status: 'available',
            agents: [newAgent],
            source_portal: prop.source_portal,
            images: prop.images || { main: null, gallery: [], floorplans: [] } // Ensure images object is present
          });


          // Create building if it doesn't exist
          if (!buildingMapByName.has(normalizedAddress)) {
            const buildingName = prop.title.includes('Level') || prop.title.includes('Suite') ?
              prop.address.split(',')[0] :
              prop.title;

            buildingsToCreate.push({
              name: buildingName,
              canonical_name: buildingName,
              address: prop.address,
              suburb: prop.suburb || 'Unknown',
              type: "Office",
              grade: prop.building_grade || "Not Rated",
              leasing_agencies: [prop.agent_company || 'Unknown']
            });
            buildingMapByName.set(normalizedAddress, { isNew: true }); // Mark as pending creation
          }
        }

        // Bulk create/update Property, Building, Tenancy entities
        let createdProperties = [];
        if (propertiesToCreate.length > 0) {
          createdProperties = await Property.bulkCreate(propertiesToCreate);
          toast({ title: "Properties Created", description: `Added ${createdProperties.length} new properties.` });
        }

        let createdBuildingIds = {};
        if (buildingsToCreate.length > 0) {
          try {
            const createdBuildings = await Building.bulkCreate(buildingsToCreate);
            createdBuildings.forEach((b) => {
              createdBuildingIds[b.address.toLowerCase().trim()] = b.id;
            });
            toast({ title: "Buildings Created", description: `Added ${createdBuildings.length} new buildings.` });
          } catch (buildingError) {
            console.error("Failed to create buildings:", buildingError);
            toast({
              variant: "destructive",
              title: "Building Creation Failed",
              description: "Some buildings could not be created. Check the logs for details."
            });
          }
        }

        // Create tenancies with strict data validation
        for (const prop of uniqueNewProperties) {
          if (!prop.address) continue;

          // Validate required numeric fields for tenancy
          const floorAreaSqm = parseFloat(prop.floor_area_sqm);
          const rentalRateSqm = parseFloat(prop.rental_rate_sqm);

          // Skip if we don't have valid size data for tenancy creation
          if (isNaN(floorAreaSqm) || floorAreaSqm <= 0) {
            continue;
          }

          const normalizedAddress = prop.address.toLowerCase().trim();
          let buildingId = buildingMapByName.get(normalizedAddress)?.id || createdBuildingIds[normalizedAddress];

          if (buildingId) {
            const tenancyData = {
              building_id: buildingId,
              floor: prop.title.includes('Level') ? prop.title.split(' ')[1] || '1' : '1',
              suite: prop.title,
              size_sqm: floorAreaSqm,
              status: "Vacant",
              rental_rate_sqm: isNaN(rentalRateSqm) ? 0 : rentalRateSqm,
              availability_date: prop.availability_date || null
            };

            // Double-check all numeric fields before adding
            if (typeof tenancyData.size_sqm === 'number' && tenancyData.size_sqm > 0 &&
              typeof tenancyData.rental_rate_sqm === 'number') {
              tenanciesToCreate.push(tenancyData);
            }
          }
        }

        if (tenanciesToCreate.length > 0) {
          try {
            console.log(`Creating ${tenanciesToCreate.length} tenancies with validated data`);
            await Tenancy.bulkCreate(tenanciesToCreate);
            toast({ title: "Tenancies Created", description: `Added ${tenanciesToCreate.length} new tenancies.` });
          } catch (tenancyError) {
            console.error("Failed to create tenancies:", tenancyError);
            toast({
              variant: "destructive",
              title: "Tenancy Creation Failed",
              description: "Some tenancies could not be created."
            });
          }
        }

        // AI ANALYSIS AGAINST CLIENT BRIEFS
        toast({ title: "Starting AI Analysis", description: "Analyzing properties against active client briefs..." });

        // Get all active briefs
        const { TenantRequirement } = await import('@/api/entities');
        const activeBriefs = await TenantRequirement.filter({ status: 'active' });

        if (activeBriefs.length === 0) {
          toast({ title: "No Active Briefs", description: "No active client briefs found for analysis." });
        } else {
          try {
            // Pass the newly created Property entities to the AI analysis function
            await runAIPropertyAnalysis(createdProperties, activeBriefs);
          } catch (aiError) {
            console.error("AI analysis failed:", aiError);
            toast({
              variant: "destructive",
              title: "AI Analysis Failed",
              description: "Property analysis could not be completed due to AI service issues."
            });
          }
        }

        const toastDescription = `Processed ${uniqueNewProperties.length} unique listings. Found ${propertiesToCreate.length} new properties.`;
        toast({
          title: "Scan Successful!",
          description: failedSources.length > 0 ? `${toastDescription} Failed to scan: ${failedSources.join(', ')}.` : toastDescription
        });

      } catch (error) {
        console.error("Error processing properties:", error);
        toast({
          variant: "destructive",
          title: "Processing Error",
          description: `Failed to process scraped properties: ${error.message || 'Unknown error'}`
        });
      }

    } catch (error) {
      console.error("Scan failed:", error);

      let errorMessage = "An unexpected error occurred during the scan process.";
      if (error.message && (error.message.includes('Network Error') || error.message.includes('fetch'))) {
        errorMessage = "Network connection failed. The AI service may be temporarily unavailable. Please try again in a few minutes.";
      }

      toast({
        variant: "destructive",
        title: "Scan Failed",
        description: errorMessage
      });
    } finally {
      setRunningScans((prev) => ({ ...prev, [config.id]: false }));
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">AI Market Listings Scan</h1>
        <Button className="stratos-button stratos-button-secondary" disabled>
          <Plus className="w-4 h-4 mr-2" /> New Agent
        </Button>
      </div>

      {loading ?
        <Loader2 className="w-8 h-8 animate-spin text-orange-400" /> :

        <div className="space-y-4">
          {configs.map((config) =>
            <div key={config.id} className="stratos-card p-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h2 className="text-xl font-bold text-white flex items-center gap-3 mb-3">
                    <Bot className="text-orange-400" />
                    {config.agent_name}
                  </h2>
                  <div className="flex items-center gap-2 text-sm text-gray-400 mb-4">
                    <Clock className="w-4 h-4" /><span>{config.schedule} scans</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Globe className="w-4 h-4 text-gray-400 mt-1" />
                    <div className="flex flex-wrap gap-1">
                      {(config.target_sources || []).map((source) =>
                        <Badge key={source.source_name} variant="secondary" className="bg-gray-700 text-gray-300 font-normal">
                          {source.source_name}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row items-end sm:items-center gap-3 ml-4">
                  <Button
                    variant="outline"
                    className="stratos-button stratos-button-secondary"
                    onClick={() => runScan(config)}
                    disabled={runningScans[config.id]}>

                    {runningScans[config.id] ?
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" /> :

                      <Play className="w-4 h-4 mr-2" />
                    }
                    {runningScans[config.id] ? 'Scanning...' : 'Run Scan'}
                  </Button>
                  <Button variant="ghost" size="icon" className="text-gray-500 hover:text-red-500" disabled>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      }
    </div>);

}
