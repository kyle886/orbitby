import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { TenantRequirement } from '@/api/entities';
import { RfpRound } from '@/api/entities';
import { RfpOffer } from '@/api/entities';
import { RfpQnA } from '@/api/entities';
import { RfpAddendum } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  FileText, 
  MessageSquare, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Plus,
  Send,
  Eye,
  Download,
  Building2
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export default function RfpManager() {
  const [searchParams] = useSearchParams();
  const dealId = searchParams.get('dealId');
  const { toast } = useToast();

  const [deal, setDeal] = useState(null);
  const [rounds, setRounds] = useState([]);
  const [activeRound, setActiveRound] = useState(null);
  const [offers, setOffers] = useState([]);
  const [qnas, setQnas] = useState([]);
  const [addendums, setAddendums] = useState([]);
  const [loading, setLoading] = useState(true);

  // Create new round form
  const [showCreateRound, setShowCreateRound] = useState(false);
  const [newRoundData, setNewRoundData] = useState({
    name: '',
    dueAt: '',
    briefingSummary: ''
  });

  // Q&A form
  const [showQnaForm, setShowQnaForm] = useState(false);
  const [newQuestion, setNewQuestion] = useState('');

  const loadData = useCallback(async () => {
    if (!dealId) return;
    
    setLoading(true);
    try {
      // Load the deal/requirement
      const dealData = await TenantRequirement.get(dealId);
      setDeal(dealData);

      // Load all rounds for this deal
      const roundsData = await RfpRound.filter({ dealId });
      setRounds(roundsData || []);
      
      // Set the most recent round as active
      if (roundsData && roundsData.length > 0) {
        const latestRound = roundsData.sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
        setActiveRound(latestRound);

        // Load data for the active round
        const [offersData, qnasData, addendumsData] = await Promise.all([
          RfpOffer.filter({ roundId: latestRound.id }),
          RfpQnA.filter({ roundId: latestRound.id }),
          RfpAddendum.filter({ roundId: latestRound.id })
        ]);

        setOffers(offersData || []);
        setQnas(qnasData || []);
        setAddendums(addendumsData || []);
      }
    } catch (error) {
      console.error('Error loading RFP data:', error);
      toast({
        variant: 'destructive',
        title: 'Failed to load RFP data',
        description: error.message
      });
    } finally {
      setLoading(false);
    }
  }, [dealId, toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleCreateRound = async () => {
    try {
      const roundData = {
        dealId,
        name: newRoundData.name,
        status: 'OPEN',
        dueAt: new Date(newRoundData.dueAt).toISOString(),
        briefingSummary: newRoundData.briefingSummary,
        createdBy: 'current_user' // This would come from auth context
      };

      const newRound = await RfpRound.create(roundData);
      setRounds(prev => [newRound, ...prev]);
      setActiveRound(newRound);
      setShowCreateRound(false);
      setNewRoundData({ name: '', dueAt: '', briefingSummary: '' });
      
      toast({
        title: 'RFP Round Created',
        description: `${newRoundData.name} has been created and is now open for responses.`
      });
    } catch (error) {
      console.error('Error creating round:', error);
      toast({
        variant: 'destructive',
        title: 'Failed to create round',
        description: error.message
      });
    }
  };

  const handleSubmitQuestion = async () => {
    if (!activeRound || !newQuestion.trim()) return;

    try {
      const qnaData = {
        roundId: activeRound.id,
        question: newQuestion,
        askedBy: 'current_user', // This would come from auth context
        createdAt: new Date().toISOString()
      };

      const newQna = await RfpQnA.create(qnaData);
      setQnas(prev => [newQna, ...prev]);
      setNewQuestion('');
      setShowQnaForm(false);

      toast({
        title: 'Question Submitted',
        description: 'Your question has been submitted and will be answered shortly.'
      });
    } catch (error) {
      console.error('Error submitting question:', error);
      toast({
        variant: 'destructive',
        title: 'Failed to submit question',
        description: error.message
      });
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      'OPEN': 'bg-green-500/20 text-green-300 border-green-700',
      'BAFO': 'bg-yellow-500/20 text-yellow-300 border-yellow-700',
      'CLOSED': 'bg-gray-500/20 text-gray-300 border-gray-700',
      'CANCELLED': 'bg-red-500/20 text-red-300 border-red-700',
      'DRAFT': 'bg-blue-500/20 text-blue-300 border-blue-700',
      'SUBMITTED': 'bg-purple-500/20 text-purple-300 border-purple-700',
      'SHORTLISTED': 'bg-orange-500/20 text-orange-300 border-orange-700',
      'PREFERRED': 'bg-emerald-500/20 text-emerald-300 border-emerald-700',
      'REJECTED': 'bg-red-500/20 text-red-300 border-red-700'
    };
    return colors[status] || colors['DRAFT'];
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-8 h-8 rounded-full animate-pulse bg-white/10"></div>
      </div>
    );
  }

  if (!deal) {
    return (
      <div className="p-8">
        <Card className="orbit-card max-w-lg mx-auto text-center">
          <CardHeader>
            <CardTitle className="text-red-400">Deal Not Found</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300">The requested deal could not be found.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">RFP Manager</h1>
            <p className="text-gray-300">{deal.company_name} - {deal.brief_reference_code}</p>
            <div className="flex items-center gap-2 mt-2">
              <Building2 className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">
                {deal.min_floor_area} - {deal.max_floor_area} sqm • {deal.property_type}
              </span>
            </div>
          </div>
          <Button 
            onClick={() => setShowCreateRound(true)}
            className="bg-orange-500 hover:bg-orange-600 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            New RFP Round
          </Button>
        </div>
      </div>

      {/* Rounds Selection */}
      {rounds.length > 0 && (
        <div className="mb-6">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {rounds.map((round) => (
              <Button
                key={round.id}
                variant={activeRound?.id === round.id ? "default" : "outline"}
                onClick={() => setActiveRound(round)}
                className="flex-shrink-0"
              >
                {round.name}
                <Badge className={`ml-2 ${getStatusColor(round.status)}`} size="sm">
                  {round.status}
                </Badge>
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Create Round Form */}
      {showCreateRound && (
        <Card className="orbit-card mb-6">
          <CardHeader>
            <CardTitle>Create New RFP Round</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Round Name</Label>
              <Input
                value={newRoundData.name}
                onChange={(e) => setNewRoundData(prev => ({...prev, name: e.target.value}))}
                placeholder="e.g., Initial RFP, BAFO Round"
                className="orbit-input"
              />
            </div>
            <div>
              <Label>Response Deadline</Label>
              <Input
                type="datetime-local"
                value={newRoundData.dueAt}
                onChange={(e) => setNewRoundData(prev => ({...prev, dueAt: e.target.value}))}
                className="orbit-input"
              />
            </div>
            <div>
              <Label>Briefing Summary</Label>
              <Textarea
                value={newRoundData.briefingSummary}
                onChange={(e) => setNewRoundData(prev => ({...prev, briefingSummary: e.target.value}))}
                placeholder="Brief summary of requirements for landlords..."
                className="orbit-input h-24"
              />
            </div>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setShowCreateRound(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateRound} className="bg-orange-500 hover:bg-orange-600">
                Create Round
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content */}
      {activeRound ? (
        <Tabs defaultValue="offers" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="offers" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Offers ({offers.length})
            </TabsTrigger>
            <TabsTrigger value="qna" className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Q&A ({qnas.length})
            </TabsTrigger>
            <TabsTrigger value="addendums" className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Addendums ({addendums.length})
            </TabsTrigger>
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Overview
            </TabsTrigger>
          </TabsList>

          <TabsContent value="offers">
            <div className="grid gap-4">
              {offers.length === 0 ? (
                <Card className="orbit-card">
                  <CardContent className="text-center py-12">
                    <FileText className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">No Offers Yet</h3>
                    <p className="text-gray-400">Offers will appear here once landlords respond to the RFP.</p>
                  </CardContent>
                </Card>
              ) : (
                offers.map((offer) => (
                  <Card key={offer.id} className="orbit-card">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-white">Property #{offer.propertyId}</CardTitle>
                          <p className="text-sm text-gray-400 mt-1">
                            Submitted {offer.submittedAt ? new Date(offer.submittedAt).toLocaleDateString() : 'Draft'}
                          </p>
                        </div>
                        <Badge className={getStatusColor(offer.status)}>
                          {offer.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {offer.commercialTerms && (
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-gray-400">Net Face Rent</span>
                            <p className="text-white font-semibold">${offer.commercialTerms.netFaceRent}/m²</p>
                          </div>
                          <div>
                            <span className="text-gray-400">Incentive</span>
                            <p className="text-white font-semibold">{offer.commercialTerms.incentivePercent}%</p>
                          </div>
                          <div>
                            <span className="text-gray-400">Term</span>
                            <p className="text-white font-semibold">{offer.commercialTerms.leaseTerm}</p>
                          </div>
                          <div>
                            <span className="text-gray-400">Commencement</span>
                            <p className="text-white font-semibold">
                              {offer.commercialTerms.commencementDate ? 
                                new Date(offer.commercialTerms.commencementDate).toLocaleDateString() : 
                                'TBC'
                              }
                            </p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="qna">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Questions & Answers</h3>
                <Button 
                  onClick={() => setShowQnaForm(true)}
                  size="sm"
                  className="bg-orange-500 hover:bg-orange-600"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Ask Question
                </Button>
              </div>

              {showQnaForm && (
                <Card className="orbit-card">
                  <CardHeader>
                    <CardTitle>Submit Question</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Textarea
                      value={newQuestion}
                      onChange={(e) => setNewQuestion(e.target.value)}
                      placeholder="Enter your question about the RFP..."
                      className="orbit-input h-24"
                    />
                    <div className="flex gap-3 justify-end">
                      <Button variant="outline" onClick={() => setShowQnaForm(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleSubmitQuestion}>
                        <Send className="w-4 h-4 mr-2" />
                        Submit Question
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {qnas.length === 0 ? (
                <Card className="orbit-card">
                  <CardContent className="text-center py-12">
                    <MessageSquare className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">No Questions Yet</h3>
                    <p className="text-gray-400">Questions and answers will appear here.</p>
                  </CardContent>
                </Card>
              ) : (
                qnas.map((qna) => (
                  <Card key={qna.id} className="orbit-card">
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <MessageSquare className="w-4 h-4 text-blue-400" />
                            <span className="text-sm text-blue-400">Question</span>
                            <span className="text-xs text-gray-500">
                              {new Date(qna.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-white">{qna.question}</p>
                        </div>
                        
                        {qna.answer && (
                          <div className="border-t border-gray-700 pt-4">
                            <div className="flex items-center gap-2 mb-2">
                              <CheckCircle className="w-4 h-4 text-green-400" />
                              <span className="text-sm text-green-400">Answer</span>
                              {qna.answeredAt && (
                                <span className="text-xs text-gray-500">
                                  {new Date(qna.answeredAt).toLocaleDateString()}
                                </span>
                              )}
                            </div>
                            <p className="text-gray-300">{qna.answer}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="addendums">
            <Card className="orbit-card">
              <CardContent className="text-center py-12">
                <AlertCircle className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No Addendums</h3>
                <p className="text-gray-400">RFP addendums will appear here when issued.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="overview">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="orbit-card">
                <CardHeader>
                  <CardTitle>Round Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Status</span>
                    <Badge className={getStatusColor(activeRound.status)}>
                      {activeRound.status}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Due Date</span>
                    <span className="text-white">
                      {new Date(activeRound.dueAt).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Responses</span>
                    <span className="text-white">{offers.filter(o => o.status === 'SUBMITTED').length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Questions</span>
                    <span className="text-white">{qnas.length}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="orbit-card">
                <CardHeader>
                  <CardTitle>Response Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {['SUBMITTED', 'DRAFT', 'SHORTLISTED', 'PREFERRED'].map(status => {
                      const count = offers.filter(o => o.status === status).length;
                      if (count === 0) return null;
                      return (
                        <div key={status} className="flex justify-between">
                          <span className="text-gray-400">{status.toLowerCase()}</span>
                          <span className="text-white">{count}</span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      ) : (
        <Card className="orbit-card">
          <CardContent className="text-center py-12">
            <FileText className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No RFP Rounds</h3>
            <p className="text-gray-400 mb-6">Create your first RFP round to start the tenant representation process.</p>
            <Button 
              onClick={() => setShowCreateRound(true)}
              className="bg-orange-500 hover:bg-orange-600 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create First Round
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}