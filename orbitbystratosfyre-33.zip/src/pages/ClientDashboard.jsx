
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Client } from "@/api/entities";
import { PropertySubmission } from "@/api/entities";
import { ClientUpdate } from "@/api/entities";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Building2, 
  Calendar, 
  TrendingUp, 
  Users, 
  CheckCircle,
  ArrowRight,
  Mail
} from "lucide-react";

export default function ClientDashboard() {
  const [user, setUser] = useState(null);
  const [clientData, setClientData] = useState(null);
  const [submissions, setSubmissions] = useState([]);
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      const clients = await Client.list("-created_date", 500);
      const client = clients.find(c => c.primary_contact_email === currentUser.email);
      setClientData(client);

      if (client) {
        const submissionsList = await PropertySubmission.filter({ client_id: client.id }, "-created_date", 200);
        setSubmissions(submissionsList);
        const updatesList = await ClientUpdate.filter({ 
          client_id: client.id, 
          is_client_visible: true 
        }, "-created_date", 5);
        setUpdates(updatesList);
      }
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };
  
  const getSubmissionStats = () => {
    const onBrief = submissions.filter(s => s.brief_match_status === 'on_brief').length;
    const shortlisted = submissions.filter(s => s.status === 'shortlisted').length;
    return { onBrief, shortlisted, total: submissions.length };
  };

  const StatCard = ({ title, value, icon: Icon, color, subtitle, onClick }) => (
    <div 
      className={`stratos-card cursor-pointer transition-all duration-200 hover:scale-105 p-6 ${onClick ? 'hover:shadow-lg' : ''}`}
      onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-moonlight mb-1">{title}</p>
          <p className="text-3xl font-bold text-white">{value}</p>
          {subtitle && (
            <p className="text-sm text-gray-400 mt-2">{subtitle}</p>
          )}
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="orbit-card animate-pulse p-6 h-36">
                <div className="h-4 bg-gray-700 rounded mb-4 w-1/2"></div>
                <div className="h-8 bg-gray-700 rounded mb-2 w-3/4"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!clientData) {
    return (
      <div className="min-h-screen">
        <div className="max-w-4xl mx-auto">
          <div className="orbit-card p-12 text-center">
            <Building2 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-white mb-2">Welcome to ORBIT</h3>
            <p className="text-gray-400 mb-4">
              Your client profile is being set up. Please contact your Stratosfyre consultant for access.
            </p>
            <p className="text-sm text-gray-500">
              Signed in as: {user?.email}
            </p>
          </div>
        </div>
      </div>
    );
  }

  const stats = getSubmissionStats();

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="stratos-h1 mb-2">
            Welcome back, {clientData.company_name}
          </h1>
          <p className="stratos-body">
            Track your commercial real estate search progress and view property options
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Options"
            value={stats.total}
            icon={Building2}
            color="bg-viz-tertiary/80"
            subtitle="Properties reviewed"
            onClick={() => window.location.href = createPageUrl("ClientProperties")}
          />
          <StatCard
            title="On Brief"
            value={stats.onBrief}
            icon={CheckCircle}
            color="bg-viz-secondary/80"
            subtitle="Perfect matches"
          />
          <StatCard
            title="Shortlisted"
            value={stats.shortlisted}
            icon={TrendingUp}
            color="bg-viz-quaternary/80"
            subtitle="Under consideration"
          />
          <StatCard
            title="Days Remaining"
            value={clientData.target_move_date ? Math.max(0, Math.ceil((new Date(clientData.target_move_date) - new Date()) / (1000 * 60 * 60 * 24))) : '∞'}
            icon={Calendar}
            color="bg-viz-primary/80"
            subtitle="Until target move"
          />
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="orbit-card">
              <div className="p-6 border-b border-gray-700">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold text-white">Recent Updates</h3>
                  <Link to={createPageUrl("ClientUpdates")}>
                    <button className="orbit-button text-gray-300 hover:text-white px-4 py-2 flex items-center gap-2 rounded-lg">
                      View All
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </Link>
                </div>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {updates.map((update) => (
                    <div key={update.id} className="flex gap-4 p-4 bg-gray-800/50 rounded-xl">
                      <div className="p-3 bg-gray-700/50 rounded-lg h-fit">
                        <Mail className="w-5 h-5 text-amber-400" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-white mb-1">{update.title}</h4>
                        <p className="text-sm text-gray-300 mb-2">{update.message}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(update.created_date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                  {updates.length === 0 && (
                    <div className="text-center py-8 text-gray-400">
                      <Mail className="w-12 h-12 mx-auto mb-3 text-gray-600" />
                      <p>No updates yet</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="space-y-6">
            <div className="orbit-card">
              <div className="p-6 border-b border-gray-700">
                <h3 className="text-xl font-bold text-white">Your Consultant</h3>
              </div>
              <div className="p-6">
                <div className="text-center">
                   <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-amber-500 mx-auto mb-4 flex items-center justify-center rounded-full">
                    <Users className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="font-medium text-white mb-1">
                    {clientData.amplifyre_consultant || 'Stratosfyre Team'}
                  </h3>
                  <p className="text-sm text-gray-400 mb-4">Senior Consultant</p>
                  <button className="w-full orbit-button bg-gray-700 hover:bg-gray-600 text-white py-3 px-4 flex items-center justify-center gap-2 rounded-lg">
                    <Mail className="w-4 h-4" />
                    Contact Consultant
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
