import { base44 } from './base44Client';


export const TenantRequirement = base44.entities.TenantRequirement;

export const PropertyMatch = base44.entities.PropertyMatch;

export const Client = base44.entities.Client;

export const PropertySubmission = base44.entities.PropertySubmission;

export const ClientUpdate = base44.entities.ClientUpdate;

export const Document = base44.entities.Document;

export const PropertyScan = base44.entities.PropertyScan;

export const ScannedProperty = base44.entities.ScannedProperty;

export const InspectionItinerary = base44.entities.InspectionItinerary;

export const InspectionFeedback = base44.entities.InspectionFeedback;

export const UserInvitation = base44.entities.UserInvitation;

export const Building = base44.entities.Building;

export const Tenancy = base44.entities.Tenancy;

export const PropertyScanJob = base44.entities.PropertyScanJob;

export const MarketIntelligence = base44.entities.MarketIntelligence;

export const DealEvidence = base44.entities.DealEvidence;

export const AgentConfiguration = base44.entities.AgentConfiguration;

export const AIPropertyReview = base44.entities.AIPropertyReview;

export const AuditLog = base44.entities.AuditLog;

export const SavedSearch = base44.entities.SavedSearch;

export const NotificationTrigger = base44.entities.NotificationTrigger;

export const RFPRequest = base44.entities.RFPRequest;

export const RFPResponse = base44.entities.RFPResponse;

export const BDTarget = base44.entities.BDTarget;

export const BDSignal = base44.entities.BDSignal;

export const BDEvent = base44.entities.BDEvent;

export const BDEventAttendance = base44.entities.BDEventAttendance;

export const BDPitch = base44.entities.BDPitch;

export const Company = base44.entities.Company;

export const Signal = base44.entities.Signal;

export const Target = base44.entities.Target;

export const Lease = base44.entities.Lease;

export const Brief = base44.entities.Brief;

export const Contact = base44.entities.Contact;

export const Event = base44.entities.Event;

export const EventROI = base44.entities.EventROI;

export const Pitch = base44.entities.Pitch;

export const Assignment = base44.entities.Assignment;

export const BDKPI = base44.entities.BDKPI;

export const AppSettings = base44.entities.AppSettings;

export const JobRun = base44.entities.JobRun;

export const Property = base44.entities.Property;

export const InboundRecommendation = base44.entities.InboundRecommendation;

export const InboundCampaign = base44.entities.InboundCampaign;

export const ContentIdea = base44.entities.ContentIdea;

export const SocialPost = base44.entities.SocialPost;

export const InboundLead = base44.entities.InboundLead;

export const ChannelSettings = base44.entities.ChannelSettings;

export const PlaybookAction = base44.entities.PlaybookAction;

export const Option = base44.entities.Option;

export const Source = base44.entities.Source;

export const ExtractionJob = base44.entities.ExtractionJob;

export const ExtractedRecord = base44.entities.ExtractedRecord;

export const BuildingPhoto = base44.entities.BuildingPhoto;

export const ListingPhoto = base44.entities.ListingPhoto;

export const UnitSettings = base44.entities.UnitSettings;

export const UserUnitPreference = base44.entities.UserUnitPreference;

export const DDProfile = base44.entities.DDProfile;

export const DueDiligence = base44.entities.DueDiligence;

export const DDFinding = base44.entities.DDFinding;

export const DDMeasure = base44.entities.DDMeasure;

export const DDDoc = base44.entities.DDDoc;

export const DevCase = base44.entities.DevCase;

export const Scenario = base44.entities.Scenario;

export const DevChecklistItem = base44.entities.DevChecklistItem;

export const Subcontractor = base44.entities.Subcontractor;

export const DMRFI = base44.entities.DMRFI;

export const CapitalOpportunity = base44.entities.CapitalOpportunity;

export const Lender = base44.entities.Lender;

export const Investor = base44.entities.Investor;

export const DebtFacility = base44.entities.DebtFacility;

export const EquityOffer = base44.entities.EquityOffer;

export const Drawdown = base44.entities.Drawdown;

export const CovenantCheck = base44.entities.CovenantCheck;

export const TermSheetDoc = base44.entities.TermSheetDoc;

export const AIProfile = base44.entities.AIProfile;

export const AIJob = base44.entities.AIJob;

export const Listing = base44.entities.Listing;

export const Engagement = base44.entities.Engagement;

export const Requirement = base44.entities.Requirement;

export const Itinerary = base44.entities.Itinerary;

export const ClientFeedback = base44.entities.ClientFeedback;

export const RFP = base44.entities.RFP;

export const Offer = base44.entities.Offer;

export const NegotiationIssue = base44.entities.NegotiationIssue;

export const DocFolder = base44.entities.DocFolder;

export const DocVersion = base44.entities.DocVersion;

export const DocTemplate = base44.entities.DocTemplate;

export const DuplicateRecordPair = base44.entities.DuplicateRecordPair;

export const LeaseClause = base44.entities.LeaseClause;

export const PMTask = base44.entities.PMTask;

export const RFI = base44.entities.RFI;

export const Submittal = base44.entities.Submittal;

export const Variation = base44.entities.Variation;

export const Diary = base44.entities.Diary;

export const Vendor = base44.entities.Vendor;

export const TenderMilestone = base44.entities.TenderMilestone;

export const TenderQnA = base44.entities.TenderQnA;

export const TenderBid = base44.entities.TenderBid;

export const PunchItem = base44.entities.PunchItem;

export const TenderRound = base44.entities.TenderRound;

export const VendorEnvelope = base44.entities.VendorEnvelope;

export const Bid = base44.entities.Bid;

export const TenderAddendum = base44.entities.TenderAddendum;

export const SanityBand = base44.entities.SanityBand;

export const OpexBaseYear = base44.entities.OpexBaseYear;

export const ReconciliationItem = base44.entities.ReconciliationItem;

export const NoticeEvent = base44.entities.NoticeEvent;

export const LongLeadItem = base44.entities.LongLeadItem;

export const Defect = base44.entities.Defect;

export const ProjectRisk = base44.entities.ProjectRisk;

export const RfpRound = base44.entities.RfpRound;

export const RfpOffer = base44.entities.RfpOffer;

export const RfpQnA = base44.entities.RfpQnA;

export const RfpAddendum = base44.entities.RfpAddendum;

export const BuildTenderPackage = base44.entities.BuildTenderPackage;

export const BuildBid = base44.entities.BuildBid;

export const BuildRFI = base44.entities.BuildRFI;

export const NotificationPreference = base44.entities.NotificationPreference;

export const RequiredAction = base44.entities.RequiredAction;

export const DocumentPin = base44.entities.DocumentPin;

export const FeasibilityScenario = base44.entities.FeasibilityScenario;

export const BoardPack = base44.entities.BoardPack;

export const DueDiligenceItem = base44.entities.DueDiligenceItem;

export const Deal = base44.entities.Deal;



// auth sdk:
export const User = base44.auth;