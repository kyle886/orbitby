import { useEffect, useRef, useState, useCallback } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { massingSolve } from "@/api/functions";

export default function MassingLab() {
  const [imgUrl, setImgUrl] = useState('');
  const [scale, setScale] = useState(0.01); // metres per pixel (default 10mm/px)
  const [bbox, setBbox] = useState({ x: 40, y: 40, width: 800, height: 500 });
  const [req, setReq] = useState({ workstations: 80, rooms: [{ type:'Meeting (6p)', count:3, area_m2:18 }, { type:'Board (12p)', count:1, area_m2:32 }, { type:'Focus', count:4, area_m2:8 }] });
  const [layout, setLayout] = useState(null);
  const [drag, setDrag] = useState(null);
  const canvasRef = useRef(null);
  const { toast } = useToast();

  const draw = useCallback(() => {
    const c = canvasRef.current; if (!c) return;
    const ctx = c.getContext('2d'); ctx.clearRect(0,0,c.width,c.height);
    ctx.fillStyle = 'rgba(255,255,255,0.02)'; ctx.fillRect(0,0,c.width,c.height);
    if (imgUrl) {
      const img = new Image(); img.crossOrigin='anonymous';
      img.onload = ()=>{ ctx.drawImage(img, 0, 0, c.width, c.height); drawOverlay(); };
      img.src = imgUrl;
    } else { drawOverlay(); }
    function drawOverlay(){
      // bbox
      ctx.strokeStyle='rgba(99,102,241,0.8)'; ctx.lineWidth=2; ctx.strokeRect(bbox.x, bbox.y, bbox.width, bbox.height);
      // rooms
      if (!layout) return;
      for (const r of layout.rooms||[]) {
        ctx.fillStyle = 'rgba(34,197,94,0.22)'; ctx.strokeStyle='rgba(34,197,94,0.9)';
        ctx.save(); ctx.translate(r.x, r.y); ctx.rotate((r.rotation||0)*Math.PI/180);
        ctx.fillRect(0, 0, r.w, r.h); ctx.strokeRect(0,0,r.w,r.h);
        ctx.fillStyle='#e5e7eb'; ctx.font='11px Inter'; ctx.fillText(r.type, 6, 14);
        ctx.restore();
      }
    }
  }, [imgUrl, bbox, layout]);

  useEffect(() => {
    draw();
  }, [draw]);

  const run = async ()=>{
    try {
      const response = await massingSolve({ 
        floorplan_url: imgUrl, 
        bbox, 
        scale_m_per_px: Number(scale), 
        requirements: req 
      });
      
      if (!response.data.ok) { 
        toast({ variant:'destructive', title:'Massing failed', description: response.data.error }); 
        return; 
      }
      
      setLayout(response.data.layout);
      toast({ 
        title:'Massing ready', 
        description: response.data.warnings?.[0] || `Area ~ ${response.data.totals.area_m2} m²` 
      });
    } catch (error) {
      toast({ variant:'destructive', title:'Massing failed', description: error.message });
    }
  };

  // simple drag on bbox
  const onMouseDown = (e)=> {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = e.clientX - rect.left, py = e.clientY - rect.top;
    if (hit(px,py,bbox)) setDrag({ dx:px-bbox.x, dy:py-bbox.y });
  };
  const onMouseMove = (e)=> {
    if (!drag) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const px = e.clientX - rect.left, py = e.clientY - rect.top;
    setBbox(prev => ({ ...prev, x: Math.max(0, px - drag.dx), y: Math.max(0, py - drag.dy) }));
  };
  const onMouseUp = ()=> setDrag(null);
  const hit = (px,py,b)=> px>=b.x && px<=b.x+b.width && py>=b.y && py<=b.y+b.height;

  const exportPNG = ()=>{
    const c = canvasRef.current; if (!c) return;
    const a = document.createElement('a'); a.download = `testfit_${Date.now()}.png`; a.href = c.toDataURL('image/png'); a.click();
  };

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3"><CardTitle className="text-base">Massing Lab (Test Fit)</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        <div className="grid md:grid-cols-4 gap-2">
          <Input value={imgUrl} onChange={e=>setImgUrl(e.target.value)} placeholder="Floorplan image URL (optional)" />
          <Input type="number" step="0.001" value={scale} onChange={e=>setScale(e.target.value)} placeholder="Scale (m per px)" />
          <Button onClick={run}>Generate</Button>
          <Button variant="outline" onClick={exportPNG} disabled={!layout}>Export PNG</Button>
        </div>
        <div className="grid md:grid-cols-3 gap-2">
          <div className="surface p-2">
            <div className="text-xs text-gray-400 mb-1">Requirements (JSON)</div>
            <Textarea value={JSON.stringify(req, null, 2)} onChange={e=> { try{ setReq(JSON.parse(e.target.value)); }catch{} }} className="min-h-[220px]" />
          </div>
          <div className="md:col-span-2 surface p-2">
            <canvas ref={canvasRef} width={1024} height={640}
                    onMouseDown={onMouseDown} onMouseMove={onMouseMove} onMouseUp={onMouseUp}
                    className="w-full rounded-lg border border-white/10" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}