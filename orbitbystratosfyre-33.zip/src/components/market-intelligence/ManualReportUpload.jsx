
import React, { useState } from 'react';
import { UploadFile, ExtractDataFromUploadedFile } from '@/api/integrations';
import { MarketIntelligence } from '@/api/entities';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { Upload, Loader2, FileText } from "lucide-react";

export default function ManualReportUpload({ isOpen, onClose, onSuccess }) {
  const [formData, setFormData] = useState({
    market: '',
    report_source: '',
    publication_date: null,
    sector: '',
    custom_author: ''
  });
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState('');

  const markets = [
    'Sydney CBD',
    'North Sydney/North Shore',
    'Sydney Fringe',
    'Parramatta',
    'Melbourne CBD',
    'Melbourne Fringe',
    'Brisbane CBD',
    'Perth CBD',
    'Adelaide CBD',
    'Canberra'
  ];

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
    } else {
      alert('Please select a PDF file');
    }
  };

  const getStateFromMarket = (market) => {
    if (market.includes('Sydney') || market.includes('Parramatta')) return 'NSW';
    if (market.includes('Melbourne')) return 'VIC';
    if (market.includes('Brisbane')) return 'QLD';
    if (market.includes('Perth')) return 'WA';
    if (market.includes('Adelaide')) return 'SA';
    if (market.includes('Canberra')) return 'ACT';
    return 'NSW'; // default
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!file || !formData.market || !formData.report_source || !formData.publication_date || !formData.sector) {
      alert('Please fill in all required fields and select a PDF file');
      return;
    }

    setIsUploading(true);
    setUploadStatus('Uploading PDF...');

    try {
      // 1. Upload the PDF file
      const { file_url } = await UploadFile({ file });
      setUploadStatus('Extracting data from PDF...');

      // 2. Extract data from the PDF
      const extractionSchema = {
        type: "object",
        properties: {
          report_title: { type: "string" },
          vacancy_data: {
            type: "object",
            properties: {
              total_vacancy_percent: { type: "number" },
              prime_vacancy_percent: { type: "number" },
              secondary_vacancy_percent: { type: "number" }
            }
          },
          rent_data: {
            type: "object", 
            properties: {
              prime_rent_sqm: { type: "number" },
              secondary_rent_sqm: { type: "number" }
            }
          },
          incentive_data: {
            type: "object",
            properties: {
              prime_incentive_percent: { type: "number" },
              secondary_incentive_percent: { type: "number" }
            }
          },
          key_insights: {
            type: "array",
            items: { type: "string" }
          },
          market_outlook: {
            type: "string",
            enum: ["Positive", "Stable", "Cautious", "Negative"]
          }
        }
      };

      const extractedData = await ExtractDataFromUploadedFile({ 
        file_url, 
        json_schema: extractionSchema 
      });

      setUploadStatus('Saving report...');

      // 3. Create the market intelligence record
      const reportData = {
        report_source: formData.report_source === 'other' ? (formData.custom_author || 'other') : formData.report_source,
        report_title: extractedData.output?.report_title || `${formData.market} ${formData.sector} Market Report`,
        report_date: formData.publication_date ? format(formData.publication_date, 'yyyy-MM-dd') : null, // Ensure publication_date is handled correctly
        state: getStateFromMarket(formData.market),
        market: formData.market,
        sector: formData.sector,
        report_url: file_url,
        vacancy_data: extractedData.output?.vacancy_data || {},
        rent_data: extractedData.output?.rent_data || {},
        incentive_data: extractedData.output?.incentive_data || {},
        key_insights: extractedData.output?.key_insights || [],
        market_outlook: extractedData.output?.market_outlook || 'Stable'
      };

      console.log('Creating report with data:', reportData); // Debug log

      await MarketIntelligence.create(reportData);
      
      setUploadStatus('Report uploaded successfully!');
      setTimeout(() => {
        onSuccess(); // This should trigger data refresh
        onClose();
        resetForm();
      }, 1000);

    } catch (error) {
      console.error('Upload failed:', error);
      setUploadStatus(`Upload failed: ${error.message}`);
    } finally {
      setIsUploading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      market: '',
      report_source: '',
      publication_date: null,
      sector: '',
      custom_author: ''
    });
    setFile(null);
    setUploadStatus('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="orbit-card max-w-2xl text-white">
        <DialogHeader>
          <DialogTitle className="text-xl text-white flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Upload Market Report
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* File Upload */}
          <div className="space-y-2">
            <Label className="text-gray-300">PDF Report File *</Label>
            <Input
              type="file"
              accept=".pdf"
              onChange={handleFileChange}
              className="orbit-input text-white"
            />
            {file && (
              <p className="text-sm text-green-400 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                {file.name}
              </p>
            )}
          </div>

          {/* Market Selection */}
          <div className="space-y-2">
            <Label className="text-gray-300">Market *</Label>
            <Select value={formData.market} onValueChange={(value) => setFormData(prev => ({...prev, market: value}))}>
              <SelectTrigger className="orbit-input text-white">
                <SelectValue placeholder="Select market" />
              </SelectTrigger>
              <SelectContent>
                {markets.map(market => (
                  <SelectItem key={market} value={market}>{market}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Author Selection */}
          <div className="space-y-2">
            <Label className="text-gray-300">Author *</Label>
            <Select value={formData.report_source} onValueChange={(value) => setFormData(prev => ({...prev, report_source: value}))}>
              <SelectTrigger className="orbit-input text-white">
                <SelectValue placeholder="Select author" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="knight_frank">Knight Frank</SelectItem>
                <SelectItem value="cbre">CBRE</SelectItem>
                <SelectItem value="cushman_wakefield">Cushman & Wakefield</SelectItem>
                <SelectItem value="savills">Savills</SelectItem>
                <SelectItem value="colliers">Colliers</SelectItem>
                <SelectItem value="jll">JLL</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Custom Author (if Other selected) */}
          {formData.report_source === 'other' && (
            <div className="space-y-2">
              <Label className="text-gray-300">Custom Author Name</Label>
              <Input
                value={formData.custom_author}
                onChange={(e) => setFormData(prev => ({...prev, custom_author: e.target.value}))}
                placeholder="Enter author name"
                className="orbit-input text-white"
              />
            </div>
          )}

          {/* Publication Date */}
          <div className="space-y-2">
            <Label className="text-gray-300">Publication Date *</Label>
            <Input
              type="date"
              value={formData.publication_date ? format(formData.publication_date, 'yyyy-MM-dd') : ''}
              onChange={(e) => setFormData(prev => ({...prev, publication_date: e.target.value ? new Date(e.target.value) : null}))}
              className="orbit-input text-white"
            />
          </div>

          {/* Sector */}
          <div className="space-y-2">
            <Label className="text-gray-300">Sector *</Label>
            <Select value={formData.sector} onValueChange={(value) => setFormData(prev => ({...prev, sector: value}))}>
              <SelectTrigger className="orbit-input text-white">
                <SelectValue placeholder="Select sector" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Office">Office</SelectItem>
                <SelectItem value="Industrial">Industrial</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Status Message */}
          {uploadStatus && (
            <div className={`p-3 rounded-lg text-sm ${
              uploadStatus.includes('failed') ? 'bg-red-900/50 text-red-200' : 
              uploadStatus.includes('successfully') ? 'bg-green-900/50 text-green-200' : 
              'bg-blue-900/50 text-blue-200'
            }`}>
              {uploadStatus}
            </div>
          )}
        </form>

        <DialogFooter className="gap-3">
          <Button type="button" variant="outline" onClick={onClose} className="orbit-button text-gray-300 border-gray-600">
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={isUploading || !file}
            className="orbit-button bg-gradient-to-r from-orange-500 to-amber-500 text-white border-0"
          >
            {isUploading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                Upload Report
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
