import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Building, Calendar, TrendingUp, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import _ from 'lodash';

const StatItem = ({ label, currentValue, previousValue, unit }) => {
  const TrendArrow = () => {
    if (currentValue === null || previousValue === null || currentValue === previousValue) {
      return <Minus className="w-3 h-3 text-gray-500" />;
    }
    if (currentValue > previousValue) {
      return <ArrowUp className="w-3 h-3 text-green-400" />;
    }
    return <ArrowDown className="w-3 h-3 text-red-400" />;
  };

  return (
    <div className="bg-gray-800/60 p-3 rounded-lg text-center flex-1">
      <p className="text-xs text-gray-400 mb-1 truncate">{label}</p>
      <div className="flex items-center justify-center gap-2">
        <p className="font-bold text-white text-lg">
          {currentValue === null || currentValue === undefined ? '-' : `${currentValue}${unit}`}
        </p>
        <TrendArrow />
      </div>
    </div>
  );
};

const SectorDetail = ({ name, data, previousData }) => {
  if (!data) return null;

  const sectorColors = {
    Office: "border-green-500",
    Industrial: "border-yellow-500",
  };

  return (
    <div className={`mt-4 pt-4 border-t-2 ${sectorColors[name] || 'border-gray-600'}`}>
      <h4 className="text-lg font-semibold text-white mb-4">{name} Market</h4>
      
      {/* Metrics */}
      <div className="space-y-4">
        <div>
          <h5 className="text-sm font-semibold text-gray-300 mb-2">Vacancy Rates</h5>
          <div className="flex gap-3">
            <StatItem label="Total" currentValue={data.vacancy_data?.total_vacancy_percent} previousValue={previousData?.vacancy_data?.total_vacancy_percent} unit="%" />
            <StatItem label="Prime" currentValue={data.vacancy_data?.prime_vacancy_percent} previousValue={previousData?.vacancy_data?.prime_vacancy_percent} unit="%" />
            <StatItem label="Secondary" currentValue={data.vacancy_data?.secondary_vacancy_percent} previousValue={previousData?.vacancy_data?.secondary_vacancy_percent} unit="%" />
          </div>
        </div>
        <div>
          <h5 className="text-sm font-semibold text-gray-300 mb-2">Net Face Rents</h5>
          <div className="flex gap-3">
            <StatItem label="Prime" currentValue={data.rent_data?.prime_rent_sqm} previousValue={previousData?.rent_data?.prime_rent_sqm} unit="/sqm" />
            <StatItem label="Secondary" currentValue={data.rent_data?.secondary_rent_sqm} previousValue={previousData?.rent_data?.secondary_rent_sqm} unit="/sqm" />
          </div>
        </div>
        <div>
          <h5 className="text-sm font-semibold text-gray-300 mb-2">Incentives</h5>
          <div className="flex gap-3">
            <StatItem label="Prime" currentValue={data.incentive_data?.prime_incentive_percent} previousValue={previousData?.incentive_data?.prime_incentive_percent} unit="%" />
            <StatItem label="Secondary" currentValue={data.incentive_data?.secondary_incentive_percent} previousValue={previousData?.incentive_data?.secondary_incentive_percent} unit="%" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default function StateMarketView({ stateName, stateData, onBack }) {
  if (!stateData || !stateData.markets || Object.keys(stateData.markets).length === 0) {
    return (
      <div className="orbit-card p-8 text-center">
        <Building className="w-12 h-12 mx-auto mb-4 text-gray-500" />
        <h3 className="text-xl font-medium text-white mb-2">No Market Data</h3>
        <p className="text-gray-400 mb-4">No reports available for {stateName}</p>
        <Button onClick={onBack} className="orbit-button text-gray-300 border border-gray-600">
          ← Back to Map
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">{stateName} Markets</h2>
          <p className="text-gray-300">Consolidated quarterly data from all sources</p>
        </div>
        <Button onClick={onBack} className="orbit-button text-gray-300 border border-gray-600">
          ← Back to Map
        </Button>
      </div>

      <div className="grid gap-6">
        {Object.entries(stateData.markets).map(([marketName, marketData]) => {
            const officeData = marketData.Office?.latest_quarter;
            const industrialData = marketData.Industrial?.latest_quarter;

            return (
              <div key={marketName} className="orbit-card p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">{marketName}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-400">
                      <Calendar className="w-4 h-4" />
                      <span>
                        Latest Data: {officeData?.quarter_string || industrialData?.quarter_string || 'N/A'}
                      </span>
                    </div>
                  </div>
                   <div className="flex flex-wrap gap-2">
                      {_.uniq([
                        ...(officeData?.sources.map(s => s.source) || []),
                        ...(industrialData?.sources.map(s => s.source) || [])
                      ]).map((source, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs border-gray-600 text-gray-300">
                          {_.startCase(source)}
                        </Badge>
                      ))}
                    </div>
                </div>

                {officeData && (
                  <SectorDetail 
                    name="Office" 
                    data={officeData.data} 
                    previousData={marketData.Office?.previous_quarter?.data} 
                  />
                )}
                {industrialData && (
                  <SectorDetail 
                    name="Industrial" 
                    data={industrialData.data} 
                    previousData={marketData.Industrial?.previous_quarter?.data} 
                  />
                )}
                
                 {/* Source Details */}
                <div className="mt-6 pt-4 border-t border-gray-700/50">
                   <h4 className="text-md font-semibold text-gray-200 mb-3">Data Sources</h4>
                   <div className="grid md:grid-cols-2 gap-x-6 gap-y-4">
                      {officeData && officeData.sources.length > 0 && (
                        <div>
                          <p className="text-sm font-medium text-green-400 mb-2">Office Reports</p>
                          <div className="space-y-1 text-xs">
                             {officeData.sources.map((source, idx) => (
                                <p key={idx} className="text-gray-400">{_.startCase(source.source)} - {source.title}</p>
                             ))}
                          </div>
                        </div>
                      )}
                      {industrialData && industrialData.sources.length > 0 && (
                        <div>
                           <p className="text-sm font-medium text-yellow-400 mb-2">Industrial Reports</p>
                           <div className="space-y-1 text-xs">
                             {industrialData.sources.map((source, idx) => (
                                <p key={idx} className="text-gray-400">{_.startCase(source.source)} - {source.title}</p>
                             ))}
                           </div>
                        </div>
                      )}
                   </div>
                </div>
              </div>
            );
        })}
      </div>
    </div>
  );
}