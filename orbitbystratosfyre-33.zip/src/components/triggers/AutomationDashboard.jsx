import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { NotificationTrigger } from '@/api/entities';
import { 
  Zap, 
  Plus, 
  Edit, 
  Trash2, 
  Power, 
  PowerOff,
  Mail,
  Users,
  Building2,
  FileText,
  AlertCircle,
  CheckCircle,
  Clock
} from 'lucide-react';

const TRIGGER_ICONS = {
  brief_status_changed: Building2,
  new_submission_received: FileText,
  client_feedback_submitted: Users,
  document_uploaded_for_client: FileText
};

const RECIPIENT_ICONS = {
  client: Users,
  stratosfyre_admin: Users,
  agent: Users
};

const STATUS_COLORS = {
  active: 'bg-green-600 text-white',
  inactive: 'bg-gray-600 text-white'
};

export default function AutomationDashboard() {
  const [triggers, setTriggers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingTrigger, setEditingTrigger] = useState(null);

  useEffect(() => {
    loadTriggers();
  }, []);

  const loadTriggers = async () => {
    try {
      setLoading(true);
      setError(null);
      const triggersList = await NotificationTrigger.list();
      setTriggers(triggersList || []);
    } catch (err) {
      console.error('Failed to load triggers:', err);
      setError('Failed to load automation triggers');
    } finally {
      setLoading(false);
    }
  };

  const toggleTriggerStatus = async (triggerId, currentStatus) => {
    try {
      const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
      await NotificationTrigger.update(triggerId, { 
        is_active: newStatus === 'active' 
      });
      await loadTriggers();
    } catch (err) {
      console.error('Failed to toggle trigger:', err);
      setError('Failed to update trigger status');
    }
  };

  const deleteTrigger = async (triggerId) => {
    if (!confirm('Are you sure you want to delete this automation trigger?')) {
      return;
    }
    
    try {
      await NotificationTrigger.delete(triggerId);
      await loadTriggers();
    } catch (err) {
      console.error('Failed to delete trigger:', err);
      setError('Failed to delete trigger');
    }
  };

  const TriggerCard = ({ trigger }) => {
    const Icon = TRIGGER_ICONS[trigger.event_name] || AlertCircle;
    const RecipientIcon = RECIPIENT_ICONS[trigger.recipient_type] || Users;
    const isActive = trigger.is_active !== false;
    
    return (
      <Card className="orbit-card">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-lg ${isActive ? 'bg-orange-600/20 text-orange-400' : 'bg-gray-600/20 text-gray-400'}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <CardTitle className="text-white text-base">
                  {trigger.description || trigger.event_name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </CardTitle>
                <div className="flex items-center gap-2 mt-1">
                  <Badge className={STATUS_COLORS[isActive ? 'active' : 'inactive']}>
                    {isActive ? <CheckCircle className="w-3 h-3 mr-1" /> : <Clock className="w-3 h-3 mr-1" />}
                    {isActive ? 'Active' : 'Inactive'}
                  </Badge>
                  <Badge variant="outline" className="text-teal-400 border-teal-400">
                    <RecipientIcon className="w-3 h-3 mr-1" />
                    {trigger.recipient_type.replace(/_/g, ' ')}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => toggleTriggerStatus(trigger.id, isActive ? 'active' : 'inactive')}
                className={isActive ? 'text-orange-400 hover:text-orange-300' : 'text-gray-400 hover:text-gray-300'}
              >
                {isActive ? <Power className="w-4 h-4" /> : <PowerOff className="w-4 h-4" />}
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setEditingTrigger(trigger)}
                className="text-gray-400 hover:text-white"
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => deleteTrigger(trigger.id)}
                className="text-red-400 hover:text-red-300"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {trigger.email_subject_template && (
              <div>
                <p className="text-xs text-gray-400 mb-1">Email Subject:</p>
                <p className="text-sm text-gray-300 bg-gray-800/50 p-2 rounded">
                  {trigger.email_subject_template}
                </p>
              </div>
            )}
            {trigger.email_body_template && (
              <div>
                <p className="text-xs text-gray-400 mb-1">Email Body:</p>
                <p className="text-sm text-gray-300 bg-gray-800/50 p-2 rounded max-h-20 overflow-hidden">
                  {trigger.email_body_template.substring(0, 150)}
                  {trigger.email_body_template.length > 150 && '...'}
                </p>
              </div>
            )}
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <Mail className="w-3 h-3" />
              Trigger: <code className="bg-gray-800 px-1 py-0.5 rounded">{trigger.event_name}</code>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="w-8 h-8 rounded-full animate-pulse bg-orange-600/20"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Automation Dashboard</h1>
          <p className="text-gray-400">Manage automated notification triggers and system workflows</p>
        </div>
        <Button 
          onClick={() => setShowForm(true)}
          className="bg-orange-600 hover:bg-orange-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Automation
        </Button>
      </div>

      {error && (
        <Card className="border-red-600/20 bg-red-600/10">
          <CardContent className="flex items-center gap-2 p-4">
            <AlertCircle className="w-5 h-5 text-red-400" />
            <p className="text-red-300">{error}</p>
            <Button 
              size="sm" 
              variant="ghost" 
              onClick={() => setError(null)}
              className="ml-auto text-red-400 hover:text-red-300"
            >
              Dismiss
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {triggers.length === 0 ? (
          <Card className="orbit-card md:col-span-2 xl:col-span-3">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Zap className="w-12 h-12 text-gray-600 mb-4" />
              <h3 className="text-lg font-medium text-white mb-2">No Automations Configured</h3>
              <p className="text-gray-400 text-center mb-6">
                Set up your first automation trigger to streamline your workflows and notifications.
              </p>
              <Button 
                onClick={() => setShowForm(true)}
                className="bg-orange-600 hover:bg-orange-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create First Automation
              </Button>
            </CardContent>
          </Card>
        ) : (
          triggers.map(trigger => (
            <TriggerCard key={trigger.id} trigger={trigger} />
          ))
        )}
      </div>

      {/* Summary Stats */}
      {triggers.length > 0 && (
        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-orange-400" />
              Automation Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-white">{triggers.length}</div>
                <div className="text-sm text-gray-400">Total Triggers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">
                  {triggers.filter(t => t.is_active !== false).length}
                </div>
                <div className="text-sm text-gray-400">Active</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-400">
                  {triggers.filter(t => t.is_active === false).length}
                </div>
                <div className="text-sm text-gray-400">Inactive</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">
                  {new Set(triggers.map(t => t.recipient_type)).size}
                </div>
                <div className="text-sm text-gray-400">Recipient Types</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}