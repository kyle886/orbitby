import { Company } from '@/api/entities';
import { Building } from '@/api/entities';
import { Target } from '@/api/entities';
import { Event } from '@/api/entities';
import { Signal } from '@/api/entities';
import { Source } from '@/api/entities';
import { ExtractionJob } from '@/api/entities';
import { ExtractedRecord } from '@/api/entities';
import { BuildingPhoto } from '@/api/entities';
import { Tenancy } from '@/api/entities';
import { DealEvidence } from '@/api/entities';
import { Listing } from '@/api/entities';
import { ListingPhoto } from '@/api/entities';

// Entity alias mapping
const ENTITY_ALIASES = [
  {canon:"Company", candidates:["Company","Companies","Org","Client"]},
  {canon:"Contact", candidates:["Contact","Contacts","People","Person"]},
  {canon:"Building", candidates:["Building","Buildings","Asset","Property","Premises"]},
  {canon:"Lease", candidates:["Lease","Tenancy","Tenancies","Occupancy"]},
  {canon:"Listing", candidates:["Listing","Listings","Availabilities","Availability"]},
  {canon:"Signal", candidates:["Signal","Signals","News","NewsItem","EventSignal"]},
  {canon:"Document", candidates:["Document","Documents","File","Files","Attachment","Uploads"]},
  {canon:"JobRun", candidates:["JobRun","JobRuns","Runs","TaskRun","TaskLog"]},
  {canon:"Target", candidates:["Target","Targets","Prospect","Prospects"]},
  {canon:"Event", candidates:["Event","Events","Conference","Meetup"]},
  {canon:"Source", candidates:["Source","Feed","ScrapeSource"]},
  {canon:"ExtractionJob", candidates:["ExtractionJob","ScrapeJob","IngestionRun"]},
  {canon:"ExtractedRecord", candidates:["ExtractedRecord","ScrapeRecord","RawPage"]},
  {canon:"BuildingPhoto", candidates:["BuildingPhoto","BuildingImage","AssetPhoto"]},
  {canon:"ListingPhoto", candidates:["ListingPhoto","ListingImage","AvailabilityPhoto"]},
  {canon:"DealEvidence", candidates:["DealEvidence","Comp","Comps","TransactionComp"]}
];

// Field mapping for common economic fields
const FIELD_MAPS = [
  {entity: "Building", canon: "area_m2", candidates: ["total_area_m2", "total_size_sqm", "nla_sqm", "gross_floor_area"]},
  {entity: "Building", canon: "rent_aud_per_m2_pa", candidates: ["rent_psm", "asking_rent", "rent_per_sqm"]},
  {entity: "Tenancy", canon: "area_m2", candidates: ["size_sqm", "area_sqm", "nla_sqm"]},
  {entity: "Tenancy", canon: "rent_aud_per_m2_pa", candidates: ["rental_rate_sqm", "rent_psm"]},
  {entity: "Listing", canon: "area_m2", candidates: ["floor_area_sqm", "area_sqm", "size_sqm"]},
  {entity: "Listing", canon: "rent_aud_per_m2_pa", candidates: ["rental_rate_sqm", "rent_psm", "asking_rent_psm"]},
  {entity: "DealEvidence", canon: "area_m2", candidates: ["lease_size_sqm", "area_sqm", "floor_area"]},
  {entity: "DealEvidence", canon: "rent_aud_per_m2_pa", candidates: ["net_effective_rent_sqm", "face_rent_sqm", "rent_psm"]}
];

export const runNamingAliasUnifier = async (payload = {}) => {
  const { dry_run = false } = payload;
  console.log('Starting Naming & Alias Unifier job...', dry_run ? '(DRY RUN)' : '(LIVE)');

  try {
    const results = {
      entity_mappings: [],
      field_mappings: [],
      skipped_entities: [],
      errors: []
    };

    // Step 1: Entity Alias Mapping
    console.log('Step 1: Checking entity aliases...');
    
    for (const alias of ENTITY_ALIASES) {
      try {
        // Check if canonical entity exists by trying to list it
        let canonicalExists = true;
        try {
          switch (alias.canon) {
            case "Company": await Company.list(null, 1); break;
            case "Building": await Building.list(null, 1); break;
            case "Target": await Target.list(null, 1); break;
            case "Event": await Event.list(null, 1); break;
            case "Signal": await Signal.list(null, 1); break;
            case "Source": await Source.list(null, 1); break;
            case "ExtractionJob": await ExtractionJob.list(null, 1); break;
            case "ExtractedRecord": await ExtractedRecord.list(null, 1); break;
            case "BuildingPhoto": await BuildingPhoto.list(null, 1); break;
            case "Tenancy": await Tenancy.list(null, 1); break;
            case "DealEvidence": await DealEvidence.list(null, 1); break;
            case "Listing": await Listing.list(null, 1); break;
            case "ListingPhoto": await ListingPhoto.list(null, 1); break;
            default: 
              canonicalExists = false;
          }
        } catch (error) {
          canonicalExists = false;
        }

        if (canonicalExists) {
          results.entity_mappings.push({
            canonical: alias.canon,
            found: alias.canon,
            status: 'exists',
            action: dry_run ? 'would_use_existing' : 'using_existing'
          });
        } else {
          results.skipped_entities.push({
            canonical: alias.canon,
            reason: 'canonical_not_found',
            candidates: alias.candidates
          });
        }
      } catch (error) {
        results.errors.push({
          type: 'entity_check',
          entity: alias.canon,
          error: error.message
        });
      }
    }

    // Step 2: Field Mapping Check
    console.log('Step 2: Checking field mappings...');
    
    for (const fieldMap of FIELD_MAPS) {
      try {
        // This is a simplified check - in a real implementation, you'd inspect the schema
        results.field_mappings.push({
          entity: fieldMap.entity,
          canonical_field: fieldMap.canon,
          candidates: fieldMap.candidates,
          status: 'schema_check_needed',
          action: dry_run ? 'would_analyze_schema' : 'analyze_schema'
        });
      } catch (error) {
        results.errors.push({
          type: 'field_check',
          entity: fieldMap.entity,
          field: fieldMap.canon,
          error: error.message
        });
      }
    }

    // Summary
    const summary = {
      entities_found: results.entity_mappings.filter(m => m.status === 'exists').length,
      entities_skipped: results.skipped_entities.length,
      fields_analyzed: results.field_mappings.length,
      errors: results.errors.length,
      dry_run: dry_run
    };

    console.log('Naming & Alias Unifier completed:', summary);

    return {
      rows_affected: summary.entities_found + summary.fields_analyzed,
      notes: dry_run ? 
        `DRY RUN: Would process ${summary.entities_found} entities and ${summary.fields_analyzed} field mappings. ${summary.entities_skipped} entities skipped (not found). ${summary.errors} errors encountered.` :
        `LIVE: Processed ${summary.entities_found} entities and ${summary.fields_analyzed} field mappings. ${summary.entities_skipped} entities skipped (not found). ${summary.errors} errors encountered.`,
      results: results
    };

  } catch (error) {
    console.error('Error in Naming & Alias Unifier job:', error);
    throw error;
  }
};