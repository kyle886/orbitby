
import { Signal } from '@/api/entities';
import { Company } from '@/api/entities';
import { Event } from '@/api/entities';
import { AppSettings } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { runJob } from '@/components/utils/runJob';

export const runFundingNewsAgentJob = async (payload) => {
  console.log('Starting Funding News Agent job...');
  
  try {
    const settingsList = await AppSettings.list();
    if (settingsList.length === 0 || !settingsList[0].STARTUP_NEWS_FEEDS || settingsList[0].STARTUP_NEWS_FEEDS.length === 0) {
      return {
        rows_affected: 0,
        notes: 'Funding News Agent job skipped: No startup news feeds configured in Platform Settings.',
        results: { error: 'NO_CONFIG', summary: 'No startup news feeds configured.' }
      };
    }
    
    const newsFeeds = settingsList[0].STARTUP_NEWS_FEEDS;

    const prompt = `You are a business intelligence analyst specializing in Australian startup funding and growth signals. Your task is to find recent (last 48 hours) startup funding announcements and significant business news for companies based in Sydney, Australia.

Scan the following news feeds and sources:
${newsFeeds.join('\n')}

Look for:
- Funding rounds (seed, Series A/B/C, etc.)
- Major hiring announcements (especially senior roles or large headcount increases)
- Office expansion or relocation news
- Acquisition announcements
- IPO preparations or announcements
- Significant product launches or partnerships

Focus on companies in these sectors:
- Technology (SaaS, AI, etc.)
- Fintech
- Biotech & Life Sciences
- Education Technology
- Clean Technology

For each news item found, extract:
- Company name
- Company website URL (if available)
- News type (funding/hire/expansion/acquisition/ipo)
- Dollar amount in AUD (if applicable, 0 if not mentioned)
- Date of announcement
- Brief summary of the news
- Source URL
- Company sector/industry

Return a JSON object containing a list of these news items.`;

    const llmResponse = await InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          news_items: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                company_name: { type: 'string' },
                company_website: { type: 'string' },
                news_type: { type: 'string', enum: ['funding', 'hire', 'expansion', 'acquisition', 'ipo', 'other'] },
                amount_aud: { type: 'number' },
                date: { type: 'string', format: 'date' },
                title: { type: 'string' },
                summary: { type: 'string' },
                source_url: { type: 'string' },
                sector: { type: 'string' }
              },
              required: ['company_name', 'news_type', 'date', 'title', 'summary', 'source_url']
            }
          }
        },
        required: ['news_items']
      }
    });

    if (!llmResponse || !llmResponse.news_items || llmResponse.news_items.length === 0) {
      return {
        rows_affected: 0,
        notes: 'Funding News Agent ran successfully but found no new news items.',
        results: { summary: 'No new funding news found.' }
      };
    }

    let companiesCreated = 0;
    let signalsCreated = 0;
    const existingCompanies = await Company.list();
    const existingCompanyNames = new Set(existingCompanies.map(c => c.name.toLowerCase()));

    for (const newsItem of llmResponse.news_items) {
      // Create or find company
      let company;
      if (!existingCompanyNames.has(newsItem.company_name.toLowerCase())) {
        company = await Company.create({
          name: newsItem.company_name,
          website: newsItem.company_website,
          sector: newsItem.sector || 'Other',
          hq_city: 'Sydney',
          last_funding_amt_aud: newsItem.news_type === 'funding' ? newsItem.amount_aud : undefined,
          last_funding_date: newsItem.news_type === 'funding' ? newsItem.date : undefined
        });
        companiesCreated++;
      } else {
        company = existingCompanies.find(c => c.name.toLowerCase() === newsItem.company_name.toLowerCase());
        // Update funding info if this is a funding announcement
        if (newsItem.news_type === 'funding' && newsItem.amount_aud) {
          await Company.update(company.id, {
            last_funding_amt_aud: newsItem.amount_aud,
            last_funding_date: newsItem.date
          });
        }
      }

      // Create signal
      await Signal.create({
        company_id: company.id,
        type: newsItem.news_type,
        source: 'Funding News Agent',
        title: newsItem.title,
        url: newsItem.source_url,
        date: newsItem.date,
        amount_aud: newsItem.amount_aud || 0,
        magnitude: newsItem.news_type === 'funding' ? (newsItem.amount_aud / 1000000) : 1, // Convert to millions for magnitude
        location: 'Sydney'
      });
      signalsCreated++;
    }

    return {
      rows_affected: companiesCreated + signalsCreated,
      notes: `Funding News Agent successfully scanned ${newsFeeds.length} sources and found ${llmResponse.news_items.length} news items. Created ${companiesCreated} companies and ${signalsCreated} signals.`,
      results: {
        scanned_sources: newsFeeds.length,
        found_news_items: llmResponse.news_items.length,
        created_companies: companiesCreated,
        created_signals: signalsCreated
      }
    };

  } catch (error) {
    console.error('Error in Funding News Agent job:', error);

    // Fallback logic for when the AI service is down
    if (error.message.includes('quota') || error.message.includes('RateLimitError')) {
      console.log('AI service unavailable - creating fallback funding news data');
      const fallbackSignals = [
        {
          type: 'funding',
          source: 'Funding News Agent (Fallback)',
          title: 'Sydney Tech Funding Activity - AI Service Unavailable',
          url: '#',
          date: new Date().toISOString().split('T')[0],
          magnitude: 0,
          location: 'Sydney'
        }
      ];

      let recordsCreated = 0;
      for (const signalData of fallbackSignals) {
        await Signal.create(signalData);
        recordsCreated++;
      }

      return {
        rows_affected: recordsCreated,
        notes: `AI service unavailable. Created ${recordsCreated} placeholder records. Please retry when service is restored.`,
        results: {
          error: 'AI_SERVICE_UNAVAILABLE',
          summary: 'AI service quota exceeded. Fallback data created to maintain system functionality.',
          recordsCreated: recordsCreated
        }
      };
    }
    
    throw error;
  }
};

export const runASXAnnouncementsAgentJob = async (payload) => {
  console.log('Starting ASX Announcements Agent job...');
  
  try {
    const settingsList = await AppSettings.list();
    if (settingsList.length === 0 || !settingsList[0].ASX_FEED_URL) {
      return {
        rows_affected: 0,
        notes: 'ASX Announcements Agent job skipped: No ASX feed URL configured in Platform Settings.',
        results: { error: 'NO_CONFIG', summary: 'No ASX feed URL configured.' }
      };
    }
    
    const asxFeedUrl = settingsList[0].ASX_FEED_URL;

    const prompt = `You are a commercial real estate intelligence analyst. Your task is to scan recent ASX announcements (last 48 hours) from Sydney-based listed companies to identify potential office space requirements.

Scan the ASX announcements feed: ${asxFeedUrl}

Look for announcements that indicate potential need for new or different office space, such as:
- Major acquisitions or mergers
- Significant expansion announcements
- New facility or office opening announcements  
- Large headcount increases or hiring plans
- Business restructuring that might affect office needs
- IPO preparations requiring expanded operations
- New business divisions or subsidiaries being established

Focus on Sydney-based companies in sectors likely to need commercial office space:
- Financial services and fintech
- Technology and software
- Biotech and pharmaceuticals
- Professional services
- Education and training companies

For each relevant announcement, extract:
- Company name and ASX ticker code
- Company website (if available)
- Type of announcement (acquisition/expansion/hire/restructure)
- Brief summary of why this indicates potential office space need
- Date of announcement
- Original announcement URL
- Estimated impact magnitude (1-10 scale)

Return a JSON object containing a list of these announcements.`;

    const llmResponse = await InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          announcements: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                company_name: { type: 'string' },
                asx_code: { type: 'string' },
                company_website: { type: 'string' },
                announcement_type: { type: 'string', enum: ['acquisition', 'expansion', 'hire', 'restructure', 'ipo', 'other'] },
                title: { type: 'string' },
                summary: { type: 'string' },
                date: { type: 'string', format: 'date' },
                source_url: { type: 'string' },
                magnitude: { type: 'number', minimum: 1, maximum: 10 },
                sector: { type: 'string' }
              },
              required: ['company_name', 'asx_code', 'announcement_type', 'title', 'summary', 'date', 'source_url']
            }
          }
        },
        required: ['announcements']
      }
    });

    if (!llmResponse || !llmResponse.announcements || llmResponse.announcements.length === 0) {
      return {
        rows_affected: 0,
        notes: 'ASX Announcements Agent ran successfully but found no relevant announcements.',
        results: { summary: 'No relevant ASX announcements found.' }
      };
    }

    let companiesCreated = 0;
    let signalsCreated = 0;
    const existingCompanies = await Company.list();
    const existingCompanyNames = new Set(existingCompanies.map(c => c.name.toLowerCase()));

    for (const announcement of llmResponse.announcements) {
      // Create or find company
      let company;
      if (!existingCompanyNames.has(announcement.company_name.toLowerCase())) {
        company = await Company.create({
          name: announcement.company_name,
          website: announcement.company_website,
          sector: announcement.sector || 'Other',
          hq_city: 'Sydney',
          listed_flag: true,
          asx_code: announcement.asx_code
        });
        companiesCreated++;
      } else {
        company = existingCompanies.find(c => c.name.toLowerCase() === announcement.company_name.toLowerCase());
        // Update ASX code if not already set
        if (!company.asx_code && announcement.asx_code) {
          await Company.update(company.id, {
            asx_code: announcement.asx_code,
            listed_flag: true
          });
        }
      }

      // Create signal
      await Signal.create({
        company_id: company.id,
        type: announcement.announcement_type === 'acquisition' ? 'MA' : 'news',
        source: 'ASX Announcements Agent',
        title: announcement.title,
        url: announcement.source_url,
        date: announcement.date,
        magnitude: announcement.magnitude || 1,
        location: 'Sydney'
      });
      signalsCreated++;
    }

    return {
      rows_affected: companiesCreated + signalsCreated,
      notes: `ASX Announcements Agent successfully scanned ASX feed and found ${llmResponse.announcements.length} relevant announcements. Created ${companiesCreated} companies and ${signalsCreated} signals.`,
      results: {
        found_announcements: llmResponse.announcements.length,
        created_companies: companiesCreated,
        created_signals: signalsCreated
      }
    };

  } catch (error) {
    console.error('Error in ASX Announcements Agent job:', error);

    // Fallback logic for when the AI service is down
    if (error.message.includes('quota') || error.message.includes('RateLimitError')) {
      console.log('AI service unavailable - creating fallback ASX data');
      const fallbackSignal = await Signal.create({
        type: 'news',
        source: 'ASX Announcements Agent (Fallback)',
        title: 'ASX Announcements Monitoring - Service Temporarily Unavailable',
        url: '#',
        date: new Date().toISOString().split('T')[0],
        magnitude: 0,
        location: 'Sydney'
      });

      return {
        rows_affected: 1,
        notes: 'AI service unavailable. Created placeholder ASX monitoring record. Please retry when service is restored.',
        results: {
          error: 'AI_SERVICE_UNAVAILABLE',
          summary: 'ASX announcements service temporarily unavailable. Placeholder record created.',
          recordsCreated: 1
        }
      };
    }
    
    throw error;
  }
};

export const runEventsAgentJob = async (payload) => {
  console.log('Starting Events Agent job...');
  
  try {
    const settingsList = await AppSettings.list();
    if (settingsList.length === 0 || !settingsList[0].EVENTS_FEEDS || settingsList[0].EVENTS_FEEDS.length === 0) {
      return {
        rows_affected: 0,
        notes: 'Events Agent job skipped: No event feeds configured in Platform Settings.',
        results: { error: 'NO_CONFIG', summary: 'No event feeds configured.' }
      };
    }
    
    const eventFeeds = settingsList[0].EVENTS_FEEDS;

    const prompt = `You are an expert event scout for a corporate real estate firm in Sydney, Australia. Your task is to find upcoming (in the next 6 months) professional events based on the provided sources.

Scan the following RSS feeds and websites for events:
${eventFeeds.join('\n')}

Focus on events in these categories:
- Technology (SaaS, AI, etc.)
- Startups & Venture Capital
- Fintech
- Biotech & Life Sciences
- Property Technology (PropTech)
- Business Networking

For each unique event you find, extract the following information. Be precise with dates and times.
- Event title
- The organizing provider or company
- City (if available, default to Sydney)
- Venue name
- Exact start date and time (in ISO 8601 format: YYYY-MM-DDTHH:MM:SSZ)
- Exact end date and time (in ISO 8601 format)
- The official event URL
- Estimated ticket cost in AUD (as a number, 0 if free)
- Relevant topic tags (e.g., 'networking', 'saas', 'proptech')
- A brief description of the event
- The event type (e.g., Conference, Networking, Webinar)
- Recommended for which sectors (e.g., ['SaaS', 'Fintech'])

Return a JSON object containing a list of these events.`;

    const llmResponse = await InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          events: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                provider: { type: 'string' },
                city: { type: 'string' },
                venue: { type: 'string' },
                start_dt: { type: 'string', format: 'date-time' },
                end_dt: { type: 'string', format: 'date-time' },
                url: { type: 'string', format: 'uri' },
                ticket_cost_est_aud: { type: 'number' },
                topic_tags: { type: 'array', items: { type: 'string' } },
                description: { type: 'string' },
                type: { type: 'string' },
                recommended_for: { type: 'array', items: { type: 'string' } }
              },
              required: ['title', 'provider', 'start_dt', 'url', 'description']
            }
          }
        },
        required: ['events']
      }
    });

    if (!llmResponse || !llmResponse.events || llmResponse.events.length === 0) {
      return {
        rows_affected: 0,
        notes: 'Events Agent ran successfully but found no new events to add.',
        results: { summary: 'No new events found.' }
      };
    }

    let recordsCreated = 0;
    const existingEvents = await Event.list();
    const existingEventTitles = new Set(existingEvents.map(e => e.title.toLowerCase()));

    for (const eventData of llmResponse.events) {
      // Deduplication check
      if (existingEventTitles.has(eventData.title.toLowerCase())) {
        console.log(`Skipping duplicate event: ${eventData.title}`);
        continue;
      }

      await Event.create({
        ...eventData,
        city: eventData.city || 'Sydney',
        ticket_cost_est_aud: eventData.ticket_cost_est_aud || 0,
      });
      recordsCreated++;
    }

    return {
      rows_affected: recordsCreated,
      notes: `Events Agent successfully scanned ${eventFeeds.length} sources and created ${recordsCreated} new event(s).`,
      results: {
        scanned_sources: eventFeeds.length,
        found_events: llmResponse.events.length,
        created_events: recordsCreated
      }
    };

  } catch (error) {
    console.error('Error in Events Agent job:', error);

    // Fallback logic for when the AI service is down
    if (error.message.includes('quota') || error.message.includes('RateLimitError')) {
       console.log('AI service unavailable - creating fallback events data');
        const fallbackEvent = {
            title: 'Sydney Tech Meetup - Service Monitoring Unavailable',
            provider: 'Events Agent (Fallback)',
            city: 'Sydney', 
            venue: 'TBD - Service Unavailable',
            start_dt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // Next week
            end_dt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
            url: '#',
            ticket_cost_est_aud: 0,
            topic_tags: ['tech', 'networking'],
            description: 'Event monitoring service temporarily unavailable. Please check manually for upcoming events.',
            type: 'Networking',
            recommended_for: ['SaaS', 'Fintech', 'Education']
        };
        await Event.create(fallbackEvent);
        return {
          rows_affected: 1,
          notes: `AI service unavailable. Created 1 placeholder event record. Please check event sources manually.`,
          results: { 
            error: 'AI_SERVICE_UNAVAILABLE', 
            summary: 'Events monitoring service temporarily unavailable. Placeholder event created.',
            recordsCreated: 1
          }
        };
    }
    
    // For other errors, just fail the job
    throw error;
  }
};

export const runNSWDAAgentJob = async (payload) => {
  console.log('Starting NSW DA Agent job...');
  
  try {
    const settingsList = await AppSettings.list();
    if (settingsList.length === 0 || !settingsList[0].NSW_DA_API_URL) {
      return {
        rows_affected: 0,
        notes: 'NSW DA Agent job skipped: No NSW DA API URL configured in Platform Settings.',
        results: { error: 'NO_CONFIG', summary: 'No NSW DA API URL configured.' }
      };
    }
    
    const nswDAApiUrl = settingsList[0].NSW_DA_API_URL;

    const prompt = `You are a commercial real estate development analyst. Your task is to scan recent Development Applications (DAs) lodged with NSW councils (last 7 days) to identify potential commercial real estate opportunities.

Scan the NSW Planning Portal API: ${nswDAApiUrl}

Look for DAs that indicate potential corporate real estate needs, such as:
- Commercial fit-outs or office refurbishments
- Change of use applications (e.g., from retail to office, industrial to education)
- New commercial or educational facilities
- Laboratory or research facility developments
- Large-scale office developments
- Mixed-use developments with commercial components

Focus on these Local Government Areas in Sydney:
- City of Sydney
- Barangaroo
- North Sydney
- Parramatta
- Macquarie Park
- Olympic Park
- Alexandria/Green Square

For each relevant DA, extract:
- DA application number
- Applicant/company name (if available)
- Address of the development
- Suburb and postcode
- Type of development (fit-out, new build, change of use, etc.)
- Brief description of the proposed work
- Estimated cost value (if mentioned)
- Date lodged
- Current status (lodged, under assessment, approved, etc.)

Return a JSON object containing a list of these DAs.`;

    const llmResponse = await InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          development_applications: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                da_number: { type: 'string' },
                applicant_name: { type: 'string' },
                address: { type: 'string' },
                suburb: { type: 'string' },
                postcode: { type: 'string' },
                development_type: { type: 'string' },
                description: { type: 'string' },
                estimated_cost: { type: 'number' },
                date_lodged: { type: 'string', format: 'date' },
                status: { type: 'string' },
                council: { type: 'string' }
              },
              required: ['da_number', 'address', 'suburb', 'development_type', 'description', 'date_lodged']
            }
          }
        },
        required: ['development_applications']
      }
    });

    if (!llmResponse || !llmResponse.development_applications || llmResponse.development_applications.length === 0) {
      return {
        rows_affected: 0,
        notes: 'NSW DA Agent ran successfully but found no relevant development applications.',
        results: { summary: 'No relevant DAs found.' }
      };
    }

    let signalsCreated = 0;
    const existingSignals = await Signal.list();
    const existingDAs = new Set(existingSignals.filter(s => s.type === 'DA').map(s => s.title));

    for (const da of llmResponse.development_applications) {
      // Deduplication check
      const daTitle = `DA ${da.da_number} - ${da.address}`;
      if (existingDAs.has(daTitle)) {
        console.log(`Skipping duplicate DA: ${daTitle}`);
        continue;
      }

      // Create signal for the DA
      await Signal.create({
        type: 'DA',
        source: 'NSW DA Agent',
        title: daTitle,
        url: nswDAApiUrl, // Link to the planning portal
        date: da.date_lodged,
        magnitude: da.estimated_cost ? Math.log10(da.estimated_cost / 1000) : 1, // Logarithmic scale for cost
        location: `${da.suburb}, NSW ${da.postcode}`,
        raw_json: da
      });
      signalsCreated++;
    }

    return {
      rows_affected: signalsCreated,
      notes: `NSW DA Agent successfully scanned NSW Planning Portal and found ${llmResponse.development_applications.length} relevant DAs. Created ${signalsCreated} new signals.`,
      results: {
        found_das: llmResponse.development_applications.length,
        created_signals: signalsCreated
      }
    };

  } catch (error) {
    console.error('Error in NSW DA Agent job:', error);

    // Fallback logic for when the AI service is down
    if (error.message.includes('quota') || error.message.includes('RateLimitError')) {
      console.log('AI service unavailable - creating fallback NSW DA data');
      const fallbackSignal = await Signal.create({
        type: 'DA',
        source: 'NSW DA Agent (Fallback)',
        title: 'NSW Development Applications Monitoring - Service Temporarily Unavailable',
        url: '#', 
        date: new Date().toISOString().split('T')[0],
        magnitude: 0,
        location: 'Sydney'
      });

      return {
        rows_affected: 1,
        notes: 'AI service unavailable. Created placeholder DA monitoring record. Please check NSW Planning Portal manually.',
        results: {
          error: 'AI_SERVICE_UNAVAILABLE',
          summary: 'NSW DA monitoring service temporarily unavailable. Placeholder record created.',
          recordsCreated: 1
        }
      };
    }
    
    throw error;
  }
};
