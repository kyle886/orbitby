import { Company } from '@/api/entities';
import { Building } from '@/api/entities';
import { DuplicateRecordPair } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';

// Function to normalize company names for a quick pre-filter
const normalizeName = (name) => {
  if (!name) return '';
  return name.toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/ pty ltd| pty| ltd| limited|proprietary/g, '')
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, '')
    .trim();
};

export async function scanForDuplicates(payload) {
  console.log('Starting Duplicate Scanner job...');

  // Clear previous pending reviews to avoid clutter
  const previousDuplicates = await DuplicateRecordPair.filter({ status: 'pending_review', entity_type: 'Company' });
  for (const dup of previousDuplicates) {
    await DuplicateRecordPair.delete(dup.id);
  }

  const companies = await Company.list();
  const potentialPairs = [];
  let duplicatesFound = 0;

  // Create a map of normalized names to company records for efficient lookup
  const normalizedMap = new Map();
  for (const company of companies) {
    const normalized = normalizeName(company.name);
    if (!normalizedMap.has(normalized)) {
      normalizedMap.set(normalized, []);
    }
    normalizedMap.get(normalized).push(company);
  }

  // Find pairs based on exact normalized name matches (high probability duplicates)
  for (const records of normalizedMap.values()) {
    if (records.length > 1) {
      // Create all combinations of pairs within this group
      for (let i = 0; i < records.length; i++) {
        for (let j = i + 1; j < records.length; j++) {
          potentialPairs.push([records[i], records[j]]);
        }
      }
    }
  }

  for (const pair of potentialPairs) {
    const [companyA, companyB] = pair;

    try {
      const prompt = `You are a data quality analyst. Compare the following two company records and determine if they are likely duplicates. Provide a similarity score from 0 (not similar) to 100 (identical) and a brief justification.
      
      Record A:
      ${JSON.stringify({ name: companyA.name, website: companyA.website, sector: companyA.sector, hq_city: companyA.hq_city }, null, 2)}
      
      Record B:
      ${JSON.stringify({ name: companyB.name, website: companyB.website, sector: companyB.sector, hq_city: companyB.hq_city }, null, 2)}
      
      Consider name variations, address, website, and other fields. Be strict; only high confidence matches should get a score above 85.`;
      
      const llmResponse = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            is_duplicate: { type: 'boolean' },
            similarity_score: { type: 'number', minimum: 0, maximum: 100 },
            justification: { type: 'string' }
          },
          required: ['is_duplicate', 'similarity_score', 'justification']
        }
      });
      
      if (llmResponse.is_duplicate && llmResponse.similarity_score > 75) {
        await DuplicateRecordPair.create({
          entity_type: 'Company',
          record_a_id: companyA.id,
          record_b_id: companyB.id,
          record_a_summary: { name: companyA.name, website: companyA.website, sector: companyA.sector },
          record_b_summary: { name: companyB.name, website: companyB.website, sector: companyB.sector },
          similarity_score: llmResponse.similarity_score,
          status: 'pending_review',
          notes: llmResponse.justification
        });
        duplicatesFound++;
      }
    } catch (error) {
      console.error(`AI check failed for pair ${companyA.name} & ${companyB.name}:`, error);
    }
  }
  
  return {
    rows_affected: duplicatesFound,
    notes: `Duplicate scan complete. Found ${duplicatesFound} potential duplicate pairs for review.`,
    results: { duplicates_found: duplicatesFound }
  };
}