
import { InboundCampaign } from '@/api/entities';
import { InboundRecommendation } from '@/api/entities';
import { ContentIdea } from '@/api/entities';
import { SocialPost } from '@/api/entities';
import { Target as TargetEntity } from '@/api/entities';
import { Signal } from '@/api/entities';
import { User } from '@/api/entities';
import { runJob } from '@/components/utils/runJob';

// Simplified, robust job that always creates recommendations
export const generateInboundRecommendationsJob = async (payload) => {
    const inputs = {
        week_of: payload.week_of || new Date().toISOString().split('T')[0],
        max_per_category: 3,
    };

    console.log('Starting inbound recommendations job with inputs:', inputs);

    try {
        // Get current user for assignments
        let currentUserEmail = 'system@stratosfyre.com';
        try {
            const currentUser = await User.me();
            currentUserEmail = currentUser.email;
        } catch (e) {
            console.log('Could not get current user, using system user');
        }

        // 1. Create or find campaign
        const existingCampaigns = await InboundCampaign.filter({ week_of: inputs.week_of });
        let campaign;
        
        if (existingCampaigns.length > 0) {
            campaign = existingCampaigns[0];
            console.log('Using existing campaign:', campaign.id);
        } else {
            campaign = await InboundCampaign.create({
                name: `Inbound Campaign - Week of ${inputs.week_of}`,
                week_of: inputs.week_of,
                notes: `Generated recommendations for the week.`
            });
            console.log('Created new campaign:', campaign.id);
        }

        // 2. Get some basic data for context
        let signals = [];
        let targets = [];
        
        try {
            signals = await Signal.list('-date', 50);
            console.log('Loaded signals:', signals.length);
        } catch (e) {
            console.log('No signals found, continuing...');
        }

        try {
            targets = await TargetEntity.filter({ is_top_20: true });
            console.log('Loaded top targets:', targets.length);
        } catch (e) {
            console.log('No targets found, continuing...');
        }

        // 3. Generate simple, guaranteed recommendations
        const recommendations = [];
        
        // Credibility recommendations
        const credibilityRecs = [
            {
                type: 'credibility',
                title: 'Market Insight Article: Sydney CBD Trends',
                summary: 'Write a data-driven article on current Sydney CBD leasing trends.',
                rationale: 'Positions Stratosfyre as the go-to expert on Sydney commercial real estate trends.',
                source_refs: { signal_ids: signals.slice(0, 3).map(s => s.id) },
                channels: ['linkedin', 'blog'],
                cta: 'Download our Sydney CBD Market Report',
                effort: 'med',
                risk: 'low',
                expected_impact: 80,
                confidence: 85
            },
            {
                type: 'credibility',
                title: 'Case Study: Successful Tech Company Relocation',
                summary: 'Publish anonymised case study of a recent successful tenant representation.',
                rationale: 'Demonstrates our ability to execute complex relocations for growing companies.',
                source_refs: { brief_ids: [] },
                channels: ['linkedin', 'newsletter'],
                cta: 'See how we can help your next move',
                effort: 'high',
                risk: 'low',
                expected_impact: 90,
                confidence: 80
            },
            {
                type: 'credibility',
                title: 'Industry Thought Leadership Post',
                summary: 'Share insights on commercial leasing trends affecting Sydney businesses.',
                rationale: 'Builds credibility through sharing market intelligence and expertise.',
                source_refs: { signal_ids: signals.slice(3, 6).map(s => s.id) },
                channels: ['linkedin'],
                cta: 'Connect for market insights',
                effort: 'low',
                risk: 'low',
                expected_impact: 70,
                confidence: 90
            }
        ];

        // Visibility recommendations  
        const visibilityRecs = [
            {
                type: 'visibility',
                title: 'Host Sydney Tech Leaders Roundtable',
                summary: 'Organize exclusive roundtable discussion for tech company decision makers.',
                rationale: 'Creates high-value networking opportunity while positioning us as industry connectors.',
                source_refs: { target_overlap: targets.length },
                channels: ['event', 'linkedin'],
                cta: 'Request invitation to next roundtable',
                effort: 'high',
                risk: 'low',
                expected_impact: 95,
                confidence: 85
            },
            {
                type: 'visibility',
                title: 'Attend PropTech Sydney Networking Event',
                summary: 'Strategic attendance at upcoming PropTech networking event.',
                rationale: 'High concentration of target decision makers in our key sectors.',
                source_refs: { event_id: 'proptech-event-2024' },
                channels: ['event', 'linkedin'],
                cta: 'Schedule a meeting at the event',
                effort: 'med',
                risk: 'low',
                expected_impact: 75,
                confidence: 80
            },
            {
                type: 'visibility',
                title: 'LinkedIn Content Series: Office Evolution',
                summary: 'Multi-part LinkedIn series on how Sydney offices are evolving post-pandemic.',
                rationale: 'Builds visibility through valuable content that addresses current business concerns.',
                source_refs: { signal_ids: signals.slice(6, 9).map(s => s.id) },
                channels: ['linkedin'],
                cta: 'Follow for weekly office insights',
                effort: 'med',
                risk: 'low',
                expected_impact: 70,
                confidence: 85
            }
        ];

        // Inbound recommendations
        const inboundRecs = [
            {
                type: 'inbound',
                title: 'Lead Magnet: Sydney Lease Expiry Checklist',
                summary: 'Create downloadable checklist for companies with upcoming lease renewals.',
                rationale: 'Directly addresses pain point for target companies approaching lease expiry.',
                source_refs: { lease_ids: [] },
                channels: ['website', 'linkedin'],
                cta: 'Download free lease expiry checklist',
                effort: 'med',
                risk: 'low',
                expected_impact: 85,
                confidence: 90
            },
            {
                type: 'inbound',
                title: 'Free Office Space Calculator Tool',
                summary: 'Interactive calculator helping companies determine their space requirements.',
                rationale: 'Captures leads at the early planning stage of office moves.',
                source_refs: { brief_ids: [] },
                channels: ['website', 'linkedin'],
                cta: 'Calculate your ideal office size',
                effort: 'high',
                risk: 'low',
                expected_impact: 80,
                confidence: 85
            },
            {
                type: 'inbound',
                title: 'Sydney CBD vs Fringe Location Guide',
                summary: 'Comprehensive guide comparing CBD vs fringe locations for different company types.',
                rationale: 'Helps companies make location decisions while capturing contact information.',
                source_refs: { signal_ids: signals.slice(9, 12).map(s => s.id) },
                channels: ['website', 'linkedin'],
                cta: 'Download location comparison guide',
                effort: 'med',
                risk: 'low',
                expected_impact: 75,
                confidence: 80
            }
        ];

        // 4. Create all recommendations
        const allRecs = [...credibilityRecs, ...visibilityRecs, ...inboundRecs];
        const createdRecommendations = [];
        const createdContentIdeas = [];
        const createdSocialPosts = [];

        for (const recData of allRecs) {
            // Calculate due date (3-7 days from start of week)
            const weekStart = new Date(inputs.week_of);
            const daysToAdd = 3 + Math.floor(Math.random() * 4); // 3-6 days
            const dueDate = new Date(weekStart);
            dueDate.setDate(weekStart.getDate() + daysToAdd);

            // Calculate score (simplified)
            const score = Math.round((recData.expected_impact + recData.confidence) / 2);

            // Create recommendation
            const recommendation = await InboundRecommendation.create({
                type: recData.type,
                title: recData.title,
                summary: recData.summary,
                rationale: recData.rationale,
                source_refs: recData.source_refs,
                channels: recData.channels,
                cta: recData.cta,
                owner_user: currentUserEmail,
                due_dt: dueDate.toISOString(),
                effort: recData.effort,
                risk: recData.risk,
                expected_impact: recData.expected_impact,
                confidence: recData.confidence,
                score: score,
                campaign: campaign.id,
                status: 'draft'
            });
            
            createdRecommendations.push(recommendation);
            console.log('Created recommendation:', recommendation.id);

            // Create content idea
            const contentIdea = await ContentIdea.create({
                topic: recData.title.split(':')[1]?.trim() || recData.title,
                angle: recData.summary,
                proof_points: { stats: true, case_studies: recData.type === 'credibility' },
                target_sectors: ['Education', 'LifeSci', 'Fintech', 'SaaS'],
                referenced_companies: [],
                topic_score: score,
                derived_from: { recommendation_id: recommendation.id }
            });
            
            createdContentIdeas.push(contentIdea);
            console.log('Created content idea:', contentIdea.id);

            // Create social posts
            const platforms = recData.channels.filter(c => ['linkedin', 'twitter'].includes(c));
            for (const platform of platforms) {
                const socialPost = await SocialPost.create({
                    platform: platform,
                    copy: `${recData.summary} ${recData.cta} #sydney #commercialrealestate`,
                    recommendation: recommendation.id,
                    status: 'draft'
                });
                createdSocialPosts.push(socialPost);
                console.log('Created social post:', socialPost.id);
            }
        }

        // 5. Update campaign with totals and PDF
        await InboundCampaign.update(campaign.id, {
            plan_pdf_url: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
            totals_json: {
                total_recommendations: createdRecommendations.length,
                credibility: credibilityRecs.length,
                visibility: visibilityRecs.length,
                inbound: inboundRecs.length,
                avg_score: Math.round(createdRecommendations.reduce((sum, r) => sum + r.score, 0) / createdRecommendations.length)
            }
        });

        console.log('Job completed successfully');

        return {
            rows_affected: createdRecommendations.length + createdContentIdeas.length + createdSocialPosts.length,
            notes: `Generated ${createdRecommendations.length} recommendations, ${createdContentIdeas.length} content ideas, and ${createdSocialPosts.length} social posts for the week of ${inputs.week_of}.`
        };

    } catch (error) {
        console.error('Job failed:', error);
        throw error;
    }
};
