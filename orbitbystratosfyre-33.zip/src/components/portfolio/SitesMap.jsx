import React, { useEffect, useState, useMemo } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function SitesMap({ buildings=[] }) {
  const [imgUrl, setImgUrl] = useState(null);

  // Extract complex expression to separate variable for static checking
  const buildingCoords = useMemo(() => 
    buildings.map(s => [s.latitude, s.longitude]), 
    [buildings]
  );

  useEffect(()=>{ (async ()=>{
    const pts = buildings.filter(s=>isFinite(s.latitude) && isFinite(s.longitude)).map(s=>({ lat:s.latitude, lng:s.longitude }));
    if (pts.length===0) { setImgUrl(null); return; }
    const r = await fetch('/api/functions/staticMapMulti', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ points: pts, w: 960, h: 420, z: 10 })});
    if (r.ok) setImgUrl(URL.createObjectURL(await r.blob()));
  })(); }, [buildings, buildingCoords]);

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3"><CardTitle className="text-base">Sites Map</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        {!imgUrl && <div className="text-sm text-gray-400">No mappable sites yet.</div>}
        {imgUrl && <img src={imgUrl} alt="Sites map" className="w-full rounded-lg border border-white/10" />}
        <div className="grid md:grid-cols-3 gap-2">
          {buildings.map(s=>(
            <div key={s.id} className="rounded-lg border border-white/10 p-2">
              <div className="text-sm font-medium">{s.name}</div>
              <div className="text-xs text-gray-400 mb-1">{s.address}</div>
              {isFinite(s.latitude) && isFinite(s.longitude) && (
                <img className="w-full rounded-md" alt="map thumb"
                     src={`/api/functions/staticMap?lat=${s.latitude}&lng=${s.longitude}&z=15&w=320&h=160`} />
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}