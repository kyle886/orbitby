import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function CriticalEvents({ events=[], buildingsById={} }) {
  const chip = k => ({
    expiry:   'bg-rose-900/30 text-rose-300',
    option_notice: 'bg-amber-900/30 text-amber-300',
    rent_review: 'bg-emerald-900/30 text-emerald-300',
    makegood: 'bg-fuchsia-900/30 text-fuchsia-300'
  }[k] || 'bg-white/5 text-gray-300');

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3"><CardTitle className="text-base">Upcoming Critical Events (120d)</CardTitle></CardHeader>
      <CardContent className="space-y-2">
        {events.length === 0 && <div className="text-sm text-gray-400">No events in window.</div>}
        {events.map((e,i)=>(
          <div key={i} className="flex items-center justify-between rounded-lg border border-white/10 p-2">
            <div className="text-sm">
              <span className={`px-2 py-0.5 rounded-md text-[11px] mr-2 ${chip(e.kind)}`}>{label(e.kind)}</span>
              <span className="font-medium">{buildingsById[e.building_id]?.name || `Building #${e.building_id}`}</span>
            </div>
            <div className="text-xs text-gray-400">{fmt(e.due_dt)}</div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
const label = k => ({ expiry:'Lease Expiry', option_notice:'Option Notice', rent_review:'Rent Review', makegood:'Make Good' }[k] || k);
const fmt = dt => { try{ return new Date(dt).toLocaleDateString('en-AU',{ day:'2-digit', month:'short', year:'numeric'}) }catch{ return String(dt||'') } };