import React, { useMemo } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import StackedBars from "@/components/charts/StackedBars";
import { downloadCsv } from "@/components/utils/csv/downloadCsv";

export default function LiabilitiesPanel({ series, currency='A$' }) {
  const data = useMemo(()=> series.labels.map((k,i)=>({ label:k, stacks:{ All: series.monthlyArray[i] }, total: series.monthlyArray[i] })), [series]);
  const total12 = Math.round(series.monthlyArray.reduce((a,b)=>a+b,0));

  const exportCsv = ()=> downloadCsv(series.labels.map((k,i)=>({ month:k, liability_aud: Math.round(series.monthlyArray[i]) })), `liabilities_${Date.now()}.csv`);

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Liabilities Forecast (next {series.labels.length} months)</CardTitle>
          <div className="text-sm text-gray-300">Total: {currency}{toAU(total12)}</div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <StackedBars data={data} currency={currency} />
        <div className="text-right">
          <button className="text-xs underline text-gray-300 hover:text-white" onClick={exportCsv}>Download CSV</button>
        </div>
      </CardContent>
    </Card>
  );
}
const toAU = n => Number(n||0).toLocaleString('en-AU',{ maximumFractionDigits:0 });