import React, { useEffect, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Document } from "@/api/entities";
import { LeaseClause } from "@/api/entities";
import { useToast } from "@/components/ui/use-toast";

export default function DocsPanel({ leaseId }) {
  const [docs, setDocs] = useState([]);
  const [busy, setBusy] = useState(null);
  const { toast } = useToast();

  useEffect(()=>{ (async ()=>{
    const list = await Document.filter({ lease_id: leaseId }, 200);
    setDocs(list||[]);
  })(); }, [leaseId]);

  const extract = async (doc) => {
    setBusy(doc.id);
    try{
      const r = await fetch('/api/functions/extractClauses', {
        method:'POST', headers:{'content-type':'application/json'},
        body: JSON.stringify({ file_url: doc.file_url })
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error||'Extract failed');
      // Persist (lightweight) into LeaseClause entity
      await LeaseClause.create({
        lease_id: leaseId,
        document_id: doc.id,
        clauses_json: j.clauses
      });
      toast({ title:'Clauses extracted', description:'Maintenance, Rent/Reviews, Outgoings, Make Good' });
    } catch(e){
      toast({ variant:'destructive', title:'Extract failed', description:String(e.message||e) });
    } finally { setBusy(null); }
  };

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3"><CardTitle className="text-base">Documents</CardTitle></CardHeader>
      <CardContent className="space-y-2">
        {docs.length===0 && <div className="text-sm text-gray-400">No documents saved to this lease.</div>}
        {docs.map(d=>(
          <div key={d.id} className="flex items-center justify-between rounded-lg border border-white/10 p-2">
            <div className="text-sm truncate max-w-[60%]">{basename(d.file_url)}</div>
            <div className="flex items-center gap-2">
              <a className="text-xs underline text-gray-300 hover:text-white" href={d.file_url} target="_blank" rel="noreferrer">Open</a>
              <Button size="sm" onClick={()=>extract(d)} disabled={busy===d.id}>{busy===d.id?'Extracting…':'Extract clauses'}</Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
function basename(u){ try{ return decodeURIComponent(String(u)).split('/').pop() }catch{ return u } }