import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { X, Filter } from "lucide-react";

export default function GeographicFilters({ 
  filters, 
  onFiltersChange, 
  availableLocations = {},
  onClearFilters 
}) {
  const { countries = [], regions = [], states = [], cities = [] } = availableLocations;

  const handleFilterChange = (key, value) => {
    const newFilters = { ...filters };
    if (value === 'all') {
      delete newFilters[key];
    } else {
      newFilters[key] = value;
    }
    
    // Clear dependent filters when parent changes
    if (key === 'country') {
      delete newFilters.state;
      delete newFilters.city;
    } else if (key === 'region') {
      delete newFilters.country;
      delete newFilters.state;
      delete newFilters.city;
    } else if (key === 'state') {
      delete newFilters.city;
    }
    
    onFiltersChange(newFilters);
  };

  const hasActiveFilters = Object.keys(filters).some(key => 
    ['country', 'region', 'state', 'city'].includes(key)
  );

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Geographic Filters
          </CardTitle>
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={onClearFilters}>
              <X className="w-4 h-4 mr-1" />
              Clear
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Region Filter */}
          <div>
            <label className="text-xs text-gray-400 mb-1 block">Region</label>
            <Select 
              value={filters.region || 'all'} 
              onValueChange={(value) => handleFilterChange('region', value)}
            >
              <SelectTrigger className="h-8 text-xs">
                <SelectValue placeholder="All Regions" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Regions</SelectItem>
                {regions.map(region => (
                  <SelectItem key={region} value={region}>{region}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Country Filter */}
          <div>
            <label className="text-xs text-gray-400 mb-1 block">Country</label>
            <Select 
              value={filters.country || 'all'} 
              onValueChange={(value) => handleFilterChange('country', value)}
            >
              <SelectTrigger className="h-8 text-xs">
                <SelectValue placeholder="All Countries" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Countries</SelectItem>
                {countries.map(country => (
                  <SelectItem key={country} value={country}>{country}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* State Filter */}
          <div>
            <label className="text-xs text-gray-400 mb-1 block">State/Province</label>
            <Select 
              value={filters.state || 'all'} 
              onValueChange={(value) => handleFilterChange('state', value)}
            >
              <SelectTrigger className="h-8 text-xs">
                <SelectValue placeholder="All States" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All States</SelectItem>
                {states.map(state => (
                  <SelectItem key={state} value={state}>{state}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* City Filter */}
          <div>
            <label className="text-xs text-gray-400 mb-1 block">City</label>
            <Select 
              value={filters.city || 'all'} 
              onValueChange={(value) => handleFilterChange('city', value)}
            >
              <SelectTrigger className="h-8 text-xs">
                <SelectValue placeholder="All Cities" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Cities</SelectItem>
                {cities.map(city => (
                  <SelectItem key={city} value={city}>{city}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Active Filters Display */}
        {hasActiveFilters && (
          <div className="flex flex-wrap gap-2 pt-2 border-t border-white/10">
            <span className="text-xs text-gray-400">Active filters:</span>
            {Object.entries(filters).map(([key, value]) => {
              if (!['country', 'region', 'state', 'city'].includes(key)) return null;
              return (
                <span 
                  key={key} 
                  className="inline-flex items-center gap-1 px-2 py-1 bg-blue-500/20 text-blue-300 rounded text-xs"
                >
                  {key}: {value}
                  <button 
                    onClick={() => handleFilterChange(key, 'all')}
                    className="hover:text-blue-100"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}