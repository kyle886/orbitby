import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, DollarSign, Building } from "lucide-react";

export default function LeaseList({ leases = [], buildingsById = {}, companiesById = {} }) {
  const formatCurrency = (amount) => {
    if (!amount) return 'N/A';
    return `$${Number(amount).toLocaleString('en-AU')}`;
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleDateString('en-AU');
    } catch {
      return 'N/A';
    }
  };

  const getExpiryStatus = (expiryDate) => {
    if (!expiryDate) return { status: 'unknown', color: 'bg-gray-500/20 text-gray-400' };
    
    const expiry = new Date(expiryDate);
    const today = new Date();
    const daysUntilExpiry = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    
    if (daysUntilExpiry < 0) {
      return { status: 'expired', color: 'bg-red-500/20 text-red-400', days: Math.abs(daysUntilExpiry) };
    } else if (daysUntilExpiry <= 90) {
      return { status: 'critical', color: 'bg-orange-500/20 text-orange-400', days: daysUntilExpiry };
    } else if (daysUntilExpiry <= 365) {
      return { status: 'warning', color: 'bg-yellow-500/20 text-yellow-400', days: daysUntilExpiry };
    } else {
      return { status: 'good', color: 'bg-green-500/20 text-green-400', days: daysUntilExpiry };
    }
  };

  if (leases.length === 0) {
    return (
      <Card className="shadow-elevated">
        <CardHeader>
          <CardTitle className="text-base">Lease Portfolio</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-400">
            <Building className="w-12 h-12 mx-auto mb-3 text-gray-600" />
            <p>No leases match the current filters</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3">
        <CardTitle className="text-base">
          Lease Portfolio ({leases.length} lease{leases.length !== 1 ? 's' : ''})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {leases.map((lease) => {
          const building = buildingsById[lease.building_id] || {};
          const company = companiesById[lease.company_id] || {};
          const expiryInfo = getExpiryStatus(lease.expiry_date);
          
          return (
            <div 
              key={lease.id} 
              className="rounded-lg border border-white/10 p-4 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="font-medium text-white">
                    {building.name || 'Unknown Building'}
                    {lease.lease_reference && (
                      <span className="text-gray-400 text-sm ml-2">({lease.lease_reference})</span>
                    )}
                  </h4>
                  <p className="text-sm text-gray-400">{company.name || 'Unknown Tenant'}</p>
                </div>
                <Badge className={expiryInfo.color}>
                  {expiryInfo.status === 'expired' ? `Expired ${expiryInfo.days}d ago` :
                   expiryInfo.status === 'critical' ? `${expiryInfo.days}d left` :
                   expiryInfo.status === 'warning' ? `${expiryInfo.days}d left` :
                   `${Math.floor(expiryInfo.days / 365)}y left`}
                </Badge>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-gray-400" />
                  <div>
                    <div className="text-gray-400">Location</div>
                    <div className="text-white">
                      {[lease.city, lease.state, lease.country].filter(Boolean).join(', ') || building.address || 'N/A'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-gray-400" />
                  <div>
                    <div className="text-gray-400">Area</div>
                    <div className="text-white">{lease.area_m2 ? `${lease.area_m2.toLocaleString()} m²` : 'N/A'}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-gray-400" />
                  <div>
                    <div className="text-gray-400">Rent p.a.</div>
                    <div className="text-white">
                      {lease.rent_aud_per_m2_pa ? 
                        formatCurrency(lease.rent_aud_per_m2_pa * (lease.area_m2 || 0)) : 
                        'N/A'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <div>
                    <div className="text-gray-400">Expires</div>
                    <div className="text-white">{formatDate(lease.expiry_date)}</div>
                  </div>
                </div>
              </div>

              {lease.notes && (
                <div className="mt-3 pt-3 border-t border-white/10">
                  <p className="text-xs text-gray-400">{lease.notes}</p>
                </div>
              )}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}