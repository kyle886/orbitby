import React, { useEffect, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { LeaseClause } from "@/api/entities";

export default function LeaseClausesPanel({ leaseId }) {
  const [rows, setRows] = useState([]);

  useEffect(()=>{ (async ()=>{
    const list = await LeaseClause.filter({ lease_id: leaseId }, 50);
    setRows(list||[]);
  })(); }, [leaseId]);

  const last = rows[0]?.clauses_json || null;

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3"><CardTitle className="text-base">Key Clauses (latest)</CardTitle></CardHeader>
      <CardContent className="grid md:grid-cols-2 gap-3 text-sm">
        {!last && <div className="text-gray-400">No extracted clauses yet.</div>}
        {last && (
          <>
            <Block title="Rent">
              {last.rent?.type==='psm_pa' ? `A$${n(last.rent.amount_psm_pa)}/m²/yr` :
               last.rent?.type==='annual' ? `A$${n(last.rent.amount_aud_pa)}/yr` : 'Not found'}
            </Block>
            <Block title="Rent Reviews">
              {last.reviews?.fixed ? `Fixed ${last.reviews.fixed}%` : last.reviews?.CPI ? 'CPI' : last.reviews?.market ? 'Market' : '—'}
              {last.reviews?.anchor_month && <div className="text-xs text-gray-400">Month: {cap(last.reviews.anchor_month)}</div>}
            </Block>
            <Block title="Outgoings">
              {last.outgoings?.basis?.toUpperCase()} {last.outgoings?.amount_psm_pa ? `· A$${n(last.outgoings.amount_psm_pa)}/m²/yr` : last.outgoings?.amount_aud_pa ? `· A$${n(last.outgoings.amount_aud_pa)}/yr` : ''}
            </Block>
            <Block title="Maintenance">{last.maintenance?.responsibility || '—'} {last.maintenance?.notes && `· ${last.maintenance.notes}`}</Block>
            <Block title="Make Good">{last.makegood?.level || '—'} {last.makegood?.note && `· ${last.makegood.note}`}</Block>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function Block({ title, children }) {
  return (
    <div className="rounded-lg border border-white/10 p-2">
      <div className="text-xs text-gray-400">{title}</div>
      <div className="font-medium">{children}</div>
    </div>
  );
}
const n = v => Number(v||0).toLocaleString('en-AU',{ maximumFractionDigits:0 });
const cap = s => s ? s[0].toUpperCase()+s.slice(1) : s;