
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  MessageSquare,
  Target,
  DollarSign,
  Calendar,
  FileText,
  Lightbulb
} from 'lucide-react';
import { InvokeLLM } from '@/api/integrations';
import { useToast } from '@/components/ui/use-toast';

export default function NegotiationCoachPanel({ 
  rfpResponse, 
  brief, 
  marketData = null,
  onUpdateStrategy 
}) {
  const [coachingData, setCoachingData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [strategy, setStrategy] = useState('');
  const { toast } = useToast();

  const buildNegotiationContext = useCallback(() => {
    return {
      property: {
        address: rfpResponse?.property_submission?.address,
        size_sqm: rfpResponse?.property_submission?.floor_area_sqm,
        grade: rfpResponse?.property_submission?.building_grade
      },
      offer_terms: {
        rent: rfpResponse?.headline_terms?.net_face_rent,
        incentive_pct: rfpResponse?.headline_terms?.incentive_percentage,
        lease_term: rfpResponse?.headline_terms?.lease_term,
        outgoings: rfpResponse?.headline_terms?.outgoings
      },
      client_requirements: {
        budget_max: brief?.budget_range_max,
        area_need: brief?.min_floor_area,
        timing: brief?.required_date,
        priorities: brief?.additional_notes
      },
      market_context: marketData || {}
    };
  }, [rfpResponse, brief, marketData]);

  const generateCoachingAdvice = useCallback(async () => {
    setLoading(true);
    try {
      const context = buildNegotiationContext();
      
      const prompt = `As a commercial real estate negotiation expert, analyze this deal and provide strategic coaching advice.

Context:
${JSON.stringify(context, null, 2)}

Provide coaching on:
1. Negotiation strengths and weaknesses
2. Market positioning analysis
3. Specific tactical recommendations
4. Risk assessment
5. Alternative scenarios

Focus on maximizing value for the tenant while maintaining deal viability.`;

      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            deal_assessment: {
              type: "object",
              properties: {
                overall_score: { type: "integer", minimum: 0, maximum: 100 },
                market_position: { type: "string", enum: ["strong", "fair", "weak"] },
                negotiation_leverage: { type: "string", enum: ["high", "medium", "low"] },
                deal_quality: { type: "string", enum: ["excellent", "good", "fair", "poor"] }
              }
            },
            strengths: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  area: { type: "string" },
                  description: { type: "string" },
                  impact: { type: "string", enum: ["high", "medium", "low"] }
                }
              }
            },
            concerns: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  issue: { type: "string" },
                  risk_level: { type: "string", enum: ["high", "medium", "low"] },
                  mitigation: { type: "string" }
                }
              }
            },
            recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  category: { type: "string" },
                  action: { type: "string" },
                  expected_impact: { type: "string" },
                  priority: { type: "string", enum: ["high", "medium", "low"] }
                }
              }
            },
            market_insights: {
              type: "object",
              properties: {
                rent_assessment: { type: "string" },
                incentive_benchmark: { type: "string" },
                market_trends: { type: "string" }
              }
            }
          }
        }
      });

      setCoachingData(response);
    } catch (error) {
      console.error('Failed to generate coaching advice:', error);
      toast({ 
        variant: "destructive", 
        title: "Coaching analysis failed", 
        description: "Could not generate negotiation advice" 
      });
    } finally {
      setLoading(false);
    }
  }, [buildNegotiationContext, toast]);

  useEffect(() => {
    if (rfpResponse && brief) {
      generateCoachingAdvice();
    }
  }, [rfpResponse, brief, generateCoachingAdvice]);

  const saveStrategy = async () => {
    try {
      await onUpdateStrategy({ 
        negotiation_strategy: strategy,
        coaching_data: coachingData 
      });
      toast({ title: "Strategy saved", description: "Negotiation strategy updated" });
    } catch (error) {
      toast({ 
        variant: "destructive", 
        title: "Save failed", 
        description: "Could not save strategy" 
      });
    }
  };

  if (loading) {
    return (
      <Card className="shadow-elevated">
        <CardContent className="p-6">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-400 mx-auto mb-4"></div>
            <p className="text-sm text-gray-400">AI Coach analyzing deal...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!coachingData) {
    return (
      <Card className="shadow-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Brain className="w-5 h-5" />
            AI Negotiation Coach
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Button onClick={generateCoachingAdvice} className="w-full">
            <Brain className="w-4 h-4 mr-2" />
            Analyze Deal
          </Button>
        </CardContent>
      </Card>
    );
  }

  const { deal_assessment, strengths, concerns, recommendations, market_insights } = coachingData;

  return (
    <div className="space-y-4">
      {/* Deal Assessment */}
      <Card className="shadow-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Target className="w-5 h-5" />
            Deal Assessment
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white mb-1">
                {deal_assessment?.overall_score || 0}%
              </div>
              <div className="text-xs text-gray-400">Overall Score</div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Market Position:</span>
                <Badge className={`text-xs ${
                  deal_assessment?.market_position === 'strong' ? 'bg-green-600' :
                  deal_assessment?.market_position === 'fair' ? 'bg-yellow-600' : 'bg-red-600'
                }`}>
                  {deal_assessment?.market_position}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Leverage:</span>
                <Badge className={`text-xs ${
                  deal_assessment?.negotiation_leverage === 'high' ? 'bg-green-600' :
                  deal_assessment?.negotiation_leverage === 'medium' ? 'bg-yellow-600' : 'bg-red-600'
                }`}>
                  {deal_assessment?.negotiation_leverage}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Strengths */}
      <Card className="shadow-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <CheckCircle className="w-5 h-5 text-green-400" />
            Negotiation Strengths
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {(strengths || []).map((strength, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <Badge className={`text-xs ${
                  strength.impact === 'high' ? 'bg-green-600' :
                  strength.impact === 'medium' ? 'bg-blue-600' : 'bg-gray-600'
                }`}>
                  {strength.impact}
                </Badge>
                <div>
                  <p className="font-medium text-white text-sm">{strength.area}</p>
                  <p className="text-xs text-gray-400">{strength.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Concerns */}
      {concerns && concerns.length > 0 && (
        <Card className="shadow-elevated">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
              Key Concerns
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {concerns.map((concern, idx) => (
                <div key={idx} className="p-3 bg-gray-800 rounded-md">
                  <div className="flex items-start justify-between mb-2">
                    <p className="font-medium text-white text-sm">{concern.issue}</p>
                    <Badge className={`text-xs ${
                      concern.risk_level === 'high' ? 'bg-red-600' :
                      concern.risk_level === 'medium' ? 'bg-yellow-600' : 'bg-gray-600'
                    }`}>
                      {concern.risk_level}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-400">{concern.mitigation}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tactical Recommendations */}
      <Card className="shadow-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Lightbulb className="w-5 h-5 text-orange-400" />
            Tactical Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {(recommendations || []).map((rec, idx) => (
              <div key={idx} className="p-3 bg-gray-800 rounded-md">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium text-white text-sm">{rec.category}</p>
                    <p className="text-sm text-gray-300">{rec.action}</p>
                  </div>
                  <Badge className={`text-xs ${
                    rec.priority === 'high' ? 'bg-red-600' :
                    rec.priority === 'medium' ? 'bg-yellow-600' : 'bg-gray-600'
                  }`}>
                    {rec.priority}
                  </Badge>
                </div>
                <p className="text-xs text-gray-400">{rec.expected_impact}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Market Insights */}
      {market_insights && (
        <Card className="shadow-elevated">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <TrendingUp className="w-5 h-5 text-blue-400" />
              Market Context
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div>
                <span className="text-gray-400">Rent Assessment: </span>
                <span className="text-white">{market_insights.rent_assessment}</span>
              </div>
              <div>
                <span className="text-gray-400">Incentive Benchmark: </span>
                <span className="text-white">{market_insights.incentive_benchmark}</span>
              </div>
              <div>
                <span className="text-gray-400">Market Trends: </span>
                <span className="text-white">{market_insights.market_trends}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Strategy Notes */}
      <Card className="shadow-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <MessageSquare className="w-5 h-5" />
            Negotiation Strategy
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={strategy}
            onChange={(e) => setStrategy(e.target.value)}
            placeholder="Document your negotiation strategy and key talking points..."
            className="mb-4 orbit-input text-white"
            rows={4}
          />
          <Button onClick={saveStrategy} className="w-full">
            <FileText className="w-4 h-4 mr-2" />
            Save Strategy
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
