import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";

/**
 * Props:
 *  open, onOpenChange
 *  payload: { selectedMoves: Array<{issue_id, move, expected_value_aud, risk, confidence}>, toEmail, ccEmail?, subject, body }
 *  onApproved: (payload) => void
 */
export default function ApprovalModal({ open, onOpenChange, payload, onApproved }) {
  const { toast } = useToast();
  const [approver, setApprover] = useState("");
  const [rationale, setRationale] = useState("");
  const [to, setTo] = useState(payload?.toEmail || "");
  const [cc, setCc] = useState(payload?.ccEmail || "");

  const approve = () => {
    if (!approver.trim()) { toast({ variant:"destructive", title:"Who is approving?" }); return; }
    if (!to.trim()) { toast({ variant:"destructive", title:"Add a recipient" }); return; }
    onApproved?.({ ...payload, approver, rationale, toEmail: to, ccEmail: cc });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="orbit-card max-w-xl text-white">
        <DialogHeader>
          <DialogTitle>Approve Counter Proposal</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <label className="text-xs text-gray-400 col-span-1 self-center">Approver</label>
            <Input value={approver} onChange={e=>setApprover(e.target.value)} className="col-span-2 orbit-input" placeholder="Name" />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <label className="text-xs text-gray-400 col-span-1 self-center">To</label>
            <Input value={to} onChange={e=>setTo(e.target.value)} className="col-span-2 orbit-input" placeholder="agent@broker.com" />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <label className="text-xs text-gray-400 col-span-1 self-center">CC</label>
            <Input value={cc} onChange={e=>setCc(e.target.value)} className="col-span-2 orbit-input" placeholder="client@company.com" />
          </div>
          <div>
            <label className="text-xs text-gray-400">Rationale (internal)</label>
            <Textarea rows={3} value={rationale} onChange={e=>setRationale(e.target.value)} className="orbit-input" placeholder="Why these moves? Risk/EV summary." />
          </div>
          <div className="rounded-lg border border-gray-700 p-3 bg-gray-800/50">
            <div className="text-xs text-gray-400 mb-1">Selected moves</div>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              {payload?.selectedMoves?.map((m,i)=>(
                <li key={i}>
                  <span className="font-medium">{m.move}</span>
                  <span className="text-gray-400"> · EV A${fmt(m.expected_value_aud)} · {m.risk} · {m.confidence}%</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={()=>onOpenChange(false)} className="orbit-button-secondary">Cancel</Button>
          <Button onClick={approve} className="orbit-button-active">Approve & Continue</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function fmt(n){ if(n==null) return "0"; try{ return Number(n).toLocaleString("en-AU"); }catch{return String(n);} }