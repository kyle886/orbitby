import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Loader2, Layout, Plus, Trash2 } from 'lucide-react';
import { massingSolve } from '@/api/functions';

export default function MassingControls({ scenario, onMassingResult }) {
  const [loading, setLoading] = useState(false);
  const [requirements, setRequirements] = useState({
    workstations: 50,
    rooms: [
      { type: 'Meeting Room', area_m2: 20, count: 3 },
      { type: 'Board Room', area_m2: 40, count: 1 },
      { type: 'Phone Booth', area_m2: 4, count: 4 }
    ]
  });
  const [floorplanUrl, setFloorplanUrl] = useState('');

  const handleRunMassing = async () => {
    if (!scenario?.assumptions?.area_sqm) {
      alert('Please set area assumptions first');
      return;
    }

    setLoading(true);
    try {
      const response = await massingSolve({
        floorplan_url: floorplanUrl,
        bbox: { x: 0, y: 0, width: 800, height: 600 }, // Default bbox
        scale_m_per_px: Math.sqrt(scenario.assumptions.area_sqm) / 800, // Rough estimate
        requirements: requirements
      });

      if (response.data?.ok) {
        onMassingResult(response.data);
      } else {
        throw new Error(response.data?.error || 'Massing solve failed');
      }
    } catch (error) {
      console.error('Massing error:', error);
      alert(`Massing failed: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const addRoom = () => {
    setRequirements(prev => ({
      ...prev,
      rooms: [...prev.rooms, { type: 'New Room', area_m2: 15, count: 1 }]
    }));
  };

  const updateRoom = (index, field, value) => {
    setRequirements(prev => ({
      ...prev,
      rooms: prev.rooms.map((room, i) => 
        i === index ? { ...room, [field]: value } : room
      )
    }));
  };

  const removeRoom = (index) => {
    setRequirements(prev => ({
      ...prev,
      rooms: prev.rooms.filter((_, i) => i !== index)
    }));
  };

  const totalRequiredArea = () => {
    const workstationArea = requirements.workstations * 6; // 6 m² per workstation
    const roomArea = requirements.rooms.reduce((sum, room) => 
      sum + (room.area_m2 * room.count), 0
    );
    const supportArea = (workstationArea + roomArea) * 0.3; // 30% for circulation/support
    return workstationArea + roomArea + supportArea;
  };

  const efficiencyRatio = () => {
    if (!scenario?.assumptions?.area_sqm) return 0;
    return (totalRequiredArea() / scenario.assumptions.area_sqm * 100);
  };

  return (
    <Card className="orbit-card">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Layout className="w-5 h-5" />
          Space Programming & Massing
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Floorplan Upload */}
        <div className="space-y-2">
          <Label className="text-gray-300">Floorplan URL (optional)</Label>
          <Input
            value={floorplanUrl}
            onChange={(e) => setFloorplanUrl(e.target.value)}
            placeholder="https://example.com/floorplan.png"
            className="orbit-input"
          />
        </div>

        {/* Workstations */}
        <div className="space-y-2">
          <Label className="text-gray-300">Workstations Required</Label>
          <Input
            type="number"
            value={requirements.workstations}
            onChange={(e) => setRequirements(prev => ({ 
              ...prev, 
              workstations: parseInt(e.target.value) || 0 
            }))}
            className="orbit-input"
          />
        </div>

        {/* Rooms */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-gray-300">Rooms & Spaces</Label>
            <Button
              size="sm"
              onClick={addRoom}
              className="h-8 px-3"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add Room
            </Button>
          </div>

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {requirements.rooms.map((room, index) => (
              <div key={index} className="flex gap-2 items-center p-2 bg-gray-800/50 rounded">
                <Input
                  value={room.type}
                  onChange={(e) => updateRoom(index, 'type', e.target.value)}
                  placeholder="Room type"
                  className="flex-1 h-8 text-sm"
                />
                <Input
                  type="number"
                  value={room.area_m2}
                  onChange={(e) => updateRoom(index, 'area_m2', parseFloat(e.target.value) || 0)}
                  placeholder="m²"
                  className="w-16 h-8 text-sm"
                />
                <span className="text-xs text-gray-400">×</span>
                <Input
                  type="number"
                  value={room.count}
                  onChange={(e) => updateRoom(index, 'count', parseInt(e.target.value) || 1)}
                  placeholder="qty"
                  className="w-12 h-8 text-sm"
                />
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => removeRoom(index)}
                  className="h-8 w-8 p-0"
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Summary */}
        <div className="border-t border-gray-700 pt-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Total Required Area:</span>
            <span className="text-white font-medium">{Math.round(totalRequiredArea())} m²</span>
          </div>
          {scenario?.assumptions?.area_sqm && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Available Area:</span>
              <span className="text-white font-medium">{scenario.assumptions.area_sqm} m²</span>
            </div>
          )}
          <div className="flex justify-between items-center">
            <span className="text-gray-400 text-sm">Efficiency Ratio:</span>
            <Badge 
              variant={efficiencyRatio() > 100 ? "destructive" : efficiencyRatio() > 85 ? "default" : "secondary"}
              className="text-xs"
            >
              {efficiencyRatio().toFixed(1)}%
            </Badge>
          </div>
        </div>

        {/* Run Massing Button */}
        <Button
          onClick={handleRunMassing}
          disabled={loading || !scenario?.assumptions?.area_sqm}
          className="w-full"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Running Massing...
            </>
          ) : (
            <>
              <Layout className="w-4 h-4 mr-2" />
              Generate Space Layout
            </>
          )}
        </Button>

        {/* Massing Results Summary */}
        {scenario.massing_result && (
          <div className="border-t border-gray-700 pt-4">
            <div className="text-sm text-gray-400 mb-2">Last Massing Result</div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-400">Rooms Placed:</span>
                <span className="text-white ml-2">
                  {scenario.massing_result.layout?.rooms?.length || 0}
                </span>
              </div>
              <div>
                <span className="text-gray-400">Total Area:</span>
                <span className="text-white ml-2">
                  {scenario.massing_result.totals?.area_m2 || 0} m²
                </span>
              </div>
            </div>
            {scenario.massing_result.warnings?.length > 0 && (
              <div className="mt-2">
                <div className="text-xs text-gray-500">
                  {scenario.massing_result.warnings[0]}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}