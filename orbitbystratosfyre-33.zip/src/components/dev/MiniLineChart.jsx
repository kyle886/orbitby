import React from "react";

export default function MiniLineChart({ points = [], height = 200, padding = 28, yLabel = "NPC/m²", xLabel = "Term (yrs)" }) {
  if (!points.length) return null;
  const width = 600; // viewBox width; scales to container
  const minX = Math.min(...points.map(p=>p.x));
  const maxX = Math.max(...points.map(p=>p.x));
  const minY = Math.min(...points.map(p=>p.y));
  const maxY = Math.max(...points.map(p=>p.y));
  const mapX = x => padding + ( (x - minX) / (maxX - minX || 1) ) * (width - 2*padding);
  const mapY = y => (height - padding) - ( (y - minY) / (maxY - minY || 1) ) * (height - 2*padding);
  const path = points.map((p,i)=> `${i?'L':'M'}${mapX(p.x)},${mapY(p.y)}`).join(' ');
  const yTicks = 4;
  const grid = Array.from({length: yTicks+1}, (_,i)=> minY + i*(maxY-minY)/yTicks);

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-[220px] rounded-lg border border-gray-800 bg-gray-900/40">
      {/* Axes */}
      <line x1={padding} y1={height-padding} x2={width-padding} y2={height-padding} stroke="#374151" strokeWidth="1"/>
      <line x1={padding} y1={padding} x2={padding} y2={height-padding} stroke="#374151" strokeWidth="1"/>
      {/* Grid + labels */}
      {grid.map((v,i)=>(
        <g key={i}>
          <line x1={padding} y1={mapY(v)} x2={width-padding} y2={mapY(v)} stroke="#1f2937" strokeWidth="1" />
          <text x="6" y={mapY(v)+4} fill="#9CA3AF" fontSize="10">A${fmt(v)}</text>
        </g>
      ))}
      <text x={width/2} y={height-6} fill="#9CA3AF" fontSize="10" textAnchor="middle">{xLabel}</text>
      <text x="14" y={padding-10} fill="#9CA3AF" fontSize="10">{yLabel}</text>
      {/* Line */}
      <path d={path} fill="none" stroke="#60A5FA" strokeWidth="2" />
      {points.map((p,i)=>(
        <circle key={i} cx={mapX(p.x)} cy={mapY(p.y)} r="2.5" fill="#93C5FD" />
      ))}
    </svg>
  );
}

function fmt(n){ try{ return Number(n||0).toLocaleString('en-AU',{maximumFractionDigits:0}); }catch{ return String(n||0);} }