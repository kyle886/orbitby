
import React, { useMemo } from "react";
import { evalLease, evalBuy, evalDevelop } from "@/components/utils/dev/feasibilityEngine";
import { Button } from "@/components/ui/button";
import { downloadCsv } from "@/components/utils/csv/downloadCsv";

export default function SensitivityTab({ lease, buy, develop }) {
  const csvData = useMemo(() => {
    let out = [];
    if (lease) {
      out = out.concat(
        sensRows('Lease', lease, 'base_rent_psm', 'Base rent', evalLease),
        sensRows('Lease', lease, 'opex_psm', 'Opex', evalLease),
        sensRows('Lease', lease, 'fitout_capex_aud', 'Fitout capex', evalLease, 'npc')
      );
    }
    if (buy) {
      out = out.concat(
        sensRows('Buy', buy, 'price_aud', 'Purchase price', evalBuy),
        sensRows('Buy', buy, 'exit_cap_rate_pct', 'Exit cap rate', evalBuy),
        sensRows('Buy', buy, 'opex_psm', 'Opex', evalBuy)
      );
    }
    if (develop) {
      out = out.concat(
        sensRows('Develop', develop, 'hard_cost_aud', 'Hard cost', evalDevelop),
        sensRows('Develop', develop, 'exit_yield_pct', 'Exit yield', evalDevelop),
        sensRows('Develop', develop, 'finance_rate_pct', 'Finance rate', evalDevelop, 'npc')
      );
    }
    return out;
  }, [lease, buy, develop]);
  const dlAll = () => downloadCsv(csvData, `sensitivities_${Date.now()}.csv`);
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="text-sm font-medium">Sensitivity (±10%)</div>
        <Button variant="outline" size="sm" onClick={dlAll} disabled={!csvData.length}>Download CSV</Button>
      </div>
      {lease && <Block title="Lease Sensitivities">{leaseTables(lease)}</Block>}
      {buy && <Block title="Buy Sensitivities">{buyTables(buy)}</Block>}
      {develop && <Block title="Develop Sensitivities">{developTables(develop)}</Block>}
    </div>
  );
}

function Block({title, children}) {
  return (
    <div className="rounded-xl border border-gray-800 p-3 bg-gray-900/50">
      <div className="text-sm font-medium mb-2">{title}</div>
      {children}
    </div>
  );
}

function leaseTables(base) {
  return (
    <div className="grid md:grid-cols-3 gap-3">
      <SensTable base={base} label="Base rent (±10%)" param="base_rent_psm" evalFn={evalLease} />
      <SensTable base={base} label="Opex (±10%)"      param="opex_psm"       evalFn={evalLease} />
      <SensTable base={base} label="Fitout capex (±10%)" param="fitout_capex_aud" evalFn={evalLease} metric="npc" />
    </div>
  );
}
function buyTables(base) {
  return (
    <div className="grid md:grid-cols-3 gap-3">
      <SensTable base={base} label="Purchase price (±10%)" param="price_aud" evalFn={evalBuy} />
      <SensTable base={base} label="Exit cap rate (±10%)"  param="exit_cap_rate_pct" evalFn={evalBuy} direction="inverse" />
      <SensTable base={base} label="Opex (±10%)"           param="opex_psm" evalFn={evalBuy} />
    </div>
  );
}
function developTables(base) {
  return (
    <div className="grid md:grid-cols-3 gap-3">
      <SensTable base={base} label="Hard cost (±10%)"    param="hard_cost_aud" evalFn={evalDevelop} />
      <SensTable base={base} label="Exit yield (±10%)"   param="exit_yield_pct" evalFn={evalDevelop} direction="inverse" />
      <SensTable base={base} label="Finance rate (±10%)" param="finance_rate_pct" evalFn={evalDevelop} metric="npc" />
    </div>
  );
}

function SensTable({ base, param, label, evalFn, direction = "normal", metric = "npc_per_m2" }) {
  const vals = useMemo(()=>{
    const b = toNum(base[param]);
    const deltas = [-0.1, -0.05, 0, 0.05, 0.1];
    return deltas.map(d => {
      const test = { ...base, [param]: b==null ? null : b*(1+d) };
      const res = evalFn(test);
      return { d, value: pickMetric(res, metric) };
    });
  }, [base, param, evalFn, metric]);
  const best = vals.reduce((m,v)=> (m==null || v.value < m.value ? v : m), null);
  return (
    <div className="rounded-lg border border-gray-800 p-2 bg-gray-900/40">
      <div className="text-xs text-gray-400 mb-2">{label}</div>
      <div className="grid grid-cols-5 text-center text-xs">
        {vals.map(v => (
          <div key={v.d} className={`p-2 ${best===v ? 'bg-emerald-900/30 border border-emerald-700 rounded' : ''}`}>
            <div className="text-gray-400">{pct(v.d)}</div>
            <div className="font-medium">A${fmt(v.value)}</div>
          </div>
        ))}
      </div>
      <div className="text-[11px] text-gray-500 mt-1">
        Metric: {metric.replace('_',' ')} {direction==='inverse' ? '(inverse sensitivity)' : ''}
      </div>
    </div>
  );
}

function pickMetric(res, metric) {
  if (!res) return 0;
  if (metric === "npc") return res.npc ?? 0;
  if (metric === "irr_pct") return -(res.irr_pct ?? 0); // invert so lower is better in table
  return res.npc_per_m2 ?? 0;
}
const toNum = v => (v==null ? null : Number(v));
const pct = d => (d===0 ? "0%" : `${(d*100>0?'+':'')}${(d*100).toFixed(0)}%`);
function fmt(n){ try{ return Number(n||0).toLocaleString('en-AU',{maximumFractionDigits:0}); }catch{ return String(n||0);} }

// Build flattened rows for CSV export (±10% steps)
function sensRows(scenario, base, param, label, evalFn, metric = "npc_per_m2") {
  const b = toNum(base[param]);
  const deltas = [-0.1, -0.05, 0, 0.05, 0.1];
  return deltas.map(d => {
    const test = { ...base, [param]: b==null ? null : b*(1+d) };
    const res = evalFn(test);
    return {
      scenario,
      parameter: label,
      delta_pct: Math.round(d*100),
      metric,
      value: metric==="npc" ? (res?.npc ?? 0) : (res?.npc_per_m2 ?? 0)
    };
  });
}
