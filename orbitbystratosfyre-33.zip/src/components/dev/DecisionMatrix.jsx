import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus, DollarSign, Clock, BarChart3 } from 'lucide-react';

export default function DecisionMatrix({ scenarios }) {
  if (!scenarios || scenarios.length === 0) {
    return (
      <Card className="surface">
        <CardHeader>
          <CardTitle className="text-white">Decision Matrix</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <BarChart3 className="w-12 h-12 mx-auto mb-4 text-gray-500" />
            <p className="text-gray-400">Add scenarios to see comparison matrix</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const bestNPV = Math.max(...scenarios.map(s => s.npv_aud || 0));
  const bestIRR = Math.max(...scenarios.map(s => s.irr_pct || 0));
  const bestPayback = Math.min(...scenarios.filter(s => s.payback_years > 0).map(s => s.payback_years || Infinity));

  const getPerformanceIndicator = (value, best, isLower = false) => {
    if (value === best) {
      return <TrendingUp className="w-4 h-4 text-green-400" />;
    }
    if (isLower ? value > best * 1.2 : value < best * 0.8) {
      return <TrendingDown className="w-4 h-4 text-red-400" />;
    }
    return <Minus className="w-4 h-4 text-yellow-400" />;
  };

  return (
    <Card className="surface">
      <CardHeader>
        <CardTitle className="text-white">Decision Matrix</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-3 px-4 text-gray-300">Scenario</th>
                <th className="text-right py-3 px-4 text-gray-300">Type</th>
                <th className="text-right py-3 px-4 text-gray-300">NPV</th>
                <th className="text-right py-3 px-4 text-gray-300">IRR</th>
                <th className="text-right py-3 px-4 text-gray-300">Payback</th>
                <th className="text-center py-3 px-4 text-gray-300">Score</th>
              </tr>
            </thead>
            <tbody>
              {scenarios.map(scenario => {
                const npvScore = scenario.npv_aud === bestNPV ? 3 : scenario.npv_aud > bestNPV * 0.8 ? 2 : 1;
                const irrScore = scenario.irr_pct === bestIRR ? 3 : scenario.irr_pct > bestIRR * 0.8 ? 2 : 1;
                const paybackScore = scenario.payback_years === bestPayback ? 3 : scenario.payback_years < bestPayback * 1.2 ? 2 : 1;
                const totalScore = npvScore + irrScore + paybackScore;

                return (
                  <tr key={scenario.id} className="border-b border-white/5 hover:bg-white/5">
                    <td className="py-3 px-4">
                      <div className="font-medium text-white">{scenario.name}</div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <Badge variant="outline" className="text-xs">
                        {scenario.type}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <span className="text-white font-mono">
                          ${scenario.npv_aud ? (scenario.npv_aud / 1000000).toFixed(1) : '0'}M
                        </span>
                        {getPerformanceIndicator(scenario.npv_aud || 0, bestNPV)}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <span className="text-white font-mono">
                          {scenario.irr_pct?.toFixed(1) || 'N/A'}%
                        </span>
                        {scenario.irr_pct && getPerformanceIndicator(scenario.irr_pct, bestIRR)}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <span className="text-white font-mono">
                          {scenario.payback_years?.toFixed(1) || 'N/A'}y
                        </span>
                        {scenario.payback_years && getPerformanceIndicator(scenario.payback_years, bestPayback, true)}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                          totalScore >= 8 ? 'bg-green-500/20 text-green-300' :
                          totalScore >= 6 ? 'bg-yellow-500/20 text-yellow-300' :
                          'bg-red-500/20 text-red-300'
                        }`}>
                          {totalScore}
                        </div>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-6 p-4 rounded-lg bg-white/5">
          <h4 className="font-medium text-white mb-2">Scoring Legend</h4>
          <div className="grid md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span className="text-gray-300">Best performer</span>
            </div>
            <div className="flex items-center gap-2">
              <Minus className="w-4 h-4 text-yellow-400" />
              <span className="text-gray-300">Good performer</span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-red-400" />
              <span className="text-gray-300">Underperformer</span>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-2">
            Total score combines NPV, IRR, and Payback performance. Higher scores indicate better financial outcomes.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}