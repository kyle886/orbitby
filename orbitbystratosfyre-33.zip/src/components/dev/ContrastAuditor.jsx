
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle, Eye } from 'lucide-react';

// WCAG contrast ratio calculation
function getLuminance(r, g, b) {
  const [rs, gs, bs] = [r, g, b].map(c => {
    c = c / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

function getContrastRatio(color1, color2) {
  const l1 = getLuminance(...color1);
  const l2 = getLuminance(...color2);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

function rgbFromString(color) {
  if (color.startsWith('#')) {
    const hex = color.slice(1);
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    return [r, g, b];
  }
  // Handle rgb() format
  const match = color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
  if (match) {
    return [parseInt(match[1]), parseInt(match[2]), parseInt(match[3])];
  }
  // Default fallback
  return [0, 0, 0];
}

export default function ContrastAuditor() {
  const [issues, setIssues] = useState([]);
  const [scanning, setScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);

  const scanForContrastIssues = () => {
    setScanning(true);
    setScanComplete(false);
    const foundIssues = [];

    // Get all text elements
    const textElements = document.querySelectorAll('*');
    const checkedElements = new Set();

    textElements.forEach((el, index) => {
      // Skip if already checked or if it's this auditor component
      if (checkedElements.has(el) || el.closest('[data-contrast-auditor]')) return;
      
      const computedStyle = window.getComputedStyle(el);
      const textContent = el.textContent?.trim();
      
      // Skip elements without visible text
      if (!textContent || textContent.length === 0) return;
      
      const color = computedStyle.color;
      const backgroundColor = computedStyle.backgroundColor;
      const fontSize = parseFloat(computedStyle.fontSize);
      const fontWeight = computedStyle.fontWeight;
      
      // Skip transparent backgrounds - check parent chain
      let bgColor = backgroundColor;
      let parent = el.parentElement;
      while ((!bgColor || bgColor === 'rgba(0, 0, 0, 0)' || bgColor === 'transparent') && parent) {
        const parentStyle = window.getComputedStyle(parent);
        bgColor = parentStyle.backgroundColor;
        parent = parent.parentElement;
      }
      
      // Default to dark background if we can't find one
      if (!bgColor || bgColor === 'rgba(0, 0, 0, 0)' || bgColor === 'transparent') {
        bgColor = '#0f172a'; // Default dark background
      }

      try {
        const textRGB = rgbFromString(color);
        const bgRGB = rgbFromString(bgColor);
        const contrastRatio = getContrastRatio(textRGB, bgRGB);
        
        // WCAG guidelines
        const isLargeText = fontSize >= 18 || (fontSize >= 14 && (fontWeight === 'bold' || parseInt(fontWeight) >= 700));
        const requiredRatio = isLargeText ? 3.0 : 4.5; // AA standard
        const aaaRequiredRatio = isLargeText ? 4.5 : 7.0; // AAA standard
        
        if (contrastRatio < requiredRatio) {
          foundIssues.push({
            id: `issue-${index}`,
            element: el.tagName.toLowerCase() + (el.className ? `.${el.className.split(' ')[0]}` : ''),
            textColor: color,
            backgroundColor: bgColor,
            contrastRatio: contrastRatio.toFixed(2),
            requiredRatio: requiredRatio.toFixed(1),
            aaaRatio: aaaRequiredRatio.toFixed(1),
            isLargeText,
            severity: contrastRatio < 2 ? 'critical' : contrastRatio < requiredRatio ? 'high' : 'medium',
            textSample: textContent.substring(0, 50) + (textContent.length > 50 ? '...' : ''),
            suggestion: getSuggestion(textRGB, bgRGB, requiredRatio)
          });
        }
        
        checkedElements.add(el);
      } catch (error) {
        // Skip elements we can't process
        console.warn('Could not process element for contrast:', error);
      }
    });

    setIssues(foundIssues);
    setScanning(false);
    setScanComplete(true);
  };

  const getSuggestion = (textRGB, bgRGB, targetRatio) => {
    const currentRatio = getContrastRatio(textRGB, bgRGB);
    if (currentRatio >= targetRatio) return 'No changes needed';
    
    // Simple suggestion: darken light text or lighten dark text
    const textLuminance = getLuminance(...textRGB);
    
    if (textLuminance > 0.5) {
      return 'Consider using darker text color';
    } else {
      return 'Consider using lighter text color or darker background';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div data-contrast-auditor className="max-w-6xl mx-auto p-6">
      <Card className="orbit-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-white">
                <Eye className="w-5 h-5" />
                Contrast Auditor
              </CardTitle>
              <p className="text-gray-400 mt-2">
                Scan the current page for WCAG AA contrast compliance issues
              </p>
            </div>
            <Button 
              onClick={scanForContrastIssues} 
              disabled={scanning}
              className="orbit-button bg-orange-600 hover:bg-orange-700"
            >
              {scanning ? 'Scanning...' : 'Scan Page'}
            </Button>
          </div>
        </CardHeader>
        
        {scanComplete && (
          <CardContent>
            <div className="mb-4">
              <div className="flex items-center gap-4">
                <Badge className={issues.length === 0 ? 'bg-green-600' : 'bg-orange-600'}>
                  {issues.length === 0 ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-1" />
                      No Issues Found
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-4 h-4 mr-1" />
                      {issues.length} Issues Found
                    </>
                  )}
                </Badge>
                
                {issues.length > 0 && (
                  <div className="flex gap-2">
                    <Badge className="bg-red-500">
                      Critical: {issues.filter(i => i.severity === 'critical').length}
                    </Badge>
                    <Badge className="bg-orange-500">
                      High: {issues.filter(i => i.severity === 'high').length}
                    </Badge>
                    <Badge className="bg-yellow-500">
                      Medium: {issues.filter(i => i.severity === 'medium').length}
                    </Badge>
                  </div>
                )}
              </div>
            </div>

            {issues.length > 0 && (
              <div className="space-y-3">
                {issues.map((issue) => (
                  <div key={issue.id} className="p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <Badge className={getSeverityColor(issue.severity)}>
                            {issue.severity}
                          </Badge>
                          <code className="text-sm text-gray-300 bg-gray-900 px-2 py-1 rounded">
                            {issue.element}
                          </code>
                        </div>
                        <p className="text-gray-400 text-sm mt-1">"{issue.textSample}"</p>
                      </div>
                      <div className="text-right text-sm">
                        <div className="text-white">
                          Ratio: {issue.contrastRatio}:1
                        </div>
                        <div className="text-gray-400">
                          Required: {issue.requiredRatio}:1
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400 text-sm">Text:</span>
                        <div 
                          className="w-4 h-4 rounded border border-gray-600"
                          style={{ backgroundColor: issue.textColor }}
                        />
                        <code className="text-xs text-gray-300">{issue.textColor}</code>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400 text-sm">Background:</span>
                        <div 
                          className="w-4 h-4 rounded border border-gray-600"
                          style={{ backgroundColor: issue.backgroundColor }}
                        />
                        <code className="text-xs text-gray-300">{issue.backgroundColor}</code>
                      </div>
                    </div>
                    
                    <div className="text-sm text-orange-300">
                      💡 {issue.suggestion}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        )}
      </Card>
    </div>
  );
}
