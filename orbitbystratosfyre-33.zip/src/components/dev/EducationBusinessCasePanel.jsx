import React, { useMemo, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ResponsiveContainer, LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';
import { computeEducationBusinessCase } from '@/components/utils/dev/educationBusinessCase';

const fmt = (n) => n.toLocaleString(undefined, { style: 'currency', currency: 'AUD', maximumFractionDigits: 0 });

export default function EducationBusinessCasePanel() {
  const [enabled, setEnabled] = useState(true);
  const [i, setI] = useState({
    sector: 'K12', termYears: 10, maxEnrolment: 1200, rampUpYears: 4,
    tuition: { averagePerStudent: 14000, distribution: undefined, university: { onlinePct: 25, onlineTuition: 9000, onCampusTuition: 15000 } },
    extraIncomePerYear: 80000,
    rent: { basePerAnnum: 1800000, escalationPct: 3, leaseType: 'net' },
    capex: { who: 'tenant', amount: 2000000, amortYears: 8 },
    thresholdRentPct: 20
  });

  const out = useMemo(() => computeEducationBusinessCase(i), [i]);

  if (!enabled) {
    return (
      <Card className="p-4 bg-black/40 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <div className="text-sm text-neutral-300">Education Test Business Case</div>
          <Switch checked={enabled} onCheckedChange={setEnabled} />
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-4 bg-black/40 backdrop-blur-xl space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-sm text-neutral-300">Education Test Business Case</div>
        <Switch checked={enabled} onCheckedChange={setEnabled} />
      </div>

      <div className="grid md:grid-cols-4 gap-2">
        <Field l="Sector">
          <select className="bg-neutral-900/60 border-neutral-800 rounded-md px-2 py-1 text-sm w-full h-10" value={i.sector} onChange={e => setI({ ...i, sector: e.target.value })}>
            <option value="K12">K-12</option>
            <option value="Primary">Primary</option>
            <option value="Secondary">Secondary</option>
            <option value="University">University</option>
          </select>
        </Field>
        <Field l="Term (years)"><Num v={i.termYears} s={(v) => setI({ ...i, termYears: v })} /></Field>
        <Field l="Max enrolment"><Num v={i.maxEnrolment} s={(v) => setI({ ...i, maxEnrolment: v })} /></Field>
        <Field l="Ramp-up (years)"><Num v={i.rampUpYears} s={(v) => setI({ ...i, rampUpYears: v })} /></Field>

        <Field l="Avg tuition ($/student)"><Num v={i.tuition.averagePerStudent || 0} s={(v) => setI({ ...i, tuition: { ...i.tuition, averagePerStudent: v } })} /></Field>
        {i.sector === 'University' && (
          <>
            <Field l="Online %"><Num v={i.tuition.university.onlinePct} s={(v) => setI({ ...i, tuition: { ...i.tuition, university: { ...i.tuition.university, onlinePct: v } } })} /></Field>
            <Field l="Online tuition ($)"><Num v={i.tuition.university.onlineTuition} s={(v) => setI({ ...i, tuition: { ...i.tuition, university: { ...i.tuition.university, onlineTuition: v } } })} /></Field>
            <Field l="On-campus tuition ($)"><Num v={i.tuition.university.onCampusTuition} s={(v) => setI({ ...i, tuition: { ...i.tuition, university: { ...i.tuition.university, onCampusTuition: v } } })} /></Field>
          </>
        )}

        <Field l="Extra income ($/yr)"><Num v={i.extraIncomePerYear || 0} s={(v) => setI({ ...i, extraIncomePerYear: v })} /></Field>
        <Field l="Base rent ($/yr)"><Num v={i.rent.basePerAnnum} s={(v) => setI({ ...i, rent: { ...i.rent, basePerAnnum: v } })} /></Field>
        <Field l="Escalation (%/yr)"><Num v={i.rent.escalationPct} s={(v) => setI({ ...i, rent: { ...i.rent, escalationPct: v } })} /></Field>
        <Field l="Lease type">
          <select className="bg-neutral-900/60 border-neutral-800 rounded-md px-2 py-1 text-sm w-full h-10" value={i.rent.leaseType} onChange={e => setI({ ...i, rent: { ...i.rent, leaseType: e.target.value } })}>
            <option value="gross">Gross</option>
            <option value="net">Net</option>
          </select>
        </Field>

        <Field l="Capex who">
          <select className="bg-neutral-900/60 border-neutral-800 rounded-md px-2 py-1 text-sm w-full h-10" value={i.capex.who} onChange={e => setI({ ...i, capex: { ...i.capex, who: e.target.value } })}>
            <option value="tenant">Tenant</option>
            <option value="landlord">Landlord</option>
          </select>
        </Field>
        <Field l="Capex amount ($)"><Num v={i.capex.amount} s={(v) => setI({ ...i, capex: { ...i.capex, amount: v } })} /></Field>
        <Field l="Capex amort (yrs)"><Num v={i.capex.amortYears || 5} s={(v) => setI({ ...i, capex: { ...i.capex, amortYears: v } })} /></Field>
        <Field l="Threshold rent %"><Num v={i.thresholdRentPct || 20} s={(v) => setI({ ...i, thresholdRentPct: v })} /></Field>
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        <Card className="p-3 bg-neutral-900/50">
          <div className="text-xs text-neutral-400 mb-1">Rent % of revenue — yearly</div>
          <div className={`${out.summary.pass ? 'text-green-400' : 'text-rose-400'} text-sm mb-2`}>
            Avg {out.summary.avgRentPct.toFixed(1)}% • Max {out.summary.maxRentPct.toFixed(1)}% • Threshold {i.thresholdRentPct}%
          </div>
          <ResponsiveContainer height={220}>
            <LineChart data={out.years.map((y, idx) => ({ y, pct: out.rentPctOfRevenue[idx] }))}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="y" stroke="#9ca3af" />
              <YAxis domain={[0, Math.max(30, Math.ceil(Math.max(...out.rentPctOfRevenue) + 5))]} stroke="#9ca3af" />
              <Tooltip formatter={(v) => `${v.toFixed(1)}%`} labelFormatter={(l) => `Year ${l}`} contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.2)' }} />
              <Line type="monotone" dataKey="pct" stroke="#8884d8" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
        <Card className="p-3 bg-neutral-900/50">
          <div className="text-xs text-neutral-400 mb-1">Revenue & Rent</div>
          <ResponsiveContainer height={220}>
            <LineChart data={out.years.map((y, idx) => ({ y, rev: out.revenue[idx], rent: out.rent[idx] }))}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="y" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" tickFormatter={(tick) => fmt(tick)} />
              <Tooltip formatter={(v) => fmt(v)} labelFormatter={(l) => `Year ${l}`} contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.2)' }} />
              <Line type="monotone" dataKey="rev" stroke="#82ca9d" name="Revenue" dot={false} />
              <Line type="monotone" dataKey="rent" stroke="#ffc658" name="Rent" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </Card>
  );
}

function Field({ l, children }) {
  return <div className="space-y-1"><Label className="text-xs text-neutral-300">{l}</Label>{children}</div>;
}
function Num({ v, s }) {
  return <Input type="number" className="bg-neutral-900/60 border-neutral-800" value={isNaN(v) ? '' : v} onChange={e => s(Number(e.target.value || 0))} />;
}