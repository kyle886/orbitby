import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { evalLease, evalBuy, evalDevelop, decisionMatrix } from '@/components/utils/dev/feasibilityEngine';
import { TrendingUp, TrendingDown, DollarSign, Calculator, Target, PieChart } from 'lucide-react';

export default function FeasibilityOutputs({ scenario }) {
  const results = useMemo(() => {
    if (!scenario?.assumptions) return null;
    
    const assumptions = scenario.assumptions;
    
    // Evaluate based on scenario type or evaluate all options
    const lease = evalLease({
      area_m2: assumptions.area_sqm || 0,
      term_years: assumptions.lease_term_years || 10,
      base_rent_psm: assumptions.rent_per_sqm_pa || 0,
      opex_psm: assumptions.opex_per_sqm_pa || 0,
      fitout_capex_aud: assumptions.construction_cost_per_sqm ? 
        (assumptions.construction_cost_per_sqm * assumptions.area_sqm) : 0,
      discount_rate_pct: assumptions.discount_rate_pct || 7.5
    });

    const buy = evalBuy({
      area_m2: assumptions.area_sqm || 0,
      price_aud: assumptions.land_cost || 0,
      opex_psm: assumptions.opex_per_sqm_pa || 0,
      exit_year: 10,
      exit_cap_rate_pct: assumptions.exit_cap_rate_pct || 5,
      discount_rate_pct: assumptions.discount_rate_pct || 7.5
    });

    const develop = evalDevelop({
      area_m2: assumptions.area_sqm || 0,
      land_cost_aud: assumptions.land_cost || 0,
      hard_cost_aud: assumptions.construction_cost_per_sqm ? 
        (assumptions.construction_cost_per_sqm * assumptions.area_sqm) : 0,
      leaseback_rent_psm: assumptions.rent_per_sqm_pa || 0,
      exit_yield_pct: assumptions.exit_cap_rate_pct || 5.75,
      discount_rate_pct: assumptions.discount_rate_pct || 7.5
    });

    const matrix = decisionMatrix({ lease, buy, develop });
    
    return { lease, buy, develop, matrix };
  }, [scenario?.assumptions]);

  if (!results) {
    return (
      <Card className="orbit-card">
        <CardContent className="p-6">
          <div className="text-center text-gray-400">
            <Calculator className="w-12 h-12 mx-auto mb-4" />
            <p>Configure scenario assumptions to see feasibility outputs</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatCurrency = (value) => {
    if (Math.abs(value) >= 1000000) {
      return `$${(value / 1000000).toFixed(1)}M`;
    }
    if (Math.abs(value) >= 1000) {
      return `$${(value / 1000).toFixed(0)}K`;
    }
    return `$${Math.round(value).toLocaleString()}`;
  };

  const formatNumber = (value, suffix = '') => {
    return `${Math.round(value).toLocaleString()}${suffix}`;
  };

  return (
    <div className="space-y-6">
      {/* Decision Matrix */}
      <Card className="orbit-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Target className="w-5 h-5" />
            Decision Matrix
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {results.matrix.rows.map((row) => (
              <div 
                key={row.mode}
                className={`flex items-center justify-between p-4 rounded-lg border ${
                  row.mode === results.matrix.bestMode 
                    ? 'border-green-500 bg-green-500/10' 
                    : 'border-gray-600 bg-gray-800/50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-white">{row.mode}</span>
                  {row.mode === results.matrix.bestMode && (
                    <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                      Recommended
                    </Badge>
                  )}
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-300">Net Present Cost</div>
                  <div className="font-bold text-white">{formatCurrency(row.npc)}</div>
                  <div className="text-xs text-gray-400">{formatCurrency(row.npc_per_m2)}/m²</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Detailed Results */}
      <div className="grid md:grid-cols-3 gap-4">
        {/* Lease Results */}
        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-gray-300">Lease Option</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-400">Net Present Cost</span>
              <span className="text-white font-semibold">{formatCurrency(results.lease.npc)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Cost per m²</span>
              <span className="text-white">{formatCurrency(results.lease.npc_per_m2)}/m²</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">NPV</span>
              <span className={`${results.lease.npv >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {formatCurrency(results.lease.npv)}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Buy Results */}
        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-gray-300">Buy Option</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-400">Net Present Cost</span>
              <span className="text-white font-semibold">{formatCurrency(results.buy.npc)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Cost per m²</span>
              <span className="text-white">{formatCurrency(results.buy.npc_per_m2)}/m²</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">IRR</span>
              <span className={`${results.buy.irr_pct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {results.buy.irr_pct.toFixed(1)}%
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Develop Results */}
        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-gray-300">Develop Option</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-400">Total Cost</span>
              <span className="text-white font-semibold">{formatCurrency(results.develop.total_cost_aud)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Profit on Cost</span>
              <span className={`${results.develop.profit_on_cost_pct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {results.develop.profit_on_cost_pct.toFixed(1)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">IRR</span>
              <span className={`${results.develop.irr_pct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {results.develop.irr_pct.toFixed(1)}%
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Massing Results */}
      {scenario.massing_result && (
        <Card className="orbit-card">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <PieChart className="w-5 h-5" />
              Massing Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <div className="text-sm text-gray-400 mb-2">Total Area</div>
                <div className="text-xl font-bold text-white">
                  {formatNumber(scenario.massing_result.totals?.area_m2 || 0)} m²
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-400 mb-2">Rooms Allocated</div>
                <div className="text-xl font-bold text-white">
                  {scenario.massing_result.layout?.rooms?.length || 0}
                </div>
              </div>
              {scenario.massing_result.warnings && scenario.massing_result.warnings.length > 0 && (
                <div className="md:col-span-2">
                  <div className="text-sm text-gray-400 mb-2">Notes</div>
                  {scenario.massing_result.warnings.map((warning, idx) => (
                    <Badge key={idx} variant="outline" className="mr-2 mb-2 text-xs">
                      {warning}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}