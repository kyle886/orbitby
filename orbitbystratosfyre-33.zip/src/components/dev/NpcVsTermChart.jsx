import React, { useMemo } from "react";
import MiniLineChart from "./MiniLineChart";
import { evalLease } from "@/components/utils/dev/feasibilityEngine";
import { Button } from "@/components/ui/button";
import { downloadCsv } from "@/components/utils/csv/downloadCsv";

export default function NpcVsTermChart({ lease, termMin=3, termMax=15 }) {
  const points = useMemo(()=>{
    if (!lease) return [];
    const pts = [];
    for (let t = termMin; t <= termMax; t++) {
      const res = evalLease({ ...lease, term_years: t });
      pts.push({ x: t, y: res?.npc_per_m2 ?? 0 });
    }
    return pts;
  }, [lease, termMin, termMax]);
  const dl = () => {
    const rows = points.map(p => ({ term_years: p.x, npc_per_m2_aud: round(p.y) }));
    downloadCsv(rows, `npc_vs_term_${Date.now()}.csv`);
  };
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="text-sm font-medium">NPC per m² vs Term (Lease)</div>
        <Button variant="outline" size="sm" onClick={dl} disabled={!points.length}>Download CSV</Button>
      </div>
      <MiniLineChart points={points} yLabel="NPC/m² (A$)" xLabel="Term (years)" />
    </div>
  );
}
function round(n){ try{ return Math.round(Number(n||0)); }catch{ return n; } }