import React, { useState } from 'react';
import { Scenario } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calculator, X } from 'lucide-react';

export default function ScenarioForm({ devCaseId, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    type: 'Lease',
    name: '',
    inputs_json: {
      area_sqm: '',
      rent_per_sqm: '',
      lease_term_years: '',
      purchase_price: '',
      development_cost: '',
      yield_pct: '',
      discount_rate: 8,
      total_cost: ''
    }
  });

  const [calculating, setCalculating] = useState(false);

  const calculateFinancials = () => {
    const inputs = formData.inputs_json;
    const area = parseFloat(inputs.area_sqm) || 0;
    const rent = parseFloat(inputs.rent_per_sqm) || 0;
    const leaseTerm = parseFloat(inputs.lease_term_years) || 10;
    const purchasePrice = parseFloat(inputs.purchase_price) || 0;
    const devCost = parseFloat(inputs.development_cost) || 0;
    const yieldPct = parseFloat(inputs.yield_pct) || 6;
    const discountRate = parseFloat(inputs.discount_rate) || 8;

    let npv = 0;
    let totalCost = 0;
    let irr = 0;
    let payback = 0;

    if (formData.type === 'Lease') {
      const annualRent = area * rent;
      totalCost = annualRent * leaseTerm;
      
      // Simple NPV calculation for lease
      for (let year = 1; year <= leaseTerm; year++) {
        npv += -annualRent / Math.pow(1 + discountRate / 100, year);
      }
    } else if (formData.type === 'Buy') {
      totalCost = purchasePrice;
      const annualIncome = purchasePrice * (yieldPct / 100);
      
      // NPV calculation for purchase
      npv = -purchasePrice;
      for (let year = 1; year <= 20; year++) {
        npv += annualIncome / Math.pow(1 + discountRate / 100, year);
      }
      
      payback = purchasePrice / annualIncome;
      irr = yieldPct;
    } else if (formData.type === 'Develop') {
      totalCost = devCost;
      const annualIncome = totalCost * (yieldPct / 100);
      
      // NPV calculation for development
      npv = -totalCost;
      for (let year = 1; year <= 20; year++) {
        npv += annualIncome / Math.pow(1 + discountRate / 100, year);
      }
      
      payback = totalCost / annualIncome;
      irr = yieldPct;
    }

    return {
      npv_aud: Math.round(npv),
      irr_pct: irr,
      payback_years: payback,
      total_cost: totalCost
    };
  };

  const handleSave = async () => {
    setCalculating(true);
    try {
      const financials = calculateFinancials();
      const scenarioData = {
        devcase_id: devCaseId,
        type: formData.type,
        name: formData.name || `${formData.type} Scenario`,
        active: true,
        inputs_json: {
          ...formData.inputs_json,
          total_cost: financials.total_cost
        },
        outputs_json: financials,
        npv_aud: financials.npv_aud,
        irr_pct: financials.irr_pct,
        payback_years: financials.payback_years
      };

      const newScenario = await Scenario.create(scenarioData);
      onSave(newScenario);
    } catch (error) {
      console.error('Failed to save scenario:', error);
    } finally {
      setCalculating(false);
    }
  };

  const updateInput = (field, value) => {
    setFormData({
      ...formData,
      inputs_json: {
        ...formData.inputs_json,
        [field]: value
      }
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="surface w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-white flex items-center gap-2">
              <Calculator className="w-5 h-5" />
              New Financial Scenario
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onCancel}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-300">Scenario Type</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Lease">Lease</SelectItem>
                  <SelectItem value="Buy">Buy</SelectItem>
                  <SelectItem value="Develop">Develop</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-gray-300">Scenario Name</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder={`${formData.type} Scenario`}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-300">Area (sqm)</Label>
              <Input
                type="number"
                value={formData.inputs_json.area_sqm}
                onChange={(e) => updateInput('area_sqm', e.target.value)}
                placeholder="1000"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-300">Discount Rate (%)</Label>
              <Input
                type="number"
                value={formData.inputs_json.discount_rate}
                onChange={(e) => updateInput('discount_rate', e.target.value)}
                placeholder="8"
              />
            </div>
          </div>

          {formData.type === 'Lease' && (
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Rent per sqm (annual)</Label>
                <Input
                  type="number"
                  value={formData.inputs_json.rent_per_sqm}
                  onChange={(e) => updateInput('rent_per_sqm', e.target.value)}
                  placeholder="850"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300">Lease Term (years)</Label>
                <Input
                  type="number"
                  value={formData.inputs_json.lease_term_years}
                  onChange={(e) => updateInput('lease_term_years', e.target.value)}
                  placeholder="5"
                />
              </div>
            </div>
          )}

          {formData.type === 'Buy' && (
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Purchase Price</Label>
                <Input
                  type="number"
                  value={formData.inputs_json.purchase_price}
                  onChange={(e) => updateInput('purchase_price', e.target.value)}
                  placeholder="5000000"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300">Expected Yield (%)</Label>
                <Input
                  type="number"
                  value={formData.inputs_json.yield_pct}
                  onChange={(e) => updateInput('yield_pct', e.target.value)}
                  placeholder="6"
                />
              </div>
            </div>
          )}

          {formData.type === 'Develop' && (
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Development Cost</Label>
                <Input
                  type="number"
                  value={formData.inputs_json.development_cost}
                  onChange={(e) => updateInput('development_cost', e.target.value)}
                  placeholder="8000000"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300">Target Yield (%)</Label>
                <Input
                  type="number"
                  value={formData.inputs_json.yield_pct}
                  onChange={(e) => updateInput('yield_pct', e.target.value)}
                  placeholder="7"
                />
              </div>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={calculating}>
              {calculating ? 'Calculating...' : 'Create Scenario'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}