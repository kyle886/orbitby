import React, { useMemo, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import StackedBars from "@/components/charts/StackedBars";
import Heatmap from "@/components/charts/Heatmap";
import { buildPipelineSeries, buildSeasonality } from "@/components/utils/pipeline/buildSeries";
import { downloadCsv } from "@/components/utils/csv/downloadCsv";

const COLORS = ['#60a5fa', '#22c55e', '#f59e0b', '#a78bfa', '#ef4444', '#14b8a6', '#eab308'];

export default function PipelinePanel({ engaged = [], bd = [], currency = 'A$' }) {
  const [months, setMonths] = useState(12);
  const [view, setView] = useState('combined'); // combined | split
  const [mode, setMode] = useState('recognition'); // recognition | cash
  const [typesFilter, setTypesFilter] = useState('all'); // all | per-type

  const series = useMemo(() => {
    try {
      return buildPipelineSeries({ engaged, bd, months, mode });
    } catch (error) {
      console.error('Error building pipeline series:', error);
      return {
        labels: [],
        types: [],
        engaged: {},
        bd: {},
        engagedTotals: [],
        bdTotals: [],
        combinedTotals: []
      };
    }
  }, [engaged, bd, months, mode]);

  const palette = useMemo(() => {
    const p = {};
    series.types.forEach((t, i) => p[t] = COLORS[i % COLORS.length]);
    return p;
  }, [series.types]);

  const combinedData = useMemo(() => series.labels.map((k, i) => ({
    label: k,
    stacks: mergeStacks(series.engaged[k], series.bd[k], typesFilter === 'per-type'),
    total: series.combinedTotals[i]
  })), [series, typesFilter]);

  const engagedData = useMemo(() => series.labels.map((k, i) => ({
    label: k, stacks: series.engaged[k], total: series.engagedTotals[i]
  })), [series]);

  const bdData = useMemo(() => series.labels.map((k, i) => ({
    label: k, stacks: series.bd[k], total: series.bdTotals[i]
  })), [series]);

  const seasonality = useMemo(() => {
    try {
      return buildSeasonality(series);
    } catch (error) {
      console.error('Error building seasonality:', error);
      return Array.from({ length: 12 }, () => 0);
    }
  }, [series]);

  const exportCsv = () => {
    try {
      const rows = series.labels.map((k, i) => ({
        month: k,
        engaged_aud: Math.round(series.engagedTotals[i]),
        bd_weighted_aud: Math.round(series.bdTotals[i]),
        combined_aud: Math.round(series.combinedTotals[i])
      }));
      downloadCsv(rows, `pipeline_${months}m_${Date.now()}.csv`);
    } catch (error) {
      console.error('Failed to export CSV:', error);
    }
  };

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <CardTitle className="text-base text-white">Pipeline Value & Timing</CardTitle>
          <div className="flex flex-wrap items-center gap-2">
            <Select value={String(months)} onValueChange={(v) => setMonths(Number(v))}>
              <SelectTrigger className="w-[120px]"><SelectValue placeholder="Window" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="6">Next 6m</SelectItem>
                <SelectItem value="12">Next 12m</SelectItem>
                <SelectItem value="18">Next 18m</SelectItem>
              </SelectContent>
            </Select>
            <Select value={mode} onValueChange={setMode}>
              <SelectTrigger className="w-[140px]"><SelectValue placeholder="Mode" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="recognition">Revenue (recognition)</SelectItem>
                <SelectItem value="cash">Cash timing</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typesFilter} onValueChange={setTypesFilter}>
              <SelectTrigger className="w-[140px]"><SelectValue placeholder="Segments" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types (merged)</SelectItem>
                <SelectItem value="per-type">Per project type</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={exportCsv} className="bg-background text-slate-950 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md transition-colors ring-focus disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-input shadow-sm hover:bg-accent hover:text-accent-foreground h-10">Download CSV</Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {view === 'combined' ?
        <StackedBars data={combinedData} palette={palette} currency={currency} /> :

        <div className="grid md:grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-gray-400 mb-1">Engaged (live)</div>
              <StackedBars data={engagedData} palette={palette} currency={currency} />
            </div>
            <div>
              <div className="text-xs text-gray-400 mb-1">BD (probability-weighted)</div>
              <StackedBars data={bdData} palette={palette} currency={currency} />
            </div>
          </div>
        }

        {/* view toggle */}
        <div className="flex items-center gap-2">
          <Button size="sm" variant={view === 'combined' ? 'default' : 'outline'} onClick={() => setView('combined')}>Combined</Button>
          <Button size="sm" variant={view === 'split' ? 'default' : 'outline'} onClick={() => setView('split')}>Split</Button>
          <div className="text-xs text-gray-400 ml-auto">Currency: {currency}</div>
        </div>

        {/* legend */}
        {typesFilter === 'per-type' &&
        <div className="flex flex-wrap gap-2">
            {series.types.map((t) =>
          <div key={t} className="flex items-center gap-2 text-xs text-gray-300">
                <span className="w-3 h-3 rounded" style={{ background: palette[t] }} />
                {t}
              </div>
          )}
          </div>
        }

        {/* seasonality */}
        <div>
          <div className="text-xs text-gray-400 mb-1">Seasonality (next {months} months, combined)</div>
          <Heatmap values={seasonality} />
        </div>
      </CardContent>
    </Card>);

}

function mergeStacks(a = {}, b = {}, perType = false) {
  if (!perType) return { All: sum(a) + sum(b) };
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  const out = {};
  keys.forEach((k) => out[k] = (a[k] || 0) + (b[k] || 0));
  return out;
}

const sum = (o) => Object.values(o || {}).reduce((x, y) => x + Number(y || 0), 0);