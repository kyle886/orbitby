import React from "react";

export default function ListingCard({ item, onOpen }) {
  const img = item.images?.[0] || "/images/placeholder-building.jpg";
  
  const formatCurrency = (value) => {
    if (!value) return "—";
    return new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const formatArea = (value) => {
    if (!value) return "—";
    return `${Math.round(value).toLocaleString()} m²`;
  };

  return (
    <div className="rounded-xl overflow-hidden border border-white/10 bg-white/5 hover:border-white/30 transition-all duration-200 hover:bg-white/8">
      <div className="h-40 w-full bg-gray-800/50 relative overflow-hidden">
        <img 
          src={img} 
          alt={item.title}
          className="h-full w-full object-cover transition-transform duration-300 hover:scale-105" 
          loading="lazy"
          onError={(e) => {
            e.currentTarget.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' fill='%23374151'/%3E%3Ctext x='50' y='50' text-anchor='middle' dy='0.35em' fill='%23d1d5db' font-size='12' font-family='Arial'%3ENo Image%3C/text%3E%3C/svg%3E";
          }}
        />
        {item.status && item.status !== 'available' && (
          <div className="absolute top-2 right-2 px-2 py-1 bg-orange-600 text-white text-xs rounded-full">
            {item.status}
          </div>
        )}
      </div>
      
      <div className="p-4 space-y-2">
        <div className="space-y-1">
          <h3 className="text-sm font-semibold text-white line-clamp-2 min-h-[2.5rem]">
            {item.title}
          </h3>
          <div className="text-xs text-gray-300 space-y-1">
            <div className="flex items-center justify-between">
              <span>Size:</span>
              <span className="font-medium">{formatArea(item.sizeSqm)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Rate:</span>
              <span className="font-medium">{formatCurrency(item.rentPsm)}/m²</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between text-xs text-gray-400 pt-1 border-t border-white/10">
          <div className="space-x-1">
            {item.suburb && <span>{item.suburb}</span>}
            {item.grade && <span>• Grade {item.grade}</span>}
          </div>
          {item.source && (
            <span className="text-teal-400 capitalize">{item.source}</span>
          )}
        </div>
        
        <div className="pt-2">
          <button 
            className="w-full px-3 py-2 rounded-lg text-xs font-medium border border-white/20 text-white hover:border-white/40 hover:bg-white/10 transition-all duration-200"
            onClick={() => onOpen(item.id)}
          >
            View Details
          </button>
        </div>
      </div>
    </div>
  );
}