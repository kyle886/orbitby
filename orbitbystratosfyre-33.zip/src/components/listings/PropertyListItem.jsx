
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Badge } from "@/components/ui/badge";
import { MapPin, Square, DollarSign, ExternalLink, Clock } from "lucide-react";
import { useUnits } from '@/components/utils/units';
import { format } from 'date-fns';

export default function PropertyListItem({ tenancy, building }) {
  const { convertEconomics } = useUnits();
  
  const economics = convertEconomics({
    area_m2: tenancy.size_sqm,
    rent_aud_per_m2_pa: tenancy.rental_rate_sqm,
  });

  if (!building) {
    return (
      <div className="orbit-card animate-pulse p-4">
        <div className="flex gap-4">
          <div className="w-24 h-16 bg-gray-700/50 rounded"></div>
          <div className="flex-1 space-y-2">
            <div className="h-5 bg-gray-700/50 rounded w-3/4"></div>
            <div className="h-4 bg-gray-700/50 rounded w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <Link to={createPageUrl(`BuildingDetails?id=${building.id}`)} className="block">
      <div className="orbit-card p-4 hover:border-orange-400/50 transition-all group">
        <div className="flex gap-4">
          {/* Thumbnail */}
          <div className="w-24 h-16 flex-shrink-0 overflow-hidden rounded-lg">
            <img 
              src={building.image_url || '/api/placeholder/96/64'} 
              alt={building.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              onError={(e) => {
                e.target.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="96" height="64"><rect width="100%" height="100%" fill="%23374151"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="%23ffffff" font-size="10">No Image</text></svg>';
              }}
            />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-bold text-white truncate text-lg">{building.name}</h3>
              <div className="flex items-center gap-2 ml-2 flex-shrink-0">
                <Badge className="bg-gray-900/50 text-white backdrop-blur-sm">
                  {building.grade || 'Not Rated'}
                </Badge>
                {/* Live Listing Link */}
                {tenancy.url && (
                  <a 
                    href={tenancy.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="p-1 bg-orange-500 hover:bg-orange-600 rounded transition-colors"
                    onClick={(e) => e.stopPropagation()}
                    title="View Live Listing"
                  >
                    <ExternalLink className="w-3 h-3 text-white" />
                  </a>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 text-gray-300 mb-2">
              <MapPin className="w-4 h-4 flex-shrink-0" />
              <span className="text-sm truncate">{building.address}</span>
            </div>

            {/* Last Updated Timestamp */}
            {tenancy.updated_date && (
              <div className="flex items-center gap-1 text-xs text-gray-400 mb-3">
                <Clock className="w-3 h-3" />
                <span>Updated {format(new Date(tenancy.updated_date), 'dd MMM yyyy, HH:mm')}</span>
              </div>
            )}

            {/* Property Details */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-400">Suite:</span>
                <span className="font-semibold text-white">
                  {tenancy.suite || tenancy.floor || 'N/A'}
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <Square className="w-4 h-4 text-orange-400 flex-shrink-0" />
                <span className="font-semibold text-white">
                  {economics.area?.value} {economics.area?.unit}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-orange-400 flex-shrink-0" />
                <span className="font-semibold text-white">
                  {economics.rent ? `$${economics.rent.value}` : 'N/A'} 
                  <span className="text-gray-400 text-xs ml-1">{economics.rent?.unit}</span>
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-gray-400">Status:</span>
                <Badge 
                  variant={tenancy.status === 'Vacant' ? 'default' : 'secondary'} 
                  className={tenancy.status === 'Vacant' ? 'bg-green-500/80 text-white' : ''}
                >
                  {tenancy.status}
                </Badge>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
