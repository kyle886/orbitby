import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Image } from 'lucide-react';
import { reHarvestListingPhotos } from '@/api/functions';

export default function PhotosPanel({ listing }) {
  const [isHarvesting, setIsHarvesting] = useState(false);
  const { toast } = useToast();
  
  const imgs = listing?.images || {};
  const hasPhotos = imgs.main || (imgs.gallery && imgs.gallery.length > 0);
  
  const handleHarvest = async () => {
    setIsHarvesting(true);
    try {
      const result = await reHarvestListingPhotos({ listingId: listing.id });
      
      if (result.success) {
        toast({
          title: "Photos Harvested",
          description: result.message || "Successfully harvested property photos"
        });
        // Refresh the page to show new photos
        window.location.reload();
      } else {
        toast({
          variant: "destructive",
          title: "Harvest Failed",
          description: result.error || "Could not harvest photos"
        });
      }
    } catch (error) {
      console.error('Photo harvest error:', error);
      toast({
        variant: "destructive",
        title: "Harvest Failed",
        description: "An error occurred while harvesting photos"
      });
    } finally {
      setIsHarvesting(false);
    }
  };

  if (!hasPhotos) {
    return (
      <div className="orbit-card p-4">
        <div className="text-center py-8">
          <Image className="w-16 h-16 mx-auto mb-4 text-gray-500" />
          <h3 className="text-lg font-medium text-white mb-2">No Photos Found</h3>
          <p className="text-gray-400 mb-4">Try harvesting photos from the original listing</p>
          <Button 
            onClick={handleHarvest}
            disabled={isHarvesting}
            className="orbit-button bg-orange-500 hover:bg-orange-600"
          >
            {isHarvesting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Harvesting...
              </>
            ) : (
              'Harvest Photos'
            )}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="orbit-card p-4">
      <h3 className="text-lg font-semibold text-white mb-4">Property Photos</h3>
      
      {/* Main Image */}
      {imgs.main && (
        <div className="mb-4">
          <img 
            src={imgs.main} 
            alt="Main property photo" 
            className="w-full h-64 object-cover rounded-lg"
            onError={(e) => {
              e.target.style.display = 'none';
            }}
          />
        </div>
      )}
      
      {/* Gallery */}
      {imgs.gallery && imgs.gallery.length > 0 && (
        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-300 mb-2">Gallery</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {imgs.gallery.slice(0, 6).map((url, index) => (
              <img 
                key={index}
                src={url} 
                alt={`Gallery photo ${index + 1}`} 
                className="w-full h-24 object-cover rounded"
                onError={(e) => {
                  e.target.style.display = 'none';
                }}
              />
            ))}
          </div>
        </div>
      )}
      
      {/* Floorplans */}
      {imgs.floorplans && imgs.floorplans.length > 0 && (
        <div>
          <h4 className="text-sm font-medium text-gray-300 mb-2">Floor Plans</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {imgs.floorplans.map((url, index) => (
              <img 
                key={index}
                src={url} 
                alt={`Floor plan ${index + 1}`} 
                className="w-full h-32 object-contain bg-white rounded"
                onError={(e) => {
                  e.target.style.display = 'none';
                }}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}