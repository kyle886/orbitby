
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Building2, MapPin, Square, DollarSign, Eye } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// Mock Building object - In a real application, this would be imported from a data service or API layer.
// For demonstration purposes, it simulates fetching building data based on an address.
const Building = {
    filter: async ({ address }) => {
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 300));
        // Return a mock building if the address contains 'Main' for example, otherwise an empty array.
        // In a real scenario, this would query a database or an API.
        if (address && address.includes('Main')) {
            return [{ id: 'building123', address: address, name: 'Sample Building' }];
        }
        return [];
    }
};

const PropertyCard = ({ property }) => {
    const placeholderImage = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/688244252a7b37f0b4a1bcf9/1947b198b_image.png";
    const navigate = useNavigate();
    
    // Find the associated building to link to its details page
    const handleViewBuilding = async () => {
        // Assume property.address is the unique identifier to find the building
        const buildings = await Building.filter({ address: property.address });
        if (buildings && buildings.length > 0) {
            navigate(createPageUrl(`BuildingDetails?id=${buildings[0].id}`));
        } else {
            alert('Building details not yet available for this property.');
        }
    };
    
    return (
        <div className="orbit-card overflow-hidden flex flex-col h-full group">
            <div className="relative">
                <img 
                    src={property.images?.[0] || placeholderImage}
                    alt={property.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 right-3 flex flex-col gap-2">
                    {(property.agents || []).slice(0, 2).map((agent, index) => (
                         <Badge key={index} className="bg-orange-500 text-white capitalize">{agent.company?.toLowerCase() || 'Agency'}</Badge>
                    ))}
                </div>
            </div>
            <div className="p-4 flex flex-col flex-grow">
                <h3 className="text-lg font-bold truncate mb-1">{property.title}</h3>
                <div className="flex items-center gap-2 text-sm text-gray-400 mb-3">
                    <MapPin className="w-4 h-4" />
                    <span className="truncate">{property.address}</span>
                </div>
                <div className="flex items-center justify-between text-sm mb-4">
                    <div className="flex items-center gap-2">
                        <Square className="w-4 h-4 text-orange-400" />
                        <span>{property.floor_area_sqm} sqm</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-green-400" />
                        <span>${property.rental_rate_sqm}/sqm</span>
                    </div>
                </div>
                <p className="text-sm text-gray-400 line-clamp-2 mb-4 flex-grow">{property.description}</p>
                <div className="mt-auto flex gap-2">
                    <Button variant="outline" className="w-1/2 orbit-button border-gray-600 hover:bg-gray-700/50" onClick={handleViewBuilding}>
                        <Building2 className="w-4 h-4 mr-2" />
                        View Building
                    </Button>
                    <Link to={createPageUrl(`PropertyDetails?id=${property.id}`)} className="w-1/2">
                        <Button variant="outline" className="w-full orbit-button border-gray-600 hover:bg-gray-700/50">
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                        </Button>
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default PropertyCard;
