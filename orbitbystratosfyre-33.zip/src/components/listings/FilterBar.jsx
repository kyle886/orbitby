import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search, SlidersHorizontal, X } from 'lucide-react';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuCheckboxItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function FilterBar({ onFilterChange, suburbs, resultCount }) {
    const [searchTerm, setSearchTerm] = useState('');
    const [minSize, setMinSize] = useState('');
    const [maxSize, setMaxSize] = useState('');
    const [minRent, setMinRent] = useState('');
    const [maxRent, setMaxRent] = useState('');
    const [selectedSuburbs, setSelectedSuburbs] = useState([]);

    useEffect(() => {
        const timer = setTimeout(() => {
            onFilterChange({ searchTerm, minSize, maxSize, minRent, maxRent, suburbs: selectedSuburbs });
        }, 500); // Debounce
        return () => clearTimeout(timer);
    }, [searchTerm, minSize, maxSize, minRent, maxRent, selectedSuburbs, onFilterChange]);

    const handleSuburbChange = (suburb) => {
        setSelectedSuburbs(prev => 
            prev.includes(suburb) ? prev.filter(s => s !== suburb) : [...prev, suburb]
        );
    };

    const clearFilters = () => {
        setSearchTerm('');
        setMinSize('');
        setMaxSize('');
        setMinRent('');
        setMaxRent('');
        setSelectedSuburbs([]);
    };

    return (
        <aside className="w-80 bg-gray-800/50 p-6 flex-shrink-0 overflow-y-auto flex flex-col border-r border-gray-700">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold flex items-center gap-2"><SlidersHorizontal className="w-5 h-5"/> Filters</h2>
                <Button variant="ghost" size="sm" onClick={clearFilters}>Clear All</Button>
            </div>
            
            <div className="space-y-6 flex-grow">
                {/* Search */}
                <div className="relative">
                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                    <Input
                        placeholder="Search by keyword..."
                        className="pl-9 orbit-input"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>

                {/* Suburb Filter */}
                <div>
                    <Label className="mb-2 block">Suburb</Label>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="outline" className="w-full justify-between orbit-input">
                                <span>{selectedSuburbs.length > 0 ? `${selectedSuburbs.length} selected` : "Select suburbs"}</span>
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="w-64 max-h-80 overflow-y-auto">
                            <DropdownMenuLabel>Sydney Suburbs</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            {suburbs.map(suburb => (
                                <DropdownMenuCheckboxItem
                                    key={suburb}
                                    checked={selectedSuburbs.includes(suburb)}
                                    onSelect={(e) => e.preventDefault()}
                                    onClick={() => handleSuburbChange(suburb)}
                                >
                                    {suburb}
                                </DropdownMenuCheckboxItem>
                            ))}
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>

                {/* Size Filter */}
                <div>
                    <Label className="mb-2 block">Size (sqm)</Label>
                    <div className="flex items-center gap-2">
                        <Input placeholder="Min" type="number" className="orbit-input" value={minSize} onChange={(e) => setMinSize(e.target.value)} />
                        <span>-</span>
                        <Input placeholder="Max" type="number" className="orbit-input" value={maxSize} onChange={(e) => setMaxSize(e.target.value)} />
                    </div>
                </div>

                {/* Rent Filter */}
                <div>
                    <Label className="mb-2 block">Net Rent ($/sqm)</Label>
                    <div className="flex items-center gap-2">
                        <Input placeholder="Min" type="number" className="orbit-input" value={minRent} onChange={(e) => setMinRent(e.target.value)} />
                        <span>-</span>
                        <Input placeholder="Max" type="number" className="orbit-input" value={maxRent} onChange={(e) => setMaxRent(e.target.value)} />
                    </div>
                </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-700 text-center">
                <p className="text-2xl font-bold text-orange-400">{resultCount}</p>
                <p className="text-sm text-gray-400">Properties Found</p>
            </div>
        </aside>
    );
}