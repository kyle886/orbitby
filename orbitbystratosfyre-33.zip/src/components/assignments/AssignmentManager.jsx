import React, { useState, useEffect } from 'react';
import { Assignment } from '@/api/entities';
import { Target } from '@/api/entities';
import { User } from '@/api/entities';
import { Company } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Users, Plus, Clock, CheckCircle, AlertTriangle } from 'lucide-react';

export default function AssignmentManager({ targetId }) {
  const [assignments, setAssignments] = useState([]);
  const [users, setUsers] = useState([]);
  const [targets, setTargets] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [newAssignment, setNewAssignment] = useState({
    object_type: 'target',
    object_id: targetId || '',
    user_id: '',
    role: 'owner',
    due_dt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 16)
  });
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, [targetId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [assignmentsData, usersData, targetsData, companiesData] = await Promise.all([
        Assignment.list('-due_dt'),
        User.list(),
        Target.list(),
        Company.list()
      ]);

      setAssignments(assignmentsData || []);
      setUsers(usersData || []);
      setTargets(targetsData || []);
      setCompanies(companiesData || []);
    } catch (error) {
      console.error('Error loading assignment data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateAssignment = async (e) => {
    e.preventDefault();
    try {
      await Assignment.create(newAssignment);
      toast({ title: "Assignment Created", description: "The assignment has been created and the assignee will be notified." });
      setShowDialog(false);
      setNewAssignment({
        object_type: 'target',
        object_id: targetId || '',
        user_id: '',
        role: 'owner',
        due_dt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 16)
      });
      loadData();
    } catch (error) {
      console.error('Error creating assignment:', error);
      toast({ variant: "destructive", title: "Assignment Failed", description: "Could not create the assignment." });
    }
  };

  const handleCompleteAssignment = async (assignment) => {
    try {
      await Assignment.update(assignment.id, { status: 'done' });
      toast({ title: "Assignment Completed", description: "The assignment has been marked as complete." });
      loadData();
    } catch (error) {
      console.error('Error completing assignment:', error);
      toast({ variant: "destructive", title: "Update Failed", description: "Could not update the assignment." });
    }
  };

  const getObjectName = (assignment) => {
    if (assignment.object_type === 'target') {
      const target = targets.find(t => t.id === assignment.object_id);
      if (target) {
        const company = companies.find(c => c.id === target.company_id);
        return company?.name || 'Unknown Target';
      }
    }
    return `${assignment.object_type} ${assignment.object_id}`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'done': return 'bg-green-500/20 text-green-300';
      case 'open': return 'bg-orange-500/20 text-orange-300';
      case 'skipped': return 'bg-gray-500/20 text-gray-300';
      default: return 'bg-gray-500/20 text-gray-300';
    }
  };

  const isOverdue = (assignment) => {
    return assignment.status === 'open' && new Date(assignment.due_dt) < new Date();
  };

  const filteredAssignments = targetId 
    ? assignments.filter(a => a.object_id === targetId)
    : assignments;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-bold text-white">
          {targetId ? 'Target Assignments' : 'All Assignments'}
        </h3>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button className="orbit-button-active">
              <Plus className="w-4 h-4 mr-2" />
              Create Assignment
            </Button>
          </DialogTrigger>
          <DialogContent className="orbit-card text-white">
            <DialogHeader>
              <DialogTitle>Create New Assignment</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateAssignment} className="space-y-4">
              <div>
                <Label className="text-gray-300">Object Type</Label>
                <Select 
                  value={newAssignment.object_type} 
                  onValueChange={(value) => setNewAssignment({...newAssignment, object_type: value})}
                >
                  <SelectTrigger className="orbit-input">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="target">Target</SelectItem>
                    <SelectItem value="event">Event</SelectItem>
                    <SelectItem value="pitch">Pitch</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-gray-300">Assignee</Label>
                <Select 
                  value={newAssignment.user_id} 
                  onValueChange={(value) => setNewAssignment({...newAssignment, user_id: value})}
                >
                  <SelectTrigger className="orbit-input">
                    <SelectValue placeholder="Select user..." />
                  </SelectTrigger>
                  <SelectContent>
                    {users.filter(u => u.user_type === 'stratosfyre_admin').map(user => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.first_name} {user.last_name} ({user.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-gray-300">Role</Label>
                <Input
                  value={newAssignment.role}
                  onChange={(e) => setNewAssignment({...newAssignment, role: e.target.value})}
                  placeholder="e.g., owner, researcher, caller"
                  className="orbit-input"
                />
              </div>

              <div>
                <Label className="text-gray-300">Due Date</Label>
                <Input
                  type="datetime-local"
                  value={newAssignment.due_dt}
                  onChange={(e) => setNewAssignment({...newAssignment, due_dt: e.target.value})}
                  className="orbit-input"
                />
              </div>

              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="orbit-button-active">
                  Create Assignment
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {filteredAssignments.map((assignment) => {
          const assignedUser = users.find(u => u.id === assignment.user_id);
          const overdue = isOverdue(assignment);

          return (
            <Card key={assignment.id} className="orbit-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0">
                <CardTitle className="text-white flex items-center gap-2">
                  {overdue && <AlertTriangle className="w-4 h-4 text-red-400" />}
                  {getObjectName(assignment)}
                </CardTitle>
                <Badge className={getStatusColor(assignment.status)}>
                  {assignment.status}
                </Badge>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400">Assignee:</p>
                    <p className="text-white">
                      {assignedUser ? `${assignedUser.first_name} ${assignedUser.last_name}` : 'Unknown User'}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400">Role:</p>
                    <p className="text-white">{assignment.role}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Due Date:</p>
                    <p className={`${overdue ? 'text-red-400' : 'text-white'}`}>
                      {new Date(assignment.due_dt).toLocaleDateString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400">Reminders Sent:</p>
                    <p className="text-white">{assignment.reminder_count || 0}</p>
                  </div>
                </div>
                {assignment.status === 'open' && (
                  <div className="mt-4 flex justify-end">
                    <Button 
                      onClick={() => handleCompleteAssignment(assignment)}
                      className="orbit-button-active"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Mark Complete
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}

        {filteredAssignments.length === 0 && !loading && (
          <Card className="orbit-card p-12 text-center">
            <Users className="w-12 h-12 mx-auto text-gray-500 mb-4" />
            <h3 className="text-xl font-medium text-white">No Assignments</h3>
            <p className="text-gray-400">Create assignments to track work and send reminders.</p>
          </Card>
        )}
      </div>
    </div>
  );
}