import React, { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { RFPResponse } from "@/api/entities";

export default function OfferNormalizer({ rfpId, onOfferSaved }) {
  const [rawText, setRawText] = useState("");
  const [normalizedOffer, setNormalizedOffer] = useState(null);
  const [offerName, setOfferName] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const normalizeOffer = async () => {
    if (!rawText.trim()) {
      toast({ variant: "destructive", title: "Please enter offer text" });
      return;
    }

    setIsProcessing(true);
    try {
      const { rfpNormalize } = await import('@/api/functions');
      const response = await rfpNormalize({ text: rawText });
      
      if (response.data.ok) {
        setNormalizedOffer(response.data.offer);
        toast({ title: "Offer normalized successfully" });
      } else {
        toast({ 
          variant: "destructive", 
          title: "Normalization failed", 
          description: response.data.error 
        });
      }
    } catch (error) {
      console.error('Normalization error:', error);
      toast({ 
        variant: "destructive", 
        title: "Processing failed", 
        description: error.message 
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const saveOffer = async () => {
    if (!normalizedOffer) return;

    try {
      const offerData = {
        rfp_request_id: rfpId,
        agent_name: offerName || normalizedOffer.landlord || 'Unknown Agent',
        headline_terms: {
          lease_term: `${normalizedOffer.term_years || 0} years`,
          net_face_rent: normalizedOffer.rent_psm_pa || 0,
          outgoings: normalizedOffer.opex_psm_pa || 0,
          incentive_percentage: normalizedOffer.incentives_pct || 0,
          fitout_contribution: normalizedOffer.fitout_contribution_aud || 0,
          parking_bays: normalizedOffer.parking_bays || 0
        },
        status: 'submitted',
        submitted_date: new Date().toISOString()
      };

      const savedOffer = await RFPResponse.create(offerData);
      
      toast({ 
        title: "Offer saved", 
        description: `${savedOffer.agent_name} offer recorded` 
      });

      // Reset form
      setRawText("");
      setNormalizedOffer(null);
      setOfferName("");
      
      if (onOfferSaved) {
        onOfferSaved(savedOffer);
      }
    } catch (error) {
      console.error('Save error:', error);
      toast({ 
        variant: "destructive", 
        title: "Save failed", 
        description: error.message 
      });
    }
  };

  const formatLabel = (key) => {
    return key.replace(/_/g, ' ').replace(/\b[a-z]/g, m => m.toUpperCase());
  };

  return (
    <Card className="shadow-elevated">
      <CardHeader>
        <CardTitle className="text-base">Offer Normalizer</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          value={rawText}
          onChange={(e) => setRawText(e.target.value)}
          placeholder="Paste HOA / email terms here…"
          className="min-h-[160px]"
        />
        
        <div className="flex gap-2">
          <Button 
            onClick={normalizeOffer} 
            disabled={isProcessing || !rawText.trim()}
          >
            {isProcessing ? 'Processing...' : 'Normalize'}
          </Button>
          <Input
            value={offerName}
            onChange={(e) => setOfferName(e.target.value)}
            placeholder="Agent/Landlord name (optional)"
            className="max-w-xs"
          />
          <Button 
            variant="outline" 
            onClick={saveOffer} 
            disabled={!normalizedOffer}
          >
            Save Offer
          </Button>
        </div>

        {normalizedOffer && (
          <div className="grid md:grid-cols-3 gap-2 text-sm">
            {Object.entries(normalizedOffer).map(([key, value]) => (
              <div key={key} className="rounded-lg border border-white/10 p-2">
                <div className="text-xs text-gray-400">{formatLabel(key)}</div>
                <div className="font-medium">
                  {value !== null && value !== undefined ? String(value) : '—'}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}