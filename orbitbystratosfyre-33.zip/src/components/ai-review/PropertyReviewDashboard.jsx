import React, { useState, useEffect } from 'react';
import { AIPropertyReview } from '@/api/entities';
import { TenantRequirement } from '@/api/entities';
import { Property } from '@/api/entities';
import { Client } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Brain, 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Loader2,
  Star,
  MapPin,
  Square,
  DollarSign
} from 'lucide-react';

export default function PropertyReviewDashboard() {
    const [reviews, setReviews] = useState([]);
    const [briefs, setBriefs] = useState([]);
    const [properties, setProperties] = useState([]);
    const [clients, setClients] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedBrief, setSelectedBrief] = useState('all');
    const [selectedRecommendation, setSelectedRecommendation] = useState('all');

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [reviewsData, briefsData, propertiesData, clientsData] = await Promise.all([
                AIPropertyReview.list('-created_date'),
                TenantRequirement.list(),
                Property.list(),
                Client.list()
            ]);
            
            setReviews(reviewsData || []);
            setBriefs(briefsData || []);
            setProperties(propertiesData || []);
            setClients(clientsData || []);
        } catch (error) {
            console.error('Error loading AI review data:', error);
        } finally {
            setLoading(false);
        }
    };

    const getProperty = (submissionId) => {
        return properties.find(p => p.id === submissionId);
    };

    const getBrief = (briefId) => {
        return briefs.find(b => b.id === briefId);
    };

    const getClient = (clientId) => {
        return clients.find(c => c.id === clientId);
    };

    const filteredReviews = reviews.filter(review => {
        const briefMatch = selectedBrief === 'all' || review.brief_id === selectedBrief;
        const recommendationMatch = selectedRecommendation === 'all' || review.ai_recommendation === selectedRecommendation;
        return briefMatch && recommendationMatch;
    });

    const getRecommendationIcon = (recommendation) => {
        switch (recommendation) {
            case 'shortlist': return <CheckCircle className="w-4 h-4 text-green-500" />;
            case 'reject': return <XCircle className="w-4 h-4 text-red-500" />;
            case 'backup': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
            default: return <Minus className="w-4 h-4 text-gray-500" />;
        }
    };

    const getRecommendationBadge = (recommendation) => {
        const styles = {
            shortlist: 'bg-green-100 text-green-800 border-green-200',
            reject: 'bg-red-100 text-red-800 border-red-200',
            backup: 'bg-yellow-100 text-yellow-800 border-yellow-200'
        };
        
        return (
            <Badge className={`${styles[recommendation]} flex items-center gap-1`}>
                {getRecommendationIcon(recommendation)}
                <span className="capitalize">{recommendation}</span>
            </Badge>
        );
    };

    const getMarketPositionIcon = (position) => {
        switch (position) {
            case 'Below Market': return <TrendingDown className="w-4 h-4 text-green-500" />;
            case 'Above Market': return <TrendingUp className="w-4 h-4 text-red-500" />;
            default: return <Minus className="w-4 h-4 text-gray-500" />;
        }
    };

    const getScoreColor = (score) => {
        if (score >= 8) return 'text-green-500';
        if (score >= 6) return 'text-yellow-500';
        return 'text-red-500';
    };

    const handleApproveReview = async (reviewId) => {
        try {
            await AIPropertyReview.update(reviewId, { consultant_review_status: 'approved' });
            loadData();
        } catch (error) {
            console.error('Error approving review:', error);
        }
    };

    const handleRejectReview = async (reviewId) => {
        try {
            await AIPropertyReview.update(reviewId, { consultant_review_status: 'rejected' });
            loadData();
        } catch (error) {
            console.error('Error rejecting review:', error);
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center p-8">
                <Loader2 className="w-8 h-8 animate-spin text-orange-400" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-2xl font-bold text-white mb-2">AI Property Reviews</h2>
                    <p className="text-gray-400">AI-powered analysis of properties against client briefs</p>
                </div>
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        <Brain className="w-5 h-5 text-orange-400" />
                        <span className="text-white font-medium">{filteredReviews.length} Reviews</span>
                    </div>
                </div>
            </div>

            <div className="flex gap-4 mb-6">
                <Select value={selectedBrief} onValueChange={setSelectedBrief}>
                    <SelectTrigger className="w-64 orbit-input">
                        <SelectValue placeholder="Filter by brief" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Briefs</SelectItem>
                        {briefs.map(brief => (
                            <SelectItem key={brief.id} value={brief.id}>
                                {brief.brief_reference_code} - {brief.company_name}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>

                <Select value={selectedRecommendation} onValueChange={setSelectedRecommendation}>
                    <SelectTrigger className="w-48 orbit-input">
                        <SelectValue placeholder="Filter by recommendation" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Recommendations</SelectItem>
                        <SelectItem value="shortlist">Shortlist</SelectItem>
                        <SelectItem value="backup">Backup</SelectItem>
                        <SelectItem value="reject">Reject</SelectItem>
                    </SelectContent>
                </Select>
            </div>

            <div className="grid gap-6">
                {filteredReviews.map(review => {
                    const property = getProperty(review.submission_id);
                    const brief = getBrief(review.brief_id);
                    const client = getClient(brief?.client_id);
                    
                    return (
                        <Card key={review.id} className="orbit-card">
                            <CardHeader className="pb-4">
                                <div className="flex justify-between items-start">
                                    <div className="flex-1">
                                        <CardTitle className="text-white mb-2 flex items-center gap-2">
                                            <Brain className="w-5 h-5 text-orange-400" />
                                            {property?.title || 'Property Not Found'}
                                        </CardTitle>
                                        <div className="flex items-center gap-4 text-sm text-gray-400">
                                            <span className="flex items-center gap-1">
                                                <MapPin className="w-4 h-4" />
                                                {property?.address}
                                            </span>
                                            <span className="flex items-center gap-1">
                                                <Square className="w-4 h-4" />
                                                {property?.floor_area_sqm} sqm
                                            </span>
                                            <span className="flex items-center gap-1">
                                                <DollarSign className="w-4 h-4" />
                                                ${property?.rental_rate_sqm}/sqm
                                            </span>
                                        </div>
                                        <p className="text-sm text-gray-300 mt-2">
                                            <span className="font-medium">Brief:</span> {brief?.brief_reference_code} - {client?.company_name}
                                        </p>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        {getRecommendationBadge(review.ai_recommendation)}
                                        <div className="text-right">
                                            <div className="text-2xl font-bold text-white">{review.match_score}%</div>
                                            <div className="text-xs text-gray-400">Match Score</div>
                                        </div>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="pt-0">
                                <Tabs defaultValue="analysis" className="w-full">
                                    <TabsList className="grid w-full grid-cols-3">
                                        <TabsTrigger value="analysis">Analysis</TabsTrigger>
                                        <TabsTrigger value="scores">Detailed Scores</TabsTrigger>
                                        <TabsTrigger value="market">Market Insights</TabsTrigger>
                                    </TabsList>
                                    
                                    <TabsContent value="analysis" className="mt-4">
                                        <div className="space-y-4">
                                            <div>
                                                <h4 className="font-medium text-white mb-2">AI Reasoning</h4>
                                                <p className="text-sm text-gray-300 leading-relaxed">{review.ai_reasoning}</p>
                                            </div>
                                            
                                            <div className="flex gap-2 pt-4">
                                                <Button 
                                                    onClick={() => handleApproveReview(review.id)}
                                                    className="bg-green-600 hover:bg-green-700 text-white"
                                                    disabled={review.consultant_review_status === 'approved'}
                                                >
                                                    <CheckCircle className="w-4 h-4 mr-2" />
                                                    Approve Analysis
                                                </Button>
                                                <Button 
                                                    onClick={() => handleRejectReview(review.id)}
                                                    variant="outline"
                                                    className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                                                    disabled={review.consultant_review_status === 'rejected'}
                                                >
                                                    <XCircle className="w-4 h-4 mr-2" />
                                                    Reject Analysis
                                                </Button>
                                            </div>
                                        </div>
                                    </TabsContent>
                                    
                                    <TabsContent value="scores" className="mt-4">
                                        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                                            {Object.entries(review.criteria_scores || {}).map(([key, score]) => (
                                                <div key={key} className="text-center">
                                                    <div className={`text-2xl font-bold ${getScoreColor(score)}`}>
                                                        {score}/10
                                                    </div>
                                                    <div className="text-xs text-gray-400 capitalize">
                                                        {key.replace('_score', '')}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </TabsContent>
                                    
                                    <TabsContent value="market" className="mt-4">
                                        <div className="space-y-4">
                                            <div className="flex items-center gap-3">
                                                <span className="text-gray-400">Market Position:</span>
                                                <div className="flex items-center gap-2">
                                                    {getMarketPositionIcon(review.deal_prediction?.market_positioning)}
                                                    <span className="text-white">{review.deal_prediction?.market_positioning || 'Not assessed'}</span>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-3">
                                                <span className="text-gray-400">Confidence Level:</span>
                                                <div className="flex items-center gap-1">
                                                    <Star className="w-4 h-4 text-yellow-400" />
                                                    <span className="text-white">{review.deal_prediction?.confidence_level || 'Medium'}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </TabsContent>
                                </Tabs>
                            </CardContent>
                        </Card>
                    );
                })}
            </div>

            {filteredReviews.length === 0 && (
                <div className="text-center py-12">
                    <Brain className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-white mb-2">No AI Reviews Found</h3>
                    <p className="text-gray-400">
                        Run the property scanning agent to generate AI-powered property analyses.
                    </p>
                </div>
            )}
        </div>
    );
}