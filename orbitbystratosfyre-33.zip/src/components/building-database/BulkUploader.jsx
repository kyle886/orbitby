import React, { useState } from 'react';
import { UploadFile } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, UploadCloud, File, CheckCircle, AlertTriangle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { runJob } from '@/components/utils/runJob';

// We'll create this backend function next.
import { ingestData } from '@/api/functions';

export default function BulkUploader({ onUploadComplete }) {
  const [file, setFile] = useState(null);
  const [entityType, setEntityType] = useState('Building');
  const [uploading, setUploading] = useState(false);
  const [status, setStatus] = useState('idle'); // idle, uploading, processing, success, error
  const { toast } = useToast();

  const handleFileChange = (event) => {
    if (event.target.files && event.target.files[0]) {
      const selectedFile = event.target.files[0];
      if (selectedFile.type === 'text/csv') {
        setFile(selectedFile);
      } else {
        toast({ variant: 'destructive', title: 'Invalid File Type', description: 'Please select a .csv file.' });
        setFile(null); // Clear any previously selected invalid file
      }
    }
  };

  const handleUpload = async () => {
    if (!file) {
      toast({ variant: 'destructive', title: 'No file selected' });
      return;
    }
    if (!entityType) {
        toast({ variant: 'destructive', title: 'Data type not selected', description: 'Please select the type of data you are uploading.' });
        return;
    }
    
    // Define the core logic for the job that `runJob` will execute.
    // This function will receive the payload we pass to `runJob`.
    const jobLogic = async (payload) => {
      // Set initial states for the UI within the job's execution context
      setUploading(true);
      setStatus('uploading');

      try {
        // 1. Upload the file to get a URL
        // The UploadFile function is expected to handle the file upload and return its URL.
        const { file_url } = await UploadFile({ file: payload.file });
        if (!file_url) {
          throw new Error("File upload failed: No URL was returned after uploading.");
        }

        setStatus('processing');
        toast({ title: 'File Uploaded', description: 'Starting data ingestion process...' });

        // 2. Call the backend function with the URL and entity type
        // This function orchestrates the actual data ingestion on the server.
        const response = await ingestData({
          file_url,
          entityType: payload.entityType,
          // 'triggeredBy' is typically handled by `runJob` or the backend itself
          // based on the authenticated user's context.
        });

        // Assuming the ingestData response has a specific structure
        if (response.data && response.data.success) {
          setStatus('success');
          const successMessage = `Successfully ingested ${response.data.rows_ingested || 0} records.`;
          toast({ title: 'Ingestion Complete', description: successMessage });
          setFile(null); // Clear the file input upon successful ingestion
          if (onUploadComplete) onUploadComplete();
          // Return data for the JobRun record
          return { rows_affected: response.data.rows_ingested, notes: successMessage };
        } else {
          // If ingestion was not successful, throw an error to be caught by runJob
          throw new Error(response.data?.message || 'Data ingestion failed on the backend without specific error details.');
        }
      } catch (error) {
        console.error('Data Ingestion JobLogic failed:', error);
        setStatus('error'); // Set status to error for UI feedback
        toast({ variant: 'destructive', title: 'Ingestion Failed', description: error.message || "An unexpected error occurred during data ingestion." });
        throw error; // Re-throw to ensure `runJob` captures the failure status correctly
      }
    };
    
    // Use `runJob` utility to wrap and track this entire operation.
    // `runJob` will create a JobRun record, execute `jobLogic`, and update the record's status.
    try {
      await runJob('CSV Data Ingestion', jobLogic, { file, entityType });
      // If `runJob` completes without throwing, it means `jobLogic` completed (successfully or with handled errors).
      // Toasts and file clearing are already handled within `jobLogic`'s success/error branches.
    } catch (error) {
      // This outer catch block handles any errors that might be propagated by `runJob` itself,
      // or critical errors preventing `runJob` from even starting `jobLogic`.
      console.error('Failed to execute or track ingestion job:', error);
      // Only show a generic error if jobLogic hasn't already set the status to 'error' and toasted.
      if (status !== 'error') {
        setStatus('error');
        toast({ variant: 'destructive', title: 'Job System Error', description: error.message || "The job tracking system encountered an unexpected error." });
      }
    } finally {
      setUploading(false); // Ensure the uploading state is reset regardless of outcome.
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="text-sm font-medium text-gray-300">Data Type</label>
          <Select value={entityType} onValueChange={setEntityType} disabled={uploading}>
            <SelectTrigger className="orbit-input w-full">
              <SelectValue placeholder="Select data type to import" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Building">Buildings</SelectItem>
              <SelectItem value="Tenancy">Tenancies</SelectItem>
              <SelectItem value="Contact">Contacts</SelectItem>
              <SelectItem value="Lease">Leases</SelectItem>
              <SelectItem value="DealEvidence">Deal Evidence</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="p-8 border-2 border-dashed rounded-lg text-center border-gray-600">
        <UploadCloud className="w-12 h-12 mx-auto text-gray-500 mb-4" />
        {file ? (
          <div className="flex flex-col items-center justify-center gap-2">
            <div className="flex items-center gap-2">
              <File className="w-5 h-5 text-gray-300" />
              <span className="font-medium text-white">{file.name}</span>
            </div>
            <Button variant="link" size="sm" className="text-red-400" onClick={() => setFile(null)}>Remove</Button>
          </div>
        ) : (
          <>
            <label htmlFor="csv-upload" className="orbit-button-active cursor-pointer inline-flex items-center justify-center px-4 py-2">
              Select CSV File
            </label>
            <input 
              id="csv-upload" 
              type="file" 
              className="hidden" 
              onChange={handleFileChange}
              accept=".csv"
            />
            <p className="text-gray-400 mt-2 text-sm">Click the button to select a file.</p>
          </>
        )}
      </div>

      <div className="flex justify-end">
        {/* Disable button if no file, currently uploading, or no entity type selected */}
        <Button onClick={handleUpload} disabled={!file || uploading || !entityType} className="orbit-button-active min-w-[120px]">
          {uploading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              {status === 'uploading' ? 'Uploading...' : 'Processing...'}
            </>
          ) : (
            'Start Ingestion'
          )}
        </Button>
      </div>
    </div>
  );
}