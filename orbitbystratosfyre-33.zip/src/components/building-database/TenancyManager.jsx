import React, { useState } from 'react';
import { Tenancy } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Edit, Trash2 } from 'lucide-react';

export default function TenancyManager({ building, tenancies, onUpdate }) {
  const [showDialog, setShowDialog] = useState(false);
  const [editingTenancy, setEditingTenancy] = useState(null);
  const [formData, setFormData] = useState({
    floor: '',
    suite: '',
    size_sqm: '',
    status: 'Vacant',
    tenant_name: '',
    lease_expiry_date: '',
    availability_date: '',
    rental_rate_sqm: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const tenancyData = {
        ...formData,
        building_id: building.id,
        size_sqm: parseFloat(formData.size_sqm) || 0,
        rental_rate_sqm: parseFloat(formData.rental_rate_sqm) || 0
      };

      if (editingTenancy) {
        await Tenancy.update(editingTenancy.id, tenancyData);
      } else {
        await Tenancy.create(tenancyData);
      }

      setShowDialog(false);
      setEditingTenancy(null);
      resetForm();
      onUpdate();
    } catch (error) {
      console.error('Error saving tenancy:', error);
      alert('Failed to save tenancy');
    }
  };

  const handleEdit = (tenancy) => {
    setEditingTenancy(tenancy);
    setFormData({
      floor: tenancy.floor || '',
      suite: tenancy.suite || '',
      size_sqm: tenancy.size_sqm?.toString() || '',
      status: tenancy.status || 'Vacant',
      tenant_name: tenancy.tenant_name || '',
      lease_expiry_date: tenancy.lease_expiry_date || '',
      availability_date: tenancy.availability_date || '',
      rental_rate_sqm: tenancy.rental_rate_sqm?.toString() || ''
    });
    setShowDialog(true);
  };

  const handleDelete = async (tenancy) => {
    if (window.confirm('Are you sure you want to delete this tenancy?')) {
      try {
        await Tenancy.delete(tenancy.id);
        onUpdate();
      } catch (error) {
        console.error('Error deleting tenancy:', error);
        alert('Failed to delete tenancy');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      floor: '',
      suite: '',
      size_sqm: '',
      status: 'Vacant',
      tenant_name: '',
      lease_expiry_date: '',
      availability_date: '',
      rental_rate_sqm: ''
    });
  };

  const openAddDialog = () => {
    setEditingTenancy(null);
    resetForm();
    setShowDialog(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h4 className="font-bold text-white">Tenancies ({tenancies.length})</h4>
        <Button onClick={openAddDialog} size="sm" className="orbit-button bg-orange-500 hover:bg-orange-600">
          <Plus className="w-4 h-4 mr-2" />
          Add Tenancy
        </Button>
      </div>

      <div className="space-y-2 max-h-60 overflow-y-auto">
        {tenancies.map(tenancy => (
          <div key={tenancy.id} className="bg-gray-800/50 p-3 rounded-lg">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-medium text-white">
                    {tenancy.floor} {tenancy.suite && `- ${tenancy.suite}`}
                  </span>
                  <div className={`px-2 py-0.5 rounded text-xs font-bold ${
                    tenancy.status === 'Vacant' ? 'bg-green-600 text-green-100' :
                    tenancy.status === 'Occupied' ? 'bg-blue-600 text-blue-100' :
                    'bg-yellow-600 text-yellow-100'
                  }`}>
                    {tenancy.status}
                  </div>
                </div>
                <div className="text-sm text-gray-300">
                  <p>{tenancy.size_sqm} sqm</p>
                  {tenancy.tenant_name && <p>Tenant: {tenancy.tenant_name}</p>}
                  {tenancy.rental_rate_sqm && <p>Rate: ${tenancy.rental_rate_sqm}/sqm</p>}
                  {tenancy.availability_date && <p>Available: {new Date(tenancy.availability_date).toLocaleDateString()}</p>}
                  {tenancy.lease_expiry_date && <p>Lease Expires: {new Date(tenancy.lease_expiry_date).toLocaleDateString()}</p>}
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={() => handleEdit(tenancy)} size="sm" variant="outline" className="h-8 w-8 p-0">
                  <Edit className="w-3 h-3" />
                </Button>
                <Button onClick={() => handleDelete(tenancy)} size="sm" variant="outline" className="h-8 w-8 p-0 text-red-400 hover:text-red-300">
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="orbit-card text-white">
          <DialogHeader>
            <DialogTitle>
              {editingTenancy ? 'Edit Tenancy' : 'Add New Tenancy'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">Floor *</Label>
                <Input
                  value={formData.floor}
                  onChange={(e) => setFormData(prev => ({...prev, floor: e.target.value}))}
                  className="orbit-input text-white"
                  placeholder="e.g. L15, Ground"
                  required
                />
              </div>
              <div>
                <Label className="text-gray-300">Suite</Label>
                <Input
                  value={formData.suite}
                  onChange={(e) => setFormData(prev => ({...prev, suite: e.target.value}))}
                  className="orbit-input text-white"
                  placeholder="e.g. 15.01, A"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">Size (sqm) *</Label>
                <Input
                  type="number"
                  value={formData.size_sqm}
                  onChange={(e) => setFormData(prev => ({...prev, size_sqm: e.target.value}))}
                  className="orbit-input text-white"
                  required
                />
              </div>
              <div>
                <Label className="text-gray-300">Status *</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({...prev, status: value}))}>
                  <SelectTrigger className="orbit-input text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Vacant">Vacant</SelectItem>
                    <SelectItem value="Occupied">Occupied</SelectItem>
                    <SelectItem value="Under Offer">Under Offer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {formData.status === 'Occupied' && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Tenant Name</Label>
                  <Input
                    value={formData.tenant_name}
                    onChange={(e) => setFormData(prev => ({...prev, tenant_name: e.target.value}))}
                    className="orbit-input text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Lease Expiry Date</Label>
                  <Input
                    type="date"
                    value={formData.lease_expiry_date}
                    onChange={(e) => setFormData(prev => ({...prev, lease_expiry_date: e.target.value}))}
                    className="orbit-input text-white"
                  />
                </div>
              </div>
            )}

            {formData.status === 'Vacant' && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Rental Rate ($/sqm/year)</Label>
                  <Input
                    type="number"
                    value={formData.rental_rate_sqm}
                    onChange={(e) => setFormData(prev => ({...prev, rental_rate_sqm: e.target.value}))}
                    className="orbit-input text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Available Date</Label>
                  <Input
                    type="date"
                    value={formData.availability_date}
                    onChange={(e) => setFormData(prev => ({...prev, availability_date: e.target.value}))}
                    className="orbit-input text-white"
                  />
                </div>
              </div>
            )}
          </form>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setShowDialog(false)} className="text-white border-gray-600">
              Cancel
            </Button>
            <Button onClick={handleSubmit} className="bg-orange-500 hover:bg-orange-600 text-white">
              {editingTenancy ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}