import React, { useState } from 'react';
import { Document } from '@/api/entities';
import { User } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { FileText, Plus, Trash2, Loader2, Upload } from 'lucide-react';

export default function BuildingDocumentManager({ building, documents, onUpdate }) {
  const [showDialog, setShowDialog] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [fileToUpload, setFileToUpload] = useState(null);
  const [documentName, setDocumentName] = useState('');

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileToUpload(file);
      setDocumentName(file.name);
    }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!fileToUpload) return;

    setIsUploading(true);
    try {
      const { file_url } = await UploadFile({ file: fileToUpload });
      const user = await User.me();
      
      const newDoc = {
        building_id: building.id, // Link to building
        document_name: documentName,
        document_type: "floorplan", // Default for now
        file_url,
        uploaded_by: user.email,
        is_client_visible: false, // Building docs are internal by default
      };

      await Document.create(newDoc);
      
      setShowDialog(false);
      setFileToUpload(null);
      setDocumentName('');
      onUpdate(); // Refresh parent component
    } catch (error) {
      console.error("Error uploading document:", error);
      alert("Failed to upload document.");
    } finally {
      setIsUploading(false);
    }
  };

  const deleteDocument = async (docId) => {
    if (window.confirm("Are you sure you want to delete this document?")) {
      await Document.delete(docId);
      onUpdate();
    }
  };

  return (
    <div className="orbit-card p-6 mt-8">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-semibold text-white text-lg">Building Documents</h3>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button className="orbit-button text-gray-300 border-gray-600 hover:bg-gray-800 flex items-center gap-2">
              <Plus className="w-4 h-4" /> Upload
            </Button>
          </DialogTrigger>
          <DialogContent className="orbit-card bg-gray-800 border-gray-700 text-white">
            <DialogHeader>
              <DialogTitle>Upload Building Document</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleUpload} className="space-y-4">
              <Input type="file" onChange={handleFileChange} className="orbit-input" required />
              <Input 
                placeholder="Document Name" 
                value={documentName} 
                onChange={(e) => setDocumentName(e.target.value)} 
                className="orbit-input" 
                required 
              />
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setShowDialog(false)} className="text-gray-300 hover:text-white">Cancel</Button>
                <Button type="submit" disabled={isUploading} className="orbit-button-active text-white">
                  {isUploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
                  Upload
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="space-y-2">
        {documents.length > 0 ? documents.map(doc => (
          <div key={doc.id} className="flex items-center justify-between bg-gray-800/50 p-3 rounded-lg">
            <a href={doc.file_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-amber-400 hover:underline">
              <FileText className="w-5 h-5" />
              <span>{doc.document_name}</span>
            </a>
            <Button variant="ghost" size="icon" onClick={() => deleteDocument(doc.id)} className="text-gray-500 hover:text-red-500">
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        )) : <p className="text-gray-400 text-center py-4">No documents for this building.</p>}
      </div>
    </div>
  );
}