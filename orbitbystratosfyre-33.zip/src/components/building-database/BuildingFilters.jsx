import React, { useState, useEffect } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { motion } from "framer-motion";

export default function BuildingFilters({ onFilterChange }) {
    const [filters, setFilters] = useState({
        grade: 'all',
        minSize: '',
        maxSize: ''
    });

    useEffect(() => {
        const handler = setTimeout(() => {
            onFilterChange(filters);
        }, 500); // Debounce filter changes

        return () => {
            clearTimeout(handler);
        };
    }, [filters, onFilterChange]);

    const handleFilterChange = (field, value) => {
        setFilters(prev => ({ ...prev, [field]: value }));
    };

    return (
        <motion.div 
            className="orbit-card p-4 mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
        >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <div>
                    <Label htmlFor="grade-filter" className="text-gray-300 text-sm">Grade</Label>
                    <Select value={filters.grade} onValueChange={v => handleFilterChange('grade', v)}>
                        <SelectTrigger id="grade-filter" className="orbit-input text-white">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Grades</SelectItem>
                            <SelectItem value="Premium">Premium</SelectItem>
                            <SelectItem value="A">A</SelectItem>
                            <SelectItem value="B">B</SelectItem>
                            <SelectItem value="C">C</SelectItem>
                            <SelectItem value="Not Rated">Not Rated</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label className="text-gray-300 text-sm">Available Size (sqm)</Label>
                    <div className="flex items-center gap-2">
                        <Input 
                            placeholder="Min" 
                            type="number" 
                            className="orbit-input text-white" 
                            value={filters.minSize} 
                            onChange={e => handleFilterChange('minSize', e.target.value)} 
                        />
                        <Input 
                            placeholder="Max" 
                            type="number" 
                            className="orbit-input text-white" 
                            value={filters.maxSize} 
                            onChange={e => handleFilterChange('maxSize', e.target.value)}
                        />
                    </div>
                </div>
            </div>
        </motion.div>
    );
}