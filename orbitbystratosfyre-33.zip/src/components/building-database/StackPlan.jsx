import React from 'react';
import _ from 'lodash';

const StackPlan = ({ tenancies }) => {
    // Group tenancies by floor. For simplicity, we'll parse numbers from floor strings.
    const getFloorNumber = (floorStr) => {
        if (!floorStr) return 0;
        const match = floorStr.match(/\d+/);
        return match ? parseInt(match[0], 10) : 0;
    };

    const groupedByFloor = _.groupBy(tenancies, (t) => getFloorNumber(t.floor));
    const sortedFloors = Object.keys(groupedByFloor).map(Number).sort((a, b) => b - a);

    if (tenancies.length === 0) {
        return <div className="text-center text-gray-500 py-10">No tenancy information available to display stack plan.</div>;
    }

    return (
        <div className="space-y-1">
            {sortedFloors.map(floorNum => {
                const floorTenancies = groupedByFloor[floorNum];
                const totalFloorSize = _.sumBy(floorTenancies, 'size_sqm');
                const vacantSize = _.sumBy(floorTenancies.filter(t => t.status === 'Vacant'), 'size_sqm');
                const occupiedPercentage = totalFloorSize > 0 ? ((totalFloorSize - vacantSize) / totalFloorSize) * 100 : 0;

                return (
                    <div key={floorNum} className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
                        <div className="w-16 text-center">
                            <p className="font-bold text-lg text-white">L{floorNum}</p>
                            <p className="text-xs text-gray-400">{totalFloorSize} sqm</p>
                        </div>
                        <div className="flex-grow bg-gray-700 h-10 rounded overflow-hidden flex">
                            {floorTenancies.map(tenancy => {
                                const tenancyWidth = (tenancy.size_sqm / totalFloorSize) * 100;
                                const isVacant = tenancy.status === 'Vacant';
                                return (
                                    <div
                                        key={tenancy.id}
                                        style={{ width: `${tenancyWidth}%` }}
                                        className={`h-full flex items-center justify-center text-xs font-medium text-white transition-all ${isVacant ? 'bg-green-500/50 hover:bg-green-500/80' : 'bg-blue-500/30 hover:bg-blue-500/50'}`}
                                        title={`${isVacant ? 'Vacant' : 'Occupied'}: ${tenancy.suite} - ${tenancy.size_sqm}sqm`}
                                    >
                                       <span className="truncate px-1">{tenancy.suite}</span>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

export default StackPlan;