
import React, { useState } from 'react';
import { Building } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';

export default function AddBuildingForm({ open, onOpenChange, onFinished }) {
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    type: 'Office',
    grade: 'Not Rated',
    owner: '',
    nabers_rating: '',
    image_url: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await Building.create(formData);
      alert('Building added successfully!');
      onFinished();
      onOpenChange(false); // Close dialog on success
    } catch (error) {
      console.error('Failed to add building:', error);
      alert('Error: Could not add building.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-gray-900/80 z-50 flex items-center justify-center p-4" onClick={() => onOpenChange(false)}>
        <div className="orbit-card w-full max-w-2xl" onClick={e => e.stopPropagation()}>
            <div className="p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Add New Building</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name" className="text-gray-300">Building Name</Label>
                      <Input id="name" value={formData.name} onChange={e => handleInputChange('name', e.target.value)} required className="orbit-input text-white"/>
                    </div>
                    <div>
                      <Label htmlFor="address" className="text-gray-300">Address</Label>
                      <Input id="address" value={formData.address} onChange={e => handleInputChange('address', e.target.value)} required className="orbit-input text-white"/>
                    </div>
                  </div>
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="type" className="text-gray-300">Type</Label>
                      <Select value={formData.type} onValueChange={v => handleInputChange('type', v)}>
                        <SelectTrigger id="type" className="orbit-input text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Office">Office</SelectItem>
                          <SelectItem value="Industrial">Industrial</SelectItem>
                          <SelectItem value="Mixed-Use">Mixed-Use</SelectItem>
                          <SelectItem value="Retail">Retail</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {formData.type === 'Office' && (
                      <div>
                        <Label htmlFor="grade" className="text-gray-300">Grade</Label>
                         <Select value={formData.grade} onValueChange={v => handleInputChange('grade', v)}>
                          <SelectTrigger id="grade" className="orbit-input text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                              <SelectItem value="Premium">Premium</SelectItem>
                              <SelectItem value="A">A</SelectItem>
                              <SelectItem value="B">B</SelectItem>
                              <SelectItem value="C">C</SelectItem>
                              <SelectItem value="Not Rated">Not Rated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="owner" className="text-gray-300">Owner</Label>
                        <Input id="owner" value={formData.owner} onChange={e => handleInputChange('owner', e.target.value)} className="orbit-input text-white"/>
                      </div>
                      <div>
                        <Label htmlFor="nabers_rating" className="text-gray-300">NABERS Rating</Label>
                        <Input id="nabers_rating" value={formData.nabers_rating} onChange={e => handleInputChange('nabers_rating', e.target.value)} className="orbit-input text-white"/>
                      </div>
                  </div>
                  <div>
                    <Label htmlFor="image_url" className="text-gray-300">Image URL</Label>
                    <Input id="image_url" value={formData.image_url} onChange={e => handleInputChange('image_url', e.target.value)} className="orbit-input text-white"/>
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="text-white border-gray-600 hover:bg-gray-800">Cancel</Button>
                    <Button type="submit" disabled={isSubmitting} className="bg-orange-500 hover:bg-orange-600 text-white font-medium">
                      {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : null}
                      Add Building
                    </Button>
                  </div>
                </form>
            </div>
        </div>
    </div>
  );
}
