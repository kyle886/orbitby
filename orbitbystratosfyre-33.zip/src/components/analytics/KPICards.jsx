import React from 'react';
import { TrendingUp, TrendingDown, Users, Building2, Clock, CheckCircle, DollarSign, Target } from 'lucide-react';

const TrendIndicator = ({ change, changeType }) => {
  if (!change) return null;
  
  const isPositive = changeType === 'positive';
  const colorClass = isPositive ? 'text-success' : 'text-danger';
  const Icon = isPositive ? TrendingUp : TrendingDown;
  const symbol = isPositive ? '▲' : '▼';
  
  return (
    <div className={`flex items-center gap-1 mt-2 text-xs ${colorClass}`}>
      <span className="font-medium">{symbol}</span>
      <Icon className="w-3 h-3" />
      <span>{change}</span>
    </div>
  );
};

const StatCard = ({ title, value, change, changeType, icon: Icon, color, subtitle, onClick }) => (
  <div 
    className={`stratos-card cursor-pointer transition-all duration-ui-extended hover:scale-105 p-6 ${onClick ? 'hover:shadow-lg' : ''}`}
    onClick={onClick}
  >
    <div className="flex items-start justify-between">
      <div className="flex-1">
        <p className="small text-onDark-mute mb-3">{title}</p>
        <p className="text-3xl font-bold text-onDark-strong mb-1">{value}</p>
        {subtitle && (
          <p className="text-xs text-onDark-mute mb-2">{subtitle}</p>
        )}
        <TrendIndicator change={change} changeType={changeType} />
      </div>
      <div className={`p-3 rounded-lg ${color} flex-shrink-0`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
    </div>
  </div>
);

export default function KPICards({ data }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <StatCard
        title="Active Clients"
        value={data.activeClients || 0}
        change="+12%"
        changeType="positive"
        icon={Users}
        color="bg-viz-tertiary"
      />
      
      <StatCard
        title="Properties Submitted"
        value={data.totalSubmissions || 0}
        change="+8%"
        changeType="positive"
        icon={Building2}
        color="bg-success"
      />
      
      <StatCard
        title="Avg. Response Time"
        value={`${data.avgResponseTime || 0}h`}
        change="▼ 15% improvement"
        changeType="positive"
        icon={Clock}
        color="bg-viz-quinary"
      />
      
      <StatCard
        title="Conversion Rate"
        value={`${data.conversionRate || 0}%`}
        subtitle="Brief to execution"
        change="+2.3%"
        changeType="positive"
        icon={Target}
        color="bg-viz-primary"
      />
      
      <StatCard
        title="Deals Closed"
        value={data.dealsCompleted || 0}
        subtitle="This quarter"
        icon={CheckCircle}
        color="bg-success"
      />
      
      <StatCard
        title="Total Deal Value"
        value={`$${((data.totalDealValue || 0) / 1000000).toFixed(1)}M`}
        subtitle="Annual lease value"
        change="+23%"
        changeType="positive"
        icon={DollarSign}
        color="bg-viz-quaternary"
      />
      
      <StatCard
        title="Avg. Deal Size"
        value={`${data.avgDealSize || 0} sqm`}
        subtitle="vs industry: 1,200 sqm"
        icon={Building2}
        color="bg-viz-tertiary"
      />
      
      <StatCard
        title="Client Satisfaction"
        value={`${data.clientSatisfaction || 0}/5`}
        subtitle="Feedback surveys"
        change="Excellent"
        changeType="positive"
        icon={Users}
        color="bg-viz-secondary"
      />
    </div>
  );
}