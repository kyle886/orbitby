import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Building2, 
  MapPin, 
  Square, 
  DollarSign, 
  Car,
  ExternalLink,
  Clock,
  Star
} from "lucide-react";

export default function PropertyScanCard({ property, onSubmitToClient, onReject }) {
  const getSourceBadgeColor = (source) => {
    switch(source) {
      case 'realcommercial': return 'bg-blue-100 text-blue-700';
      case 'commercialrealestate': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getSourceName = (source) => {
    switch(source) {
      case 'realcommercial': return 'RealCommercial';
      case 'commercialrealestate': return 'CommercialRealEstate';
      default: return source;
    }
  };

  return (
    <div className="amplifyre-card hover:scale-105 transition-all duration-200">
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-2">
            <div className="amplifyre-button p-2 bg-gradient-to-br from-yellow-400 to-yellow-500">
              <Building2 className="w-4 h-4 text-blue-800" />
            </div>
            <Badge className={`amplifyre-button border-0 ${getSourceBadgeColor(property.source_portal)}`}>
              {getSourceName(property.source_portal)}
            </Badge>
          </div>
          
          <div className="flex items-center gap-2">
            {property.is_new_since_brief && (
              <Badge className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-blue-800 border-0 flex items-center gap-1">
                <Star className="w-3 h-3" />
                New Since Brief
              </Badge>
            )}
            
            {property.match_score && (
              <div className="amplifyre-button px-3 py-1 text-sm font-medium text-blue-700">
                {property.match_score}% match
              </div>
            )}
          </div>
        </div>

        <h3 className="text-xl font-bold text-blue-800 mb-2">{property.property_title}</h3>
        
        <div className="flex items-center gap-2 text-blue-600 mb-4">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">{property.address}</span>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          {property.floor_area_sqm && (
            <div className="flex items-center gap-2">
              <Square className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium">{property.floor_area_sqm} sqm</span>
            </div>
          )}
          
          {property.rental_rate_sqm && (
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium">${property.rental_rate_sqm}/sqm</span>
            </div>
          )}
          
          {property.parking_spaces && (
            <div className="flex items-center gap-2">
              <Car className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium">{property.parking_spaces} spaces</span>
            </div>
          )}
          
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium">
              Found {new Date(property.discovered_date).toLocaleDateString()}
            </span>
          </div>
        </div>

        {property.building_grade && (
          <div className="px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-sm font-medium mb-4 inline-block">
            Grade {property.building_grade}
          </div>
        )}

        {property.agent_name && (
          <div className="mb-4 text-sm text-blue-600">
            <p className="font-medium">{property.agent_name}</p>
            <p>{property.agent_company}</p>
          </div>
        )}

        <div className="flex justify-between items-center pt-4 border-t border-blue-100">
          <a 
            href={property.external_url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="amplifyre-button text-blue-600 hover:text-blue-700 px-4 py-2 text-sm flex items-center gap-1"
          >
            <ExternalLink className="w-4 h-4" />
            View Original
          </a>
          
          <div className="flex gap-2">
            <Button 
              variant="outline"
              size="sm"
              onClick={() => onReject(property.id)}
              className="amplifyre-button text-red-600 hover:text-red-700"
            >
              Not Suitable
            </Button>
            <Button 
              size="sm"
              onClick={() => onSubmitToClient(property.id)}
              className="amplifyre-button bg-gradient-to-r from-yellow-400 to-yellow-500 text-blue-800 hover:from-yellow-300 hover:to-yellow-400"
            >
              Submit to Client
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}