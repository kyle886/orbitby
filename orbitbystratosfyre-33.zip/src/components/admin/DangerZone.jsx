import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { purgeTestData } from '@/api/functions';
import { AlertTriangle } from 'lucide-react';

export function DangerZone() {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handlePurge = async () => {
    setLoading(true);
    try {
      const { data } = await purgeTestData({ confirm: text });
      toast({
        title: "Test Data Purged",
        description: `Successfully deleted ${data.deleted} items.`,
      });
      setText('');
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Purge Failed",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-red-900/20 border border-red-700/50 p-4 rounded-xl">
      <h4 className="font-semibold text-red-400 mb-2 flex items-center gap-2"><AlertTriangle className="w-5 h-5"/> Danger Zone</h4>
      <div className="text-red-300 text-sm mb-3">Type <code>PURGE-TEST-DATA</code> to delete all records marked as test data. This action is irreversible.</div>
      <div className="flex flex-col sm:flex-row gap-2 items-center">
        <Input 
          className="bg-gray-900/60 border-red-800 focus:ring-red-500" 
          value={text} 
          onChange={e => setText(e.target.value)} 
          placeholder="PURGE-TEST-DATA"
        />
        <Button 
          variant="destructive" 
          disabled={text !== 'PURGE-TEST-DATA' || loading} 
          onClick={handlePurge}
          className="w-full sm:w-auto"
        >
          {loading ? "Purging..." : "Purge Test Data"}
        </Button>
      </div>
    </div>
  );
}