import React, { useState } from "react";
import { toast } from "@/components/system/Toaster";
import { Button } from "@/components/ui/button";

export default function ActionButton({ action, onResult }) {
  const [busy, setBusy] = useState(false);
  const f = window.base44?.functions || {};

  async function handle() {
    let payload;
    if (action.confirm) {
      const phrase = prompt(`Type ${action.confirm} to confirm`);
      if (phrase !== action.confirm) return;
      payload = { confirm: phrase };
    }

    setBusy(true);
    const t0 = performance.now();
    try {
      let r;

      if (action.primaryFn && f.runAndLogAction) {
        // Preferred: wrapper exists -> server calls + logs atomically
        r = await f.runAndLogAction({ key: action.key, label: action.label, fn: action.primaryFn, args: payload });
      } else if (action.primaryFn && f[action.primaryFn]) {
        // Fallback: call target directly, then client-log
        r = await f[action.primaryFn](payload || {});
        await f.logOpsEvent?.({
          key: action.key, label: action.label,
          result: { ...(r || {}), durationMs: Math.round(performance.now() - t0) }
        });
      } else if (action.run) {
        // Custom runner (used by composite actions)
        r = await action.run(payload);
        await f.logOpsEvent?.({
          key: action.key, label: action.label,
          result: { ...(r || {}), durationMs: Math.round(performance.now() - t0) }
        });
      } else {
        throw new Error("Action not wired: no primaryFn or custom runner");
      }

      const who = r?.__log?.userEmail || r?.__log?.userName || null;
      const when = r?.__log?.at ? new Date(r.__log.at).toLocaleString() : "";
      const dur = r?.__log?.durationMs != null ? `${r.__log.durationMs} ms` : "";
      toast.success(action.label, { msg: [who, when, dur].filter(Boolean).join(" • ") });
      onResult?.(r);
      if (r?.url) window.open(r.url, "_blank");
    } catch (e) {
      toast.error(`${action.label}: ${e?.message || String(e)}`);
      await f.logOpsEvent?.({ key: action.key, label: action.label, error: e?.message || String(e) });
    } finally {
      setBusy(false);
    }
  }
  
  const isAvailable = (action.primaryFn && (f[action.primaryFn] || f.runAndLogAction)) || action.run;
  const disabled = busy || !isAvailable;

  return (
    <Button
      className="orbit-button w-full"
      disabled={disabled}
      onClick={handle}
      title={disabled && !busy ? "Function not available in this environment" : action.desc}
    >
      {busy ? "Running…" : action.label}
    </Button>
  );
}