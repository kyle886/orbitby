import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import ActionButton from "./ActionButton";
import { ACTIONS, getAction } from "./registry";

export default function ActionGrid({ groups }) {
  return (
    <div className="space-y-6">
      {groups.map(g => (
        <Card key={g.title} className="orbit-card">
          <CardHeader>
            <CardTitle className="text-white">{g.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {g.keys.map(k => {
                const a = getAction(k);
                return a ? <ActionButton key={k} action={a} /> : null;
              })}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// Default preset used by multiple pages
export const DEFAULT_GROUPS = [
  { title:"System Health & Maintenance", keys:["dbHealth","dedupeSitePages","repairListingPhotos","purgeTestData"] },
  { title:"Data Foundation Quick Fixes", keys:["backfillGeocodes","repairBuildingPhotos","kickoffListings","applyIndexes"] },
  { title:"System Reports & Tests", keys:["testDataCount","integrity","geoCoverage","imageCompleteness","indexAdvisor","errorTrend","chartShape","storageUsage","summaryPDF"] },
];