
/**
 * Admin Action Registry
 * - Each action renders as a tile/button on System Reports & Tests
 * - Runner logic (in the page) prefers server wrapper runAndLogAction(fn,args),
 *   falls back to direct function call, or client-run handler if provided.
 *
 * Fields:
 *  - key: unique id
 *  - label: button label
 *  - primaryFn: backend function name (Base44 function) to run
 *  - confirm: optional confirmation phrase users must type
 *  - sampleKeys: optional array of keys to pull into a toast summary
 *  - clientRun: optional async () => result   (used if no backend function)
 */

// Single source of truth for System Reports & Tests tiles.
// Each item: { key, label, primaryFn, confirm?, sampleKeys?, clientRun? }
const QuickFixes = [
  { key: "repairBuildingPhotos", label: "Repair Building Photos", primaryFn: "backfillAllListingPhotos", sampleKeys: ["ok","updated"] },
  { key: "backfillGeocodes",     label: "Backfill Building Geocodes", primaryFn: "geocodeAddress", sampleKeys: ["ok","updated"] },
  { key: "scanSydney",           label: "Wombot (Sydney)", primaryFn: "marketIntelligenceScan", sampleKeys: ["ok","created","updated","source"] },
  { key: "applyIndexes",         label: "Apply Suggested Indexes", primaryFn: "applySuggestedIndexes", sampleKeys: ["ok","indexesApplied"] },
  { key: "dedupeSitePages",      label: "Dedupe Site Pages", primaryFn: "duplicateScanner", sampleKeys: ["ok","deduped"] },
  { key: "purgeTestData",        label: "Purge Test Data", confirm: "PURGE-TEST-DATA", primaryFn: "purgeTestData" },
];

const Audits = [
  { key: "auditJson",    label: "Audit: JSON Parse",         primaryFn: "repoAuditJson",    sampleKeys: ["ok","exitCode","url"] },
  { key: "auditImports", label: "Audit: Imports & Paths",    primaryFn: "repoAuditImports", sampleKeys: ["ok","exitCode","url"] },
  { key: "auditRoutes",  label: "Audit: Router Coverage",    primaryFn: "repoAuditRoutes",  sampleKeys: ["ok","missingCount","url"] },
  { key: "auditActions", label: "Audit: Actions ↔ Functions",primaryFn: "repoAuditActions", sampleKeys: ["ok","missingCount","url"] },
  { key: "auditCss",     label: "Audit: CSS/JSX Style",      primaryFn: "repoAuditCss",     sampleKeys: ["ok","issues","url"] },
  { key: "auditEslint",  label: "Audit: ESLint",             primaryFn: "repoAuditEslint",  sampleKeys: ["ok","exitCode","url"] },
  { key: "auditAll",     label: "Audit: Run All",            primaryFn: "repoAuditAll",     sampleKeys: ["ok","sectionsPassed","sectionsFailed"] },
];

const Reports = [
  { key: "dbHealth",        label: "Run DB Health Check", primaryFn: "dbHealthReport", sampleKeys: ["ok"] },
  { key: "exportSummary",   label: "Export Summary (PDF)", primaryFn: "exportSummaryPdf", sampleKeys: ["url"] },
  { key: "geoCoverage",     label: "Geo Coverage", primaryFn: "system_geoCoverageReport", sampleKeys: ["ok"] },
  { key: "imageCompleteness",label: "Image Completeness", primaryFn: "system_imageCompletenessReport", sampleKeys: ["ok", "totals", "percent"] },
  { key: "indexAdvisor",    label: "Index Advisor", primaryFn: "system_indexAdvisor", sampleKeys: ["ok"] },
  { key: "errorTrend",      label: "Error Trend (14d)", primaryFn: "system_errorTrendReport", sampleKeys: ["ok"] },
  { key: "chartShape",      label: "Chart Data Check", primaryFn: "system_chartShapeReport", sampleKeys: ["ok"] },
  { key: "storageUsage",    label: "Storage Usage", primaryFn: "system_storageUsageReport", sampleKeys: ["ok"] },
  { key: "integrity",       label: "Integrity Check", primaryFn: "system_integrityReport", sampleKeys: ["ok", "listingWithoutBuilding", "docWithoutLink"] },
  { key: "testDataCount",   label: "Test Data Count", primaryFn: "system_testDataCount", sampleKeys: ["total"] },
];

// This is the new comprehensive registry of action groups
const ALL_ACTION_GROUPS = [
  { title: "Quick Fixes", items: QuickFixes },
  { title: "Audits",      items: Audits },
  { title: "Reports",     items: Reports },
];

// Export the comprehensive registry as the default export
export default ALL_ACTION_GROUPS;

/**
 * Retrieves an action definition by its unique key.
 * @param {string} key - The unique key of the action.
 * @returns {object|undefined} The action object if found, otherwise undefined.
 */
export function getAction(key) {
  for (const group of ALL_ACTION_GROUPS) {
    const action = group.items.find(a => a.key === key);
    if (action) return action;
  }
  return undefined;
}
