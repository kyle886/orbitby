import React from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

export default function AnalyticsCharts({ summaryStats, config }) {

  const briefMatchData = [
    { name: 'On Brief', value: summaryStats.onBrief },
    { name: 'Partial Match', value: summaryStats.partialMatch },
    { name: 'Off Brief', value: summaryStats.offBrief },
  ].filter(d => d.value > 0);

  const fitoutData = [
    { name: 'Fitted', value: summaryStats.fitted },
    { name: 'Unfitted/Refurbished', value: summaryStats.unfitted },
  ].filter(d => d.value > 0);
  
  const sizeData = [
    { name: 'Min Size', sqm: summaryStats.minSize },
    { name: 'Avg Size', sqm: summaryStats.avgSize },
    { name: 'Max Size', sqm: summaryStats.maxSize },
  ];

  return (
    <div className="space-y-12">
      <div className="grid grid-cols-2 gap-8 items-center">
        <div>
          <h3 className="text-xl font-semibold text-center mb-4">Brief Match Analysis</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={briefMatchData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                {briefMatchData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
        
        {config.includeFitoutStatus && (
        <div>
          <h3 className="text-xl font-semibold text-center mb-4">Fitout Status</h3>
           <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={fitoutData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                 {fitoutData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index + 1 % COLORS.length]} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
        )}
      </div>

      {config.includeSizeAnalysis && (
        <div>
          <h3 className="text-xl font-semibold text-center mb-4">Size Analysis (SQM)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={sizeData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="sqm" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}