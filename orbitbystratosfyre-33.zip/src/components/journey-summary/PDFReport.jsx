import React from 'react';
import AnalyticsCharts from './AnalyticsCharts';
import { Building2, Calendar, CheckSquare, MapPin, Square, Users, DollarSign, ParkingCircle } from "lucide-react";

const PageBreak = () => <div className="break-after-page"></div>;

const ReportPage = ({ children }) => (
  <section className="p-12 bg-white min-h-[29.7cm] w-[21cm] shadow-xl">
    {children}
  </section>
);

export default function PDFReport({ brief, sourcedProperties, shortlistedProperties, config }) {
  if (!brief) return null;

  const summaryStats = {
    totalResponses: sourcedProperties.length,
    onBrief: sourcedProperties.filter(p => p.match_score >= 80).length,
    partialMatch: sourcedProperties.filter(p => p.match_score >= 50 && p.match_score < 80).length,
    offBrief: sourcedProperties.filter(p => p.match_score < 50).length,
    fitted: sourcedProperties.filter(p => p.fitout_status?.toLowerCase().includes('fit')).length,
    unfitted: sourcedProperties.filter(p => p.fitout_status?.toLowerCase().includes('shell') || p.fitout_status?.toLowerCase().includes('refurb')).length,
    minSize: Math.min(...sourcedProperties.map(p => p.size_sqm)),
    maxSize: Math.max(...sourcedProperties.map(p => p.size_sqm)),
    avgSize: (sourcedProperties.reduce((acc, p) => acc + p.size_sqm, 0) / sourcedProperties.length).toFixed(0),
  };
  
  const activeDate = brief.updated_date; // Placeholder for when brief went active

  return (
    <div className="font-sans text-gray-800">
      {/* Cover Page */}
      <ReportPage>
        <div className="flex flex-col h-full">
          <div className="flex-grow flex flex-col justify-center items-center text-center">
            <div className="w-24 h-24 bg-blue-600 text-white flex items-center justify-center rounded-full mb-8">
              <Building2 className="w-12 h-12"/>
            </div>
            <h1 className="text-5xl font-bold text-blue-800 mb-4">{brief.company_name}</h1>
            <p className="text-2xl text-gray-600">Commercial Real Estate Journey Summary</p>
            <p className="text-lg text-gray-500 mt-2">Brief Reference: {brief.brief_reference_code}</p>
          </div>
          <div className="text-center pb-8">
            <p className="text-lg font-semibold text-blue-700">Amplifyre</p>
            <p className="text-sm text-gray-500">Report Generated: {new Date().toLocaleDateString()}</p>
          </div>
        </div>
      </ReportPage>
      <PageBreak />

      {/* Requirement Summary */}
      <ReportPage>
        <h2 className="text-3xl font-bold text-blue-800 border-b-4 border-yellow-400 pb-2 mb-8">1. The Requirement</h2>
        <div className="space-y-6 text-lg">
            <p>Requirement confirmed on <span className="font-bold">{new Date(brief.created_date).toLocaleDateString()}</span> for <span className="font-bold">{brief.company_name}</span>.</p>
            <div className="grid grid-cols-2 gap-x-12 gap-y-6 p-6 border rounded-lg">
                <div className="flex items-center gap-4"><Users className="w-8 h-8 text-blue-600"/><span>Property Type: <span className="font-semibold">{brief.property_type.charAt(0).toUpperCase() + brief.property_type.slice(1)}</span></span></div>
                <div className="flex items-center gap-4"><Square className="w-8 h-8 text-blue-600"/><span>Size: <span className="font-semibold">{brief.min_floor_area} - {brief.max_floor_area} sqm</span></span></div>
                <div className="flex items-center gap-4"><MapPin className="w-8 h-8 text-blue-600"/><span>Suburbs: <span className="font-semibold">{brief.preferred_suburbs.join(', ')}</span></span></div>
                <div className="flex items-center gap-4"><DollarSign className="w-8 h-8 text-blue-600"/><span>Budget: <span className="font-semibold">Up to ${brief.max_rental_total.toLocaleString()}/yr</span></span></div>
                <div className="flex items-center gap-4"><ParkingCircle className="w-8 h-8 text-blue-600"/><span>Parking: <span className="font-semibold">Min {brief.min_parking} spaces</span></span></div>
                <div className="flex items-center gap-4"><Calendar className="w-8 h-8 text-blue-600"/><span>Target Date: <span className="font-semibold">{new Date(brief.required_date).toLocaleDateString()}</span></span></div>
            </div>
            {brief.required_amenities?.length > 0 && 
              <div>
                <h3 className="font-semibold text-xl mb-2">Key Amenities:</h3>
                <ul className="list-disc list-inside grid grid-cols-2 gap-2">
                  {brief.required_amenities.map(a => <li key={a}>{a}</li>)}
                </ul>
              </div>
            }
        </div>
      </ReportPage>
      <PageBreak />
      
      {/* Sourcing Summary */}
      {config.includeAnalytics && (
        <>
          <ReportPage>
            <h2 className="text-3xl font-bold text-blue-800 border-b-4 border-yellow-400 pb-2 mb-8">2. Market Sourcing Summary</h2>
            <p className="text-lg mb-8">Brief issued to market on <span className="font-bold">{new Date(activeDate).toLocaleDateString()}</span>. A total of <span className="font-bold">{summaryStats.totalResponses}</span> options were sourced and reviewed.</p>
            <AnalyticsCharts summaryStats={summaryStats} config={config} />
          </ReportPage>
          <PageBreak />
        </>
      )}

      {/* Shortlisted Properties */}
      {config.includeShortlist && shortlistedProperties.length > 0 && (
        <>
          <ReportPage>
            <h2 className="text-3xl font-bold text-blue-800 border-b-4 border-yellow-400 pb-2 mb-8">3. Shortlisted Options</h2>
            <p className="text-lg">The following <span className="font-bold">{shortlistedProperties.length} properties</span> have been identified as the preferred options for further consideration.</p>
            <div className="mt-8 space-y-4">
              {shortlistedProperties.map(p => (
                <div key={p.id} className="p-4 border rounded-lg">
                  <p className="text-xl font-semibold">{p.property_title}</p>
                  <p className="text-gray-600">{p.address}</p>
                </div>
              ))}
            </div>
          </ReportPage>
          <PageBreak />
          
          {shortlistedProperties.map(prop => (
            <React.Fragment key={prop.id}>
              <ReportPage>
                <h3 className="text-2xl font-bold text-blue-700">{prop.property_title}</h3>
                <p className="text-lg text-gray-600 mb-6">{prop.address}</p>
                
                <div className="grid grid-cols-3 gap-6 mb-8 text-center">
                  <div className="p-4 bg-blue-50 rounded-lg"><p className="text-2xl font-bold">{prop.floor_area_sqm}</p><p>SQM</p></div>
                  <div className="p-4 bg-blue-50 rounded-lg"><p className="text-2xl font-bold">${prop.rental_rate_sqm}</p><p>per SQM</p></div>
                  <div className="p-4 bg-blue-50 rounded-lg"><p className="text-2xl font-bold">${prop.total_monthly_cost?.toLocaleString()}</p><p>per Month</p></div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                    {prop.images && prop.images[0] && <img src={prop.images[0]} alt="Property" className="rounded-lg object-cover h-64 w-full" />}
                    <div className="space-y-4">
                        <p><span className="font-semibold">Grade:</span> {prop.building_grade}</p>
                        <p><span className="font-semibold">Parking:</span> {prop.parking_spaces} spaces</p>
                        <p><span className="font-semibold">Available:</span> {new Date(prop.availability_date).toLocaleDateString()}</p>
                        <div>
                          <h4 className="font-semibold">Amenities:</h4>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {prop.amenities?.map(a => <span key={a} className="bg-gray-200 px-2 py-1 text-sm rounded">{a}</span>)}
                          </div>
                        </div>
                    </div>
                </div>
                
                <div className="mt-8">
                    <h4 className="font-semibold text-lg mb-2">Amplifyre Notes</h4>
                    <p className="text-gray-700 p-4 border bg-gray-50 rounded-lg">{prop.amplifyre_notes}</p>
                </div>

              </ReportPage>
              <PageBreak />

              {prop.images?.length > 1 && (
                <>
                <ReportPage>
                  <h3 className="text-2xl font-bold text-blue-700 mb-6">Photos: {prop.property_title}</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {prop.images.slice(0, 4).map(img => <img key={img} src={img} alt="Property" className="rounded-lg w-full h-64 object-cover"/>)}
                  </div>
                </ReportPage>
                <PageBreak />
                </>
              )}
            </React.Fragment>
          ))}
        </>
      )}
    </div>
  );
}