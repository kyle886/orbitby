import React, { useState, useEffect } from 'react';
import { Search, Building2, Users, FileText, Bookmark, Bell } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { SavedSearch } from '@/api/entities';
import { User } from '@/api/entities';

export default function GlobalSearch() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchType, setSearchType] = useState('global');
  const [results, setResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [savedSearches, setSavedSearches] = useState([]);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [saveSearchName, setSaveSearchName] = useState('');

  useEffect(() => {
    loadSavedSearches();
  }, []);

  const loadSavedSearches = async () => {
    try {
      const user = await User.me();
      const searches = await SavedSearch.filter({ user_email: user.email });
      setSavedSearches(searches || []);
    } catch (error) {
      console.error('Error loading saved searches:', error);
    }
  };

  const performSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      // This would need to be implemented as a backend search endpoint
      // For now, we'll simulate the search structure
      const mockResults = [
        {
          type: 'building',
          id: '1',
          title: 'Aurora Place',
          subtitle: '88 Phillip Street, Sydney',
          description: 'Premium office building with multiple vacancies',
          relevance: 0.95
        },
        {
          type: 'submission',
          id: '2',
          title: 'Level 15 - Premium Office Space',
          subtitle: 'Sydney CBD - 1,250 sqm',
          description: 'Recently submitted property matching multiple briefs',
          relevance: 0.87
        },
        {
          type: 'client',
          id: '3',
          title: 'TechCorp Australia',
          subtitle: 'Active client - Software industry',
          description: 'Looking for 800-1200 sqm in Sydney CBD',
          relevance: 0.78
        }
      ];
      
      setResults(mockResults);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const saveCurrentSearch = async () => {
    if (!saveSearchName.trim()) return;
    
    try {
      const user = await User.me();
      const searchCriteria = {
        query: searchQuery,
        type: searchType,
        timestamp: new Date().toISOString()
      };

      await SavedSearch.create({
        user_email: user.email,
        search_name: saveSearchName,
        search_type: searchType,
        search_criteria: searchCriteria,
        is_alert_enabled: false
      });

      setSaveSearchName('');
      setShowSaveDialog(false);
      loadSavedSearches();
    } catch (error) {
      console.error('Error saving search:', error);
    }
  };

  const executeSearch = (e) => {
    e.preventDefault();
    performSearch();
  };

  const getResultIcon = (type) => {
    switch (type) {
      case 'building': return Building2;
      case 'submission': return FileText;
      case 'client': return Users;
      default: return FileText;
    }
  };

  const getResultColor = (type) => {
    switch (type) {
      case 'building': return 'bg-blue-100 text-blue-800';
      case 'submission': return 'bg-green-100 text-green-800';
      case 'client': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Form */}
      <div className="orbit-card p-6">
        <form onSubmit={executeSearch} className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search buildings, submissions, clients, briefs..."
                className="orbit-input pl-10 text-white"
              />
            </div>
            <Select value={searchType} onValueChange={setSearchType}>
              <SelectTrigger className="w-40 orbit-input text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="global">All</SelectItem>
                <SelectItem value="buildings">Buildings</SelectItem>
                <SelectItem value="submissions">Submissions</SelectItem>
                <SelectItem value="clients">Clients</SelectItem>
              </SelectContent>
            </Select>
            <Button type="submit" disabled={isSearching} className="orbit-button bg-orange-500 hover:bg-orange-600">
              {isSearching ? 'Searching...' : 'Search'}
            </Button>
          </div>
          
          {searchQuery && (
            <div className="flex gap-2">
              <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="text-white border-gray-600">
                    <Bookmark className="w-4 h-4 mr-2" />
                    Save Search
                  </Button>
                </DialogTrigger>
                <DialogContent className="orbit-card text-white">
                  <DialogHeader>
                    <DialogTitle>Save Search</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Input
                      value={saveSearchName}
                      onChange={(e) => setSaveSearchName(e.target.value)}
                      placeholder="Enter search name..."
                      className="orbit-input text-white"
                    />
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setShowSaveDialog(false)} className="text-white border-gray-600">
                        Cancel
                      </Button>
                      <Button onClick={saveCurrentSearch} className="bg-orange-500 hover:bg-orange-600">
                        Save
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </form>
      </div>

      {/* Saved Searches */}
      {savedSearches.length > 0 && (
        <div className="orbit-card p-6">
          <h3 className="text-lg font-bold text-white mb-4">Saved Searches</h3>
          <div className="flex flex-wrap gap-2">
            {savedSearches.map(search => (
              <Button
                key={search.id}
                variant="outline"
                size="sm"
                onClick={() => {
                  setSearchQuery(search.search_criteria.query || '');
                  setSearchType(search.search_type);
                  performSearch();
                }}
                className="text-white border-gray-600 hover:bg-gray-800"
              >
                {search.search_name}
                {search.is_alert_enabled && <Bell className="w-3 h-3 ml-2" />}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Search Results */}
      {results.length > 0 && (
        <div className="orbit-card p-6">
          <h3 className="text-lg font-bold text-white mb-4">
            Search Results ({results.length})
          </h3>
          <div className="space-y-3">
            {results.map(result => {
              const IconComponent = getResultIcon(result.type);
              return (
                <div key={result.id} className="bg-gray-800/50 p-4 rounded-lg hover:bg-gray-800 cursor-pointer transition-colors">
                  <div className="flex items-start gap-3">
                    <IconComponent className="w-5 h-5 text-gray-400 mt-1" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-white">{result.title}</h4>
                        <Badge className={getResultColor(result.type)}>
                          {result.type}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-300 mb-1">{result.subtitle}</p>
                      <p className="text-sm text-gray-400">{result.description}</p>
                    </div>
                    <div className="text-xs text-gray-500">
                      {Math.round(result.relevance * 100)}% match
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}