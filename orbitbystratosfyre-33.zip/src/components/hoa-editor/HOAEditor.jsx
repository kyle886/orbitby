import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  MessageSquare, 
  Save, 
  Download, 
  CheckCircle, 
  AlertCircle,
  Lightbulb,
  Edit3,
  Eye,
  FileText
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { InvokeLLM } from '@/api/integrations';

export default function HOAEditor({ 
  rfpResponse, 
  onSave, 
  onApprove, 
  readOnly = false 
}) {
  const [hoaText, setHoaText] = useState(rfpResponse?.heads_of_agreement_text || '');
  const [aiSuggestions, setAiSuggestions] = useState(rfpResponse?.ai_suggestions || []);
  const [selectedText, setSelectedText] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [loading, setLoading] = useState(false);
  const [changes, setChanges] = useState([]);
  const textareaRef = useRef(null);
  const { toast } = useToast();

  useEffect(() => {
    if (rfpResponse?.heads_of_agreement_text) {
      setHoaText(rfpResponse.heads_of_agreement_text);
    }
  }, [rfpResponse]);

  const handleTextSelection = () => {
    const textarea = textareaRef.current;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const selected = hoaText.substring(start, end);
      setSelectedText(selected);
    }
  };

  const generateAISuggestions = async () => {
    setLoading(true);
    try {
      const prompt = `Analyze this Heads of Agreement text and provide specific suggestions for improvements, risk mitigation, and better terms for the tenant. Focus on rent, incentives, lease terms, and conditions.

HOA Text:
${hoaText}

Selected portion (if any): ${selectedText}

Provide 3-5 specific, actionable suggestions with brief explanations.`;

      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  original_text: { type: "string" },
                  suggested_text: { type: "string" },
                  explanation: { type: "string" },
                  risk_level: { type: "string", enum: ["low", "medium", "high"] },
                  category: { type: "string", enum: ["rent", "incentives", "terms", "conditions", "legal"] }
                }
              }
            }
          }
        }
      });

      setAiSuggestions(response.suggestions || []);
      setShowSuggestions(true);
      toast({ title: "AI suggestions generated", description: `${response.suggestions?.length || 0} recommendations ready` });
    } catch (error) {
      console.error('Failed to generate AI suggestions:', error);
      toast({ 
        variant: "destructive", 
        title: "AI analysis failed", 
        description: "Could not generate suggestions" 
      });
    } finally {
      setLoading(false);
    }
  };

  const applySuggestion = (suggestion) => {
    if (!suggestion.original_text) {
      // If no original text, append to end
      const newText = hoaText + '\n\n' + suggestion.suggested_text;
      setHoaText(newText);
    } else {
      // Replace original text with suggested text
      const newText = hoaText.replace(suggestion.original_text, suggestion.suggested_text);
      setHoaText(newText);
    }
    
    // Track the change
    setChanges([...changes, {
      type: 'ai_suggestion',
      original: suggestion.original_text,
      suggested: suggestion.suggested_text,
      explanation: suggestion.explanation,
      timestamp: new Date().toISOString()
    }]);

    toast({ title: "Suggestion applied", description: "Text updated with AI recommendation" });
  };

  const insertRedline = (text, type = 'addition') => {
    const cursor = textareaRef.current?.selectionStart || hoaText.length;
    const before = hoaText.substring(0, cursor);
    const after = hoaText.substring(cursor);
    
    let redlineText;
    if (type === 'addition') {
      redlineText = `[ADDED: ${text}]`;
    } else if (type === 'deletion') {
      redlineText = `[DELETED: ${text}]`;
    } else {
      redlineText = `[AMENDED: ${text}]`;
    }
    
    const newText = before + redlineText + after;
    setHoaText(newText);
    
    setChanges([...changes, {
      type: 'redline',
      action: type,
      text,
      timestamp: new Date().toISOString()
    }]);
  };

  const saveHOA = async () => {
    try {
      await onSave({
        heads_of_agreement_text: hoaText,
        ai_suggestions: aiSuggestions,
        changes: changes
      });
      toast({ title: "HOA saved", description: "Changes saved successfully" });
    } catch (error) {
      toast({ 
        variant: "destructive", 
        title: "Save failed", 
        description: "Could not save changes" 
      });
    }
  };

  const approveHOA = async () => {
    try {
      await onApprove({
        heads_of_agreement_text: hoaText,
        ai_suggestions: aiSuggestions,
        changes: changes,
        status: 'accepted'
      });
      toast({ title: "HOA approved", description: "Heads of Agreement has been approved" });
    } catch (error) {
      toast({ 
        variant: "destructive", 
        title: "Approval failed", 
        description: "Could not approve HOA" 
      });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Main HOA Editor */}
      <div className="lg:col-span-2 space-y-4">
        <Card className="shadow-elevated">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center gap-2 text-white">
                <Edit3 className="w-5 h-5" />
                Heads of Agreement Editor
              </CardTitle>
              <div className="flex gap-2">
                {!readOnly && (
                  <>
                    <Button 
                      onClick={generateAISuggestions} 
                      disabled={loading}
                      variant="outline"
                      size="sm"
                    >
                      <Lightbulb className="w-4 h-4 mr-2" />
                      AI Suggestions
                    </Button>
                    <Button onClick={saveHOA} variant="outline" size="sm">
                      <Save className="w-4 h-4 mr-2" />
                      Save
                    </Button>
                  </>
                )}
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Textarea
              ref={textareaRef}
              value={hoaText}
              onChange={(e) => setHoaText(e.target.value)}
              onSelect={handleTextSelection}
              placeholder="Paste or type the Heads of Agreement text here..."
              className="min-h-[500px] font-mono text-sm orbit-input text-white"
              readOnly={readOnly}
            />
            
            {!readOnly && (
              <div className="flex gap-2 mt-4">
                <Button 
                  onClick={() => insertRedline('New text here', 'addition')}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700"
                >
                  Add Text
                </Button>
                <Button 
                  onClick={() => insertRedline(selectedText, 'deletion')}
                  size="sm"
                  className="bg-red-600 hover:bg-red-700"
                  disabled={!selectedText}
                >
                  Delete Selected
                </Button>
                <Button 
                  onClick={() => insertRedline('Amended text here', 'amendment')}
                  size="sm"
                  className="bg-yellow-600 hover:bg-yellow-700"
                >
                  Amend
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Change Log */}
        {changes.length > 0 && (
          <Card className="shadow-elevated">
            <CardHeader>
              <CardTitle className="text-white">Change History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {changes.map((change, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-2 bg-gray-800 rounded-md">
                    <Badge 
                      className={`text-xs ${
                        change.type === 'ai_suggestion' ? 'bg-blue-600' : 
                        change.action === 'addition' ? 'bg-green-600' :
                        change.action === 'deletion' ? 'bg-red-600' : 'bg-yellow-600'
                      }`}
                    >
                      {change.type === 'ai_suggestion' ? 'AI' : change.action}
                    </Badge>
                    <div className="flex-1 text-sm">
                      <p className="text-gray-300">{change.explanation || change.text}</p>
                      <p className="text-xs text-gray-500">
                        {new Date(change.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* AI Suggestions Panel */}
      <div className="space-y-4">
        <Card className="shadow-elevated">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <MessageSquare className="w-5 h-5" />
              AI Suggestions
              {aiSuggestions.length > 0 && (
                <Badge className="bg-blue-600">{aiSuggestions.length}</Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-400 mx-auto"></div>
                <p className="text-sm text-gray-400 mt-2">Analyzing HOA...</p>
              </div>
            ) : aiSuggestions.length > 0 ? (
              <div className="space-y-4">
                {aiSuggestions.map((suggestion, idx) => (
                  <div key={idx} className="p-3 bg-gray-800 rounded-md">
                    <div className="flex items-start justify-between mb-2">
                      <Badge className={`text-xs ${
                        suggestion.risk_level === 'high' ? 'bg-red-600' :
                        suggestion.risk_level === 'medium' ? 'bg-yellow-600' : 'bg-green-600'
                      }`}>
                        {suggestion.category} • {suggestion.risk_level}
                      </Badge>
                      <Button 
                        onClick={() => applySuggestion(suggestion)}
                        size="sm"
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Apply
                      </Button>
                    </div>
                    <p className="text-sm text-gray-300 mb-2">{suggestion.explanation}</p>
                    {suggestion.suggested_text && (
                      <div className="text-xs">
                        <p className="text-gray-500 mb-1">Suggested text:</p>
                        <div className="bg-gray-900 p-2 rounded font-mono">
                          {suggestion.suggested_text}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Lightbulb className="w-12 h-12 mx-auto text-gray-500 mb-2" />
                <p className="text-sm text-gray-400">Select text and click "AI Suggestions" for recommendations</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Approval Actions */}
        {!readOnly && (
          <Card className="shadow-elevated">
            <CardHeader>
              <CardTitle className="text-white">Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button 
                onClick={approveHOA}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Approve HOA
              </Button>
              <Button variant="outline" className="w-full">
                <AlertCircle className="w-4 h-4 mr-2" />
                Request Changes
              </Button>
              <Button variant="outline" className="w-full">
                <FileText className="w-4 h-4 mr-2" />
                Send to Legal
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}