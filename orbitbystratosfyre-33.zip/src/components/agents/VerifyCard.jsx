import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { User } from "@/api/entities";

export default function VerifyCard({ agent, onVerificationComplete }) {
  const [formData, setFormData] = useState({
    name: agent?.first_name && agent?.last_name ? `${agent.first_name} ${agent.last_name}` : '',
    email: agent?.email || '',
    abn: agent?.abn || '',
    licenseNumber: agent?.license_number || ''
  });
  const [verificationResult, setVerificationResult] = useState(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const { toast } = useToast();

  const runVerification = async () => {
    setIsVerifying(true);
    try {
      const { agentVerify } = await import('@/api/functions');
      const response = await agentVerify(formData);
      
      if (response.data.ok) {
        setVerificationResult(response.data);
        
        // Update agent record with verification results
        if (agent?.id) {
          await User.update(agent.id, {
            verification_status: response.data.verified ? 'verified' : 'pending_review',
            verification_score: response.data.score,
            abn: formData.abn,
            license_number: formData.licenseNumber
          });
        }

        toast({ 
          title: response.data.verified ? 'Verification Successful' : 'Manual Review Required',
          description: `Score: ${response.data.score}/100 - ${response.data.recommendation}`,
          variant: response.data.verified ? 'default' : 'destructive'
        });

        if (onVerificationComplete) {
          onVerificationComplete(response.data);
        }
      } else {
        toast({
          variant: "destructive",
          title: "Verification Failed",
          description: response.data.error
        });
      }
    } catch (error) {
      console.error('Verification error:', error);
      toast({
        variant: "destructive",
        title: "Verification Error",
        description: error.message
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const getStatusIcon = (checkName) => {
    if (!verificationResult?.checks) return null;
    
    const passed = verificationResult.checks[checkName];
    if (passed) {
      return <CheckCircle className="w-4 h-4 text-green-400" />;
    } else {
      return <XCircle className="w-4 h-4 text-red-400" />;
    }
  };

  return (
    <Card className="shadow-elevated">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          Agent Verification
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">Full Name</label>
            <div className="flex items-center gap-2">
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Agent full name"
              />
              {getStatusIcon('name_valid')}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">Email</label>
            <div className="flex items-center gap-2">
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="agent@company.com"
              />
              {getStatusIcon('email_present')}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">ABN (optional)</label>
            <div className="flex items-center gap-2">
              <Input
                value={formData.abn}
                onChange={(e) => setFormData({ ...formData, abn: e.target.value })}
                placeholder="12 345 678 901"
                maxLength={14}
              />
              {getStatusIcon('abn_format_valid')}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">License Number (optional)</label>
            <div className="flex items-center gap-2">
              <Input
                value={formData.licenseNumber}
                onChange={(e) => setFormData({ ...formData, licenseNumber: e.target.value })}
                placeholder="RE License #"
              />
              {getStatusIcon('license_present')}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Button 
            onClick={runVerification}
            disabled={isVerifying || !formData.email}
            className="min-w-[120px]"
          >
            {isVerifying ? 'Verifying...' : 'Run Verification'}
          </Button>

          {verificationResult && (
            <div className="flex items-center gap-2">
              <Badge variant={verificationResult.verified ? 'default' : 'destructive'}>
                Score: {verificationResult.score}/100
              </Badge>
              <Badge variant="outline">
                {verificationResult.verified ? 'Verified' : 'Review Required'}
              </Badge>
            </div>
          )}
        </div>

        {verificationResult && (
          <div className="p-3 rounded-lg bg-gray-800/50 border border-white/10">
            <div className="text-sm">
              <div className="font-medium text-white mb-2">Verification Results:</div>
              <div className="text-gray-300 text-xs">
                {verificationResult.recommendation}
              </div>
              
              <div className="mt-3 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span>Email Present</span>
                  {getStatusIcon('email_present')}
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span>Name Valid</span>
                  {getStatusIcon('name_valid')}
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span>ABN Format</span>
                  {getStatusIcon('abn_format_valid')}
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span>License Present</span>
                  {getStatusIcon('license_present')}
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}