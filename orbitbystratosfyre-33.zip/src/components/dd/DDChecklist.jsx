
import React, { useEffect, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle, XCircle, Clock, Plus } from "lucide-react";
import { DDFinding } from "@/api/entities";
import { useToast } from "@/components/ui/use-toast";

const DD_SECTIONS = [
  { key: 'structural', title: 'Structural & Building Fabric', icon: '🏗️' },
  { key: 'mep', title: 'MEP (Mechanical/Electrical/Plumbing)', icon: '⚡' },
  { key: 'fire_safety', title: 'Fire Safety & Compliance', icon: '🔥' },
  { key: 'access', title: 'Access & Vertical Transport', icon: '🛗' },
  { key: 'planning', title: 'Planning & Approvals', icon: '📋' },
  { key: 'environmental', title: 'Environmental & Sustainability', icon: '🌱' },
  { key: 'technology', title: 'Technology & Communications', icon: '💻' },
  { key: 'operations', title: 'Operations & Management', icon: '🔧' }
];

const SEVERITY_LEVELS = [
  { value: 1, label: 'Minor', color: 'bg-blue-500/20 text-blue-400', description: 'Cosmetic issues' },
  { value: 2, label: 'Low', color: 'bg-green-500/20 text-green-400', description: 'Minor maintenance' },
  { value: 3, label: 'Medium', color: 'bg-yellow-500/20 text-yellow-400', description: 'Needs attention' },
  { value: 4, label: 'High', color: 'bg-orange-500/20 text-orange-400', description: 'Significant issue' },
  { value: 5, label: 'Critical', color: 'bg-red-500/20 text-red-400', description: 'Deal breaker' }
];

export default function DDChecklist({ engagementId, buildingId, onRiskScoreChange }) {
  const [findings, setFindings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newFinding, setNewFinding] = useState({
    section: 'structural',
    title: '',
    severity: 3,
    description: '',
    recommendation: ''
  });
  const { toast } = useToast();

  const calculateRiskScore = React.useCallback(() => {
    if (findings.length === 0) return 0;
    
    const totalSeverity = findings.reduce((sum, finding) => sum + (finding.severity || 3), 0);
    const avgSeverity = totalSeverity / findings.length;
    
    // Convert to 0-100 scale (1-5 severity becomes 0-100)
    return Math.round(((avgSeverity - 1) / 4) * 100);
  }, [findings]);

  const loadFindings = React.useCallback(async () => {
    try {
      const filter = {};
      if (engagementId) filter.engagement_id = engagementId;
      if (buildingId) filter.building_id = buildingId;

      const findingsData = await DDFinding.list();
      // Filter client-side if needed since the entity might not support complex filters
      const relevantFindings = (findingsData || []).filter(f => {
        if (engagementId && f.engagement_id !== engagementId) return false;
        if (buildingId && f.building_id !== buildingId) return false;
        return true;
      });

      setFindings(relevantFindings);
    } catch (error) {
      console.error("Failed to load DD findings:", error);
      toast({
        variant: "destructive",
        title: "Failed to load findings"
      });
    } finally {
      setLoading(false);
    }
  }, [engagementId, buildingId, toast]);

  useEffect(() => {
    loadFindings();
  }, [loadFindings]);

  useEffect(() => {
    const riskScore = calculateRiskScore();
    if (onRiskScoreChange) {
      onRiskScoreChange(riskScore);
    }
  }, [calculateRiskScore, onRiskScoreChange]);

  const addFinding = async () => {
    if (!newFinding.title.trim()) {
      toast({
        variant: "destructive",
        title: "Please enter a finding title"
      });
      return;
    }

    try {
      const findingData = {
        ...newFinding,
        engagement_id: engagementId,
        building_id: buildingId,
        created_date: new Date().toISOString()
      };

      const created = await DDFinding.create(findingData);
      setFindings([created, ...findings]);
      setNewFinding({
        section: 'structural',
        title: '',
        severity: 3,
        description: '',
        recommendation: ''
      });
      setShowAddForm(false);
      
      toast({
        title: "Finding added successfully"
      });
    } catch (error) {
      console.error("Failed to add finding:", error);
      toast({
        variant: "destructive",
        title: "Failed to add finding"
      });
    }
  };

  const getRiskScoreColor = (score) => {
    if (score >= 80) return 'text-red-400';
    if (score >= 60) return 'text-orange-400';
    if (score >= 40) return 'text-yellow-400';
    if (score >= 20) return 'text-blue-400';
    return 'text-green-400';
  };

  const getRiskScoreIcon = (score) => {
    if (score >= 80) return <XCircle className="w-5 h-5 text-red-400" />;
    if (score >= 60) return <AlertTriangle className="w-5 h-5 text-orange-400" />;
    if (score >= 40) return <Clock className="w-5 h-5 text-yellow-400" />;
    return <CheckCircle className="w-5 h-5 text-green-400" />;
  };

  const getSectionIcon = (sectionKey) => {
    return DD_SECTIONS.find(s => s.key === sectionKey)?.icon || '📝';
  };

  const getSectionTitle = (sectionKey) => {
    return DD_SECTIONS.find(s => s.key === sectionKey)?.title || sectionKey;
  };

  const getSeverityConfig = (severity) => {
    return SEVERITY_LEVELS.find(s => s.value === severity) || SEVERITY_LEVELS[2];
  };

  const riskScore = calculateRiskScore();

  if (loading) {
    return (
      <Card className="shadow-elevated">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-gray-700 rounded w-1/3"></div>
            <div className="space-y-2">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-4 bg-gray-700 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-elevated">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-3">
            <span>Due Diligence Checklist</span>
            <div className="flex items-center gap-2">
              {getRiskScoreIcon(riskScore)}
              <span className={`font-bold ${getRiskScoreColor(riskScore)}`}>
                Risk Score: {riskScore}/100
              </span>
            </div>
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAddForm(!showAddForm)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Finding
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {showAddForm && (
          <div className="p-4 rounded-lg border border-white/10 bg-gray-800/50 space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Section</label>
                <Select
                  value={newFinding.section}
                  onValueChange={(value) => setNewFinding({ ...newFinding, section: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DD_SECTIONS.map(section => (
                      <SelectItem key={section.key} value={section.key}>
                        {section.icon} {section.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Severity</label>
                <Select
                  value={newFinding.severity.toString()}
                  onValueChange={(value) => setNewFinding({ ...newFinding, severity: parseInt(value) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SEVERITY_LEVELS.map(level => (
                      <SelectItem key={level.value} value={level.value.toString()}>
                        {level.label} - {level.description}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Finding Title *</label>
              <Input
                value={newFinding.title}
                onChange={(e) => setNewFinding({ ...newFinding, title: e.target.value })}
                placeholder="Brief description of the finding"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Description</label>
              <Textarea
                value={newFinding.description}
                onChange={(e) => setNewFinding({ ...newFinding, description: e.target.value })}
                placeholder="Detailed description of the issue"
                className="min-h-[80px]"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Recommendation</label>
              <Textarea
                value={newFinding.recommendation}
                onChange={(e) => setNewFinding({ ...newFinding, recommendation: e.target.value })}
                placeholder="Recommended action or resolution"
                className="min-h-[60px]"
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={addFinding}>
                Add Finding
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddForm(false);
                  setNewFinding({
                    section: 'structural',
                    title: '',
                    severity: 3,
                    description: '',
                    recommendation: ''
                  });
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {findings.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <CheckCircle className="w-12 h-12 mx-auto mb-3 text-gray-600" />
              <p>No findings yet. Add findings as you conduct due diligence.</p>
            </div>
          ) : (
            findings.map(finding => {
              const severityConfig = getSeverityConfig(finding.severity);
              return (
                <div
                  key={finding.id}
                  className="p-4 rounded-lg border border-white/10 hover:bg-white/5 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{getSectionIcon(finding.section)}</span>
                      <div>
                        <h4 className="font-medium text-white">{finding.title}</h4>
                        <p className="text-xs text-gray-400">
                          {getSectionTitle(finding.section)}
                        </p>
                      </div>
                    </div>
                    <Badge className={severityConfig.color}>
                      {severityConfig.label}
                    </Badge>
                  </div>
                  
                  {finding.description && (
                    <p className="text-sm text-gray-300 mb-2">
                      {finding.description}
                    </p>
                  )}
                  
                  {finding.recommendation && (
                    <div className="text-sm">
                      <span className="font-medium text-gray-300">Recommendation: </span>
                      <span className="text-gray-400">{finding.recommendation}</span>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {findings.length > 0 && (
          <div className="pt-4 border-t border-white/10">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">
                {findings.length} findings identified
              </span>
              <span className={`font-medium ${getRiskScoreColor(riskScore)}`}>
                Overall Risk Level: {riskScore >= 80 ? 'Critical' : riskScore >= 60 ? 'High' : riskScore >= 40 ? 'Medium' : riskScore >= 20 ? 'Low' : 'Very Low'}
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
