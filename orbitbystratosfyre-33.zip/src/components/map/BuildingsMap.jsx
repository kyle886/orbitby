import React, { useMemo } from 'react';
import { MapContainer, TileLayer, CircleMarker, Tooltip } from 'react-leaflet';
import { createPageUrl } from '@/utils';

export default function BuildingsMap({ buildings, filters }){
  const data = useMemo(() => {
    const xs = (buildings || []).filter(b => b?.latitude && b?.longitude);
    if (filters?.minNLA) return xs.filter(b => (b.total_size_sqm || 0) >= filters.minNLA);
    return xs;
  }, [buildings, filters]);

  const center = data.length ? [data[0].latitude, data[0].longitude] : [-33.8688, 151.2093];

  return (
    <div className="h-[520px] rounded-xl overflow-hidden orbit-card">
      <MapContainer center={center} zoom={12} scrollWheelZoom style={{height:'100%', width:'100%', background: '#1a202c'}}>
        <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />
        {data.map((b) => (
          <CircleMarker 
              key={b.id} 
              center={[b.latitude, b.longitude]} 
              radius={6} 
              pathOptions={{color:'#75c0ff', fillColor: '#75c0ff', fillOpacity:0.6}}
              eventHandlers={{
                  click: () => {
                      window.location.href = createPageUrl(`BuildingDetails?id=${b.id}`);
                  }
              }}
          >
            <Tooltip direction="top" offset={[0, -6]} opacity={1} permanent={false}>
              <div className="text-xs">{b.name || 'Building'} • {b.total_size_sqm ? `${b.total_size_sqm.toLocaleString()} m²` : ''}</div>
            </Tooltip>
          </CircleMarker>
        ))}
      </MapContainer>
    </div>
  );
}