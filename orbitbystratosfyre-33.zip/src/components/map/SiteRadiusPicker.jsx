
import React, { useEffect, useMemo, useState } from 'react';
import { MapContainer, TileLayer, Circle, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';

const defaultCenter = [-33.8688, 151.2093]; // Sydney

const markerIcon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41], iconAnchor: [12, 41]
});

function ClickCatcher({ onClick }) {
  useMapEvents({ click(e) { onClick([e.latlng.lat, e.latlng.lng]); } });
  return null;
}

export default function SiteRadiusPicker({ value, onChange }) {
  const [center, setCenter] = useState(value ? [value.lat, value.lng] : defaultCenter);
  const [radius, setRadius] = useState(value?.radius_m ?? 500);

  useEffect(() => { 
    if (value) { 
      setCenter([value.lat, value.lng]); 
      setRadius(value.radius_m); 
    } 
  }, [value]);
  
  const lat = useMemo(() => center[0].toFixed(6), [center]);
  const lng = useMemo(() => center[1].toFixed(6), [center]);

  return (
    <Card className="p-4 bg-black/40 backdrop-blur-xl space-y-3">
      <div className="text-sm text-neutral-300">Select site by pin, then set radius</div>
      <div className="grid grid-cols-3 gap-2 items-center">
        <label className="text-xs text-neutral-400">Lat</label>
        <Input className="col-span-2 bg-neutral-900/60 border-neutral-800" value={lat} readOnly />
        <label className="text-xs text-neutral-400">Lng</label>
        <Input className="col-span-2 bg-neutral-900/60 border-neutral-800" value={lng} readOnly />
        <label className="text-xs text-neutral-400">Radius (m)</label>
        <div className="col-span-2">
          <Slider value={[radius]} min={100} max={5000} step={50} onValueChange={(v) => setRadius(v[0])} />
          <div className="text-xs text-neutral-400 mt-1">{radius} m</div>
        </div>
      </div>
      <div className="h-72 rounded-xl overflow-hidden">
        <MapContainer center={center} zoom={15} style={{ height: '100%', width: '100%' }} scrollWheelZoom>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="&copy; OpenStreetMap" />
          <ClickCatcher onClick={(p) => setCenter(p)} />
          <Marker position={center} icon={markerIcon} />
          <Circle center={center} radius={radius} pathOptions={{ color: '#75c0ff', fillOpacity: 0.15 }} />
        </MapContainer>
      </div>
      <div className="flex justify-end">
        <Button className="bg-white/10" onClick={() => onChange({ lat: center[0], lng: center[1], radius_m: radius })}>Use selection</Button>
      </div>
    </Card>
  );
}
