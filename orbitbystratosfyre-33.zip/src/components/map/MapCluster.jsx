import React from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Fix for default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

export default function MapCluster({
  points = [],
  onBoundsChange,
  onSelect
}) {
  const ref = React.useRef(null);
  const mapRef = React.useRef(null);
  const markersRef = React.useRef(null);

  React.useEffect(() => {
    if (!ref.current) return;
    
    // Initialize map
    const map = L.map(ref.current, { 
      zoomControl: true, 
      attributionControl: true 
    });
    
    const sydney = [-33.8688, 151.2093];
    map.setView(sydney, 12);
    
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { 
      attribution: "© OpenStreetMap contributors" 
    }).addTo(map);

    // Store map reference
    mapRef.current = map;
    
    // Create marker group
    const markers = L.layerGroup().addTo(map);
    markersRef.current = markers;

    // Set up move event handler
    const handleMove = () => {
      const bounds = map.getBounds();
      const bbox = [
        bounds.getWest(),
        bounds.getSouth(), 
        bounds.getEast(),
        bounds.getNorth()
      ];
      onBoundsChange?.(bbox);
    };

    map.on("moveend", handleMove);
    
    // Initial bounds
    setTimeout(handleMove, 100);

    return () => {
      map.off("moveend", handleMove);
      map.remove();
      mapRef.current = null;
      markersRef.current = null;
    };
  }, [onBoundsChange]);

  // Update markers when points change
  React.useEffect(() => {
    if (!mapRef.current || !markersRef.current) return;
    
    const map = mapRef.current;
    const markers = markersRef.current;
    
    // Clear existing markers
    markers.clearLayers();
    
    // Add new markers
    points.forEach(point => {
      if (point.lat && point.lng) {
        const marker = L.marker([point.lat, point.lng]);
        
        if (point.title) {
          marker.bindPopup(point.title);
        }
        
        marker.on("click", () => {
          onSelect?.(point.id);
        });
        
        markers.addLayer(marker);
      }
    });

    // Fit bounds if we have points
    if (points.length > 0) {
      const validPoints = points.filter(p => p.lat && p.lng);
      if (validPoints.length > 0) {
        const bounds = L.latLngBounds(
          validPoints.map(p => [p.lat, p.lng])
        );
        map.fitBounds(bounds, { padding: [20, 20] });
      }
    }
  }, [points, onSelect]);

  return (
    <div 
      ref={ref} 
      className="w-full h-full rounded-xl overflow-hidden border border-white/10 bg-gray-900"
    />
  );
}