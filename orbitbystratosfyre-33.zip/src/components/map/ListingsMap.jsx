import React, { useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import { createPageUrl } from '@/utils';

const icon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41], iconAnchor: [12, 41]
});

export default function ListingsMap({ listings, filters }){
  const data = useMemo(() => {
    return (listings || []).filter(l => {
      if (!l?.building?.latitude || !l?.building?.longitude) return false;
      // You can expand filters here later
      return true;
    });
  }, [listings]);

  const center = data.length ? [data[0].building.latitude, data[0].building.longitude] : [-33.8688, 151.2093];

  return (
    <div className="h-[440px] rounded-xl overflow-hidden orbit-card">
      <MapContainer center={center} zoom={12} scrollWheelZoom style={{height:'100%', width:'100%', background: '#1a202c'}}>
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />
        <>
          {data.map((l) => (
            <Marker key={l.id} position={[l.building.latitude, l.building.longitude]} icon={icon}>
              <Popup>
                <div className="text-sm bg-gray-800 text-white p-1">
                  <div className="font-medium text-base">{l.building.name || l.building.address}</div>
                  {l.rental_rate_sqm ? <div>${l.rental_rate_sqm.toLocaleString()}/m²</div> : null}
                  <a className="text-sky-400 hover:underline" href={createPageUrl(`BuildingDetails?id=${l.building.id}`)} onClick={(e) => e.stopPropagation()}>Open Building</a>
                </div>
              </Popup>
            </Marker>
          ))}
        </>
      </MapContainer>
    </div>
  );
}