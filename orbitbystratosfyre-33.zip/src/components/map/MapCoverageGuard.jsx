import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, AlertCircle } from 'lucide-react';

export default function MapCoverageGuard({ pct, onBackfill, children }) {
  if ((pct ?? 0) < 10) {
    return (
      <Card className="orbit-card">
        <CardContent className="p-6 text-center">
          <AlertCircle className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">Map Coverage Low</h3>
          <p className="text-gray-300 mb-4">
            Only {pct}% of buildings have coordinates. Backfill geocodes to enable map features.
          </p>
          <Button onClick={onBackfill} className="orbit-button bg-orange-500 hover:bg-orange-600">
            <MapPin className="w-4 h-4 mr-2" />
            Backfill Geocodes
          </Button>
        </CardContent>
      </Card>
    );
  }
  return children;
}