import React from "react";

export default class ErrorBoundary extends React.Component {
  state = { hasError: false };
  static getDerivedStateFromError() { return { hasError: true }; }
  async componentDidCatch(error, info) {
    try { await window.base44?.functions?.logClientError?.({ error: String(error), info }); } catch {}
  }
  render() {
    if (!this.state.hasError) return this.props.children;
    return <div style={{padding:24}}>Something went wrong. Try refresh. It's been logged.</div>;
  }
}