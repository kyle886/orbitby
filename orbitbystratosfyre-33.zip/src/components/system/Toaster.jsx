import React from "react";

let emit;
export const toast = Object.assign(
  (opts) => emit?.({ ...opts, id: crypto.randomUUID(), kind: opts.kind || "info", ttl: opts.ttl ?? 4200 }),
  {
    success: (msg, opts = {}) => toast({ ...opts, kind: "success", title: opts.title || "Done", msg }),
    error: (msg, opts = {}) => toast({ ...opts, kind: "error", title: opts.title || "Error", msg }),
    info: (msg, opts = {}) => toast({ ...opts, kind: "info", title: opts.title || "Info", msg }),
  }
);

export default function Toaster() {
  const [items, setItems] = React.useState([]);
  
  React.useEffect(() => { 
    emit = (t) => {
      setItems(x => [...x, t]);
      setTimeout(() => setItems(x => x.filter(i => i.id !== t.id)), t.ttl ?? 4200);
    }; 
    return () => (emit = null); 
  }, []);

  const bg = (k) => k === "success" ? "bg-emerald-600/90" : k === "error" ? "bg-rose-600/90" : "bg-slate-700/90";
  const icon = (k) => k === "success" ? "✓" : k === "error" ? "!" : "•";

  return (
    <div className="fixed bottom-4 right-4 z-[9999] space-y-2 w-[360px]">
      {items.map(t => (
        <div key={t.id} className={`shadow-xl rounded-xl ${bg(t.kind)} text-white p-3 backdrop-blur border border-white/10`}>
          <div className="flex gap-2 items-start">
            <div className="mt-0.5">{icon(t.kind)}</div>
            <div className="flex-1">
              <div className="text-sm font-semibold">{t.title}</div>
              {t.msg && <div className="text-xs opacity-90">{t.msg}</div>}
              {t.action && <button onClick={t.action.onClick} className="text-xs underline mt-1">{t.action.label}</button>}
            </div>
            <button className="text-xs opacity-70" onClick={() => setItems(x => x.filter(i => i.id !== t.id))}>✕</button>
          </div>
        </div>
      ))}
    </div>
  );
}