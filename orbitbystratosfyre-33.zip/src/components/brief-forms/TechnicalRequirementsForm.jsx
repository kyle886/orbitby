import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function TechnicalRequirementsForm({ requirements = {}, onChange }) {
  const updateSection = (section, field, value) => {
    onChange({
      ...requirements,
      [section]: {
        ...(requirements[section] || {}),
        [field]: value
      }
    });
  };

  const toggleSection = (section, enabled) => {
    onChange({
      ...requirements,
      [section]: {
        ...(requirements[section] || {}),
        enabled
      }
    });
  };

  const TechnicalSection = ({ title, section, children }) => (
    <Card className="amplifyre-card mb-6">
      <CardHeader>
        <div className="flex items-center space-x-3">
          <Checkbox
            checked={requirements[section]?.enabled || false}
            onCheckedChange={(checked) => toggleSection(section, checked)}
          />
          <CardTitle className="text-lg text-blue-800">{title}</CardTitle>
        </div>
      </CardHeader>
      {requirements[section]?.enabled && (
        <CardContent className="space-y-4">
          {children}
          <div className="space-y-2">
            <Label>Special Requirements</Label>
            <Textarea
              placeholder="Any specific requirements or notes for this section..."
              value={requirements[section]?.special_requirements || ""}
              onChange={(e) => updateSection(section, 'special_requirements', e.target.value)}
            />
          </div>
        </CardContent>
      )}
    </Card>
  );

  return (
    <div className="space-y-6">
      <TechnicalSection title="Lifts" section="lifts">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Grade Required</Label>
            <Select
              value={requirements.lifts?.grade || ""}
              onValueChange={(value) => updateSection('lifts', 'grade', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select grade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="premium">Premium</SelectItem>
                <SelectItem value="standard">Standard</SelectItem>
                <SelectItem value="basic">Basic</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Number of Lifts Required</Label>
            <Input
              type="number"
              placeholder="e.g., 6"
              value={requirements.lifts?.number_required || ""}
              onChange={(e) => updateSection('lifts', 'number_required', parseInt(e.target.value))}
            />
          </div>
          <div className="space-y-2">
            <Label>Minimum Capacity (kg)</Label>
            <Input
              type="number"
              placeholder="e.g., 2000"
              value={requirements.lifts?.capacity_kg || ""}
              onChange={(e) => updateSection('lifts', 'capacity_kg', parseInt(e.target.value))}
            />
          </div>
        </div>
      </TechnicalSection>

      <TechnicalSection title="Electrical Services" section="electrical">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Power Required (VA/sqm)</Label>
            <Input
              type="number"
              placeholder="e.g., 40"
              value={requirements.electrical?.power_va_per_sqm || ""}
              onChange={(e) => updateSection('electrical', 'power_va_per_sqm', parseInt(e.target.value))}
            />
          </div>
          <div className="space-y-2 flex items-center space-x-3">
            <Checkbox
              checked={requirements.electrical?.backup_power_required || false}
              onCheckedChange={(checked) => updateSection('electrical', 'backup_power_required', checked)}
            />
            <Label>Backup Power Required</Label>
          </div>
          <div className="space-y-2 flex items-center space-x-3">
            <Checkbox
              checked={requirements.electrical?.ups_required || false}
              onCheckedChange={(checked) => updateSection('electrical', 'ups_required', checked)}
            />
            <Label>UPS Required</Label>
          </div>
        </div>
      </TechnicalSection>

      <TechnicalSection title="Mechanical Services" section="mechanical">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>HVAC Type</Label>
            <Select
              value={requirements.mechanical?.hvac_type || ""}
              onValueChange={(value) => updateSection('mechanical', 'hvac_type', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select HVAC type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="vav">Variable Air Volume (VAV)</SelectItem>
                <SelectItem value="chilled_beams">Chilled Beams</SelectItem>
                <SelectItem value="fan_coil">Fan Coil Units</SelectItem>
                <SelectItem value="hybrid">Hybrid System</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Zones per Floor</Label>
            <Input
              type="number"
              placeholder="e.g., 4"
              value={requirements.mechanical?.zones_per_floor || ""}
              onChange={(e) => updateSection('mechanical', 'zones_per_floor', parseInt(e.target.value))}
            />
          </div>
          <div className="space-y-2 flex items-center space-x-3">
            <Checkbox
              checked={requirements.mechanical?.after_hours_ac || false}
              onCheckedChange={(checked) => updateSection('mechanical', 'after_hours_ac', checked)}
            />
            <Label>After Hours Air Conditioning Required</Label>
          </div>
        </div>
      </TechnicalSection>

      <TechnicalSection title="Structural Requirements" section="structural">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Floor Loading Requirements</Label>
            <Input
              placeholder="e.g., 5kPa office loading"
              value={requirements.structural?.floor_loading_requirements || ""}
              onChange={(e) => updateSection('structural', 'floor_loading_requirements', e.target.value)}
            />
          </div>
        </div>
      </TechnicalSection>

      <TechnicalSection title="Environmental Requirements" section="environmental">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Natural Light Requirements</Label>
            <Textarea
              placeholder="Natural light and window requirements..."
              value={requirements.environmental?.natural_light_requirements || ""}
              onChange={(e) => updateSection('environmental', 'natural_light_requirements', e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label>Acoustic Requirements</Label>
            <Textarea
              placeholder="Acoustic and noise control requirements..."
              value={requirements.environmental?.acoustic_requirements || ""}
              onChange={(e) => updateSection('environmental', 'acoustic_requirements', e.target.value)}
            />
          </div>
        </div>
      </TechnicalSection>

      <TechnicalSection title="Communications & Technology" section="communications">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Fiber Requirements</Label>
            <Input
              placeholder="e.g., Category 6A, fiber to desk"
              value={requirements.communications?.fiber_requirements || ""}
              onChange={(e) => updateSection('communications', 'fiber_requirements', e.target.value)}
            />
          </div>
          <div className="space-y-2 flex items-center space-x-3">
            <Checkbox
              checked={requirements.communications?.wifi_coverage || false}
              onCheckedChange={(checked) => updateSection('communications', 'wifi_coverage', checked)}
            />
            <Label>Building-wide Wi-Fi Coverage</Label>
          </div>
          <div className="space-y-2 flex items-center space-x-3">
            <Checkbox
              checked={requirements.communications?.mobile_coverage || false}
              onCheckedChange={(checked) => updateSection('communications', 'mobile_coverage', checked)}
            />
            <Label>Mobile Phone Coverage Enhancement</Label>
          </div>
        </div>
      </TechnicalSection>

      <TechnicalSection title="Security Systems" section="security">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2 flex items-center space-x-3">
            <Checkbox
              checked={requirements.security?.access_control || false}
              onCheckedChange={(checked) => updateSection('security', 'access_control', checked)}
            />
            <Label>Access Control System</Label>
          </div>
          <div className="space-y-2 flex items-center space-x-3">
            <Checkbox
              checked={requirements.security?.cctv_required || false}
              onCheckedChange={(checked) => updateSection('security', 'cctv_required', checked)}
            />
            <Label>CCTV Coverage</Label>
          </div>
          <div className="space-y-2 flex items-center space-x-3">
            <Checkbox
              checked={requirements.security?.security_desk || false}
              onCheckedChange={(checked) => updateSection('security', 'security_desk', checked)}
            />
            <Label>Security Desk/Concierge</Label>
          </div>
        </div>
      </TechnicalSection>
    </div>
  );
}