import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export default function GovernanceRequirementsForm({ requirements = {}, onChange }) {
  const updateField = (field, value) => {
    onChange({
      ...requirements,
      [field]: value
    });
  };

  return (
    <Card className="amplifyre-card">
      <CardHeader>
        <CardTitle className="text-xl text-blue-800">Governance Requirements</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label>Ownership Disclosure Requirements</Label>
          <Textarea
            placeholder="Requirements for transparency in building ownership, beneficial ownership disclosure, etc..."
            value={requirements?.ownership_disclosure || ""}
            onChange={(e) => updateField('ownership_disclosure', e.target.value)}
            className="h-24"
          />
        </div>

        <div className="space-y-2">
          <Label>Supply Chain Ethics</Label>
          <Textarea
            placeholder="Ethical sourcing requirements, fair labor practices, local supplier preferences..."
            value={requirements?.supply_chain_ethics || ""}
            onChange={(e) => updateField('supply_chain_ethics', e.target.value)}
            className="h-24"
          />
        </div>

        <div className="space-y-2">
          <Label>Compliance Standards</Label>
          <Textarea
            placeholder="Required regulatory compliance, industry standards, certifications..."
            value={requirements?.compliance_standards || ""}
            onChange={(e) => updateField('compliance_standards', e.target.value)}
            className="h-24"
          />
        </div>

        <div className="space-y-2">
          <Label>Reporting Requirements</Label>
          <Textarea
            placeholder="Governance reporting, transparency reports, stakeholder communication requirements..."
            value={requirements?.reporting_requirements || ""}
            onChange={(e) => updateField('reporting_requirements', e.target.value)}
            className="h-24"
          />
        </div>

        <div className="space-y-2">
          <Label>Additional Governance Requirements</Label>
          <Textarea
            placeholder="Other governance, ethical, or compliance requirements..."
            value={requirements?.other_governance_notes || ""}
            onChange={(e) => updateField('other_governance_notes', e.target.value)}
            className="h-32"
          />
        </div>
      </CardContent>
    </Card>
  );
}