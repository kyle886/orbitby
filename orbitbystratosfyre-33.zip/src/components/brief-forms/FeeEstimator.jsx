import React, { useState, useEffect, useCallback } from 'react';
import { MarketIntelligence } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { DollarSign, Calculator, Info, AlertTriangle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function FeeEstimator({ brief, onChange }) {
  const [calculation, setCalculation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [milestonePercentages, setMilestonePercentages] = useState({
    milestone_1_pct: brief?.milestone_1_pct || 10,
    milestone_2_pct: brief?.milestone_2_pct || 20,
    milestone_3_pct: brief?.milestone_3_pct || 30,
    milestone_4_pct: brief?.milestone_4_pct || 40,
  });

  const handleMilestoneChange = (milestone, value) => {
    const newPercentages = { ...milestonePercentages, [milestone]: Number(value) };
    setMilestonePercentages(newPercentages);
    
    if (onChange) {
      // Only pass serializable data
      onChange({
        ...newPercentages,
        fee_recognition_type: brief.fee_recognition_type
      });
    }
  };

  const calculateFeeEstimate = useCallback(async () => {
    setLoading(true);
    try {
      const marketReports = await MarketIntelligence.list();
      const sydneyOfficeReports = marketReports.filter(report => 
        report.market?.includes('Sydney') && report.sector === 'Office'
      );

      if (sydneyOfficeReports.length === 0) {
        setCalculation({ error: 'No market data available for Sydney office market' });
        setLoading(false);
        return;
      }

      const latestReport = sydneyOfficeReports.reduce((latest, current) => 
        new Date(current.report_date) > new Date(latest.report_date) ? current : latest
      );

      const minArea = brief.min_floor_area || 0;
      const maxArea = brief.max_floor_area || minArea;
      const avgArea = (minArea + maxArea) / 2;

      let rentPerSqm = 0;
      if (brief.property_grade === 'prime') {
        rentPerSqm = latestReport.rent_data?.prime_rent_sqm || 900;
      } else {
        rentPerSqm = latestReport.rent_data?.secondary_rent_sqm || 650;
      }

      const annualFaceRent = avgArea * rentPerSqm;
      const minFee = Math.round(annualFaceRent * (4 / 52));
      const maxFee = Math.round(annualFaceRent * (6 / 52));
      const pipelineValue = Math.round(annualFaceRent * (5 / 52));

      const calc = {
        avgArea,
        rentPerSqm,
        annualFaceRent,
        minFee,
        maxFee,
        pipelineValue,
        marketSource: `${latestReport.report_source} - ${latestReport.report_title}`,
        marketDate: latestReport.report_date // Keep as string, don't convert to Date
      };

      setCalculation(calc);

      // Only pass serializable data to parent
      if (onChange) {
        const updateData = {
          estimated_fee_min_aud: minFee,
          estimated_fee_max_aud: maxFee,
          pipeline_value_aud: pipelineValue,
          fee_recognition_type: brief.fee_recognition_type || 'success-based',
          ...milestonePercentages
        };
        onChange(updateData);
      }

    } catch (error) {
      console.error('Error calculating fee estimate:', error);
      setCalculation({ error: 'Failed to calculate fee estimate' });
    } finally {
      setLoading(false);
    }
  }, [brief.min_floor_area, brief.max_floor_area, brief.property_grade, brief.fee_recognition_type, milestonePercentages, onChange]);

  useEffect(() => {
    if (brief.preferred_suburbs?.length > 0 && brief.min_floor_area && brief.property_grade) {
      calculateFeeEstimate();
    }
  }, [brief.preferred_suburbs, brief.min_floor_area, brief.max_floor_area, brief.property_grade, calculateFeeEstimate]);

  const getTotalMilestonePercentage = () => {
    return Object.values(milestonePercentages).reduce((sum, pct) => sum + Number(pct), 0);
  };

  if (!brief.preferred_suburbs?.length || !brief.min_floor_area || !brief.property_grade) {
    return (
      <Card className="orbit-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Calculator className="w-5 h-5 text-orange-400" />
            Fee Estimate
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-400 text-sm">
            Complete the property requirements (suburbs, area, grade) to see fee estimates.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="orbit-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Calculator className="w-5 h-5 text-orange-400 animate-spin" />
            Calculating Fee Estimate...
          </CardTitle>
        </CardHeader>
      </Card>
    );
  }

  if (calculation?.error) {
    return (
      <Card className="orbit-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Calculator className="w-5 h-5 text-red-400" />
            Fee Estimate
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-red-400 text-sm">{calculation.error}</p>
        </CardContent>
      </Card>
    );
  }

  if (!calculation) return null;

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <Card className="orbit-card">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-green-400" />
          Fee Estimate & Pipeline Value
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
            <div>
              <p className="text-sm font-medium text-gray-300">Est. Pipeline Value (5 wks)</p>
              <p className="text-xl font-bold text-white">{formatCurrency(calculation.pipelineValue)}</p>
            </div>
            <DollarSign className="w-6 h-6 text-green-400" />
          </div>
          <div className="text-xs text-gray-400">
            Based on {calculation.avgArea.toFixed(0)} sqm at {formatCurrency(calculation.rentPerSqm)}/sqm from {calculation.marketSource} ({calculation.marketDate ? new Date(calculation.marketDate).getFullYear() : 'N/A'}).
          </div>

          <div>
            <label className="text-sm font-medium text-white">Fee Recognition Type</label>
            <Select 
              value={brief.fee_recognition_type || 'success-based'} 
              onValueChange={(value) => {
                if (onChange) {
                  onChange({ fee_recognition_type: value });
                }
              }}
            >
              <SelectTrigger className="w-full mt-1 orbit-input">
                <SelectValue placeholder="Select recognition type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="success-based">Success-Based</SelectItem>
                <SelectItem value="milestones">Milestones</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {brief.fee_recognition_type === 'milestones' && (
            <div className="space-y-2 pt-2">
              <h4 className="text-sm font-medium text-white">Milestone Percentages</h4>
              <div className="grid grid-cols-2 gap-3">
                {Object.keys(milestonePercentages).map((key, i) => (
                  <div key={key}>
                    <label htmlFor={key} className="text-xs text-gray-400">Milestone {i + 1} (%)</label>
                    <input
                      id={key}
                      type="number"
                      min="0"
                      max="100"
                      value={milestonePercentages[key]}
                      onChange={(e) => handleMilestoneChange(key, e.target.value)}
                      className="w-full mt-1 orbit-input"
                    />
                  </div>
                ))}
              </div>
               {getTotalMilestonePercentage() !== 100 && (
                <p className="text-xs text-red-400 flex items-center gap-1">
                  <Info className="w-3 h-3" />
                  Milestones must sum to 100%.
                </p>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}