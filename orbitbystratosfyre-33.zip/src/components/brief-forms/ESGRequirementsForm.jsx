import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ESGRequirementsForm({ requirements = {}, onChange }) {
  const updateField = (field, value) => {
    onChange({
      ...requirements,
      [field]: value
    });
  };

  return (
    <Card className="amplifyre-card">
      <CardHeader>
        <CardTitle className="text-xl text-blue-800">ESG & Sustainability Requirements</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label>Required Sustainability Rating</Label>
            <Select
              value={requirements?.sustainability_rating || ""}
              onValueChange={(value) => updateField('sustainability_rating', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select rating requirement" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="green_star_6">Green Star 6 Star</SelectItem>
                <SelectItem value="green_star_5">Green Star 5 Star</SelectItem>
                <SelectItem value="green_star_4">Green Star 4 Star</SelectItem>
                <SelectItem value="nabers_6">NABERS Energy 6 Star</SelectItem>
                <SelectItem value="nabers_5">NABERS Energy 5+ Star</SelectItem>
                <SelectItem value="nabers_4">NABERS Energy 4+ Star</SelectItem>
                <SelectItem value="well_platinum">WELL Platinum</SelectItem>
                <SelectItem value="well_gold">WELL Gold</SelectItem>
                <SelectItem value="breeam_outstanding">BREEAM Outstanding</SelectItem>
                <SelectItem value="no_requirement">No Specific Requirement</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2 flex items-center space-x-3">
            <Checkbox
              checked={requirements?.carbon_neutral || false}
              onCheckedChange={(checked) => updateField('carbon_neutral', checked)}
            />
            <Label>Carbon Neutral Building Required</Label>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Energy Efficiency Requirements</Label>
          <Textarea
            placeholder="Specify energy efficiency requirements, renewable energy usage, etc..."
            value={requirements?.energy_efficiency || ""}
            onChange={(e) => updateField('energy_efficiency', e.target.value)}
            className="h-24"
          />
        </div>

        <div className="space-y-2">
          <Label>Water Efficiency Requirements</Label>
          <Textarea
            placeholder="Water conservation, recycling, NABERS Water rating requirements..."
            value={requirements?.water_efficiency || ""}
            onChange={(e) => updateField('water_efficiency', e.target.value)}
            className="h-24"
          />
        </div>

        <div className="space-y-2">
          <Label>Waste Management Requirements</Label>
          <Textarea
            placeholder="Recycling facilities, waste diversion targets, composting requirements..."
            value={requirements?.waste_management || ""}
            onChange={(e) => updateField('waste_management', e.target.value)}
            className="h-24"
          />
        </div>

        <div className="space-y-2">
          <Label>Renewable Energy Requirements</Label>
          <Textarea
            placeholder="Solar panels, renewable energy sourcing, on-site generation requirements..."
            value={requirements?.renewable_energy || ""}
            onChange={(e) => updateField('renewable_energy', e.target.value)}
            className="h-24"
          />
        </div>

        <div className="space-y-2">
          <Label>Additional ESG Requirements</Label>
          <Textarea
            placeholder="Other environmental, social, or governance requirements..."
            value={requirements?.other_esg_notes || ""}
            onChange={(e) => updateField('other_esg_notes', e.target.value)}
            className="h-32"
          />
        </div>
      </CardContent>
    </Card>
  );
}