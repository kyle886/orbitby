import React, { useState, useEffect } from 'react';
import { SendEmail } from '@/api/integrations';
import { AuditLog } from '@/api/entities';

class EmailNotificationManager {
  static async sendClientWelcome(client) {
    const subject = `Welcome to ORBIT - ${client.company_name}`;
    const body = `
Dear ${client.primary_contact_name},

Welcome to ORBIT by Stratosfyre! We're excited to partner with you in finding your perfect commercial space.

Your dedicated consultant team will be in touch shortly to begin the search process.

Company: ${client.company_name}
Industry: ${client.industry}
Team Size: ${client.team_size} people

We'll keep you updated throughout the entire process with regular progress reports and property recommendations.

Best regards,
The Stratosfyre Team
    `;

    try {
      await SendEmail({
        to: client.primary_contact_email,
        subject,
        body,
        from_name: "Stratosfyre ORBIT"
      });
      
      await this.logNotification('client_welcome', client.id, client.primary_contact_email);
    } catch (error) {
      console.error('Failed to send welcome email:', error);
    }
  }

  static async sendSubmissionAlert(submission, briefs, clients) {
    if (!briefs.length) return;

    for (const brief of briefs) {
      const client = clients.find(c => c.id === brief.client_id);
      if (!client) continue;

      const subject = `New Property Match - ${submission.property_title}`;
      const body = `
Dear ${client.primary_contact_name},

We've found a new property that matches your requirements:

Property: ${submission.property_title}
Address: ${submission.address}
Size: ${submission.floor_area_sqm} sqm
Rate: $${submission.rental_rate_sqm}/sqm/year
Available: ${submission.availability_date ? new Date(submission.availability_date).toLocaleDateString() : 'Now'}

Match Quality: ${submission.brief_match_status?.replace('_', ' ').toUpperCase()}
${submission.amplifyre_notes ? `\nNotes: ${submission.amplifyre_notes}` : ''}

Our team is reviewing this property and will be in touch with more details soon.

Best regards,
Your Stratosfyre Consultant Team
      `;

      try {
        await SendEmail({
          to: client.primary_contact_email,
          subject,
          body,
          from_name: "Stratosfyre ORBIT"
        });

        await this.logNotification('submission_alert', submission.id, client.primary_contact_email);
      } catch (error) {
        console.error('Failed to send submission alert:', error);
      }
    }
  }

  static async sendStatusUpdate(client, oldStatus, newStatus) {
    const statusMessages = {
      'discovery': 'We\'re gathering your requirements and understanding your needs.',
      'search_active': 'We\'re actively searching the market for suitable properties.',
      'negotiation': 'We\'re in negotiations on your preferred properties.',
      'lease_execution': 'We\'re finalizing lease documentation.',
      'completed': 'Congratulations! Your lease has been successfully executed.'
    };

    const subject = `Status Update - Your Property Search`;
    const body = `
Dear ${client.primary_contact_name},

Your property search status has been updated:

Previous Status: ${oldStatus?.replace('_', ' ').toUpperCase() || 'N/A'}
Current Status: ${newStatus.replace('_', ' ').toUpperCase()}

${statusMessages[newStatus] || ''}

${newStatus === 'completed' ? 
  'Thank you for choosing Stratosfyre. We look forward to working with you again in the future.' :
  'We\'ll continue to keep you updated on progress. Please don\'t hesitate to reach out with any questions.'
}

Best regards,
Your Stratosfyre Consultant Team
    `;

    try {
      await SendEmail({
        to: client.primary_contact_email,
        subject,
        body,
        from_name: "Stratosfyre ORBIT"
      });

      await this.logNotification('status_update', client.id, client.primary_contact_email);
    } catch (error) {
      console.error('Failed to send status update:', error);
    }
  }

  static async sendWeeklyDigest(client, submissions, updates) {
    const subject = `Weekly Update - Your Property Search`;
    const body = `
Dear ${client.primary_contact_name},

Here's your weekly property search summary:

NEW SUBMISSIONS THIS WEEK: ${submissions.length}
${submissions.map(s => `• ${s.property_title} - ${s.address} (${s.floor_area_sqm} sqm)`).join('\n')}

RECENT UPDATES:
${updates.map(u => `• ${u.title}: ${u.message}`).join('\n')}

Your dedicated consultant team continues to actively search for properties that match your requirements. We'll be in touch with any new developments.

Best regards,
Your Stratosfyre Consultant Team
    `;

    try {
      await SendEmail({
        to: client.primary_contact_email,
        subject,
        body,
        from_name: "Stratosfyre ORBIT"
      });

      await this.logNotification('weekly_digest', client.id, client.primary_contact_email);
    } catch (error) {
      console.error('Failed to send weekly digest:', error);
    }
  }

  static async logNotification(type, entityId, recipient) {
    try {
      await AuditLog.create({
        user_email: 'system@stratosfyre.com',
        action_type: 'create',
        entity_type: 'EmailNotification',
        entity_id: entityId,
        changes: {
          notification_type: type,
          recipient: recipient,
          timestamp: new Date().toISOString()
        },
        timestamp: new Date().toISOString(),
        additional_context: `Automated email notification sent: ${type}`
      });
    } catch (error) {
      console.error('Failed to log notification:', error);
    }
  }
}

export default EmailNotificationManager;

// React component for managing email notification settings
export function EmailNotificationSettings() {
  const [settings, setSettings] = useState({
    client_welcome: true,
    submission_alerts: true,
    status_updates: true,
    weekly_digest: true,
    inspection_reminders: true
  });

  return (
    <div className="orbit-card p-6">
      <h3 className="text-lg font-bold text-white mb-4">Email Notification Settings</h3>
      <div className="space-y-3">
        {Object.entries(settings).map(([key, value]) => (
          <div key={key} className="flex items-center justify-between">
            <span className="text-gray-300 capitalize">
              {key.replace('_', ' ')}
            </span>
            <input
              type="checkbox"
              checked={value}
              onChange={(e) => setSettings(prev => ({...prev, [key]: e.target.checked}))}
              className="w-4 h-4 text-orange-500"
            />
          </div>
        ))}
      </div>
    </div>
  );
}