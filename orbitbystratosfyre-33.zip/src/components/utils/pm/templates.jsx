
// PM Templates and default data
export const STAGES = [
  { key:'design', title:'Design', color:'#60a5fa' },
  { key:'tender', title:'Tender', color:'#f59e0b' },
  { key:'construction', title:'Construction', color:'#22c55e' },
  { key:'handover', title:'Handover', color:'#a78bfa' }
];

export const PRELIMINARY_MILESTONES = [
  {
    title: 'Project Kick-off Meeting',
    stage: 'design',
    duration_days: 1,
  },
  {
    title: 'Finalize Scope & Concept Design',
    stage: 'design',
    duration_days: 14,
  },
  {
    title: 'Detailed Design & Documentation',
    stage: 'design',
    duration_days: 21,
  },
  {
    title: 'Submit for Regulatory Approval',
    stage: 'design',
    duration_days: 5,
  },
  {
    title: 'Tender Package Preparation',
    stage: 'tender',
    duration_days: 7,
  },
  {
    title: 'Issue Tender to Market',
    stage: 'tender',
    duration_days: 1,
  },
  {
    title: 'Tender Period & Queries',
    stage: 'tender',
    duration_days: 14,
  },
  {
    title: 'Review Bids & Appoint Contractor',
    stage: 'tender',
    duration_days: 7,
  },
  {
    title: 'Site Mobilization',
    stage: 'construction',
    duration_days: 7,
  },
  {
    title: 'Main Construction Works',
    stage: 'construction',
    duration_days: 60,
  },
  {
    title: 'Practical Completion & Defecting',
    stage: 'construction',
    duration_days: 7,
  },
  {
    title: 'Client Handover & Training',
    stage: 'handover',
    duration_days: 5,
  },
];

export function defaultTasks(projectId){
  const now = new Date();
  const dt = (m)=> iso(addMonths(now, m));
  return [
    { project_id:projectId, stage:'design', title:'Brief & Test Fit', start_dt:dt(0), end_dt:dt(1), owner:'Design' },
    { project_id:projectId, stage:'design', title:'DD Package', start_dt:dt(1), end_dt:dt(2), owner:'Design' },
    { project_id:projectId, stage:'tender', title:'Issue RFT', start_dt:dt(2), end_dt:dt(2), owner:'PM' },
    { project_id:projectId, stage:'tender', title:'Tender Q&A', start_dt:dt(2), end_dt:dt(3), owner:'PM' },
    { project_id:projectId, stage:'tender', title:'Tender Analysis / BAFO', start_dt:dt(3), end_dt:dt(3), owner:'PM' },
    { project_id:projectId, stage:'construction', title:'Site Establishment', start_dt:dt(4), end_dt:dt(4), owner:'Builder' },
    { project_id:projectId, stage:'construction', title:'Fitout Works', start_dt:dt(4), end_dt:dt(6), owner:'Builder' },
    { project_id:projectId, stage:'handover', title:'Practical Completion', start_dt:dt(6), end_dt:dt(6), owner:'PM' },
    { project_id:projectId, stage:'handover', title:'Defects / Close-out', start_dt:dt(6), end_dt:dt(7), owner:'PM' },
  ];
}

export function defaultRegisters(projectId){
  return {
    rfi: [], submittals: [], variations: [], diary: [], punchlist: []
  };
}

function addMonths(d,m){ const x=new Date(d); x.setMonth(x.getMonth()+m); return x; }
function iso(d){ return new Date(d).toISOString(); }
