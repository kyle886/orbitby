/**
 * Client-side functions for external API data.
 * These now call backend functions instead of direct API calls.
 */

export async function searchNews(query, fromDate = null, category = 'business') {
  const response = await fetch('/functions/searchNews', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, fromDate, category })
  });
  return response.json();
}

export async function searchEvents(params = {}) {
  const response = await fetch('/functions/searchEvents', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params)
  });
  return response.json();
}