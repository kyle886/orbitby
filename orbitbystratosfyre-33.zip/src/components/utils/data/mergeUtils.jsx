import { Company } from '@/api/entities';
import { Building } from '@/api/entities';
import { Tenancy } from '@/api/entities';
import { Signal } from '@/api/entities';
import { Contact } from '@/api/entities';
import { Target } from '@/api/entities';
import { Brief } from '@/api/entities';
import { DealEvidence } from '@/api/entities';
import { Lease } from '@/api/entities';
import { Pitch } from '@/api/entities';
import { DevCase } from '@/api/entities';
import { Listing } from '@/api/entities';
import { BuildingPhoto } from '@/api/entities';
import { DueDiligence } from '@/api/entities';

const ENTITY_MAP = {
  Company, Building, Tenancy, Signal, Contact, Target, Brief, DealEvidence, Lease, Pitch, DevCase, Listing, BuildingPhoto, DueDiligence
};

/**
 * Merges a 'loser' record into a 'winner' record, re-parenting all known child relationships
 * before deleting the loser.
 * @param {string} type - The entity type (e.g., 'Company', 'Building').
 * @param {object} winner - The full record object to keep.
 * @param {object} loser - The full record object to merge and delete.
 * @returns {Promise<{reparented: number, deleted: number}>} - The count of reparented and deleted records.
 */
export async function mergeAndReparent(type, winner, loser) {
  if (!winner || !loser || !type) {
    throw new Error("mergeAndReparent requires a type, winner, and loser record.");
  }
  
  const winnerId = winner.id;
  const loserId = loser.id;
  let reparentedCount = 0;
  
  console.log(`Starting merge for ${type}: winner=${winnerId}, loser=${loserId}`);

  // Define which entities and fields to check for re-parenting
  const relationsToUpdate = {
    'Company': [
      { entity: Signal, field: 'company_id' },
      { entity: Contact, field: 'company_id' },
      { entity: Tenancy, field: 'company_id' },
      { entity: Target, field: 'company_id' },
      { entity: Brief, field: 'company_id' },
      { entity: DealEvidence, field: 'company_id' },
      { entity: Lease, field: 'company_id' },
      { entity: Pitch, field: 'company_id' },
      { entity: DevCase, field: 'company_id' },
    ],
    'Building': [
      { entity: Tenancy, field: 'building_id' },
      { entity: Listing, field: 'building_id' },
      { entity: BuildingPhoto, field: 'building_id' },
      { entity: Target, field: 'building_id' },
      { entity: DealEvidence, field: 'building_id' },
      { entity: Lease, field: 'building_id' },
      { entity: DueDiligence, field: 'building_id' },
    ],
    // Add other types like Tenancy or Signal here if they have child relationships
  };

  const relations = relationsToUpdate[type];
  if (relations) {
    for (const rel of relations) {
      try {
        const { entity, field } = rel;
        const filter = { [field]: loserId };
        const children = await entity.filter(filter);

        if (children.length > 0) {
          console.log(`Found ${children.length} children of type ${entity.name} to re-parent...`);
          for (const child of children) {
            await entity.update(child.id, { [field]: winnerId });
            reparentedCount++;
          }
        }
      } catch (error) {
        console.error(`Failed to re-parent children for ${type} of relation ${rel.entity.name}:`, error);
        // Decide if this should be a fatal error or if we can continue
      }
    }
  }

  // Finally, delete the loser record
  const LoserEntity = ENTITY_MAP[type];
  if (!LoserEntity) {
    throw new Error(`Invalid entity type provided for deletion: ${type}`);
  }

  await LoserEntity.delete(loserId);
  console.log(`Successfully deleted loser ${type} with id ${loserId}.`);

  return {
    reparented: reparentedCount,
    deleted: 1,
  };
}