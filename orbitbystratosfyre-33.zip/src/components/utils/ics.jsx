function fmt(dt) { return dt.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z"; }

export function makeICS(opts) {
  const lines = [
    "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Orbit//Inspection//EN", "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH", "BEGIN:VEVENT",
    `UID:${opts.uid}`,
    `DTSTAMP:${fmt(new Date())}`,
    `DTSTART:${fmt(opts.start)}`,
    `DTEND:${fmt(opts.end)}`,
    `SUMMARY:${(opts.title || "Inspection").replace(/\n/g, " ")}`,
    `DESCRIPTION:${(opts.desc || "").replace(/\n/g, " ")}`,
    opts.location ? `LOCATION:${opts.location.replace(/\n/g, " ")}` : "",
    opts.organizer?.email ? `ORGANIZER;CN=${opts.organizer?.name || "Organizer"}:mailto:${opts.organizer.email}` : "",
    ...(opts.attendees || []).map(a => `ATTENDEE;CN=${a.name || a.email};ROLE=REQ-PARTICIPANT:mailto:${a.email}`),
    "END:VEVENT", "END:VCALENDAR"
  ].filter(Boolean);
  return lines.join("\r\n");
}

export function downloadICS(filename, ics) {
  const blob = new Blob([ics], { type: "text/calendar;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
}