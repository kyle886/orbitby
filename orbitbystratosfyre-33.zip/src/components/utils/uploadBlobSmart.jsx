import { UploadFile } from "@/api/integrations";

/**
 * Upload a blob to storage and return the file URL
 * @param {Blob} blob - The blob to upload
 * @param {string} filename - The filename to use
 * @returns {Promise<string>} - The uploaded file URL
 */
export async function uploadBlobSmart(blob, filename) {
  try {
    // Convert blob to File object for the UploadFile integration
    const file = new File([blob], filename, { type: blob.type || 'application/octet-stream' });
    
    // Use the Core integration to upload the file
    const { file_url } = await UploadFile({ file });
    
    return file_url;
  } catch (error) {
    console.error('Failed to upload blob:', error);
    throw new Error(`Upload failed: ${error.message}`);
  }
}

export default uploadBlobSmart;