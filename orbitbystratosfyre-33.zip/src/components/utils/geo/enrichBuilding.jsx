import { Building } from "@/api/entities";

export async function enrichBuildingWithPlaces(buildingId, { name, address }) {
  const query = address || name;
  if (!query) return null;
  
  try {
    // Use the placesEnrich function
    const { placesEnrich } = await import('@/api/functions');
    const response = await placesEnrich({ query });
    
    if (!response.data.ok || !response.data.match) return null;

    const match = response.data.match;
    const updateData = {
      google_place_id: match.place_id,
      latitude: match.lat,
      longitude: match.lng,
      primary_photo_url: match.photo_urls?.[0] || null,
      google_maps_url: `https://www.google.com/maps/place/?q=place_id:${match.place_id}`
    };

    await Building.update(buildingId, updateData);
    return updateData;
  } catch (error) {
    console.error('Building enrichment failed:', error);
    return null;
  }
}