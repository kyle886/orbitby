
// Enhanced cosmic mode utilities
import { User } from '@/api/entities';

const K_FLAG = "orbit_cosmic_until";

export function enableCosmic(hours = 24) {
  const until = Date.now() + hours * 3600 * 1000;
  try { 
    localStorage.setItem(K_FLAG, String(until)); 
  } catch(e) {
    console.warn('Could not save cosmic mode preference:', e);
  }
  applyCosmic();
}

export function disableCosmic() {
  try { 
    localStorage.removeItem(K_FLAG); 
  } catch(e) {
    console.warn('Could not remove cosmic mode preference:', e);
  }
  document.documentElement.classList.remove("cosmic-mode");
}

export function isCosmicActive() {
  try {
    const until = Number(localStorage.getItem(K_FLAG) || 0);
    return until > Date.now();
  } catch { 
    return false; 
  }
}

export function applyCosmic() {
  const shouldBeActive = isCosmicActive();
  const isCurrentlyActive = document.documentElement.classList.contains("cosmic-mode");
  
  if (shouldBeActive && !isCurrentlyActive) {
    document.documentElement.classList.add("cosmic-mode");
    console.log('🌌 Cosmic Mode activated');
  } else if (!shouldBeActive && isCurrentlyActive) {
    document.documentElement.classList.remove("cosmic-mode");
    console.log('🌟 Cosmic Mode deactivated');
  }
}

export function toggleCosmic() {
  if (isCosmicActive()) {
    disableCosmic();
  } else {
    enableCosmic(24);
  }
}

export function setCosmic(on) {
  if (typeof window !== 'undefined') {
    document.body.classList.toggle('cosmic', on);
  }
}

/** Call once at app start */
export async function initCosmic() {
  // New admin-specific initialization logic
  try {
    const user = await User.me();
    if (user.user_type === 'stratosfyre_admin') {
      console.log('Cosmic mode initialized for admin');
      // Additional admin-specific theme logic can go here.
      // For example, an admin might always have the 'cosmic' class applied to the body.
      // setCosmic(true);
    }
  } catch (error) {
    // User not logged in or not an admin, proceed with standard cosmic mode behavior.
    // console.log('User not an admin or not logged in, skipping admin cosmic init:', error);
  }

  // Existing cosmic mode application logic
  applyCosmic();
  
  // Recheck cosmic mode when page becomes visible
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      applyCosmic();
    }
  });
  
  // Debug helper
  if (typeof window !== 'undefined') {
    window.cosmicMode = {
      enable: () => enableCosmic(),
      disable: disableCosmic,
      toggle: toggleCosmic,
      isActive: isCosmicActive,
      apply: applyCosmic,
      setBodyCosmicClass: (on) => setCosmic(on) // Expose the new setCosmic function for debugging
    };
  }
}
