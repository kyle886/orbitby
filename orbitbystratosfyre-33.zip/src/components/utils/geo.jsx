/**
 * Client-side functions for geographic data processing.
 * These now call backend functions instead of direct API calls.
 */

export async function placeSearch(text) {
  const response = await fetch('/functions/geocodeAddress', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ address: text })
  });
  return response.json();
}

export async function geocodeAddress(address) {
  const response = await fetch('/functions/geocodeAddress', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ address })
  });
  return response.json();
}

export async function enrichBuildingWithPlaces(buildingId) {
  const response = await fetch('/functions/enrichWithGooglePlaces', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ buildingId })
  });
  return response.json();
}