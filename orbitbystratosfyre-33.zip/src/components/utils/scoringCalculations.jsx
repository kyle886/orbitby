// Updated BD Target Scoring Calculations
import { format, differenceInDays, differenceInMonths, parseISO } from 'date-fns';

// Individual calculation functions for granular scoring
export function calculateFundingMomentum(signals = []) {
  const fundingSignals = signals.filter(s => s.type === 'funding');
  if (fundingSignals.length === 0) return 0;

  // Find most recent funding
  const recentFunding = fundingSignals
    .sort((a, b) => new Date(b.date) - new Date(a.date))[0];
  
  const monthsSinceFunding = differenceInMonths(new Date(), new Date(recentFunding.date));
  
  let score = 0;
  if (monthsSinceFunding <= 6) {
    score = 20; // Very recent funding
  } else if (monthsSinceFunding <= 12) {
    score = 15; // Recent funding
  } else if (monthsSinceFunding <= 24) {
    score = 10; // Somewhat recent
  } else {
    score = 5; // Old funding but still relevant
  }

  // Bonus for large funding amounts
  if (recentFunding.amount_aud && recentFunding.amount_aud > 5000000) {
    score += 5; // Bonus for large rounds
  }

  return Math.min(score, 20);
}

export function calculateLeaseExpiryProximity(leaseExpiryDate) {
  if (!leaseExpiryDate) return 0;
  
  const expiryDate = new Date(leaseExpiryDate);
  const today = new Date();
  
  if (expiryDate <= today) return 0; // Already expired
  
  const daysToExpiry = differenceInDays(expiryDate, today);
  
  if (daysToExpiry <= 180) { // 6 months
    return 20;
  } else if (daysToExpiry <= 365) { // 12 months
    return 15;
  } else if (daysToExpiry <= 730) { // 24 months
    return 10;
  } else {
    return 5;
  }
}

export function calculateBuildingLeverage(buildingId, briefs = [], buildings = []) {
  if (!buildingId) return 0;
  
  // Check if building has active/won briefs
  const activeBriefs = briefs.filter(b => 
    b.building_id === buildingId && 
    ['active', 'won'].includes(b.status)
  );
  
  if (activeBriefs.length > 0) {
    return 15; // Maximum leverage score
  }
  
  // Check building occupancy/activity (simplified)
  const building = buildings.find(b => b.id === buildingId);
  if (building && building.vacancy_pct !== undefined) {
    // Higher score for buildings with some vacancy (opportunity)
    if (building.vacancy_pct > 10 && building.vacancy_pct < 30) {
      return 10;
    } else if (building.vacancy_pct > 0) {
      return 5;
    }
  }
  
  return 0;
}

export function calculateSectorFit(sector, sectorWeights = {}) {
  const defaultWeights = {
    'Education': 1.2,
    'LifeSci': 1.5,
    'Biotech': 1.4,
    'Fintech': 1.3,
    'SaaS': 1.1,
    'AI': 1.6,
    'Other': 1.0
  };
  
  const weights = { ...defaultWeights, ...sectorWeights };
  const sectorWeight = weights[sector] || 1.0;
  const score = Math.round(15 * sectorWeight);
  
  return Math.min(score, 15);
}

export function calculateHiringSignal(signals = []) {
  const hiringSignals = signals.filter(s => s.type === 'hire');
  if (hiringSignals.length === 0) return 0;

  // Recent hiring activity
  const recentHiring = hiringSignals.filter(s => {
    const signalDate = new Date(s.date);
    const monthsAgo = differenceInMonths(new Date(), signalDate);
    return monthsAgo <= 6;
  });

  const score = Math.min(recentHiring.length * 5, 15);
  return score;
}

export function calculateNewsHeat(signals = []) {
  const newsSignals = signals.filter(s => s.type === 'news');
  if (newsSignals.length === 0) return 0;

  const recentNews = newsSignals.filter(s => {
    const signalDate = new Date(s.date);
    const monthsAgo = differenceInMonths(new Date(), signalDate);
    return monthsAgo <= 3; // News in last 3 months
  });

  // Score based on recency and magnitude
  let newsScore = 0;
  recentNews.forEach(news => {
    const magnitude = news.magnitude || 1;
    const monthsAgo = differenceInMonths(new Date(), new Date(news.date));
    
    if (monthsAgo <= 1) {
      newsScore += magnitude * 3; // Very recent news
    } else if (monthsAgo <= 3) {
      newsScore += magnitude * 2; // Recent news
    }
  });

  return Math.min(newsScore, 15);
}

export function calculatePriorityScore({
  funding_momentum_score = 0,
  lease_expiry_proximity_score = 0,
  building_leverage_score = 0,
  sector_fit_score = 0,
  hiring_signal_score = 0,
  news_heat_score = 0
}) {
  const totalScore = 
    funding_momentum_score + 
    lease_expiry_proximity_score + 
    building_leverage_score + 
    sector_fit_score + 
    hiring_signal_score + 
    news_heat_score;
  
  return Math.min(totalScore, 100);
}

// Legacy function for backward compatibility
export function calculateScores(signals = [], leases = [], target, settings = {}) {
  console.log('Calculating scores for target:', target?.id, 'with', signals?.length, 'signals and', leases?.length, 'leases');
  
  // Calculate individual scores
  const funding_momentum_score = calculateFundingMomentum(signals);
  const lease_expiry_proximity_score = calculateLeaseExpiryProximity(target?.lease_expiry_date);
  const building_leverage_score = calculateBuildingLeverage(target?.building_id);
  const sector_fit_score = calculateSectorFit(target?.company?.sector, settings.SECTOR_WEIGHTS);
  const hiring_signal_score = calculateHiringSignal(signals);
  const news_heat_score = calculateNewsHeat(signals);
  
  // Calculate total priority score
  const priority_score = calculatePriorityScore({
    funding_momentum_score,
    lease_expiry_proximity_score,
    building_leverage_score,
    sector_fit_score,
    hiring_signal_score,
    news_heat_score
  });

  const result = {
    priority_score,
    funding_momentum_score,
    lease_expiry_proximity_score,
    building_leverage_score,
    sector_fit_score,
    hiring_signal_score,
    news_heat_score,
    last_refreshed_at: new Date().toISOString()
  };

  console.log('Calculated scores:', result);
  return result;
}

// Event ROI Calculation
export function calculateEventROI(event, targetOverlapPct, settings = {}) {
  const defaultMQL = settings.DEFAULT_MQL || 0.05;
  const defaultMeeting = settings.DEFAULT_MEETING || 0.4;
  const defaultWin = settings.DEFAULT_WIN || 0.25;
  const defaultAvgFee = settings.DEFAULT_AVG_FEE_AUD || 100000;
  const defaultMargin = settings.DEFAULT_MARGIN || 0.35;

  const predictedAttendance = event.last_year_attend_est || event.venue_capacity || 500;
  const sponsorCost = event.sponsor_cost_est_aud || 10000;
  
  // Calculate expected leads from event
  const targetCompaniesAtEvent = Math.round((predictedAttendance * targetOverlapPct) / 100);
  const expectedMQLs = targetCompaniesAtEvent * defaultMQL;
  const expectedMeetings = expectedMQLs * defaultMeeting;
  const expectedWins = expectedMeetings * defaultWin;
  const expectedRevenue = expectedWins * defaultAvgFee;
  const expectedProfit = expectedRevenue * defaultMargin;
  
  const expectedValue = expectedProfit - sponsorCost;
  const roiScore = sponsorCost > 0 ? Math.round((expectedValue / sponsorCost) * 100) : 0;
  
  let recommendation = 'skip';
  if (roiScore >= 200) recommendation = 'sponsor';
  else if (roiScore >= 50) recommendation = 'attend';
  
  return {
    predicted_attendance: predictedAttendance,
    target_overlap_pct: targetOverlapPct,
    expected_value_aud: expectedValue,
    roi_score: roiScore,
    sponsor_rec: recommendation
  };
}