export async function downloadAndHash(url) {
  // Using a CORS proxy for external images
  const proxyUrl = `https://cors-anywhere.herokuapp.com/${url}`;
  
  const res = await fetch(proxyUrl, { mode: 'cors' });
  if (!res.ok) throw new Error(`Image fetch failed for ${url} with status ${res.status}`);
  
  const blob = await res.blob();
  const arrayBuffer = await blob.arrayBuffer();
  const hashBuf = await crypto.subtle.digest('SHA-1', arrayBuffer);
  const hash = [...new Uint8Array(hashBuf)].map(b=>b.toString(16).padStart(2,'0')).join('');
  
  // In a real app, you'd upload this blob to your own storage (e.g., S3, Supabase Storage)
  // and get a new URL. For this example, we'll just return the original URL.
  const file_url = url; 

  const dims = await readImageSize(blob);
  return { file_url, hash, width: dims?.w ?? null, height: dims?.h ?? null };
}

function readImageSize(blob) {
  return new Promise((resolve) => {
    try {
      const img = new Image();
      img.onload = () => resolve({ w: img.width, h: img.height });
      img.onerror = () => resolve(null);
      img.src = URL.createObjectURL(blob);
    } catch { resolve(null); }
  });
}