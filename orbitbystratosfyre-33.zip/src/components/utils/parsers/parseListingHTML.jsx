// Heuristic parser for listing/building pages. Runs in browser (Vite).
export function parseListingHTML(html, url) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const text = doc.body?.innerText || '';
  const get = (sel) => doc.querySelector(sel)?.textContent?.trim();
  const ogImage = doc.querySelector('meta[property="og:image"]')?.getAttribute('content');
  // Very light heuristics — tune per source
  const address = get('address') || (text.match(/\d{1,4}\s+[A-Za-z].+?(NSW|VIC|QLD|SA|WA|TAS|ACT)\s+\d{4}/)?.[0] ?? null);
  // Area and rents (AU canonical)
  const area_m2 = numberOrNull(text.match(/([\d,.]+)\s*(m2|sqm|m²)/i)?.[1]);
  const rent_aud_per_m2_pa = numberOrNull(text.match(/\$?\s*([\d,.]+)\s*\/?\s*(m2|sqm|m²)\s*\/?\s*(pa|per\s*annum)/i)?.[1]);
  const opex_aud_per_m2_pa = numberOrNull(text.match(/outgoings[^$]*\$?\s*([\d,.]+)/i)?.[1]);
  const incentives_pct = numberOrNull((text.match(/incentiv(e|es|e:)\s*([\d.]+)\s*%/i) || [])[2]);
  const building_name = get('h1') || get('[itemprop="name"]') || null;
  const image_url = pickImage(doc, ogImage);
  // Location pieces
  const suburb = (text.match(/\b([A-Z][a-z]+)\s+NSW\b/)||[])[1] || null;
  const postcode = (text.match(/\b(\d{4})\b/)||[])[1] || null;
  const city = text.includes('Sydney') ? 'Sydney' : null;
  const state = text.match(/\bNSW\b/) ? 'NSW' : null;
  return {
    url, building_name, address, suburb, postcode, city, state,
    area_m2, rent_aud_per_m2_pa, opex_aud_per_m2_pa, incentives_pct,
    image_url, confidence: scoreConfidence({address, area_m2, rent_aud_per_m2_pa, image_url})
  };
}

const numberOrNull = (v) => {
  if (!v && v !== 0) return null;
  const n = parseFloat(String(v).replace(/[, ]/g,''));
  return Number.isFinite(n) ? n : null;
};

function pickImage(doc, og) {
  const imgs = [...doc.querySelectorAll('img')].map(img => ({
    src: img.getAttribute('src') || img.getAttribute('data-src'),
    w: parseInt(img.getAttribute('width')||'0',10),
    h: parseInt(img.getAttribute('height')||'0',10),
    alt: img.getAttribute('alt') || ''
  })).filter(i => i.src && !i.src.startsWith('data:'));
  const bestTag = imgs.sort((a,b)=> (b.w*b.h)-(a.w*a.h))[0];
  return bestTag?.src || og || null;
}

function scoreConfidence(fields) {
  let c = 0;
  if (fields.address) c += 30;
  if (fields.area_m2) c += 25;
  if (fields.rent_aud_per_m2_pa) c += 25;
  if (fields.image_url) c += 20;
  return c;
}