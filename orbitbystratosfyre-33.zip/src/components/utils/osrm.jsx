// Free travel-time matrix via public OSRM (sufficient for small batches).
// Input: [{lat, lng}] in display order
export async function getLegDurations(stops) {
  if (!stops || stops.length < 2) return { legs: [], totalSec: 0 };
  const coords = stops.map(s => `${s.lng},${s.lat}`).join(";");
  const url = `https://router.project-osrm.org/table/v1/driving/${coords}?annotations=duration`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`OSRM ${res.status}`);
  const json = await res.json();
  // duration matrix seconds; legs = duration[i][i+1]
  const legs = [];
  let totalSec = 0;
  for (let i = 0; i < stops.length - 1; i++) {
    const d = Math.max(0, Math.round(json.durations[i][i + 1] || 0));
    legs.push(d);
    totalSec += d;
  }
  return { legs, totalSec };
}