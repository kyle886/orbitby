/**
 * Build Negotiation Coach context from current records.
 * Pulls: Engagement, Option, latest Offer per Option, NegotiationIssue, Requirement.
 */
import { Engagement, Option, Offer, NegotiationIssue, Requirement, Brief } from "@/api/entities";

export async function buildCoachContext(engagementId) {
  const engagement = await Engagement.get(engagementId);
  const req = (await Requirement.filter({ engagement_id: engagementId }, 1))?.[0] || null;
  const brief = (await Brief.filter({ engagement_id: engagementId, status: 'issued' }, 1))?.[0] || null;

  const options = await Option.filter({ engagement_id: engagementId }, 500);
  const offersByOption = {};
  for (const opt of options) {
    const offers = await Offer.filter({ engagement_id: engagementId, option_id: opt.id }, 10);
    // latest by received_dt
    offers.sort((a,b)=> new Date(b.received_date||0) - new Date(a.received_date||0));
    offersByOption[opt.id] = offers[0] || null;
  }
  const issues = await NegotiationIssue.filter({ engagement_id: engagementId }, 500);

  return {
    engagement: pick(engagement, ['id','company_id','state','sector']),
    requirement: req,
    brief: brief ? { recipients: brief.recipients, created_at: brief.created_date } : null,
    options: options.map(o => ({
      id: o.id, 
      building_id: o.building_id,
      area_sqm: o.area_sqm,
      rent_sqm_pa: o.rent_sqm_pa,
      incentive_months: o.incentive_months,
      lease_term_years: o.lease_term_years,
      tco_npv_aud: o.tco_npv_aud, 
      status: o.shortlist_bool ? 'shortlisted' : 'candidate', 
      notes: o.notes
    })),
    latest_offers: Object.entries(offersByOption).map(([option_id, offer]) => ({ option_id, offer })),
    issues: issues.map(i => ({
      id: i.id, 
      option_id: i.offer_id, // Assuming offer_id on issue links to the option context
      category: i.issue_type, 
      tenant_position: i.tenant_position,
      landlord_position: i.landlord_position, 
      status: i.status, 
      priority: i.priority
    }))
  };
}

function pick(obj, keys){ if(!obj) return null; const out={}; keys.forEach(k=> out[k]=obj[k]); return out; }