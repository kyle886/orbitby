// Build monthly series for Engaged (live) and BD (pipeline) with segmentation by project_type.
// Updated to handle milestone-based and success-based fee recognition
export function buildPipelineSeries({ engaged = [], bd = [], months = 12, mode = 'recognition', today = new Date() }) {
  const start = firstOfMonth(today);
  const end = addMonths(start, months - 1);
  const labels = monthsBetween(start, end).map(d => ym(d));
  const types = uniq([...engaged.map(x => x.project_type).filter(Boolean), ...bd.map(x => x.project_type).filter(Boolean)]);

  const engagedSeries = initMatrix(labels, types);
  const bdSeries = initMatrix(labels, types);

  // --- ENGAGED (with milestone and success-based handling) ---
  for (const r of engaged) {
    const type = r.project_type || 'General';
    const value = num(r.fee_aud ?? 0);
    
    // Use the appropriate date based on mode
    let targetDate;
    if (mode === 'cash') {
      targetDate = parseDate(r.cash_dt) || parseDate(r.end_dt) || start;
    } else {
      // Revenue recognition mode
      targetDate = parseDate(r.start_dt) || parseDate(r.end_dt) || start;
    }

    const targetMonth = ym(targetDate);
    
    // Add value to the target month if it exists in our series
    if (engagedSeries[targetMonth] && engagedSeries[targetMonth][type] !== undefined) {
      engagedSeries[targetMonth][type] = (engagedSeries[targetMonth][type] || 0) + value;
    }
  }

  // --- BD (unchanged logic) ---
  for (const r of bd) {
    const type = r.project_type || 'General';
    const base = num(r.expected_value_aud ?? r.value_aud ?? 0);
    const p = clamp01(r.probability ?? 0.5);
    const close = parseDate(r.expected_close_dt) || parseDate(r.target_start_dt) || start;
    
    // BD treatment: weight by probability, drop into close month (50%), and smear 25% to -1m and +1m to reflect slippage.
    const weighted = base * p;
    const month0 = ym(close);
    const monthM1 = ym(addMonths(close, -1));
    const monthP1 = ym(addMonths(close, +1));
    add(bdSeries, monthM1, type, weighted * 0.25);
    add(bdSeries, month0, type, weighted * 0.5);
    add(bdSeries, monthP1, type, weighted * 0.25);
  }

  // Totals per month
  const engagedTotals = labels.map(k => sumObj(engagedSeries[k]));
  const bdTotals = labels.map(k => sumObj(bdSeries[k]));

  return {
    labels, types,
    engaged: engagedSeries,
    bd: bdSeries,
    engagedTotals,
    bdTotals,
    combinedTotals: labels.map((_, i) => engagedTotals[i] + bdTotals[i]),
  };
}

export function buildSeasonality(series) {
  // Returns 12 values (Jan..Dec) from future series
  const map = Array.from({ length: 12 }, () => 0);
  series.labels.forEach((k, i) => {
    const m = Number(k.slice(5, 7)) - 1; // 0..11
    if (m >= 0 && m < 12) { // Ensure valid month index
      map[m] += series.combinedTotals[i];
    }
  });
  return map;
}

// ---------- helpers ----------
function initMatrix(labels, types) {
  const m = {}; 
  labels.forEach(k => { 
    m[k] = {}; 
    types.forEach(t => m[k][t] = 0); 
  }); 
  return m;
}

function monthsBetween(a, b) { const out=[]; const d=new Date(a); d.setDate(1); while (d <= b){ out.push(new Date(d)); d.setMonth(d.getMonth()+1);} return out; }
function firstOfMonth(d){ const x=new Date(d); x.setDate(1); x.setHours(0,0,0,0); return x; }
function addMonths(d,n){ const x=new Date(d); x.setMonth(x.getMonth()+n); return x; }
function ym(d){ const y=d.getFullYear(); const m=String(d.getMonth()+1).padStart(2,'0'); return `${y}-${m}`; }
function parseDate(x){ const t=Date.parse(x||''); return isFinite(t)? new Date(t): null; }
function add(series, key, type, v){ if (!series[key] || series[key][type] === undefined) return; series[key][type]=(series[key][type]||0)+v; }
function sumObj(o){ return Object.values(o||{}).reduce((a,b)=>a+num(b),0); }
function uniq(a){ return [...new Set(a)]; }
function num(x){ const n=Number(x||0); return isFinite(n)?n:0; }
function clamp01(p){ return Math.max(0, Math.min(1, Number(p||0))); }