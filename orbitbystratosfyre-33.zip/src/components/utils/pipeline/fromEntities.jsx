// Updated to handle milestone-based and success-based fee recognition
export function mapEngagements(rows=[]) {
  return rows.map(r => {
    const projectType = r.project_type || r.type || 'General';
    const totalFee = toNum(r.pipeline_value_aud ?? r.fee_aud ?? r.expected_fee_aud ?? r.value_aud ?? r.budget_range_max);
    const feeRecognitionType = r.fee_recognition_type || 'success-based';
    const estimatedCloseDate = r.estimated_project_close_date || r.close_dt || r.target_complete_dt;
    const projectStartDate = r.created_date || new Date().toISOString();

    // === FIX: Guard against invalid or missing close dates ===
    if (!estimatedCloseDate) {
      return []; // Return an empty array for this engagement if the close date is missing
    }

    // Validate the date
    const closeDateObj = new Date(estimatedCloseDate);
    if (isNaN(closeDateObj.getTime())) {
      return []; // Return empty if date is invalid
    }
    
    if (feeRecognitionType === 'success-based') {
      // Success-based: 100% revenue recognition at close date, cash 30 days later
      const recognitionDate = estimatedCloseDate;
      const cashDateObj = new Date(closeDateObj);
      cashDateObj.setDate(cashDateObj.getDate() + 30);
      const cashDate = cashDateObj.toISOString().split('T')[0]; // Keep as date string
      
      return {
        project_type: projectType,
        start_dt: recognitionDate, // Revenue recognition date
        end_dt: recognitionDate,   // Same date for success-based
        cash_dt: cashDate,         // Cash 30 days later
        fee_aud: totalFee,
        recognition: 'success-based'
      };
    } else {
      // Milestone-based: spread across project timeline
      const milestones = [];
      const startDate = new Date(projectStartDate);
      const closeDate = new Date(estimatedCloseDate);

      // === FIX: Check for valid dates before calculating totalDays ===
      if (isNaN(startDate.getTime()) || isNaN(closeDate.getTime()) || closeDate < startDate) {
        return []; // Return empty if dates are invalid
      }
      
      const totalDays = Math.max(1, Math.floor((closeDate - startDate) / (1000 * 60 * 60 * 24)));
      
      const milestoneData = [
        { pct: toNum(r.milestone_1_pct || 10), timelinePct: 0.1 },
        { pct: toNum(r.milestone_2_pct || 20), timelinePct: 0.3 },
        { pct: toNum(r.milestone_3_pct || 30), timelinePct: 0.6 },
        { pct: toNum(r.milestone_4_pct || 40), timelinePct: 1.0 }
      ];

      milestoneData.forEach((milestone, index) => {
        const daysIntoProject = Math.floor(totalDays * milestone.timelinePct);
        const milestoneDate = new Date(startDate);
        milestoneDate.setDate(milestoneDate.getDate() + daysIntoProject);
        
        const cashDate = new Date(milestoneDate);
        cashDate.setDate(cashDate.getDate() + 30);
        
        const milestoneValue = (totalFee * milestone.pct) / 100;

        milestones.push({
          project_type: projectType,
          start_dt: milestoneDate.toISOString().split('T')[0], // Keep as date string
          end_dt: milestoneDate.toISOString().split('T')[0],   // Keep as date string
          cash_dt: cashDate.toISOString().split('T')[0],       // Keep as date string
          fee_aud: milestoneValue,
          recognition: 'milestone',
          milestone_number: index + 1
        });
      });

      return milestones;
    }
  }).flat(); // Flatten in case of milestone arrays
}

export function mapBD(rows=[]) {
  return rows.map(r => {
    const estimatedCloseDate = r.expected_close_dt || r.target_close_dt || r.meeting_dt || r.created_date;
    
    // Guard against invalid dates
    if (!estimatedCloseDate) {
      return {
        project_type: r.project_type || r.type || 'General',
        expected_close_dt: new Date().toISOString().split('T')[0], // Default to today
        target_start_dt: r.target_start_dt || null,
        expected_value_aud: toNum(r.expected_value_aud ?? r.pipeline_value_aud ?? r.value_aud),
        probability: toNum(r.probability ?? r.win_prob ?? 0.5)
      };
    }

    const closeDateObj = new Date(estimatedCloseDate);
    if (isNaN(closeDateObj.getTime())) {
      return {
        project_type: r.project_type || r.type || 'General',
        expected_close_dt: new Date().toISOString().split('T')[0], // Default to today
        target_start_dt: r.target_start_dt || null,
        expected_value_aud: toNum(r.expected_value_aud ?? r.pipeline_value_aud ?? r.value_aud),
        probability: toNum(r.probability ?? r.win_prob ?? 0.5)
      };
    }

    return {
      project_type: r.project_type || r.type || 'General',
      expected_close_dt: estimatedCloseDate,
      target_start_dt: r.target_start_dt || null,
      expected_value_aud: toNum(r.expected_value_aud ?? r.pipeline_value_aud ?? r.value_aud),
      probability: toNum(r.probability ?? r.win_prob ?? 0.5)
    };
  });
}

const toNum = v => { const n = Number(v||0); return isFinite(n)?n:0; };