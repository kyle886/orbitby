// Offline queue for mobile apps
const K='orbit_offline_queue';

export function enqueue(kind, payload){ 
  const q = read(); 
  q.push({kind, payload, ts: Date.now()}); 
  localStorage.setItem(K, JSON.stringify(q)); 
}

export function read(){ 
  try{ 
    return JSON.parse(localStorage.getItem(K)||'[]'); 
  } catch{ 
    return []; 
  } 
}

export async function flush(handler){
  const q = read(); 
  const ok = []; 
  
  for (const it of q){ 
    try{ 
      await handler(it); 
      ok.push(it); 
    } catch(error) {
      console.error('Failed to process queue item:', error);
    }
  }
  
  if (ok.length){ 
    const rest = q.filter(x => !ok.includes(x)); 
    localStorage.setItem(K, JSON.stringify(rest)); 
  }
  
  return ok.length;
}