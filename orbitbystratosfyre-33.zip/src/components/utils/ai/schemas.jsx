export const Schemas = {
  InboundGenie: {
    type: "object",
    properties: {
      credibility: {
        type: "array",
        items: {
          type: "object",
          properties: {
            title: { type: "string", description: "Concise, engaging title for the recommendation.", minLength: 5 },
            summary: { type: "string", description: "Brief summary of the recommendation's content or action.", minLength: 10 },
            rationale: { type: "string", description: "Explanation of why this recommendation is valuable.", minLength: 20 },
            cta: { type: "string", description: "Call to action for the recommendation (e.g., 'Learn more', 'Download guide').", minLength: 3 },
            channels: { type: "array", items: { type: "string" }, description: "Suggested channels for distribution (e.g., 'linkedin', 'blog', 'twitter').", minItems: 1 },
            score: { type: "number", minimum: 1, maximum: 10, description: "A score from 1-10 indicating the potential impact/quality." },
            effort: { type: "string", enum: ["low", "med", "high"], description: "Estimated effort to execute (low, med, high)." },
            source_refs: {
              type: "object",
              properties: {
                event_id: { type: "string", description: "ID of an internal event if tied to one." },
                target_overlap: { type: "number", description: "Score indicating overlap with top target accounts." },
                lease_ids: { type: "array", items: { type: "string" }, description: "List of related lease IDs for context." },
                brief_ids: { type: "array", items: { type: "string" }, description: "List of related brief IDs for context." },
                building_ids: { type: "array", items: { type: "string" }, description: "List of related building IDs for context." },
              },
              description: "References to internal data that informed the recommendation."
            }
          },
          required: ["title", "summary", "rationale", "cta", "channels", "score", "effort"]
        }
      },
      visibility: { 
        type: "array", 
        items: { $ref: "#/properties/credibility/items" } 
      },
      inbound: { 
        type: "array", 
        items: { $ref: "#/properties/credibility/items" } 
      }
    },
    required: ["credibility", "visibility", "inbound"]
  },

  NegotiationCoach: {
    type: "object",
    properties: {
      situation_assessment: {
        type: "string",
        description: "Overall assessment of the current negotiation position and market dynamics"
      },
      recommended_moves: {
        type: "array",
        items: {
          type: "object",
          properties: {
            issue_id: { type: "string", description: "Reference to the negotiation issue being addressed" },
            move: { type: "string", description: "Recommended negotiation move or counter-proposal" },
            expected_value_aud: { type: "number", description: "Expected financial impact in AUD" },
            risk: { type: "string", enum: ["low", "medium", "high"] },
            confidence: { type: "number", minimum: 0, maximum: 100 }
          },
          required: ["move", "risk", "confidence"]
        }
      },
      strategic_notes: {
        type: "string",
        description: "Strategic insights and relationship management advice"
      },
      email_template: {
        type: "object",
        properties: {
          subject: { type: "string" },
          body: { type: "string" },
          suggested_tone: { type: "string", enum: ["professional_formal", "professional_collaborative", "firm_but_fair"] }
        }
      }
    },
    required: ["situation_assessment", "recommended_moves"]
  }
};