import { AIPropertyReview } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { PropertyReviewSchema } from "./propertyReviewSchemas";

export async function runPropertyReview({ brief, property, currentUser }) {
  try {
    // Build prompt input
    const briefData = {
      id: brief.id,
      area_need: brief.min_floor_area || brief.max_floor_area,
      locations: brief.preferred_suburbs || [],
      budget_max: brief.budget_max || null,
      property_type: brief.property_type,
      constraints: brief.additional_notes || ''
    };

    const propertyData = {
      id: property.id,
      title: property.property_title || property.title,
      address: property.address || property.street_address,
      area: property.floor_area_sqm,
      rent_rate: property.rental_rate_sqm,
      description: property.description || ''
    };

    const prompt = `Analyze this property against the client brief and provide a detailed assessment:

PROPERTY:
- Title: ${propertyData.title}
- Address: ${propertyData.address}
- Size: ${propertyData.area} sqm
- Rental Rate: $${propertyData.rent_rate}/sqm/annum
- Description: ${propertyData.description}

CLIENT BRIEF:
- Required Size: ${briefData.area_need} sqm
- Budget: ${briefData.budget_max ? `$${briefData.budget_max}` : 'Not specified'}
- Preferred Locations: ${briefData.locations.join(', ') || 'Not specified'}
- Property Type: ${briefData.property_type}
- Additional Requirements: ${briefData.constraints}

Provide:
1. Overall match score (0-100)
2. Recommendation (shortlist/reject/backup)
3. Detailed rationale (minimum 30 characters)
4. List of issues or concerns with category, note, and severity (1-5)`;

    // Call AI with schema validation
    const aiResponse = await InvokeLLM({
      prompt,
      response_json_schema: PropertyReviewSchema
    });

    // Create review record
    const reviewData = {
      submission_id: property.id,
      brief_id: brief.id,
      ai_recommendation: aiResponse.ai_recommendation || "pending",
      match_score: aiResponse.match_score || 0,
      criteria_scores: {
        location_score: calculateLocationScore(briefData.locations, propertyData.address),
        size_score: calculateSizeScore(briefData.area_need, propertyData.area),
        budget_score: calculateBudgetScore(briefData.budget_max, propertyData.rent_rate, propertyData.area)
      },
      ai_reasoning: aiResponse.rationale || "Analysis completed",
      deal_prediction: {
        confidence_level: aiResponse.match_score > 80 ? "High" : aiResponse.match_score > 60 ? "Medium" : "Low"
      }
    };

    const review = await AIPropertyReview.create(reviewData);
    return review;

  } catch (error) {
    console.error('Property review failed:', error);
    
    // Create fallback review record
    const fallbackReview = await AIPropertyReview.create({
      submission_id: property.id,
      brief_id: brief.id,
      ai_recommendation: "pending",
      match_score: 0,
      ai_reasoning: `AI analysis failed: ${error.message}`,
      deal_prediction: { confidence_level: "Low" }
    });
    
    return fallbackReview;
  }
}

// Helper scoring functions
function calculateLocationScore(preferredLocations, address) {
  if (!preferredLocations.length || !address) return 5;
  const addressLower = address.toLowerCase();
  const hasMatch = preferredLocations.some(loc => 
    addressLower.includes(loc.toLowerCase())
  );
  return hasMatch ? 9 : 3;
}

function calculateSizeScore(targetArea, actualArea) {
  if (!targetArea || !actualArea) return 5;
  const ratio = actualArea / targetArea;
  if (ratio >= 0.8 && ratio <= 1.2) return 10;
  if (ratio >= 0.6 && ratio <= 1.5) return 7;
  return 4;
}

function calculateBudgetScore(budgetMax, rentRate, area) {
  if (!budgetMax || !rentRate || !area) return 5;
  const totalAnnualRent = rentRate * area;
  const ratio = totalAnnualRent / budgetMax;
  if (ratio <= 0.8) return 10;
  if (ratio <= 1.0) return 8;
  if (ratio <= 1.2) return 5;
  return 2;
}