import { Schemas } from "./schemas.js";
import { AIJob } from "@/api/entities";
import { AIProfile } from "@/api/entities";
import { validateJson } from "@/api/functions";

/**
 * callAIGuarded(profileName, invokeFn, input)
 * - Looks up AIProfile (optional)
 * - Calls invokeFn(input) (your existing LLM caller)
 * - Validates JSON result against Schemas[profileName] via a backend function
 * - Writes AIJob success/failed with confidence + notes
 * - Returns { ok, data, error }
 */
export async function callAIGuarded(profileName, invokeFn, input, { currentUser } = {}) {
  let profile;
  try {
    const profiles = await AIProfile.filter({ name: profileName });
    profile = profiles?.[0] || null;
  } catch (e) {
    profile = null;
  }
  
  const started = new Date().toISOString();
  let job = null;
  
  try {
    const jobData = {
      input_summary: summarizeInput(input),
      status: "success", // Assume success until failure
      notes: "",
      confidence: 70
    };
    
    // Only include profile_id if we have a valid profile
    if (profile?.id) {
      jobData.profile_id = profile.id;
    }
    
    job = await AIJob.create(jobData);
  } catch(e) {
      console.warn("Could not create AIJob log entry:", e);
  }

  try {
    const raw = await invokeFn(input, profile);
    const data = typeof raw === "string" ? safeParse(raw) : raw;
    const schema = Schemas[profileName];
    if (!schema) throw new Error(`No schema for profile ${profileName}`);
    
    // Call backend function for validation
    const validationResult = await validateJson({ data, schema });

    if (!validationResult.data.ok) {
      const msg = validationResult.data.error;
      await safeUpdate(job, { status: "failed", notes: msg, output_json: data ?? null, confidence: 0 });
      return { ok: false, error: msg };
    }

    const confidence = extractConfidence(data) ?? 70;
    await safeUpdate(job, { status: "success", output_json: data, confidence });
    return { ok: true, data };
  } catch (e) {
    await safeUpdate(job, { status: "failed", notes: e?.message || "AI call failed", confidence: 0 });
    return { ok: false, error: e.message };
  }
}

function summarizeInput(input) {
  const str = JSON.stringify(input);
  return str.length > 500 ? str.slice(0, 497) + '...' : str;
}

async function safeUpdate(job, payload) {
  if (!job?.id) return;
  try {
    await AIJob.update(job.id, payload);
  } catch(e) {
    console.warn(`Could not update AIJob ${job.id}:`, e);
  }
}

function safeParse(str) {
  try { return JSON.parse(str); } catch { return null; }
}

function extractConfidence(data) {
  if (typeof data !== 'object' || !data) return null;
  return data.confidence ?? data.score ?? null;
}