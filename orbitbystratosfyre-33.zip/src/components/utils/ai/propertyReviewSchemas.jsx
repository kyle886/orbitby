export const PropertyReviewSchema = {
  type: "object",
  required: ["match_score", "ai_recommendation", "rationale", "issues"],
  properties: {
    match_score: { 
      type: "integer", 
      minimum: 0, 
      maximum: 100 
    },
    ai_recommendation: { 
      type: "string",
      enum: ["shortlist", "reject", "backup", "pending"]
    },
    rationale: { 
      type: "string", 
      minLength: 30 
    },
    issues: {
      type: "array",
      items: {
        type: "object",
        required: ["category", "note", "severity"],
        properties: {
          category: { type: "string" },
          note: { type: "string" },
          severity: { type: "integer", minimum: 1, maximum: 5 }
        },
        additionalProperties: false
      }
    }
  },
  additionalProperties: false
};