
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserUnitPreference } from '@/api/entities';
import { UnitSettings } from '@/api/entities';
import { User } from '@/api/entities';
import { fxRates as fetchFxRates } from '@/components/utils/forex';

const UnitContext = createContext();

export const useUnits = () => useContext(UnitContext);

const defaultPreferences = {
  currency: 'AUD',
  area_unit: 'm2',
  rent_unit: 'AUD_per_m2_pa',
};

const defaultFxRates = {
  AUDUSD: 0.68,
  AUDEUR: 0.62,
  AUDGBP: 0.54,
  USDAUD: 1.47,
  GBPAUD: 1.85,
  EURAUD: 1.61
};

const SQM_TO_SQFT = 10.76391041671;

export const UnitProvider = ({ children }) => {
  const [preferences, setPreferences] = useState(defaultPreferences);
  const [fxRates, setFxRates] = useState(defaultFxRates);
  const [loading, setLoading] = useState(true);

  const loadPreferences = useCallback(async () => {
    setLoading(true);
    try {
      const user = await User.me();
      const [userPrefs] = await UserUnitPreference.filter({ user_id: user.id });
      const [globalSettings] = await UnitSettings.list();

      if (userPrefs) {
        setPreferences(userPrefs);
      } else if (globalSettings) {
        setPreferences({
          currency: globalSettings.default_currency,
          area_unit: globalSettings.default_area_unit,
          rent_unit: globalSettings.default_rent_unit,
        });
      }

      // --- FX RATES INTEGRATION ---
      const cachedFx = localStorage.getItem('fxRates');
      const now = new Date().getTime();
      if (cachedFx) {
        const { rates, timestamp } = JSON.parse(cachedFx);
        if (now - timestamp < 24 * 60 * 60 * 1000) { // 24-hour TTL
          setFxRates(rates);
          console.log("Using cached FX rates.");
        }
      }

      // Fetch fresh rates if cache is stale or missing
      try {
        const freshRates = await fetchFxRates('AUD', 'USD,EUR,GBP');
        if (freshRates && freshRates.rates) {
            const combinedRates = {
                ...defaultFxRates, // Fallback
                AUDUSD: freshRates.rates.USD,
                AUDEUR: freshRates.rates.EUR,
                AUDGBP: freshRates.rates.GBP,
                USDAUD: 1 / freshRates.rates.USD,
                EURAUD: 1 / freshRates.rates.EUR,
                GBPAUD: 1 / freshRates.rates.GBP,
            };
            setFxRates(combinedRates);
            localStorage.setItem('fxRates', JSON.stringify({ rates: combinedRates, timestamp: now }));
            console.log("Fetched and cached fresh FX rates.");
        }
      } catch (apiError) {
          console.error("Failed to fetch fresh FX rates, using defaults/cached.", apiError);
          // If API fails, we'll just stick with what we have (defaults or cached)
      }

    } catch (error) {
      console.error("Failed to load unit preferences:", error);
      // Fallback to defaults
      setPreferences(defaultPreferences);
      setFxRates(defaultFxRates); // Ensure fxRates also falls back to default on general error
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPreferences();
  }, [loadPreferences]);

  const updatePreference = async (key, value) => {
    try {
      const user = await User.me();
      const newPrefs = { ...preferences, [key]: value };
      setPreferences(newPrefs);
      
      const [userPrefs] = await UserUnitPreference.filter({ user_id: user.id });
      if (userPrefs) {
        await UserUnitPreference.update(userPrefs.id, { [key]: value });
      } else {
        await UserUnitPreference.create({ ...defaultPreferences, ...newPrefs, user_id: user.id });
      }
    } catch (error) {
      console.error("Failed to save unit preference:", error);
    }
  };

  const convertEconomics = useCallback((input) => {
    const output = {};
    
    // Area Conversion
    if (typeof input.area_m2 === 'number') {
      if (preferences.area_unit === 'ft2') {
        output.area = { value: (input.area_m2 * SQM_TO_SQFT).toLocaleString(undefined, { maximumFractionDigits: 0 }), unit: 'sqft' };
      } else {
        output.area = { value: input.area_m2.toLocaleString(undefined, { maximumFractionDigits: 0 }), unit: 'sqm' };
      }
    }

    // Rent Conversion
    if (typeof input.rent_aud_per_m2_pa === 'number') {
      let rent = input.rent_aud_per_m2_pa;
      const targetCurrency = preferences.currency;
      const targetAreaUnit = preferences.area_unit;
      const targetRentUnit = preferences.rent_unit;

      // Apply FX
      if (targetCurrency !== 'AUD') {
        const fxKey = `AUD${targetCurrency}`;
        rent = rent * (fxRates[fxKey] || 1);
      }

      // Apply Area and Frequency Conversion
      if (targetRentUnit.includes('ft2_pm')) {
        rent = (rent / 12) / SQM_TO_SQFT;
      } else if (targetRentUnit.includes('ft2_pa')) {
        rent = rent / SQM_TO_SQFT;
      } else if (targetRentUnit.includes('m2_pm')) {
        rent = rent / 12;
      }
      
      // Derive unit label for display, e.g., AUD/m2/pa, USD/sqft/pm
      const rentUnitParts = targetRentUnit.split('_');
      let frequency = rentUnitParts[rentUnitParts.length - 1]; // e.g., 'pa' or 'pm'
      if (frequency === 'pa') frequency = '/pa';
      else if (frequency === 'pm') frequency = '/pm';
      else frequency = ''; // Fallback for unexpected formats

      const unitLabel = `${targetCurrency}/${targetAreaUnit}${frequency}`;
      output.rent = { value: rent.toLocaleString(undefined, { maximumFractionDigits: 2 }), unit: unitLabel };
    }

    // Incentives (passthrough)
    if (typeof input.incentives_pct === 'number') {
        output.incentives = { value: input.incentives_pct, unit: '%' };
    }

    return output;

  }, [preferences, fxRates]);

  const value = {
    preferences,
    updatePreference,
    convertEconomics,
    loading,
  };

  return <UnitContext.Provider value={value}>{children}</UnitContext.Provider>;
};
