/**
 * Fetches latest foreign exchange rates from the free exchangerate.host API.
 * No API key required.
 * @param {string} base Base currency (e.g., 'AUD')
 * @param {string} symbols Comma-separated list of currencies to fetch (e.g., 'USD,EUR,GBP')
 * @returns {Promise<object>} API response, e.g., { rates: { USD: 0.66, ... } }
 */
export async function fxRates(base = 'AUD', symbols = 'USD,EUR,GBP') {
  const url = `https://api.exchangerate.host/latest?base=${base}&symbols=${symbols}`;
  return fetch(url).then(r => r.json());
}