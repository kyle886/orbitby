const IMG_EXT = /\.(jpe?g|png|webp)(?:\?.*)?$/i;

function toAbs(u, baseUrl) {
  try { 
    return new URL(u, baseUrl).toString(); 
  } catch { 
    return ""; 
  }
}

function normForDedupe(u) {
  try {
    const url = new URL(u);
    return `${url.protocol}//${url.host}${url.pathname}`.toLowerCase();
  } catch { 
    return u.toLowerCase(); 
  }
}

function parseSrcset(srcset, baseUrl) {
  // pick the largest width
  const parts = srcset.split(",").map(s => s.trim());
  let best = "";
  let maxW = -1;
  
  for (const p of parts) {
    const [u, d] = p.split(/\s+/);
    const match = d && /(\d+)w/.exec(d);
    const w = match ? parseInt(match[1]) : 0;
    const abs = toAbs(u, baseUrl);
    if (abs && w >= maxW) { 
      maxW = w; 
      best = abs; 
    }
  }
  return best;
}

function scoreUrl(u) {
  try {
    const url = new URL(u);
    const name = url.pathname.split('/').pop()?.toLowerCase() || '';
    let score = 0;
    
    if (/(hero|main|primary|cover|exterior|building|property)/.test(name)) score += 5;
    if (/(gallery|image|photo)/.test(name)) score += 2;
    if (/(logo|icon|sprite|map|placeholder)/.test(name)) score -= 5;
    // prefer larger hints
    if (/(xl|large|1920|2048|2560|@2x)/.test(u)) score += 3;
    
    return score;
  } catch {
    return 0;
  }
}

export function harvestImagesFromHtml(html, baseUrl) {
  // Simple cheerio-like parsing using DOM methods when available
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  
  const found = new Set();
  const floorplans = new Set();

  const add = (u, isFloorplan = false) => {
    if (!u) return;
    if (!IMG_EXT.test(u)) return;
    const abs = toAbs(u, baseUrl);
    if (!abs) return;
    const key = normForDedupe(abs);
    if (/(floor[-_ ]?plan|plan)/i.test(abs) || isFloorplan) {
      floorplans.add(key);
    } else {
      found.add(key);
    }
  };

  // Meta & link tags
  const metaTags = doc.querySelectorAll('meta[property="og:image"], meta[name="twitter:image"], link[rel="image_src"]');
  metaTags.forEach(el => {
    const u = el.getAttribute('content') || el.getAttribute('href');
    if (u) add(u);
  });

  // JSON-LD
  const jsonLdScripts = doc.querySelectorAll('script[type="application/ld+json"]');
  jsonLdScripts.forEach(script => {
    try {
      const data = JSON.parse(script.textContent || "null");
      const imgs = Array.isArray(data?.image) ? data.image : data?.image ? [data.image] : [];
      imgs.forEach(u => add(u));
    } catch {}
  });

  // Images
  const images = doc.querySelectorAll('img');
  images.forEach(img => {
    const src = img.getAttribute('src');
    const dataSrc = img.getAttribute('data-src') || img.getAttribute('data-original');
    const srcset = img.getAttribute('srcset') || img.getAttribute('data-srcset');
    const cand = srcset ? parseSrcset(srcset, baseUrl) : (src || dataSrc);
    add(cand || "");
  });

  // Generic regex fallback (catches Colliers/CDNs)
  const rx = /https?:\/\/[^\s"'<>]+?\.(?:jpg|jpeg|png|webp)(?:\?[^\s"'<>]*)?/gi;
  const matches = html.match(rx) || [];
  matches.forEach(u => add(u));

  // Pick main by score
  const all = Array.from(found);
  const ranked = all.sort((a, b) => scoreUrl(b) - scoreUrl(a));
  const main = ranked[0] || null;

  const gallery = ranked.slice(0, 12).filter(u => u !== main);
  const floor = Array.from(floorplans).slice(0, 8);

  return { 
    main, 
    gallery, 
    floorplans: floor 
  };
}

export function pickImages(llmImages, html, baseUrl) {
  const fallback = harvestImagesFromHtml(html, baseUrl);

  const main = llmImages?.main || fallback.main;
  const gallery = Array.from(new Set([...(llmImages?.gallery || []), ...(fallback.gallery || [])]));
  const floorplans = Array.from(new Set([...(llmImages?.floorplans || []), ...(fallback.floorplans || [])]));

  return { main, gallery, floorplans };
}