import { User } from '@/api/entities';
import { JobRun } from '@/api/entities';

/**
 * Wraps a client-side job function with JobRun tracking.
 * @param {string} jobName - The name of the job for logging.
 * @param {Function} jobLogic - The async function to execute. It receives the payload.
 * @param {object} payload - The payload to pass to the jobLogic function.
 * @returns {Promise<object>} - The completed JobRun record.
 */
export async function runJob(jobName, jobLogic, payload = {}) {
  const user = await User.me();
  let jobRunId;

  try {
    const jobRun = await JobRun.create({
      job_name: jobName,
      started_at: new Date().toISOString(),
      status: 'queued',
      triggered_by: user.email,
      payload: payload
    });
    jobRunId = jobRun.id;

    // Execute the actual job logic
    const result = await jobLogic(payload);

    // Update job run with success
    const finalJobRun = await JobRun.update(jobRunId, {
      status: 'success',
      finished_at: new Date().toISOString(),
      rows_affected: result.rows_affected || 0,
      notes: result.notes || 'Job completed successfully',
      results: result.results || {}
    });
    
    return finalJobRun;

  } catch (error) {
    console.error(`Error in job "${jobName}":`, error);
    if (jobRunId) {
      // Update job run with failure details
      const finalJobRun = await JobRun.update(jobRunId, {
        status: 'failed',
        finished_at: new Date().toISOString(),
        notes: error.message,
        results: { error: error.stack }
      });
      return finalJobRun;
    }
    // Re-throw if we couldn't even create the initial job record
    throw error;
  }
}

/**
 * Triggers a BACKEND job by calling a function and creates a JobRun record
 * @param {string} jobType - The type of job to run (e.g., 'fundingNewsAgent')
 * @param {object} params - Additional parameters for the job
 * @returns {Promise<string>} - The JobRun ID for tracking
 */
export async function triggerJob(jobType, params = {}) {
  const user = await User.me();
  
  try {
    // Create job run record first
    const jobRun = await JobRun.create({
      job_name: jobType,
      started_at: new Date().toISOString(),
      status: 'queued',
      triggered_by: user.email,
      payload: params
    });

    // Call the backend function using the new platform method
    const jobModule = await import(`@/api/functions/${jobType}`);
    const jobFunction = jobModule.default || jobModule[jobType];
    
    if (!jobFunction || typeof jobFunction !== 'function') {
      throw new Error(`Function ${jobType} not found or not a function`);
    }

    const result = await jobFunction({
      triggered_by: user.email,
      job_run_id: jobRun.id,
      ...params
    });

    if (!result || !result.data) {
      throw new Error('Invalid response from backend function');
    }

    if (result.data.status === 'failed') {
      // Update job run with failure
      await JobRun.update(jobRun.id, {
        status: 'failed',
        finished_at: new Date().toISOString(),
        notes: result.data.error || 'Job failed',
        results: result.data
      });
      throw new Error(result.data.error || 'Job failed');
    }

    // Update job run with success
    await JobRun.update(jobRun.id, {
      status: result.data.status || 'success',
      finished_at: new Date().toISOString(),
      rows_affected: result.data.rows_affected || 0,
      notes: result.data.notes || 'Job completed successfully',
      results: result.data.results || {}
    });

    return jobRun.id;
    
  } catch (error) {
    console.error('Error triggering job:', error);
    throw error;
  }
}

/**
 * Polls a JobRun for completion
 * @param {string} jobRunId - The job run ID to monitor
 * @param {number} maxWaitMs - Maximum time to wait in milliseconds
 * @returns {Promise<object>} - The completed JobRun record
 */
export async function waitForJobCompletion(jobRunId, maxWaitMs = 60000) {
  const startTime = Date.now();
  
  while (Date.now() - startTime < maxWaitMs) {
    const jobRun = await JobRun.get(jobRunId);
    
    if (jobRun.status !== 'queued') {
      return jobRun;
    }
    
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  
  throw new Error('Job timed out waiting for completion');
}