// src/utils/portfolio/schedule.js
// Shapes expected:
// sites: [{ id, name, address, lat, lng, place_id }]
// leases: [{
//   id, site_id, area_m2, base_rent_psm_pa, outgoings_psm_pa, start_dt, end_dt,
//   review_month?: 1..12, review_kind?: 'cpi'|'fixed'|'market', review_fixed_pct?: number
//   option_notice_dt?, makegood_dt?
// }]

export function buildLiabilitySeries({ leases=[], months=12, today=new Date() }) {
  const start = firstOfMonth(today);
  const labels = monthsBetween(start, addMonths(start, months-1)).map(d => ym(d));
  const monthly = labels.reduce((acc,k)=> (acc[k]=0, acc), {});
  const bySite = labels.reduce((acc,k)=> (acc[k]={}, acc), {});

  for (const L of leases) {
    const s = parse(L.start_date) || start;
    const e = parse(L.expiry_date) || start;
    const rent_psm = toNum(L.rent_aud_per_m2_pa);
    const out_psm = toNum(L.opex_aud_per_m2_pa);
    const area = toNum(L.area_m2);

    if (!area || (!rent_psm && !out_psm)) continue;

    let rent = rent_psm * area;     // A$/year
    let out  = (out_psm||0) * area; // A$/year

    const revMonth = L.review_month ? Number(L.review_month) : null;
    const revKind  = (L.review_kind||'').toLowerCase();
    const revPct   = toNum(L.review_fixed_pct);

    for (const key of labels) {
      const d = parseYm(key);
      if (d < firstOfMonth(s) || d > firstOfMonth(e)) continue;

      // apply escalation on anniversary month
      if (revMonth && (d.getMonth()+1) === revMonth && (revKind==='fixed') && revPct) {
        rent *= (1 + revPct/100);
        out  *= 1; // usually outgoings are pass-through; leave as-is
      }
      // CPI (assume 3% proxy if no live CPI)
      if (revMonth && (d.getMonth()+1) === revMonth && revKind==='cpi') {
        rent *= 1.03;
      }

      const m = (rent + out) / 12;
      monthly[key] += m;
      bySite[key][L.building_id] = (bySite[key][L.building_id]||0) + m;
    }
  }

  return {
    labels,
    monthly,          // { 'YYYY-MM': A$ }
    monthlyArray: labels.map(k => monthly[k]),
    bySite            // { 'YYYY-MM': { site_id: A$ } }
  };
}

export function buildCriticalEvents({ leases=[], withinDays=120, today=new Date() }) {
  const now = today.getTime(), horizon = withinDays*864e5;
  const events = [];

  for (const L of leases) {
    const push = (title, dt, kind) => {
      const t = Date.parse(dt||''); if (!isFinite(t)) return;
      const delta = t - now; if (delta < 0 || delta > horizon) return;
      events.push({ lease_id:L.id, building_id:L.building_id, title, due_dt: new Date(t).toISOString(), kind });
    };

    push('Lease Expiry', L.expiry_date, 'expiry');
    if (L.option_notice_dt) push('Option Notice Deadline', L.option_notice_dt, 'option_notice');
    if (L.makegood_dt) push('Make Good Deadline', L.makegood_dt, 'makegood');

    // Rent review event (next occurrence within window)
    if (L.review_month) {
      const next = nextMonthOcc(Number(L.review_month), today);
      push('Rent Review', next.toISOString(), 'rent_review');
    }
  }

  // sort by due date ascending
  events.sort((a,b)=> new Date(a.due_dt) - new Date(b.due_dt));
  return events;
}

// --------- helpers ----------
const toNum = v => { const n=Number(v||0); return isFinite(n)?n:0; };
const parse = s => { const t = Date.parse(s||''); return isFinite(t)? new Date(t) : null; };
function monthsBetween(a,b){ const out=[]; const d=new Date(a); d.setDate(1); while (d<=b){ out.push(new Date(d)); d.setMonth(d.getMonth()+1);} return out; }
function addMonths(d,n){ const x=new Date(d); x.setMonth(x.getMonth()+n); return x; }
function firstOfMonth(d){ const x=new Date(d); x.setDate(1); x.setHours(0,0,0,0); return x; }
function ym(d){ return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`; }
function parseYm(k){ const [y,m]=k.split('-').map(Number); return new Date(y, m-1, 1); }
function nextMonthOcc(month1to12, today){
  const y=today.getFullYear(), cur=today.getMonth()+1;
  const y2 = month1to12 >= cur ? y : y+1;
  return new Date(y2, month1to12-1, 1);
}