export function computeEducationBusinessCase(i) {
  const Y = i.termYears;
  const years = Array.from({ length: Y }, (_, k) => k + 1);
  const enrolment = years.map(y => Math.round(i.maxEnrolment * Math.min(1, y / Math.max(1, i.rampUpYears))));

  function tuitionRevenueForEnrol(n) {
    if (i.sector === 'University' && i.tuition.university) {
      const u = i.tuition.university;
      const online = Math.round(n * (u.onlinePct / 100));
      const campus = n - online;
      return online * u.onlineTuition + campus * u.onCampusTuition;
    }
    if (i.tuition.distribution) {
      let sum = 0;
      Object.values(i.tuition.distribution).forEach(b => sum += n * (b.sharePct / 100) * b.tuition);
      return sum;
    }
    const avg = i.tuition.averagePerStudent ?? 0;
    return n * avg;
  }

  const revenue = years.map((_, idx) => tuitionRevenueForEnrol(enrolment[idx]) + (i.extraIncomePerYear ?? 0));

  const rent = years.map((_, idx) => i.rent.basePerAnnum * Math.pow(1 + (i.rent.escalationPct / 100), idx));

  // Capex impact: if tenant pays, subtract annual amortisation from effective revenue headroom
  const capexAmort = (i.capex.who === 'tenant' && i.capex.amount > 0) ? (i.capex.amount / (i.capex.amortYears || 5)) : 0;

  const rentPctOfRevenue = years.map((_, idx) => {
    const revAdj = Math.max(1, revenue[idx]) - capexAmort; // avoid divide by zero, subtract tenant capex annuity
    return (rent[idx] / revAdj) * 100;
  });

  const avgRentPct = rentPctOfRevenue.reduce((a, b) => a + b, 0) / Y;
  const maxRentPct = Math.max(...rentPctOfRevenue);
  const minRentPct = Math.min(...rentPctOfRevenue);
  const threshold = i.thresholdRentPct ?? 20;
  const pass = avgRentPct <= threshold && maxRentPct <= threshold * 1.25; // leeway on peak year

  return { years, enrolment, revenue, rent, rentPctOfRevenue, summary: { avgRentPct, maxRentPct, minRentPct, pass } };
}