// Feasibility engine — all AUD & m² canonical inputs.
export function npv(ratePct, cashflows) {
  const r = (ratePct ?? 10) / 100;
  return cashflows.reduce((acc, cf, t) => acc + cf / Math.pow(1 + r, t), 0);
}
export function irr(cashflows, guessPct = 10) {
  // Newton-Raphson with clamps
  let r = (guessPct ?? 10) / 100;
  for (let i = 0; i < 50; i++) {
    let f = 0, df = 0;
    for (let t = 0; t < cashflows.length; t++) {
      const denom = Math.pow(1 + r, t);
      f += cashflows[t] / denom;
      if (t > 0) df += -t * cashflows[t] / (denom * (1 + r));
    }
    const step = f / (df || 1e-9);
    r = Math.min(1.0, Math.max(-0.99, r - step));
    if (Math.abs(step) < 1e-7) break;
  }
  return r * 100;
}
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

// ---------- Lease scenario ----------
export function evalLease({
  area_m2,
  term_years,
  base_rent_psm,
  opex_psm = 0,
  indexation_pct = 3,
  incentives_pct = 0,           // treat as upfront credit against cost
  fitout_capex_aud = 0,
  landlord_contrib_aud = 0,
  discount_rate_pct = 10
}) {
  const years = Math.max(1, Math.round(term_years || 0));
  const idx = (indexation_pct ?? 0) / 100;
  const rent0 = (base_rent_psm ?? 0) * (area_m2 ?? 0);
  const opex0 = (opex_psm ?? 0) * (area_m2 ?? 0);
  const flows = [];
  // t=0: capex outflow net of landlord contrib + incentive credit
  const incentiveCredit = incentives_pct ? -(incentives_pct / 100) * (rent0 * years) : 0;
  flows.push(-(fitout_capex_aud || 0) + (landlord_contrib_aud || 0) + incentiveCredit);
  for (let y = 1; y <= years; y++) {
    const rentY = rent0 * Math.pow(1 + idx, y - 1);
    const opexY = opex0 * Math.pow(1 + idx, y - 1);
    flows.push(-(rentY + opexY));
  }
  const NPV = npv(discount_rate_pct, flows);
  const NPC = -NPV; // net present cost
  const NPC_per_m2 = (area_m2 ? NPC / (area_m2) : NPC);
  return { cashflows: flows, npv: NPV, npc: NPC, npc_per_m2: NPC_per_m2 };
}

// ---------- Buy (owner-occupy) ----------
export function evalBuy({
  area_m2,
  price_aud,
  stamp_duty_pct = 5.5,
  closing_cost_pct = 1.0,
  opex_psm = 0,
  exit_year = 10,
  exit_cap_rate_pct = 6.0,
  indexation_pct = 3.0,
  discount_rate_pct = 10.0,
  rent_equivalent_psm = 0 // optional shadow rent benefit; offsets opex
}) {
  const duty = (stamp_duty_pct / 100) * (price_aud || 0);
  const closing = (closing_cost_pct / 100) * (price_aud || 0);
  const flows = [];
  // t=0: purchase (outflow)
  flows.push(-((price_aud || 0) + duty + closing));
  const idx = (indexation_pct ?? 0) / 100;
  const opex0 = (opex_psm ?? 0) * (area_m2 ?? 0);
  const rentEq0 = (rent_equivalent_psm ?? 0) * (area_m2 ?? 0);
  for (let y = 1; y <= exit_year; y++) {
    const opexY = opex0 * Math.pow(1 + idx, y - 1);
    const rentEqY = rentEq0 * Math.pow(1 + idx, y - 1);
    // cash cost: opex minus the benefit of not paying rent (negative cost)
    flows.push(-(opexY - rentEqY));
  }
  // Exit value (positive inflow): capitalised "NOI" at exit OR market value
  const NOI_exit = Math.max(0, (rentEq0 - opex0)) * Math.pow(1 + idx, exit_year - 1);
  const exitValue = (exit_cap_rate_pct > 0) ? (NOI_exit / (exit_cap_rate_pct / 100)) : 0;
  flows[exit_year] += exitValue; // add to final year
  const NPV = npv(discount_rate_pct, flows);
  const NPC = -NPV;
  const NPC_per_m2 = (area_m2 ? NPC / (area_m2) : NPC);
  const _irr = irr(flows, discount_rate_pct);
  return { cashflows: flows, npv: NPV, npc: NPC, npc_per_m2: NPC_per_m2, irr_pct: clamp(_irr, -99, 200) };
}

// ---------- Develop (tenant-led, sell on completion or hold) ----------
export function evalDevelop({
  area_m2,
  land_cost_aud = 0,
  hard_cost_aud = 0,
  soft_cost_pct = 12,
  contingency_pct = 7.5,
  dm_fee_pct = 2.0,
  finance_rate_pct = 7.0,
  dev_period_years = 2.0,
  hold = false,
  leaseback_rent_psm = 0,   // if sell & leaseback
  opex_psm = 0,
  exit_yield_pct = 5.75,    // value on completion
  discount_rate_pct = 10.0
}) {
  const soft = (soft_cost_pct / 100) * hard_cost_aud;
  const cont = (contingency_pct / 100) * (hard_cost_aud + soft);
  const dm = (dm_fee_pct / 100) * (hard_cost_aud + soft);
  const baseCost = land_cost_aud + hard_cost_aud + soft + cont + dm;
  // simple IDC approximation: rate * avg balance * years
  const idc = (finance_rate_pct / 100) * (0.5 * baseCost) * (dev_period_years || 1);
  const totalCost = baseCost + idc;
  const flows = [];
  // Spread capex over dev period (quarterly draw approximation -> two outflows)
  flows.push(-0.5 * totalCost);
  flows.push(-0.5 * totalCost);
  if (!hold) {
    // value on completion via capitalised net rent (leaseback) or dev margin proxy
    const netRent0 = Math.max(0, (leaseback_rent_psm - opex_psm)) * (area_m2 || 0);
    const value = exit_yield_pct > 0 ? netRent0 / (exit_yield_pct / 100) : totalCost * 1.1;
    flows.push(value); // sale at PC
  } else {
    // hold: rent net of opex for N years (5 default here), terminal value at yield
    const years = 5;
    const net0 = Math.max(0, (leaseback_rent_psm - opex_psm)) * (area_m2 || 0);
    for (let y = 1; y <= years; y++) flows.push(net0);
    const terminal = exit_yield_pct > 0 ? (net0 / (exit_yield_pct / 100)) : net0 * 12;
    flows[flows.length - 1] += terminal;
  }
  const NPV = npv(discount_rate_pct, flows);
  const devMargin = (flows.reduce((a,b)=>a+b,0) + 0) - 0; // gross, not discounted
  const profitOnCost_pct = ((flows.at(-1) ?? 0) - totalCost) / (totalCost || 1) * 100;
  const _irr = irr(flows, discount_rate_pct);
  const NPC = -Math.min(NPV, 0); // for comparability (cost perspective)
  const NPC_per_m2 = (area_m2 ? NPC / area_m2 : NPC);
  return {
    cashflows: flows, npv: NPV,
    total_cost_aud: totalCost,
    profit_on_cost_pct: profitOnCost_pct,
    irr_pct: clamp(_irr, -99, 300),
    npc: NPC, npc_per_m2: NPC_per_m2
  };
}

// Roll-up comparison for Decision Matrix
export function decisionMatrix({ lease, buy, develop }) {
  const rows = [];
  if (lease) rows.push({ mode:"Lease", npc: lease.npc, npc_per_m2: lease.npc_per_m2, npv: lease.npv, irr_pct: null });
  if (buy)   rows.push({ mode:"Buy",   npc: buy.npc,   npc_per_m2: buy.npc_per_m2,   npv: buy.npv,   irr_pct: buy.irr_pct });
  if (develop) rows.push({ mode:"Develop", npc: develop.npc, npc_per_m2: develop.npc_per_m2, npv: develop.npv, irr_pct: develop.irr_pct });
  // lower NPC is better
  const best = rows.reduce((b,r)=> (b && b.npc <= r.npc) ? b : r, null);
  return { rows, bestMode: best?.mode || null };
}