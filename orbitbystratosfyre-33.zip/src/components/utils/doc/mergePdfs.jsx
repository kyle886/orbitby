export async function mergePdfs(urls = []) {
  try {
    // Try local install first, then CDN (no FS required)
    let PDFDocument;
    try {
      ({ PDFDocument } = await import('pdf-lib'));
    } catch {
      ({ PDFDocument } = await import('https://esm.sh/pdf-lib@1.17.1'));
    }
    const mergedPdf = await PDFDocument.create();
    for (const u of urls) {
      const bytes = await fetch(u).then(r => r.arrayBuffer());
      const src = await PDFDocument.load(bytes);
      const copied = await mergedPdf.copyPages(src, src.getPageIndices());
      copied.forEach(p => mergedPdf.addPage(p));
    }
    const mergedBytes = await mergedPdf.save();
    return new Blob([mergedBytes], { type: 'application/pdf' });
  } catch (e) {
    console.error("PDF Merge Error:", e);
    throw new Error("PDF merge failed. (Tried local & CDN import)");
  }
}