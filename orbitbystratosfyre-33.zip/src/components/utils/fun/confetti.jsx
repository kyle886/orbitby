// Lightweight confetti (no deps). Call fireConfetti() to celebrate.
export function fireConfetti({ count = 120, duration = 2000 } = {}) {
  const root = document.createElement('div');
  root.style.position = 'fixed';
  root.style.inset = '0';
  root.style.pointerEvents = 'none';
  root.style.zIndex = '70';
  document.body.appendChild(root);

  const colors = ['#6366f1', '#22c55e', '#f59e0b', '#ef4444', '#06b6d4', '#eab308'];
  const w = window.innerWidth;
  for (let i = 0; i < count; i++) {
    const p = document.createElement('div');
    const size = 6 + Math.random() * 6;
    const hue = colors[i % colors.length];
    const startX = (Math.random() * w) | 0;
    const drift = (Math.random() * 180 - 90) | 0;

    p.style.position = 'absolute';
    p.style.left = startX + 'px';
    p.style.top = '-60px';
    p.style.width = size + 'px';
    p.style.height = size * 0.6 + 'px';
    p.style.background = hue;
    p.style.transform = `translate3d(0,0,0) rotate(${Math.random()*180}deg)`;
    p.style.borderRadius = '2px';
    p.style.animation = `confetti-fall ${1.8 + Math.random() * 1.2}s cubic-bezier(.15,.65,.4,1) forwards`;
    p.style.setProperty('--x', drift + 'px');

    root.appendChild(p);
  }

  setTimeout(() => {
    root.remove();
  }, duration + 800);
}