
import React from 'react';
import { Target } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { MoreVertical, RefreshCw, Pin, PinOff } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { runJob } from '@/components/utils/runJob'; // Updated import path
import { calculateScores } from '@/components/utils/scoringCalculations';
import { Signal } from '@/api/entities';
import { Lease } from '@/api/entities';
import { AppSettings } from '@/api/entities';
import { useToast } from "@/components/ui/use-toast";

export function TargetActions({ target }) {
    const { toast } = useToast();

    const handleRecomputeScore = async () => {
        toast({ title: "Recomputing Score...", description: `Refreshing priority score for ${target.company_name}.` });
        
        await runJob('Recompute Single Target Score', async () => {
            const [signals, leases, settings] = await Promise.all([
                Signal.filter({ company_id: target.company_id }),
                Lease.filter({ company_id: target.company_id }),
                AppSettings.list().then(res => res[0] || {})
            ]);

            const scores = calculateScores(signals, leases, target, settings);
            
            await Target.update(target.id, {
                ...scores,
                last_refreshed_at: new Date().toISOString()
            });

            return { rows_affected: 1, notes: `Successfully recomputed score for ${target.company_name}. New score: ${scores.priority_score}` };
        }, { target_id: target.id });

        toast({ title: "Score Recomputed", description: `Score updated for ${target.company_name}.` });
    };

    const handlePin = async () => {
        const newPinnedState = !target.pinned;
        const thirtyDaysFromNow = new Date();
        thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);

        try {
            await Target.update(target.id, {
                pinned: newPinnedState,
                pinned_until: newPinnedState ? thirtyDaysFromNow.toISOString() : null
            });
            toast({ title: newPinnedState ? "Target Pinned" : "Target Unpinned" });
        } catch (error) {
            console.error("Failed to update pin status:", error);
            toast({ variant: "destructive", title: "Update Failed" });
        }
    };
    
    const isPinActive = target.pinned && new Date(target.pinned_until) > new Date();

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
                <DropdownMenuItem onClick={handleRecomputeScore}>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Recompute Score
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handlePin}>
                    {isPinActive ? <PinOff className="mr-2 h-4 w-4" /> : <Pin className="mr-2 h-4 w-4" />}
                    {isPinActive ? "Unpin Target" : "Pin for 30 Days"}
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}
