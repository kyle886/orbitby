import React from 'react';
import { Pitch } from '@/api/entities';
import { Company } from '@/api/entities';
import { Signal } from '@/api/entities';
import { Contact } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { MoreVertical, FileText, TrendingUp, Users, Send } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { runJob } from '@/components/utils/runJob';
import { InvokeLLM } from '@/api/integrations';
import { useToast } from "@/components/ui/use-toast";

export function PitchActions({ pitch, onUpdate }) {
    const { toast } = useToast();

    const handleCalculateReadiness = async () => {
        toast({ title: "Calculating Readiness...", description: `Analyzing readiness score for ${pitch.pitch_name || 'pitch'}.` });
        
        await runJob('Calculate Pitch Readiness', async () => {
            // Get related data for readiness calculation
            const [company, signals, contacts] = await Promise.all([
                Company.filter({ id: pitch.company_id }).then(c => c[0]),
                Signal.filter({ company_id: pitch.company_id }),
                Contact.filter({ company_id: pitch.company_id })
            ]);

            const readinessPrompt = `
                Analyze the readiness score for this business pitch:
                Company: ${company?.name || 'Unknown'}
                Sector: ${company?.sector || 'Unknown'}
                Pitch Status: ${pitch.status}
                Meeting Date: ${pitch.meeting_dt || 'Not scheduled'}
                Project Brief: ${pitch.project_brief || 'Not provided'}
                Pitch Pack URL: ${pitch.pack_url ? 'Available' : 'Not available'}
                
                Recent Signals (${signals.length} total):
                ${signals.slice(0, 5).map(s => `- ${s.type}: ${s.title}`).join('\n')}
                
                Key Contacts (${contacts.length} total):
                ${contacts.slice(0, 3).map(c => `- ${c.name} (${c.role})`).join('\n')}
                
                Calculate readiness score (0-100) based on:
                1. Company research completeness (25 points)
                2. Pitch materials preparation (25 points)  
                3. Meeting logistics setup (20 points)
                4. Team preparation and assignments (20 points)
                5. Follow-up strategy (10 points)
                
                Provide specific recommendations for improvement.
            `;

            const readinessAnalysis = await InvokeLLM({
                prompt: readinessPrompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        readiness_score: { type: "number", minimum: 0, maximum: 100 },
                        research_score: { type: "number", minimum: 0, maximum: 25 },
                        materials_score: { type: "number", minimum: 0, maximum: 25 },
                        logistics_score: { type: "number", minimum: 0, maximum: 20 },
                        team_score: { type: "number", minimum: 0, maximum: 20 },
                        strategy_score: { type: "number", minimum: 0, maximum: 10 },
                        recommendations: { type: "array", items: { type: "string" } },
                        missing_items: { type: "array", items: { type: "string" } }
                    },
                    required: ["readiness_score", "recommendations"]
                }
            });

            await Pitch.update(pitch.id, {
                readiness_score: readinessAnalysis.readiness_score,
                recommendations: {
                    ...readinessAnalysis,
                    calculated_at: new Date().toISOString()
                }
            });

            return { 
                rows_affected: 1, 
                notes: `Readiness score: ${readinessAnalysis.readiness_score}%. ${readinessAnalysis.recommendations.length} recommendations provided.` 
            };
        }, { pitch_id: pitch.id });

        if (onUpdate) onUpdate();
        toast({ title: "Readiness Calculated", description: `Score updated for ${pitch.pitch_name || 'pitch'}.` });
    };

    const handleGenerateDossier = async () => {
        toast({ title: "Generating Dossier...", description: "Creating comprehensive pitch dossier." });
        
        await runJob('Generate Pitch Dossier', async () => {
            const [company, signals, contacts] = await Promise.all([
                Company.filter({ id: pitch.company_id }).then(c => c[0]),
                Signal.filter({ company_id: pitch.company_id }),
                Contact.filter({ company_id: pitch.company_id })
            ]);

            const dossierPrompt = `
                Create a comprehensive business intelligence dossier for this pitch meeting:
                
                TARGET COMPANY:
                Name: ${company?.name || 'Unknown'}
                Sector: ${company?.sector || 'Unknown'}
                Website: ${company?.website || 'Not available'}
                HQ City: ${company?.hq_city || 'Unknown'}
                Employees: ${company?.employees_est || 'Unknown'}
                Last Funding: ${company?.last_funding_amt_aud ? `AUD ${company.last_funding_amt_aud.toLocaleString()}` : 'Unknown'}
                
                RECENT SIGNALS (Last 12 months):
                ${signals.slice(0, 10).map(s => `- ${s.date}: ${s.type.toUpperCase()} - ${s.title}`).join('\n')}
                
                KEY CONTACTS:
                ${contacts.map(c => `- ${c.name}, ${c.role || 'Unknown role'} (${c.decision_level || 'Unknown level'})`).join('\n')}
                
                PITCH CONTEXT:
                Brief: ${pitch.project_brief || 'Not provided'}
                Meeting Date: ${pitch.meeting_dt || 'Not scheduled'}
                Status: ${pitch.status}
                
                Generate a strategic dossier including:
                1. Executive Summary
                2. Company Profile & Recent Activity
                3. Decision Maker Analysis
                4. Market Position & Competitive Landscape
                5. Tailored Value Proposition
                6. Potential Objections & Responses
                7. Next Steps Strategy
                8. Key Questions to Ask
            `;

            const dossier = await InvokeLLM({
                prompt: dossierPrompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        executive_summary: { type: "string" },
                        company_profile: { type: "string" },
                        decision_makers: { type: "string" },
                        market_position: { type: "string" },
                        value_proposition: { type: "string" },
                        objections_responses: { type: "array", items: { type: "string" } },
                        next_steps: { type: "array", items: { type: "string" } },
                        key_questions: { type: "array", items: { type: "string" } },
                        risk_assessment: { type: "string" },
                        win_probability: { type: "number", minimum: 0, maximum: 100 }
                    },
                    required: ["executive_summary", "value_proposition"]
                }
            });

            // Store dossier in pitch recommendations
            await Pitch.update(pitch.id, {
                recommendations: {
                    ...pitch.recommendations,
                    dossier: dossier,
                    dossier_generated_at: new Date().toISOString()
                }
            });

            return { 
                rows_affected: 1, 
                notes: `Pitch dossier generated. Win probability: ${dossier.win_probability || 'Unknown'}%` 
            };
        }, { pitch_id: pitch.id });

        if (onUpdate) onUpdate();
        toast({ title: "Dossier Generated", description: "Comprehensive pitch dossier created." });
    };

    const handleUpdateStatus = async (newStatus) => {
        try {
            await Pitch.update(pitch.id, { status: newStatus });
            if (onUpdate) onUpdate();
            toast({ title: "Status Updated", description: `Pitch status changed to ${newStatus}.` });
        } catch (error) {
            toast({ variant: "destructive", title: "Update Failed", description: "Could not update pitch status." });
        }
    };

    const handleViewDossier = () => {
        // Open printable dossier in new window
        window.open(`/pitch-dossier/${pitch.id}`, '_blank');
    };

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
                <DropdownMenuItem onClick={handleCalculateReadiness}>
                    <TrendingUp className="mr-2 h-4 w-4" />
                    Calculate Readiness
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleGenerateDossier}>
                    <FileText className="mr-2 h-4 w-4" />
                    Generate Dossier
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleViewDossier}>
                    <FileText className="mr-2 h-4 w-4" />
                    View Dossier
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleUpdateStatus('scheduled')}>
                    <Send className="mr-2 h-4 w-4" />
                    Mark as Scheduled
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleUpdateStatus('won')}>
                    <Users className="mr-2 h-4 w-4" />
                    Mark as Won
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}