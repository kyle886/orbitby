/**
 * Contains business logic guards for actions.
 */

/**
 * Checks if a pitch can be moved to 'issued' status.
 * It's only possible if a pitch pack URL is present.
 * @param {object} pitch - The pitch record.
 * @returns {boolean} - True if the pitch can be issued, false otherwise.
 */
export const canIssuePitch = (pitch) => {
    return !!pitch.pack_url;
};

/**
 * Checks if a target is pinned and the pin has not expired.
 * @param {object} target - The target record.
 * @returns {boolean}
 */
export const isPinActive = (target) => {
    if (!target || !target.pinned || !target.pinned_until) {
        return false;
    }
    return new Date(target.pinned_until) > new Date();
};