import React from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Play, Send, Eye, FileText, Check, Copy } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useToast } from "@/components/ui/use-toast";
import { runJob } from '@/components/utils/runJob';

export function BriefActions({ brief, onUpdate }) {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSyncToLease = async () => {
    if (brief.status !== 'won') {
      toast({
        variant: "destructive",
        title: "Sync Failed",
        description: "Only briefs with status 'won' can be synced."
      });
      return;
    }

    const jobName = `Deal Sync (Brief: ${brief.brief_reference_code || brief.id})`;
    
    // This is a simplified, single-record version of the dealSyncLogic
    const syncLogic = async () => {
        const { Lease, Signal, Target, Building } = await import('@/api/entities');
        
        let leasesUpserted = 0, signalsCreated = 0, leverageBoosts = 0;

        const existingLeases = await Lease.filter({ 
          company_id: brief.client_company_id, 
          building_id: brief.building_id 
        });

        if (existingLeases.length === 0) {
            await Lease.create({
              company_id: brief.client_company_id,
              building_id: brief.building_id,
              area_m2: brief.area_need_m2,
              start_date: brief.required_date,
              expiry_date: new Date(new Date(brief.required_date).setFullYear(new Date(brief.required_date).getFullYear() + (brief.lease_term_years || 5))).toISOString().split('T')[0],
              source: 'manual'
            });
            leasesUpserted++;
        }

        await Signal.create({
          company_id: brief.client_company_id,
          type: 'reported_deal',
          source: 'internal_brief',
          title: `Lease executed: ${brief.company_name}`,
          date: new Date().toISOString().split('T')[0]
        });
        signalsCreated++;
        
        await onUpdate(); // Refresh the list

        return {
            rows_affected: leasesUpserted + signalsCreated,
            notes: `Synced brief: 1 lease, 1 signal.`
        };
    };

    try {
        await runJob(jobName, syncLogic, { brief_id: brief.id });
        toast({ title: "Sync Job Started", description: "Syncing brief to lease and signals..." });
    } catch(e) {
        toast({ variant: "destructive", title: "Job Error", description: "Could not start sync job."});
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-8 w-8 p-0">
          <span className="sr-only">Open menu</span>
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => navigate(createPageUrl(`BriefDetails?id=${brief.id}`))}>
          <Eye className="mr-2 h-4 w-4" />
          <span>View Details</span>
        </DropdownMenuItem>
        {brief.status === 'won' && (
          <DropdownMenuItem onClick={handleSyncToLease}>
            <Play className="mr-2 h-4 w-4" />
            <span>Sync to Lease now</span>
          </DropdownMenuItem>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}