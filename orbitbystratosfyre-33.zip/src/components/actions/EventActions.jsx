import React from 'react';
import { Event } from '@/api/entities';
import { EventROI } from '@/api/entities';
import { BDEventAttendance } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { MoreVertical, Users, Calculator, Calendar, ExternalLink } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { runJob } from '@/components/utils/runJob';
import { InvokeLLM } from '@/api/integrations';
import { useToast } from "@/components/ui/use-toast";

export function EventActions({ event, onUpdate, onAssign }) {
    const { toast } = useToast();

    const handleCalculateROI = async () => {
        toast({ title: "Calculating ROI...", description: `Analyzing ROI for ${event.title}.` });
        
        await runJob('Calculate Event ROI', async () => {
            // Get existing ROI record or create new one
            const existingROI = await EventROI.filter({ event_id: event.id });
            
            const roiPrompt = `
                Analyze the ROI potential for this business event:
                Event: ${event.title}
                Provider: ${event.provider || 'Unknown'}
                City: ${event.city || 'Unknown'}
                Venue: ${event.venue || 'Unknown'}
                Estimated Cost: AUD ${event.ticket_cost_est_aud || 'Unknown'}
                Topic Tags: ${(event.topic_tags || []).join(', ')}
                Last Year Attendance: ${event.last_year_attend_est || 'Unknown'}
                
                Consider:
                1. Target audience alignment with commercial real estate
                2. Networking opportunities with potential clients
                3. Brand visibility and thought leadership opportunities
                4. Cost-benefit ratio
                5. Strategic value for business development
                
                Provide your assessment with specific reasoning.
            `;

            const roiAnalysis = await InvokeLLM({
                prompt: roiPrompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        predicted_attendance: { type: "number" },
                        target_overlap_pct: { type: "number" },
                        expected_value_aud: { type: "number" },
                        roi_score: { type: "number" },
                        sponsor_rec: { type: "string", enum: ["sponsor", "attend", "skip"] },
                        reasoning: { type: "string" }
                    },
                    required: ["roi_score", "sponsor_rec", "reasoning"]
                }
            });

            if (existingROI.length > 0) {
                await EventROI.update(existingROI[0].id, roiAnalysis);
            } else {
                await EventROI.create({
                    event_id: event.id,
                    ...roiAnalysis
                });
            }

            return { rows_affected: 1, notes: `ROI calculated for ${event.title}. Recommendation: ${roiAnalysis.sponsor_rec}` };
        }, { event_id: event.id });

        if (onUpdate) onUpdate();
        toast({ title: "ROI Calculated", description: `Analysis complete for ${event.title}.` });
    };

    const handleAssignTeam = () => {
        if (onAssign) {
            onAssign(event);
        }
    };

    const handleViewEvent = () => {
        if (event.url) {
            window.open(event.url, '_blank');
        }
    };

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
                <DropdownMenuItem onClick={handleCalculateROI}>
                    <Calculator className="mr-2 h-4 w-4" />
                    Calculate ROI
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleAssignTeam}>
                    <Users className="mr-2 h-4 w-4" />
                    Assign Team
                </DropdownMenuItem>
                {event.url && (
                    <DropdownMenuItem onClick={handleViewEvent}>
                        <ExternalLink className="mr-2 h-4 w-4" />
                        View Event Details
                    </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={() => window.open(`/events/${event.id}/brief`, '_blank')}>
                    <Calendar className="mr-2 h-4 w-4" />
                    Generate Brief
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}