
import React, { useState, useMemo } from 'react';
import { PropertySubmission } from '@/api/entities';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  MapPin, 
  Square, 
  DollarSign, 
  AlertTriangle, 
  Eye, 
  Building2,
  Users
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ClientBriefSelector from '@/components/ClientBriefSelector';

const STATUSES = ['submitted', 'under_review', 'shortlisted', 'rejected', 'in_negotiation', 'selected'];

const getSizeRange = (size) => {
  if (!size || size === 0) return 'Unknown';
  if (size < 200) return 'Small (< 200 sqm)';
  if (size < 500) return 'Medium (200-500 sqm)';
  if (size < 1000) return 'Large (500-1000 sqm)';
  if (size < 2000) return 'X-Large (1000-2000 sqm)';
  return 'XX-Large (2000+ sqm)';
};

const getGeographicGroup = (address, suburb) => {
  if (!address && !suburb) return 'Unknown Location';
  
  const location = (suburb || address || '').toLowerCase();
  
  // Sydney CBD and surrounds
  if (location.includes('cbd') || location.includes('sydney') || location.includes('circular quay') || 
      location.includes('martin place') || location.includes('george street')) {
    return 'Sydney CBD';
  }
  
  // North Sydney / North Shore
  if (location.includes('north sydney') || location.includes('milsons point') || 
      location.includes('neutral bay') || location.includes('cremorne') ||
      location.includes('st leonards') || location.includes('chatswood')) {
    return 'North Sydney / North Shore';
  }
  
  // Parramatta
  if (location.includes('parramatta') || location.includes('westmead') || 
      location.includes('harris park')) {
    return 'Parramatta';
  }
  
  // Eastern Suburbs
  if (location.includes('bondi') || location.includes('paddington') || 
      location.includes('double bay') || location.includes('edgecliff') ||
      location.includes('woollahra')) {
    return 'Eastern Suburbs';
  }
  
  // Inner West
  if (location.includes('surry hills') || location.includes('redfern') || 
      location.includes('newtown') || location.includes('glebe') ||
      location.includes('leichhardt')) {
    return 'Inner West';
  }
  
  // Barangaroo
  if (location.includes('barangaroo')) {
    return 'Barangaroo';
  }
  
  return 'Other Sydney';
};

const StatusColumn = ({ 
  status, 
  submissions, 
  onStatusChange, 
  inspectionItems, 
  rfpItems,
  onToggleInspection, 
  onToggleRfp,
  onUpdateInspectionOrder,
  onSubmissionUpdate,
  allClients,
  allBriefs,
  detectConflicts
}) => {
  const statusConfig = {
    submitted: { title: 'Submitted', color: 'bg-gray-600' },
    under_review: { title: 'Under Review', color: 'bg-blue-600' },
    shortlisted: { title: 'Shortlisted', color: 'bg-yellow-600' },
    rejected: { title: 'Rejected', color: 'bg-red-600' },
    in_negotiation: { title: 'In Negotiation', color: 'bg-purple-600' },
    selected: { title: 'Selected', color: 'bg-green-600' }
  };

  const config = statusConfig[status];
  const submissionCount = submissions.length;

  // Group by geography, then by size
  const groupedSubmissions = useMemo(() => {
    const groups = {};
    
    submissions.forEach(submission => {
      const geoGroup = getGeographicGroup(submission.address, submission.suburb);
      const sizeRange = getSizeRange(submission.floor_area_sqm);
      
      if (!groups[geoGroup]) groups[geoGroup] = {};
      if (!groups[geoGroup][sizeRange]) groups[geoGroup][sizeRange] = [];
      
      groups[geoGroup][sizeRange].push(submission);
    });
    
    return groups;
  }, [submissions]);

  return (
    <div className="flex-1 min-w-80">
      <div className={`${config.color} text-white rounded-t-lg p-3 font-semibold`}>
        <div className="flex items-center justify-between">
          <span>{config.title}</span>
          <Badge variant="outline" className="bg-white/20 text-white border-white/30">
            {submissionCount}
          </Badge>
        </div>
      </div>
      
      <div className="bg-gray-100 min-h-96 p-2 space-y-3 rounded-b-lg">
        {Object.keys(groupedSubmissions).length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            <Building2 className="w-8 h-8 mx-auto mb-2" />
            <p className="text-sm">No submissions</p>
          </div>
        ) : (
          Object.entries(groupedSubmissions).map(([geoGroup, sizeGroups]) => (
            <div key={geoGroup} className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-medium text-gray-700 border-b border-gray-300 pb-1">
                <MapPin className="w-4 h-4" />
                <span>{geoGroup}</span>
              </div>
              
              {Object.entries(sizeGroups).map(([sizeRange, sizeSubmissions]) => (
                <div key={`${geoGroup}-${sizeRange}`} className="space-y-2">
                  <div className="text-xs text-gray-600 pl-6">
                    <Square className="w-3 h-3 inline mr-1" />
                    {sizeRange} ({sizeSubmissions.length})
                  </div>
                  
                  <div className="space-y-2 pl-8">
                    {sizeSubmissions.map(submission => {
                      const conflicts = detectConflicts(submission);
                      return (
                        <SubmissionCard
                          key={submission.id}
                          submission={submission}
                          conflicts={conflicts}
                          onStatusChange={onStatusChange}
                          inspectionItems={inspectionItems}
                          rfpItems={rfpItems}
                          onToggleInspection={onToggleInspection}
                          onToggleRfp={onToggleRfp}
                          onUpdateInspectionOrder={onUpdateInspectionOrder}
                          onSubmissionUpdate={onSubmissionUpdate}
                          allClients={allClients}
                          allBriefs={allBriefs}
                        />
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const SubmissionCard = ({ 
  submission, 
  conflicts, 
  onStatusChange, 
  inspectionItems, 
  rfpItems,
  onToggleInspection, 
  onToggleRfp,
  onUpdateInspectionOrder,
  onSubmissionUpdate,
  allClients,
  allBriefs
}) => {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <div className="orbit-card bg-white p-3 shadow-sm hover:shadow-md transition-shadow">
      <div className="space-y-2">
        <div className="flex justify-between items-start">
          <h4 className="font-medium text-gray-900 text-sm leading-tight">
            {submission.property_title}
          </h4>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowDetails(!showDetails)}
            className="h-6 w-6 p-0"
          >
            <Eye className="w-3 h-3" />
          </Button>
        </div>

        <div className="text-xs text-gray-600 space-y-1">
          <div className="flex items-center gap-1">
            <MapPin className="w-3 h-3" />
            <span className="truncate">{submission.address}</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <Square className="w-3 h-3" />
              <span>{submission.floor_area_sqm} sqm</span>
            </div>
            <div className="flex items-center gap-1">
              <DollarSign className="w-3 h-3" />
              <span>${submission.rental_rate_sqm}/sqm</span>
            </div>
          </div>
        </div>

        {conflicts.length > 0 && (
          <div className="flex items-center gap-1 px-2 py-1 bg-red-100 border border-red-300 rounded text-xs text-red-700">
            <AlertTriangle className="w-3 h-3" />
            <span>Conflict: {conflicts[0]}</span>
          </div>
        )}

        <div className="flex items-center gap-2 text-xs">
          <Checkbox
            id={`kanban-inspect-${submission.id}`}
            checked={!!inspectionItems[submission.id]}
            onCheckedChange={(checked) => onToggleInspection(submission.id, checked)}
            className="h-3 w-3"
          />
          <Label htmlFor={`kanban-inspect-${submission.id}`} className="text-xs">Inspect</Label>

          {['shortlisted', 'in_negotiation', 'selected'].includes(submission.status) && (
            <>
              <Checkbox
                id={`kanban-rfp-${submission.id}`}
                checked={rfpItems.includes(submission.id)}
                onCheckedChange={(checked) => onToggleRfp(submission.id, checked)}
                className="h-3 w-3"
              />
              <Label htmlFor={`kanban-rfp-${submission.id}`} className="text-xs">RFP</Label>
            </>
          )}
        </div>

        {inspectionItems[submission.id] && (
          <Input
            type="number"
            min="1"
            value={inspectionItems[submission.id].order || ''}
            onChange={(e) => onUpdateInspectionOrder(submission.id, e.target.value)}
            placeholder="Order"
            className="h-6 text-xs"
          />
        )}

        {showDetails && (
          <div className="space-y-2 border-t border-gray-200 pt-2">
            <ClientBriefSelector
              submission={submission}
              onUpdate={onSubmissionUpdate}
              allClients={allClients}
              allBriefs={allBriefs}
            />
            
            <Select
              value={submission.status}
              onValueChange={(value) => onStatusChange(submission.id, value)}
            >
              <SelectTrigger className="h-7 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="submitted">Submitted</SelectItem>
                <SelectItem value="under_review">Under Review</SelectItem>
                <SelectItem value="shortlisted">Shortlisted</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="in_negotiation">In Negotiation</SelectItem>
                <SelectItem value="selected">Selected</SelectItem>
              </SelectContent>
            </Select>

            <Link 
              to={createPageUrl(`SubmissionDetails?id=${submission.id}`)}
              className="block"
            >
              <Button variant="outline" size="sm" className="w-full h-7 text-xs">
                View Details
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default function KanbanView({
  filteredSubmissions,
  onStatusChange,
  inspectionItems,
  rfpItems,
  onToggleInspection,
  onToggleRfp,
  onUpdateInspectionOrder,
  onSubmissionUpdate,
  allClients,
  allBriefs,
  detectConflicts
}) {
  const submissionsByStatus = useMemo(() => {
    const groups = {};
    STATUSES.forEach(status => {
      groups[status] = filteredSubmissions.filter(s => s.status === status);
    });
    return groups;
  }, [filteredSubmissions]); // STATUSES is a global constant, no need to add to dependencies

  return (
    <div className="orbit-card p-4">
      <div className="flex gap-4 overflow-x-auto pb-4">
        {STATUSES.map(status => (
          <StatusColumn
            key={status}
            status={status}
            submissions={submissionsByStatus[status]}
            onStatusChange={onStatusChange}
            inspectionItems={inspectionItems}
            rfpItems={rfpItems}
            onToggleInspection={onToggleInspection}
            onToggleRfp={onToggleRfp}
            onUpdateInspectionOrder={onUpdateInspectionOrder}
            onSubmissionUpdate={onSubmissionUpdate}
            allClients={allClients}
            allBriefs={allBriefs}
            detectConflicts={detectConflicts}
          />
        ))}
      </div>
    </div>
  );
}
