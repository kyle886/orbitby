import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { X, Star, Heart } from "lucide-react";

const QUICK_TAGS = ["Great location", "Natural light", "Modern fitout", "Good transport", "Parking available", "Too small", "Too expensive", "Poor condition"];

export default function FeedbackDrawer({ open, onClose, property, onSubmit }) {
  const [rating, setRating] = useState(0);
  const [shortlist, setShortlist] = useState(false);
  const [tags, setTags] = useState([]);
  const [notes, setNotes] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const drawerRef = useRef(null);

  const toggleTag = (tag) => {
    setTags((prev) => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]);
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      await onSubmit({ rating, shortlist, tags, notes, display_name: displayName });
      // Reset form
      setRating(0);
      setShortlist(false);
      setTags([]);
      setNotes("");
      setDisplayName("");
      onClose();
    } catch (error) {
      console.error("Failed to submit feedback:", error);
    } finally {
      setSubmitting(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex justify-end" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={drawerRef} className="w-full max-w-md h-full shadow-elevated-2 slide-up" style={{ background:"var(--bg-elev-1)" }}>
        <div className="p-4 border-b" style={{ borderColor:"rgba(255,255,255,0.10)" }}>
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold" style={{ color:"var(--text-1)" }}>Rate & Review</h3>
            <Button variant="ghost" size="icon" onClick={onClose} className="ring-focus">
              <X className="w-5 h-5" />
            </Button>
          </div>
          {property && (
            <div className="mt-2">
              <p className="font-medium" style={{ color:"var(--text-1)" }}>{property.name}</p>
              <p className="text-sm" style={{ color:"var(--text-2)" }}>{property.address}</p>
            </div>
          )}
        </div>

        <div className="p-4 space-y-6 overflow-y-auto" style={{ maxHeight:"calc(100vh - 140px)" }}>
          {/* Rating */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color:"var(--text-1)" }}>Overall Rating</label>
            <div className="flex gap-1">
              {[1,2,3,4,5].map((n) => (
                <button key={n} onClick={() => setRating(n)}
                        className={`px-2 py-1 rounded-md text-sm ring-focus transition-all ${rating >= n ? 'btn-gradient' : 'bg-white/10 text-gray-200 hover:bg-white/20'}`}>
                  {n}★
                </button>
              ))}
            </div>
          </div>

          {/* Shortlist Toggle */}
          <div>
            <button
              onClick={() => setShortlist(!shortlist)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg ring-focus transition-all ${shortlist ? 'btn-gradient' : 'bg-white/10 hover:bg-white/20'}`}
            >
              <Heart className={`w-4 h-4 ${shortlist ? 'fill-current' : ''}`} />
              <span>{shortlist ? 'Added to shortlist' : 'Add to shortlist'}</span>
            </button>
          </div>

          {/* Quick Tags */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color:"var(--text-1)" }}>Quick Tags</label>
            <div className="flex flex-wrap gap-2">
              {QUICK_TAGS.map((t) => (
                <button key={t} onClick={() => toggleTag(t)}
                        className={`px-2 py-1 rounded-md text-xs ring-focus transition-all ${tags.includes(t) ? 'bg-white text-black' : 'bg-white/10 text-gray-200 hover:bg-white/20'}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color:"var(--text-1)" }}>Additional Notes</label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="What did you think about this property?"
              rows={4}
              className="ring-focus"
              style={{ background:"var(--bg-elev-2)", color:"var(--text-1)", borderColor:"rgba(255,255,255,0.12)" }}
            />
          </div>

          {/* Display Name */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color:"var(--text-1)" }}>Your Name (Optional)</label>
            <Input
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="How should we identify your feedback?"
              className="ring-focus"
              style={{ background:"var(--bg-elev-2)", color:"var(--text-1)", borderColor:"rgba(255,255,255,0.12)" }}
            />
          </div>
        </div>

        <div className="p-4 border-t" style={{ borderColor:"rgba(255,255,255,0.10)" }}>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} className="flex-1 ring-focus">
              Cancel
            </Button>
            <Button
              variant="gradient"
              onClick={handleSubmit}
              disabled={submitting || rating === 0}
              className="flex-1 ring-focus"
            >
              {submitting ? "Submitting..." : "Submit Feedback"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}