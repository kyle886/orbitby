import { useEffect, useRef, useMemo } from "react";

const LCSS = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
const LJS = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";

export default function LeafletMap({ points = [], onFocus = () => {} }) {
  const mapRef = useRef(null);
  const elRef = useRef(null);
  
  // Memoize serialized points to avoid complex dependency
  const serializedPoints = useMemo(() => JSON.stringify(points), [points]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      await ensureLeaflet();
      if (!mounted) return;
      const L = window.L;
      if (!mapRef.current && elRef.current) {
        const m = L.map(elRef.current, { zoomControl: true, scrollWheelZoom: true });
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>',
        }).addTo(m);
        mapRef.current = m;
      }
      const map = mapRef.current;
      if (!map) return;

      // Clear existing markers
      map.eachLayer((layer) => {
        if (layer instanceof window.L.Marker) {
          map.removeLayer(layer);
        }
      });

      const group = L.featureGroup();
      points.forEach((p) => {
        if (!isFinite(p.lat) || !isFinite(p.lng)) return;
        const marker = L.marker([p.lat, p.lng]);
        marker.on("click", () => onFocus(p.id));
        marker.bindTooltip(p.name || "Property");
        marker.addTo(group);
      });
      
      if (group.getLayers().length > 0) {
        group.addTo(map);
        try {
          map.fitBounds(group.getBounds().pad(0.1));
        } catch {
          if (points[0]) map.setView([points[0].lat, points[0].lng], 14);
        }
      }
    })();
    
    return () => {
      mounted = false;
    };
  }, [serializedPoints, onFocus, points]);

  return <div ref={elRef} className="w-full h-[420px] rounded-xl border border-white/10 shadow-elevated fade-in" style={{ background:"var(--bg-elev-1)" }} />;
}

function ensureLeaflet() {
  return new Promise((resolve) => {
    if (window.L) return resolve();
    
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = LCSS;
    document.head.appendChild(link);
    
    const script = document.createElement("script");
    script.src = LJS;
    script.onload = () => resolve();
    document.body.appendChild(script);
  });
}