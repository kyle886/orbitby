
import { useEffect, useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { PropertySubmission } from "@/api/entities";
import { Building, Mail, Calendar } from "lucide-react";

export default function PublishModal({ open, onOpenChange, engagement_id }) {
  const [properties, setProperties] = useState([]);
  const [selectedProps, setSelectedProps] = useState(new Set());
  const [expirationDays, setExpirationDays] = useState(14);
  const [recipients, setRecipients] = useState('');
  const [subject, setSubject] = useState('Your Property Inspection Pack');
  const [message, setMessage] = useState('We\'ve prepared a curated selection of properties with an interactive map and feedback system.');
  const [isPublishing, setIsPublishing] = useState(false);
  const { toast } = useToast();

  const loadProperties = useCallback(async () => {
    try {
      // Load submissions related to this engagement/client
      const submissions = await PropertySubmission.list();
      // Filter for relevant submissions - you may need to adjust this filter based on your data model
      const relevantSubmissions = submissions.filter(sub => 
        sub.status === 'shortlisted' || sub.brief_match_status === 'on_brief'
      ).slice(0, 20); // Limit to 20 most relevant

      setProperties(relevantSubmissions);
      
      // Pre-select top 5 properties
      const topProperties = relevantSubmissions.slice(0, 5).map(p => p.id);
      setSelectedProps(new Set(topProperties));
    } catch (error) {
      console.error('Error loading properties:', error);
      toast({ variant: 'destructive', title: 'Failed to load properties' });
    }
  }, [toast]);

  useEffect(() => {
    if (open && engagement_id) {
      loadProperties();
    }
  }, [open, engagement_id, loadProperties]);

  const toggleProperty = (propertyId) => {
    setSelectedProps(prev => {
      const newSet = new Set(prev);
      if (newSet.has(propertyId)) {
        newSet.delete(propertyId);
      } else {
        newSet.add(propertyId);
      }
      return newSet;
    });
  };

  const publish = async () => {
    if (selectedProps.size === 0) {
      toast({ variant: 'destructive', title: 'Please select at least one property' });
      return;
    }

    setIsPublishing(true);
    try {
      const selectedProperties = properties
        .filter(p => selectedProps.has(p.id))
        .map(mapSubmissionToPublicShape);

      const emailList = recipients.split(',')
        .map(email => email.trim())
        .filter(email => email.includes('@'));

      const response = await fetch('/functions/publishInspection', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          engagement_id,
          expires_in_days: parseInt(expirationDays),
          properties: selectedProperties,
          recipients: emailList,
          subject,
          message
        })
      });

      const result = await response.json();
      
      if (!result.ok) {
        throw new Error(result.error || 'Failed to publish inspection pack');
      }

      // Copy URL to clipboard
      try {
        await navigator.clipboard.writeText(result.url);
        toast({ 
          title: 'Inspection Pack Published!', 
          description: 'Link copied to clipboard and emails sent to recipients.'
        });
      } catch {
        toast({ 
          title: 'Inspection Pack Published!', 
          description: `Link: ${result.url}`
        });
      }

      // Open the inspection pack in a new tab
      window.open(result.url, '_blank', 'noopener,noreferrer');
      
      onOpenChange(false);
      
    } catch (error) {
      console.error('Publish error:', error);
      toast({ 
        variant: 'destructive', 
        title: 'Failed to Publish', 
        description: error.message 
      });
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="orbit-card max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Building className="w-5 h-5 text-orange-400" />
            Publish Inspection Pack
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-y-auto space-y-6">
          {/* Property Selection */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-3">Select Properties</h3>
            <div className="grid grid-cols-1 gap-3 max-h-64 overflow-y-auto">
              {properties.map(property => (
                <div 
                  key={property.id}
                  className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${
                    selectedProps.has(property.id) 
                      ? 'border-orange-400/50 bg-orange-400/10' 
                      : 'border-gray-600 bg-gray-800/30'
                  }`}
                >
                  <Checkbox 
                    checked={selectedProps.has(property.id)}
                    onCheckedChange={() => toggleProperty(property.id)}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-white truncate">
                      {property.property_title || 'Property'}
                    </div>
                    <div className="text-sm text-gray-400 truncate">
                      {property.address || property.street_address}
                    </div>
                    <div className="flex gap-2 mt-1">
                      {property.floor_area_sqm && (
                        <Badge variant="outline" className="text-xs">
                          {property.floor_area_sqm.toLocaleString()} m²
                        </Badge>
                      )}
                      {property.brief_match_status && (
                        <Badge variant="outline" className="text-xs">
                          {property.brief_match_status}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {properties.length === 0 && (
              <div className="text-center py-8 text-gray-400">
                <Building className="w-16 h-16 mx-auto mb-3 text-gray-600" />
                <p>No suitable properties found for this engagement.</p>
                <p className="text-sm">Properties need to be shortlisted or marked as on-brief.</p>
              </div>
            )}
          </div>

          {/* Configuration */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Link Expires In (Days)
              </label>
              <Input 
                type="number" 
                value={expirationDays} 
                onChange={(e) => setExpirationDays(e.target.value)}
                className="orbit-input"
                min="1"
                max="90"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                <Mail className="w-4 h-4 inline mr-1" />
                Email Recipients
              </label>
              <Input 
                value={recipients}
                onChange={(e) => setRecipients(e.target.value)}
                placeholder="client@company.com, advisor@firm.com"
                className="orbit-input"
              />
              <p className="text-xs text-gray-500 mt-1">Comma-separated email addresses</p>
            </div>
          </div>

          {/* Email Content */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Email Subject</label>
              <Input 
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="orbit-input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Email Message</label>
              <Textarea 
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="orbit-input min-h-[80px]"
              />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t border-gray-700">
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            disabled={isPublishing}
          >
            Cancel
          </Button>
          <Button 
            onClick={publish}
            disabled={isPublishing || selectedProps.size === 0}
            className="bg-orange-600 hover:bg-orange-700 text-white"
          >
            {isPublishing ? 'Publishing...' : `Publish & Send to ${recipients.split(',').filter(e => e.trim().includes('@')).length} Recipients`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function mapSubmissionToPublicShape(submission) {
  return {
    id: submission.id,
    name: submission.property_title || 'Property',
    address: submission.address || submission.street_address || '',
    latitude: submission.latitude,
    longitude: submission.longitude,
    area_m2: submission.floor_area_sqm,
    rent_psm: submission.rental_rate_sqm,
    opex_psm: null, // Add if available in your schema
    floor: submission.floor_level,
    images: submission.images || [],
    property_title: submission.property_title,
    street_address: submission.street_address,
    floor_area_sqm: submission.floor_area_sqm,
    rental_rate_sqm: submission.rental_rate_sqm,
    status: submission.status
  };
}
