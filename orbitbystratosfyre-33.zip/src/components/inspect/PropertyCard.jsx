import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function PropertyCard({ property: p, active, onFocus, onFeedback }) {
  const metrics = [
    ["Area", p.area_m2 ? `${Math.round(p.area_m2)} m²` : "—"],
    ["Rent", p.rent_psm ? `$${Math.round(p.rent_psm)}/m²` : "—"],
    ["Floor", p.floor || "—"],
    ["Available", "Now"], // You might want to add availability_date to your data
  ].filter(([,v]) => v !== "—");

  return (
    <Card className={`shadow-elevated overflow-hidden lift ${active ? 'ring-2 ring-brand-500/60' : ''}`}>
      <CardContent className="p-0">
        <div className="relative">
          {p.images?.[0] ? (
            <img src={p.images[0]} alt="" className="w-full h-40 object-cover" />
          ) : (
            <div className="w-full h-40" style={{ background:"linear-gradient(135deg, rgba(99,102,241,.22), rgba(17,24,39,.22))" }} />
          )}
          <div className="absolute top-2 left-2 text-xs px-2 py-1 rounded-md text-white font-medium" style={{ background:"rgba(0,0,0,.55)", backdropFilter:"blur(4px)" }}>{p.name}</div>
        </div>
        <div className="p-3">
          <div className="text-sm mb-2 truncate" style={{ color:"var(--text-2)" }}>{p.address}</div>
          <div className="grid grid-cols-2 gap-2">
            {metrics.map(([k, v]) => (
              <div key={k} className="rounded-md p-2 text-xs" style={{ background:"var(--surface-strong)", border:"1px solid rgba(255,255,255,0.10)" }}>
                <div className="text-gray-400">{k}</div>
                <div className="font-medium text-white">{v}</div>
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-2">
            <Button size="sm" variant="gradient" className="ring-focus" onClick={() => onFocus(p.id)}>Focus</Button>
            <Button size="sm" variant="outline" className="ring-focus" onClick={() => onFeedback(p)}>Give feedback</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}