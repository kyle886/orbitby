
import { z } from "https://esm.sh/zod";

export const ZTimeseriesPoint = z.object({
  date: z.string(),
  leads: z.number().nonnegative().default(0),
  listings: z.number().nonnegative().default(0),
  scans: z.number().nonnegative().default(0),
  errors: z.number().nonnegative().default(0),
});

export const ZTimeseries = z.object({
  series: z.array(ZTimeseriesPoint).default([])
});

export const ZSummary = z.object({
  totals: z.object({
    leadsNew: z.number().default(0),
    listingsNew: z.number().default(0),
    scansRun: z.number().default(0),
    errors: z.number().default(0),
    activeBrokers: z.number().default(0),
    responseMedianMs: z.number().nullable().optional()
  })
});

export const ZFunnel = z.object({
  stages: z.array(z.object({ 
    key: z.string(), 
    label: z.string(), 
    value: z.number().default(0) 
  }))
});

export const ZLeaders = z.object({
  topSources: z.array(z.object({ name: z.string(), count: z.number() })).default([]),
  topSuburbs: z.array(z.object({ name: z.string(), count: z.number() })).default([]),
  topBrokers: z.array(z.object({ name: z.string(), count: z.number() })).default([])
});
