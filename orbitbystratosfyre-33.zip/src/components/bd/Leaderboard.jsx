import React from "react";

export default function Leaderboard({ title, items }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
      <div className="text-sm font-medium mb-2 text-white">{title}</div>
      <div className="space-y-2">
        {(items || []).slice(0, 10).map((r, i) => (
          <div key={i} className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <div className="w-5 text-neutral-500">{i + 1}.</div>
              <div className="truncate max-w-[180px] text-gray-300">{r.name || "—"}</div>
            </div>
            <div className="text-neutral-300">{r.count.toLocaleString()}</div>
          </div>
        ))}
        {!items?.length && <div className="text-xs text-neutral-500">No data</div>}
      </div>
    </div>
  );
}