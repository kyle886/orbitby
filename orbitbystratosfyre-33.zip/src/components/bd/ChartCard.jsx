import React from "react";

export default function ChartCard({ title, children }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
      <div className="text-sm font-medium mb-2 text-white">{title}</div>
      <div className="h-64">{children}</div>
    </div>
  );
}