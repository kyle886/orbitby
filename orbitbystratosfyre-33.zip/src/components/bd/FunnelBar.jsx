import React from "react";

export default function FunnelBar({ stages }) {
  const mx = Math.max(1, ...stages.map(s => s.value || 0));
  
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
      <div className="text-sm font-medium mb-2 text-white">Funnel</div>
      <div className="space-y-2">
        {stages.map((s, i) => (
          <div key={i} className="flex items-center gap-2">
            <div className="text-xs w-28 truncate text-neutral-300">{s.label}</div>
            <div className="flex-1 h-3 rounded bg-white/10 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-orange-500 to-amber-400" 
                style={{ width: `${(s.value || 0) / mx * 100}%` }} 
              />
            </div>
            <div className="text-xs w-14 text-right text-white">
              {(s.value || 0).toLocaleString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}