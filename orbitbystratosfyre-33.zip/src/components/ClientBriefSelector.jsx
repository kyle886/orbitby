
import React, { useState, useEffect } from "react";
import { Client } from "@/api/entities";
import { TenantRequirement } from "@/api/entities";
import { PropertySubmission } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Check, ChevronsUpDown, X, Tags, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function ClientBriefSelector({ submission, onUpdate, allClients, allBriefs }) {
  const [selectedBriefs, setSelectedBriefs] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [localClients, setLocalClients] = useState([]);
  const [localBriefs, setLocalBriefs] = useState([]);

  useEffect(() => {
    // If data isn't passed as props, load it locally
    if (!allClients || !allBriefs) {
      loadLocalData();
    } else {
      setLocalClients(allClients);
      setLocalBriefs(allBriefs);
    }
  }, [allClients, allBriefs]);

  useEffect(() => {
    // Initialize selected briefs from submission's brief_ids
    if (submission.brief_ids && Array.isArray(localBriefs) && localBriefs.length > 0) {
      const initialBriefs = (submission.brief_ids || [])
        .map(id => localBriefs.find(b => b.id === id))
        .filter(Boolean);
      setSelectedBriefs(initialBriefs);
    }
  }, [submission, localBriefs]);

  const loadLocalData = async () => {
    try {
      const [clientsData, briefsData] = await Promise.all([
        Client.list(),
        TenantRequirement.list()
      ]);
      setLocalClients(clientsData || []);
      setLocalBriefs(briefsData || []);
    } catch (error) {
      console.error("Error loading clients and briefs:", error);
      setLocalClients([]);
      setLocalBriefs([]);
    }
  };

  const handleToggleBrief = (brief) => {
    setSelectedBriefs(prev => {
      const isSelected = prev.some(b => b.id === brief.id);
      if (isSelected) {
        return prev.filter(b => b.id !== brief.id);
      } else {
        return [...prev, brief];
      }
    });
  };

  const handleApplyChanges = async () => {
    setLoading(true);
    try {
      const brief_ids = selectedBriefs.map(b => b.id);
      const updateData = {
        brief_ids,
        brief_match_status: brief_ids.length > 0 ? "on_brief" : "off_brief",
      };
      
      const payload = { ...submission, ...updateData };
      if (!payload.street_address && payload.address) {
        payload.street_address = payload.address;
      }
      
      await PropertySubmission.update(submission.id, payload);
      onUpdate(submission.id, updateData);
      
      setOpen(false);
    } catch (error) {
      console.error("Error updating submission:", error);
      alert("Failed to assign to briefs.");
    } finally {
      setLoading(false);
    }
  };

  const clearAllBriefs = async () => {
    setLoading(true);
    try {
      const updateData = {
        brief_ids: [],
        brief_match_status: "off_brief",
      };
      
      const payload = { ...submission, ...updateData };
      if (!payload.street_address && payload.address) {
        payload.street_address = payload.address;
      }

      await PropertySubmission.update(submission.id, payload);
      onUpdate(submission.id, updateData);
      setSelectedBriefs([]);
    } catch (error) {
      console.error("Error clearing briefs:", error);
      alert("Failed to clear assignments.");
    } finally {
      setLoading(false);
    }
  };

  // Group briefs by client for display
  const groupedBriefs = (Array.isArray(localClients) ? localClients : []).map(client => ({
    ...client,
    briefs: (Array.isArray(localBriefs) ? localBriefs : []).filter(b => 
      b.client_id === client.id || 
      b.company_name === client.company_name
    )
  })).filter(client => client.briefs.length > 0);

  // Also show all active briefs at the top level for easier browsing
  const activeBriefs = (Array.isArray(localBriefs) ? localBriefs : []).filter(b => 
    b.status === 'active' || !b.status
  );

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="orbit-input h-auto text-xs justify-between w-full min-h-[40px] items-start"
          disabled={loading}
        >
          <div className="flex flex-wrap gap-1">
            {selectedBriefs.length > 0 ? (
              selectedBriefs.map(brief => {
                const client = localClients.find(c => c.id === brief.client_id || c.company_name === brief.company_name);
                return (
                  <Badge key={brief.id} variant="outline" className="font-normal bg-amber-900/40 border-amber-500/50 text-amber-200">
                    {client?.company_name || brief.company_name} - {brief.brief_reference_code || brief.property_type}
                  </Badge>
                );
              })
            ) : (
              <span className="text-gray-400">Assign to briefs...</span>
            )}
          </div>
          <ChevronsUpDown className="ml-2 h-3 w-3 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0">
        <Command>
          <CommandInput placeholder="Search by client name or brief..." className="text-xs" />
          <CommandList className="max-h-64">
            <CommandEmpty>No briefs found.</CommandEmpty>
            
            {/* Show recent active briefs first */}
            {activeBriefs.length > 0 && (
              <CommandGroup heading="Active Briefs">
                {activeBriefs.slice(0, 8).map((brief) => {
                  const client = localClients.find(c => c.id === brief.client_id || c.company_name === brief.company_name);
                  const isSelected = selectedBriefs.some(b => b.id === brief.id);
                  const displayText = `${client?.company_name || brief.company_name} - ${brief.brief_reference_code || brief.property_type}`;
                  
                  return (
                    <CommandItem
                      key={brief.id}
                      value={displayText}
                      onSelect={() => handleToggleBrief(brief)}
                      className="text-xs"
                    >
                      <Check
                        className={`mr-2 h-3 w-3 ${
                          isSelected ? "opacity-100" : "opacity-0"
                        }`}
                      />
                      <div className="flex-1">
                        <div className="font-medium">{client?.company_name || brief.company_name}</div>
                        <div className="text-gray-500">{brief.brief_reference_code || brief.property_type}</div>
                      </div>
                    </CommandItem>
                  );
                })}
              </CommandGroup>
            )}

            {/* Show grouped by client */}
            {groupedBriefs.map((client) => (
              <CommandGroup key={client.id} heading={client.company_name}>
                {(client.briefs || []).map((brief) => {
                  const isSelected = selectedBriefs.some(b => b.id === brief.id);
                  return (
                    <CommandItem
                      key={brief.id}
                      value={`${client.company_name} ${brief.brief_reference_code} ${brief.property_type} ${brief.company_name}`}
                      onSelect={() => handleToggleBrief(brief)}
                      className="text-xs"
                    >
                      <Check
                        className={`mr-2 h-3 w-3 ${
                          isSelected ? "opacity-100" : "opacity-0"
                        }`}
                      />
                      <span>{brief.brief_reference_code || brief.property_type}</span>
                      {brief.status && (
                        <span className="ml-auto text-gray-400">({brief.status})</span>
                      )}
                    </CommandItem>
                  );
                })}
              </CommandGroup>
            ))}
          </CommandList>
          <div className="p-2 border-t border-gray-700 flex gap-2">
            {selectedBriefs.length > 0 && (
              <Button onClick={clearAllBriefs} size="sm" variant="outline" className="flex-1">
                Clear All
              </Button>
            )}
            <Button onClick={handleApplyChanges} size="sm" className="flex-1 bg-orange-500 hover:bg-orange-600 text-white" disabled={loading}>
              {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Apply'}
            </Button>
          </div>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
