import React, { createContext, useState, useMemo } from 'react';

const initialState = {
  title: "Inspection",
  startISO: new Date().toISOString(),
  stops: [],
  attendees: [],
  criteria: [],
};

export const InspectionPackContext = createContext({
  draft: initialState,
  setTitle: () => {},
  setStartISO: () => {},
  setStops: () => {},
  addStop: () => {},
  setAttendees: () => {},
  setCriteria: () => {},
  reset: () => {},
});

export const InspectionPackProvider = ({ children }) => {
  const [draft, setDraft] = useState(initialState);

  const contextValue = useMemo(() => ({
    draft,
    setTitle: (t) => setDraft(d => ({ ...d, title: t })),
    setStartISO: (iso) => setDraft(d => ({ ...d, startISO: iso })),
    setStops: (stops) => setDraft(d => ({ ...d, stops })),
    addStop: (stop) => setDraft(d => ({ ...d, stops: [...d.stops, stop] })),
    setAttendees: (attendees) => setDraft(d => ({ ...d, attendees })),
    setCriteria: (criteria) => setDraft(d => ({ ...d, criteria })),
    reset: () => setDraft(initialState),
  }), [draft]);

  return (
    <InspectionPackContext.Provider value={contextValue}>
      {children}
    </InspectionPackContext.Provider>
  );
};