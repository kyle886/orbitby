
import { create } from "https://esm.sh/zustand";

export const useBDDashboard = create((set, get) => ({
  range: "30d",
  market: null,
  loading: false,
  summary: null, 
  timeseries: null, 
  funnel: null, 
  leaders: null, 
  activity: null,
  
  setRange: (r) => set({ range: r }),
  setMarket: (m) => set({ market: m || null }),
  
  load: async () => {
    const { range, market } = get();
    set({ loading: true });
    
    try {
      const fns = window.base44?.functions || {};
      const [summary, timeseries, funnel, leaders, activity] = await Promise.all([
        fns.bdSummary({ range, market }),
        fns.bdTimeseries({ range, market }),
        fns.bdFunnel({ range, market }),
        fns.bdLeaderboards({ range, market }),
        fns.bdActivity({ range, market })
      ]);
      set({ loading: false, summary, timeseries, funnel, leaders, activity });
    } catch (error) {
      console.error('Dashboard load error:', error);
      set({ loading: false });
    }
  }
}));
