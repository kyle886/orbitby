import { create } from "zustand";

const qs = new URLSearchParams(window.location.search);
const init = {
  q: qs.get("q") || "",
  minSize: qs.get("minSize") ? Number(qs.get("minSize")) : undefined,
  maxSize: qs.get("maxSize") ? Number(qs.get("maxSize")) : undefined,
  minRent: qs.get("minRent") ? Number(qs.get("minRent")) : undefined,
  maxRent: qs.get("maxRent") ? Number(qs.get("maxRent")) : undefined,
  grade: qs.get("grade") ? qs.get("grade").split(",") : [],
  status: qs.get("status") ? qs.get("status").split(",") : [],
  page: Number(qs.get("page") || 1),
  pageSize: 50
};

export const useListingsSearch = create((set, get) => ({
  ...init,
  loading: false,
  total: 0,
  items: [],
  bbox: undefined,
  
  set: (k, v) => set({ [k]: v }),
  
  setBBox: (b) => set({ bbox: b }),
  
  search: async () => {
    const s = get();
    set({ loading: true });

    try {
      // URL sync
      const params = new URLSearchParams();
      if (s.q) params.set("q", s.q);
      if (s.minSize != null) params.set("minSize", String(s.minSize));
      if (s.maxSize != null) params.set("maxSize", String(s.maxSize));
      if (s.minRent != null) params.set("minRent", String(s.minRent));
      if (s.maxRent != null) params.set("maxRent", String(s.maxRent));
      if (s.grade.length) params.set("grade", s.grade.join(","));
      if (s.status.length) params.set("status", s.status.join(","));
      params.set("page", String(s.page));
      window.history.replaceState({}, "", `?${params.toString()}`);

      // Call search function
      const { searchListings } = await import("@/api/functions");
      const r = await searchListings({
        q: s.q,
        minSize: s.minSize,
        maxSize: s.maxSize,
        minRent: s.minRent,
        maxRent: s.maxRent,
        grade: s.grade,
        status: s.status,
        bbox: s.bbox,
        page: s.page,
        pageSize: s.pageSize
      });

      set({ 
        loading: false, 
        items: r.items || [], 
        total: r.total || 0 
      });
    } catch (error) {
      console.error('Search failed:', error);
      set({ 
        loading: false, 
        items: [], 
        total: 0 
      });
    }
  }
}));