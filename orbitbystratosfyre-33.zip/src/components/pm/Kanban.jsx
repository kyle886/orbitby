import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const COLUMNS = ['Backlog','Design','Tender','Construction','Done'];

export default function Kanban({ tasks=[], onMove=()=>{}, onNew=()=>{} }) {
  const by = (col)=> tasks.filter(t=> (t.status||'Backlog')===col);
  return (
    <div className="grid xl:grid-cols-5 md:grid-cols-3 gap-3">
      {COLUMNS.map(col=>(
        <Card key={col} className="shadow-elevated">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">{col}</CardTitle>
              {col==='Backlog' && <Button size="sm" onClick={onNew}>New</Button>}
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {by(col).map(t=>(
              <div key={t.id} className="rounded-lg border border-white/10 p-2">
                <div className="text-sm font-medium">{t.title}</div>
                <div className="text-xs text-gray-400">{t.stage} · {t.owner||'—'}</div>
                <div className="mt-2 flex gap-1 flex-wrap">
                  {COLUMNS.map(c=> c!==col && <Button key={c} size="sm" variant="outline" onClick={()=>onMove(t.id, c)} className="text-xs">{c}</Button>)}
                </div>
              </div>
            ))}
            {by(col).length===0 && <div className="text-xs text-gray-500">No items</div>}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}