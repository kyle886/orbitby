import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';

const GanttChart = ({ tasks = [] }) => {
  if (tasks.length === 0) {
    return <div className="text-center py-12 text-gray-500">No tasks to display in the schedule.</div>;
  }

  const data = tasks.map(task => {
    const start = new Date(task.start_dt);
    const end = new Date(task.end_dt);
    const today = new Date();
    
    const startDay = (start - today) / (1000 * 3600 * 24);
    const duration = (end - start) / (1000 * 3600 * 24);

    return {
      name: task.title,
      range: [startDay, startDay + duration],
      status: task.status,
    };
  });
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'Done': return '#10B981'; // Green
      case 'Construction': return '#3B82F6'; // Blue
      case 'Tender': return '#F59E0B'; // Amber
      case 'Design': return '#8B5CF6'; // Violet
      default: return '#6B7280'; // Gray
    }
  };

  return (
    <div style={{ height: tasks.length * 50 + 80, minHeight: 300 }}>
        <ResponsiveContainer width="100%" height="100%">
            <BarChart
                layout="vertical"
                data={data}
                margin={{ top: 5, right: 20, left: 20, bottom: 5 }}
            >
                <XAxis type="number" domain={['dataMin - 10', 'dataMax + 10']} stroke="#9CA3AF" name="Days from Today" />
                <YAxis dataKey="name" type="category" width={150} stroke="#9CA3AF" />
                <Tooltip 
                  cursor={{fill: 'rgba(255,255,255,0.1)'}}
                  contentStyle={{ background: '#1F2937', border: '1px solid #374151', color: '#E5E7EB' }}
                />
                <Legend />
                <Bar dataKey="range" name="Task Duration">
                    {data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={getStatusColor(entry.status)} />
                    ))}
                </Bar>
            </BarChart>
        </ResponsiveContainer>
    </div>
  );
};

export default GanttChart;