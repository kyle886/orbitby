import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useMemo } from "react";
import { useToast } from "@/components/ui/use-toast";

export default function ScoringMatrix({ rows=[], weights={ price:0.6, programme:0.2, exclusions:0.2 }, onBAFO=()=>{} }){
  const { toast } = useToast();
  
  const scored = useMemo(()=>{
    if (rows.length===0) return [];
    
    const minPrice = Math.min(...rows.map(r=>r.headline_aud||Infinity));
    
    return rows.map(r=>{
      const priceScore = minPrice>0 ? (minPrice/(r.headline_aud||minPrice))*100 : 0;
      const progScore = r.programme_weeks ? Math.max(0, 100 - (r.programme_weeks*2)) : 50;
      const exclScore = 100 - Math.min(100, (r.exclusions?.length||0)*5);
      const total = Math.round(
        priceScore * weights.price + 
        progScore * weights.programme + 
        exclScore * weights.exclusions
      );
      
      return { 
        ...r, 
        priceScore: Math.round(priceScore), 
        progScore: Math.round(progScore), 
        exclScore: Math.round(exclScore), 
        total 
      };
    }).sort((a,b)=> b.total - a.total);
  }, [rows, weights]);

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Scoring Matrix</CardTitle>
          <Button variant="outline" onClick={()=> onBAFO(scored.slice(0,3))}>
            Request BAFO (Top 3)
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="grid grid-cols-6 gap-2 text-xs text-gray-400">
          <div>Vendor</div>
          <div className="text-right">Price (A$)</div>
          <div className="text-right">Programme (wks)</div>
          <div className="text-right">Price%</div>
          <div className="text-right">Prog%</div>
          <div className="text-right font-semibold">Score</div>
        </div>
        <div className="space-y-1">
          {scored.map(b=>(
            <div key={b.id} className="grid grid-cols-6 gap-2 items-center rounded-lg border border-white/10 p-2">
              <div className="text-sm">{b.vendor}</div>
              <div className="text-right">{num(b.headline_aud)}</div>
              <div className="text-right">{b.programme_weeks||'—'}</div>
              <div className="text-right">{b.priceScore}</div>
              <div className="text-right">{b.progScore}</div>
              <div className="text-right font-semibold">{b.total}</div>
            </div>
          ))}
          {rows.length===0 && <div className="text-sm text-gray-400">No bids yet.</div>}
        </div>
      </CardContent>
    </Card>
  );
}

function num(n){ 
  const x = Number(n||0); 
  return isFinite(x) ? x.toLocaleString('en-AU',{maximumFractionDigits:0}) : '—'; 
}