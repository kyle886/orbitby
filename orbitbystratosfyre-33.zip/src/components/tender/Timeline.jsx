import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { TenderMilestone } from "@/api/entities";
import { useToast } from "@/components/ui/use-toast";

export default function Timeline({ tenderId, rows=[], onAdd=()=>{}, onStatus=()=>{}, onDigest=()=>{} }){
  const [title, setTitle] = useState(''); 
  const [due, setDue] = useState('');
  const { toast } = useToast();
  
  const add = async ()=>{
    try {
      const r = await TenderMilestone.create({ 
        tender_id: tenderId, 
        title, 
        due_dt: due, 
        status: 'pending', 
        created_at: new Date().toISOString() 
      });
      onAdd(r); 
      setTitle(''); 
      setDue(''); 
      toast({title:'Milestone added'});
    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to add milestone', description: error.message });
    }
  };

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Tender Milestones</CardTitle>
          <Button variant="outline" onClick={onDigest}>Send Q&A Digest</Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="grid md:grid-cols-3 gap-2">
          <Input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Milestone title" />
          <Input type="date" value={due} onChange={e=>setDue(e.target.value)} placeholder="YYYY-MM-DD" />
          <Button onClick={add}>Add</Button>
        </div>
        <div className="space-y-2">
          {rows.map(m=>(
            <div key={m.id} className="rounded-lg border border-white/10 p-2 flex items-center justify-between">
              <div className="text-sm">{m.title}</div>
              <div className="text-xs text-gray-400">{fmt(m.due_dt)} · {m.status||'pending'}</div>
              <div className="flex gap-2">
                <Button size="sm" onClick={()=>onStatus(m.id,'done')}>Done</Button>
                <Button size="sm" variant="outline" onClick={()=>onStatus(m.id,'delayed')}>Delayed</Button>
              </div>
            </div>
          ))}
          {rows.length===0 && <div className="text-sm text-gray-400">No milestones yet.</div>}
        </div>
      </CardContent>
    </Card>
  );
}

function fmt(dt){ 
  try{ 
    return new Date(dt).toLocaleDateString('en-AU'); 
  } catch{ 
    return dt; 
  } 
}