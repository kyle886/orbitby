import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { TenderQnA } from "@/api/entities";
import { useToast } from "@/components/ui/use-toast";

export default function QnARegister({ tenderId, rows=[], onAdd=()=>{}, onAnswer=()=>{} }){
  const [q, setQ] = useState('');
  const { toast } = useToast();
  
  const add = async ()=>{
    try {
      const r = await TenderQnA.create({ 
        tender_id: tenderId, 
        q, 
        created_at: new Date().toISOString() 
      });
      onAdd(r); 
      setQ(''); 
      toast({title:'Question logged'});
    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to add question', description: error.message });
    }
  };

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3"><CardTitle className="text-base">Q&A Register</CardTitle></CardHeader>
      <CardContent className="space-y-2">
        <div className="grid md:grid-cols-6 gap-2">
          <Textarea className="md:col-span-5" value={q} onChange={e=>setQ(e.target.value)} placeholder="Supplier question…" />
          <Button onClick={add}>Add</Button>
        </div>
        <div className="space-y-2">
          {rows.map(r=>(
            <div key={r.id} className="rounded-lg border border-white/10 p-2">
              <div className="text-sm">{r.q}</div>
              {r.a ? 
                <div className="text-xs text-emerald-300 mt-1">Answer: {r.a}</div> :
                <div className="mt-2">
                  <Button size="sm" onClick={()=>{ 
                    const a = prompt('Answer'); 
                    if(a) onAnswer(r.id, a); 
                  }}>
                    Answer
                  </Button>
                </div>
              }
            </div>
          ))}
          {rows.length===0 && <div className="text-sm text-gray-400">No Q&A yet.</div>}
        </div>
      </CardContent>
    </Card>
  );
}