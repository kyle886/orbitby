import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Vendor } from "@/api/entities";
import { useToast } from "@/components/ui/use-toast";

export default function VendorList({ tenderId, rows=[], onInsert=()=>{}, onToggle=()=>{} }) {
  const [name, setName] = useState(''); 
  const [email, setEmail] = useState('');
  const { toast } = useToast();
  
  const add = async ()=>{
    try {
      const r = await Vendor.create({ 
        tender_id: tenderId, 
        name, 
        email, 
        invited: true, 
        created_at: new Date().toISOString() 
      });
      onInsert(r); 
      setName(''); 
      setEmail(''); 
      toast({title:'Vendor added'});
    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to add vendor', description: error.message });
    }
  };

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3"><CardTitle className="text-base">Vendors</CardTitle></CardHeader>
      <CardContent className="space-y-2">
        <div className="grid md:grid-cols-3 gap-2">
          <Input value={name} onChange={e=>setName(e.target.value)} placeholder="Company name" />
          <Input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Contact email" />
          <Button onClick={add}>Invite</Button>
        </div>
        <div className="space-y-2">
          {rows.map(v=>(
            <div key={v.id} className="rounded-lg border border-white/10 p-2 flex items-center justify-between">
              <div className="text-sm">{v.name} · <span className="text-xs text-gray-400">{v.email}</span></div>
              <div className="flex gap-2 items-center">
                <span className={`text-xs ${v.invited?'text-emerald-400':'text-gray-400'}`}>
                  {v.invited?'Invited':'Draft'}
                </span>
                <Button size="sm" variant="outline" onClick={()=>onToggle(v.id,!v.invited)}>
                  {v.invited?'Revoke':'Invite'}
                </Button>
              </div>
            </div>
          ))}
          {rows.length===0 && <div className="text-sm text-gray-400">No vendors yet.</div>}
        </div>
      </CardContent>
    </Card>
  );
}