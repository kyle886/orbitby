import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { TenderBid } from "@/api/entities";
import { useToast } from "@/components/ui/use-toast";
import { normalizeBid } from "@/api/functions";

export default function BidDropBox({ tenderId, onAdd=()=>{} }){
  const [vendor, setVendor] = useState(''); 
  const [raw, setRaw] = useState('');
  const { toast } = useToast();
  
  const normalize = async ()=>{
    try {
      const response = await normalizeBid({ text: raw });
      
      if (!response.data.ok) { 
        toast({
          variant: 'destructive',
          title: 'Parse failed',
          description: response.data.error
        }); 
        return; 
      }
      
      const row = await TenderBid.create({ 
        tender_id: tenderId, 
        vendor, 
        ...response.data.offer, 
        created_at: new Date().toISOString() 
      });
      
      onAdd(row); 
      toast({title: 'Bid saved', description: vendor}); 
      setVendor(''); 
      setRaw('');
    } catch (error) {
      toast({ 
        variant: 'destructive', 
        title: 'Failed to normalize bid', 
        description: error.message 
      });
    }
  };

  return (
    <Card className="shadow-elevated">
      <CardHeader className="pb-3"><CardTitle className="text-base">Bid Inbox</CardTitle></CardHeader>
      <CardContent className="space-y-2">
        <div className="grid md:grid-cols-4 gap-2">
          <Input value={vendor} onChange={e=>setVendor(e.target.value)} placeholder="Vendor name" />
          <div className="md:col-span-3">
            <Textarea value={raw} onChange={e=>setRaw(e.target.value)} placeholder="Paste tender email / PDF text here…" />
          </div>
        </div>
        <Button onClick={normalize}>Normalize & Save</Button>
      </CardContent>
    </Card>
  );
}