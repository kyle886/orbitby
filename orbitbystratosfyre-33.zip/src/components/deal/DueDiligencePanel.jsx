import React, { useEffect, useState, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DueDiligenceItem } from '@/api/entities';
import { Plus, Trash2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export default function DueDiligencePanel({ dealId, buildingId }) {
  const [rows, setRows] = useState([]);
  const { toast } = useToast();

  const loadItems = useCallback(async () => {
    if (!dealId || !buildingId) return;
    try {
      const items = await DueDiligenceItem.filter({ dealId, buildingId }, '-created_date');
      setRows(items);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to load DD items', description: error.message });
    }
  }, [dealId, buildingId, toast]);

  useEffect(() => {
    loadItems();
  }, [loadItems]);

  const handleAdd = async () => {
    try {
      await DueDiligenceItem.create({
        dealId,
        buildingId,
        category: 'Engineering',
        severity: 'med',
        desc: 'New due diligence item',
        mitigation: '',
        owner: '',
        status: 'open'
      });
      loadItems();
    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to add item', description: error.message });
    }
  };
  
  const handleUpdate = async (id, field, value) => {
    try {
      await DueDiligenceItem.update(id, { [field]: value });
      setRows(prev => prev.map(r => r.id === id ? {...r, [field]: value} : r));
    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to update item', description: error.message });
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this item?")) return;
    try {
      await DueDiligenceItem.delete(id);
      loadItems();
    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to delete item', description: error.message });
    }
  };

  return (
    <Card className="orbit-card">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-white text-base">Due Diligence Register</CardTitle>
        <Button size="sm" className="orbit-button bg-gray-700 hover:bg-gray-600" onClick={handleAdd}>
          <Plus className="w-4 h-4 mr-2" /> Add Item
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        {rows.length === 0 ? (
          <p className="text-gray-400 text-center py-4">No due diligence items for this property.</p>
        ) : (
          <div className="space-y-2">
            {/* Header */}
            <div className="hidden md:grid grid-cols-12 gap-2 text-xs text-gray-400 font-medium px-2">
              <div className="col-span-2">Category</div>
              <div className="col-span-1">Severity</div>
              <div className="col-span-3">Description</div>
              <div className="col-span-3">Mitigation</div>
              <div className="col-span-1">Owner</div>
              <div className="col-span-1">Status</div>
              <div className="col-span-1"></div>
            </div>
            {/* Rows */}
            {rows.map(r => (
              <div key={r.id} className="grid grid-cols-1 md:grid-cols-12 gap-2 items-center p-2 rounded-lg bg-gray-800/50">
                <Input className="orbit-input md:col-span-2" placeholder="Category" value={r.category || ''} onBlur={e => handleUpdate(r.id, 'category', e.target.value)} />
                <Select value={r.severity} onValueChange={val => handleUpdate(r.id, 'severity', val)}>
                  <SelectTrigger className="orbit-input md:col-span-1"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="low">Low</SelectItem><SelectItem value="med">Med</SelectItem><SelectItem value="high">High</SelectItem></SelectContent>
                </Select>
                <Input className="orbit-input md:col-span-3" placeholder="Description" value={r.desc || ''} onBlur={e => handleUpdate(r.id, 'desc', e.target.value)} />
                <Input className="orbit-input md:col-span-3" placeholder="Mitigation" value={r.mitigation || ''} onBlur={e => handleUpdate(r.id, 'mitigation', e.target.value)} />
                <Input className="orbit-input md:col-span-1" placeholder="Owner" value={r.owner || ''} onBlur={e => handleUpdate(r.id, 'owner', e.target.value)} />
                <Select value={r.status} onValueChange={val => handleUpdate(r.id, 'status', val)}>
                  <SelectTrigger className="orbit-input md:col-span-1"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="open">Open</SelectItem><SelectItem value="in-progress">In Progress</SelectItem><SelectItem value="closed">Closed</SelectItem></SelectContent>
                </Select>
                <div className="md:col-span-1 flex justify-end">
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(r.id)}><Trash2 className="w-4 h-4 text-red-500"/></Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}