import React from 'react';
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { GripVertical } from 'lucide-react';

const reorder = (list, startIndex, endIndex) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);
  return result;
};

const Row = ({ item, provided, snapshot }) => {
  const badge = item.type === "break" ? "☕" : "🏢";
  const sub = item.type === "break" ? `${item.dwellMin} min` : `${item.dwellMin} min on site`;
  
  return (
    <div
      ref={provided.innerRef}
      {...provided.draggableProps}
      {...provided.dragHandleProps}
      className={`flex items-center gap-3 p-3 rounded-lg border border-white/10 ${snapshot.isDragging ? 'bg-white/20' : 'bg-white/5'}`}
      style={provided.draggableProps.style}
    >
      <div className="w-6 text-center text-lg">{badge}</div>
      <div className="flex-1">
        <div className="text-sm text-white">{item.title}</div>
        <div className="text-xs text-gray-400">{sub}</div>
      </div>
      <GripVertical className="text-gray-400"/>
    </div>
  );
};

export default function StopsBuilder({ items, setItems }) {
  const onDragEnd = (result) => {
    if (!result.destination) {
      return;
    }
    const reorderedItems = reorder(
      items,
      result.source.index,
      result.destination.index
    );
    setItems(reorderedItems);
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <Droppable droppableId="droppable">
        {(provided) => (
          <div
            {...provided.droppableProps}
            ref={provided.innerRef}
            className="space-y-2"
          >
            {items.map((item, index) => (
              <Draggable key={item.id} draggableId={item.id} index={index}>
                {(provided, snapshot) => (
                  <Row item={item} provided={provided} snapshot={snapshot} />
                )}
              </Draggable>
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </DragDropContext>
  );
}