import React, { useRef, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

// A simplified annotator using vanilla canvas APIs as Fabric.js is not available.
export default function FloorplanAnnotator({ imageUrl, onExport }) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    
    // Clear canvas
    ctx.fillStyle = "#111827"; // bg-gray-900
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (imageUrl) {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = imageUrl;
      img.onload = () => {
        // Scale image to fit canvas
        const hRatio = canvas.width / img.width;
        const vRatio = canvas.height / img.height;
        const ratio = Math.min(hRatio, vRatio);
        const centerShift_x = (canvas.width - img.width * ratio) / 2;
        const centerShift_y = (canvas.height - img.height * ratio) / 2;
        ctx.drawImage(img, 0, 0, img.width, img.height,
                      centerShift_x, centerShift_y, img.width * ratio, img.height * ratio);
      };
    }
  }, [imageUrl]);

  const startDrawing = ({ nativeEvent }) => {
    const { offsetX, offsetY } = nativeEvent;
    const ctx = canvasRef.current.getContext("2d");
    ctx.strokeStyle = '#EA580C'; // Orange color
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(offsetX, offsetY);
    setIsDrawing(true);
  };

  const stopDrawing = () => {
    const ctx = canvasRef.current.getContext("2d");
    ctx.closePath();
    setIsDrawing(false);
  };

  const draw = ({ nativeEvent }) => {
    if (!isDrawing) return;
    const { offsetX, offsetY } = nativeEvent;
    const ctx = canvasRef.current.getContext("2d");
    ctx.lineTo(offsetX, offsetY);
    ctx.stroke();
  };
  
  const handleExport = () => {
    const dataUrl = canvasRef.current.toDataURL("image/png");
    onExport(dataUrl);
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#111827";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    if (imageUrl) {
       // Redraw image
       const event = new Event('load');
       const img = new Image();
       img.src = imageUrl;
       img.onload = () => ctx.drawImage(img, 0, 0);
       img.dispatchEvent(event);
    }
  };


  return (
    <div className="space-y-2">
      <div className="flex gap-2">
        <Button onClick={handleExport}>Export PNG</Button>
        <Button variant="outline" onClick={handleClear}>Clear</Button>
      </div>
      <canvas
        ref={canvasRef}
        width={800}
        height={600}
        className="border border-white/10 rounded-lg bg-gray-900"
        onMouseDown={startDrawing}
        onMouseUp={stopDrawing}
        onMouseMove={draw}
        onMouseLeave={stopDrawing}
      />
    </div>
  );
}