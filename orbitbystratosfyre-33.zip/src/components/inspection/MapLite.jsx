import React from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Fix for default icon path issue with webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

export default function MapLite({ points, route }) {
  const ref = React.useRef(null);

  // Extract complex expressions for React hook dependencies
  const pointsKey = JSON.stringify(points);
  const routeKey = route ? JSON.stringify(route.coordinates) : "";

  React.useEffect(() => {
    if (!ref.current) return;
    
    const map = L.map(ref.current, { zoomControl: true });
    const first = points[0] || { lat: -33.8688, lng: 151.2093 };
    map.setView([first.lat, first.lng], 13);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OSM" }).addTo(map);

    const group = [];
    points.forEach((p, i) => {
      const m = L.marker([p.lat, p.lng]).addTo(map);
      m.bindPopup(`${i + 1}. ${p.label || ""}`);
      group.push([p.lat, p.lng]);
    });

    if (route?.coordinates?.length) {
      L.polyline(route.coordinates.map(([lng, lat]) => [lat, lng]), { 
        weight: 4, 
        opacity: 0.8, 
        color: '#ea580c' 
      }).addTo(map);
    }

    if (group.length) map.fitBounds(group, { padding: [30, 30] });

    return () => map.remove();
  }, [pointsKey, routeKey]);

  return <div className="h-64 w-full rounded-lg overflow-hidden border border-white/10 bg-gray-800" ref={ref} />;
}