
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Loader2, Book, CheckSquare, Square, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { DocFolder } from '@/api/entities';
import { DocVersion } from '@/api/entities';
import { Document } from '@/api/entities';
import { mergePdfs } from "@/components/utils/doc/mergePdfs";
import { uploadBlobSmart } from '@/components/utils/uploadBlobSmart';

export default function DocumentBinderModal({ open, onOpenChange, context }) {
    const { toast } = useToast();
    const [folders, setFolders] = useState([]);
    const [versions, setVersions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false); // Renamed from setIsCreating to setBusy for consistency
    const [selected, setSelected] = useState([]);

    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const [allFolders, allVersions] = await Promise.all([
                DocFolder.list('-created_date'),
                DocVersion.list('-uploaded_at')
            ]);
            setFolders(allFolders || []);
            setVersions(allVersions || []);
        } catch (error) {
            console.error("Error loading document data:", error);
            toast({ variant: "destructive", title: "Error loading documents" });
        } finally {
            setLoading(false);
        }
    }, [toast]);

    useEffect(() => {
        if (!open) return;
        loadData();
    }, [open, context, loadData]);

    const toggleSelection = (id) => {
        setSelected(prev => prev.includes(id) 
            ? prev.filter(x => x !== id) 
            : [...prev, id]
        );
    };

    const createBinder = async () => {
        if (selected.length < 2) { // Keeping original logic for minimum documents
            toast({ variant:"destructive", title:"Pick at least two documents" });
            return;
        }
        
        setBusy(true);
        toast({ title: 'Creating Binder...', description: `Merging ${selected.length} documents.` });
        
        try {
            const chosen = selected.map(id => versions.find(v => v.id === id)).filter(Boolean);
            
            let fileUrl = null;
            // Try backend binder first (persistent + faster)
            try {
                const resp = await fetch('/functions/docBinder', {
                    method:'POST',
                    headers:{ 'content-type':'application/json' },
                    body: JSON.stringify({ urls: chosen.map(v=>v.file_url), filename: `binder-${Date.now()}.pdf` })
                });
                if (resp.ok) {
                    const j = await resp.json();
                    fileUrl = j.url;
                } else {
                    console.warn("Backend binder creation failed with status:", resp.status, await resp.text());
                }
            } catch (e) {
                console.warn("Error calling backend binder function:", e);
            }

            // Fallback to client-side merge if backend failed
            if (!fileUrl) {
                toast({ title: 'Backend binder failed, falling back to client-side merge.' });
                const blob = await mergePdfs(chosen.map(v => v.file_url));
                fileUrl = await uploadBlobSmart(blob, `binder-${Date.now()}.pdf`);
            }

            if (!fileUrl) {
                throw new Error("Failed to obtain a file URL for the binder.");
            }

            await Document.create({
                folder_id: context.folder_id ?? null,
                document_type: 'other',
                file_url: fileUrl,
                document_name: `Binder - ${new Date().toISOString().split('T')[0]}`,
                uploaded_by: context.user_email || 'system'
            });
            toast({ title: "Binder created" });
            onOpenChange(false);
        } catch (e) {
            console.error("Binder creation failed:", e);
            toast({ variant:"destructive", title:"Binder failed", description: String(e.message || e) });
        } finally {
            setBusy(false);
        }
    };

    const relevantVersions = versions.filter(v => 
        !context.folder_id || v.folder_id === context.folder_id
    );

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="orbit-card max-w-2xl text-white">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Book className="w-5 h-5 text-orange-400" />
                        Create Document Binder
                    </DialogTitle>
                    <DialogDescription className="text-gray-400">
                        Select documents to merge into a single PDF binder
                    </DialogDescription>
                </DialogHeader>

                <div className="max-h-96 overflow-y-auto">
                    {loading ? (
                        <div className="flex items-center justify-center py-8">
                            <Loader2 className="w-6 h-6 animate-spin text-orange-400" />
                        </div>
                    ) : relevantVersions.length === 0 ? (
                        <div className="text-center py-8 text-gray-400">
                            No documents available for binding
                        </div>
                    ) : (
                        <div className="space-y-2">
                            {relevantVersions.map(version => (
                                <div key={version.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-800/50">
                                    <button 
                                        onClick={() => toggleSelection(version.id)}
                                        className="text-orange-400 hover:text-orange-300"
                                    >
                                        {selected.includes(version.id) ? 
                                            <CheckSquare className="w-5 h-5" /> : 
                                            <Square className="w-5 h-5" />
                                        }
                                    </button>
                                    <div className="flex-1">
                                        <p className="text-sm font-medium text-white">{version.name}</p>
                                        <p className="text-xs text-gray-400">
                                            v{version.version} • {new Date(version.uploaded_at).toLocaleDateString()}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <DialogFooter className="flex justify-between">
                    <div className="text-sm text-gray-400">
                        {selected.length} document{selected.length !== 1 ? 's' : ''} selected
                    </div>
                    <div className="flex gap-2">
                        <Button variant="outline" onClick={() => onOpenChange(false)}>
                            Cancel
                        </Button>
                        <Button 
                            onClick={createBinder} 
                            disabled={busy || selected.length < 2}
                            className="bg-orange-500 hover:bg-orange-600"
                        >
                            {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                            Create Binder
                        </Button>
                    </div>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
