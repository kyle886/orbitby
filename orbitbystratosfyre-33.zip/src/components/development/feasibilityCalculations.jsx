// Simplified financial calculations for feasibility analysis

/**
 * Calculates cash flows for a Lease scenario.
 * @param {object} inputs - Lease scenario inputs.
 * @returns {object} - Calculated outputs including cash flows.
 */
export const calculateLeaseScenario = (inputs) => {
    const {
        area_m2 = 0,
        rent_aud_per_m2_pa = 0,
        opex_aud_per_m2_pa = 0,
        incentives_pct = 0,
        fitout_capex_aud = 0,
        term_years = 1,
        makegood_aud = 0,
        indexation_pct = 0.03
    } = inputs;

    const annual_base_rent = rent_aud_per_m2_pa * area_m2;
    const annual_opex = opex_aud_per_m2_pa * area_m2;
    const total_incentive = annual_base_rent * term_years * (incentives_pct / 100);
    const amortised_incentive_pa = total_incentive / term_years;

    const cashflows = [];
    cashflows.push(-fitout_capex_aud); // Year 0 outflow

    let currentRent = annual_base_rent;
    for (let year = 1; year <= term_years; year++) {
        const annual_cost = currentRent + annual_opex - amortised_incentive_pa;
        cashflows.push(-annual_cost);
        currentRent *= (1 + indexation_pct); // Apply indexation for next year
    }
    
    cashflows[term_years] -= makegood_aud; // Add make-good cost at the end

    const npv = calculateNPV(0.08, cashflows); // Assume 8% discount rate
    
    return {
        cashflows,
        npv,
        total_occupancy_cost: -npv,
        payback_years: null, // Not applicable for lease
        irr_pct: null, // Not applicable for lease
    };
};

/**
 * Calculates NPV for a Buy scenario.
 * @param {object} inputs - Buy scenario inputs.
 * @returns {object} - Calculated outputs.
 */
export const calculateBuyScenario = (inputs) => {
    const {
        price_aud = 0,
        stamp_duty_aud = 0,
        fitout_capex_aud = 0,
        opex_aud_per_m2_pa = 0,
        exit_value_aud_at_T = 0,
        holding_years = 1,
        area_m2 = 1,
    } = inputs;

    const cashflows = [];
    cashflows.push(-(price_aud + stamp_duty_aud + fitout_capex_aud)); // Year 0

    const annual_opex = opex_aud_per_m2_pa * area_m2;
    for (let year = 1; year <= holding_years; year++) {
        cashflows.push(-annual_opex);
    }

    cashflows[holding_years] += exit_value_aud_at_T; // Add exit value

    const npv = calculateNPV(0.08, cashflows);
    const irr = calculateIRR(cashflows) * 100;

    return { cashflows, npv, irr_pct: irr, payback_years: null };
};

/**
 * Calculates project IRR for a Develop scenario.
 * @param {object} inputs - Develop scenario inputs.
 * @returns {object} - Calculated outputs.
 */
export const calculateDevelopScenario = (inputs) => {
    const {
        land_cost_aud = 0,
        hard_cost_aud = 0,
        soft_cost_aud = 0,
        contingency_pct = 0.1,
        construction_months = 24,
        exit_cap_rate_pct = 0.05,
        area_m2 = 1,
        leaseback_rent_aud_per_m2_pa = 0,
    } = inputs;

    const total_hard_cost = hard_cost_aud * (1 + contingency_pct);
    const total_dev_cost = land_cost_aud + total_hard_cost + soft_cost_aud;
    const construction_years = construction_months / 12;

    const cashflows = [];
    cashflows.push(-land_cost_aud); // Year 0

    // Spread dev costs over construction period
    for (let i = 1; i <= Math.floor(construction_years); i++) {
        cashflows.push(-(total_hard_cost + soft_cost_aud) / construction_years);
    }
    
    const noi = leaseback_rent_aud_per_m2_pa * area_m2;
    const residual_value = noi / (exit_cap_rate_pct / 100);

    // Assume sale at the end of the year after construction finishes
    const final_year_index = Math.ceil(construction_years);
    if(cashflows.length <= final_year_index) {
        cashflows[final_year_index] = 0;
    }
    cashflows[final_year_index] += residual_value;

    const npv = calculateNPV(0.08, cashflows);
    const irr = calculateIRR(cashflows) * 100;

    return { cashflows, npv, irr_pct: irr, total_dev_cost, residual_value };
};


// Financial utility functions
const calculateNPV = (rate, cashflows) => {
    return cashflows.reduce((acc, val, i) => acc + val / Math.pow(1 + rate, i), 0);
};

const calculateIRR = (cashflows, guess = 0.1) => {
  const maxTries = 100;
  const tolerance = 0.00001;

  for (let i = 0; i < maxTries; i++) {
    const npv = calculateNPV(guess, cashflows);
    const derivative = cashflows.reduce((acc, val, j) => acc - (j * val) / Math.pow(1 + guess, j + 1), 0);
    
    if (Math.abs(npv) < tolerance) return guess;
    
    guess = guess - npv / derivative;
  }
  return NaN; // Failed to converge
};