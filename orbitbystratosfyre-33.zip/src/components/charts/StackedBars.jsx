import React from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const CustomXAxisTick = ({ x, y, payload }) => {
  if (!payload || !payload.value) return null;
  
  const [year, monthNum] = payload.value.split('-').map(Number);
  const date = new Date(year, monthNum - 1); // monthNum is 1-based, Date constructor expects 0-based
  
  const monthLabel = date.toLocaleDateString('en-US', { 
    month: 'short', 
    year: '2-digit' 
  });

  return (
    <g transform={`translate(${x},${y})`}>
      <text 
        x={0} 
        y={0} 
        dy={16} 
        textAnchor="middle" 
        fill="#9CA3AF" 
        fontSize="12"
        className="text-gray-400"
      >
        {monthLabel}
      </text>
    </g>
  );
};

export default function StackedBars({ 
  data = [], 
  dataKeys = [], 
  colors = [], 
  height = 300,
  showGrid = true,
  showTooltip = true,
  showLegend = true 
}) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-400">
        No data to display
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart
        data={data}
        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
      >
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#374151" />}
        <XAxis 
          dataKey="period" 
          stroke="#9CA3AF"
          tick={<CustomXAxisTick />}
        />
        <YAxis stroke="#9CA3AF" />
        {showTooltip && (
          <Tooltip
            contentStyle={{
              backgroundColor: '#1F2937',
              border: '1px solid #374151',
              borderRadius: '8px',
              color: '#F3F4F6'
            }}
          />
        )}
        {showLegend && <Legend />}
        {dataKeys.map((key, index) => (
          <Bar 
            key={key}
            dataKey={key} 
            stackId="a"
            fill={colors[index] || `hsl(${index * 45}, 70%, 50%)`}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
}