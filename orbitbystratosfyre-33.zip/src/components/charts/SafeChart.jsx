import React from 'react';
import { ResponsiveContainer } from 'recharts';

export function ChartShell({ children, h = 260 }) {
  return (
    <div style={{ height: h, width: "100%" }} className="w-full bg-black/30 rounded-xl p-2">
      <ResponsiveContainer>{children}</ResponsiveContainer>
    </div>
  );
}

export function safeData(rows, keys = []) {
  if (!Array.isArray(rows) || rows.length === 0) return [];
  for (const k of keys) {
    if (rows.some((r) => r[k] == null)) {
      console.warn(`Chart data validation failed: key '${k}' is missing in some records.`);
      return [];
    }
  }
  return rows;
}

export function emptyIfBad(xs, keys = []) {
  if (!Array.isArray(xs) || xs.length === 0) return [];
  for (const k of keys) {
    if (xs.some((r) => r[k] == null)) {
      console.warn(`Chart data validation failed: key '${k}' is missing in some records.`);
      return [];
    }
  }
  return xs;
}