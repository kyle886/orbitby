import React from "react";

export default function Sparkline({
  data = [],
  width = 160,
  height = 48,
  stroke = "#818cf8",        // brand.400
  strokeWidth = 2,
  fill = "rgba(129,140,248,0.15)", // brand.400 @ 15%
  showArea = true,
  showDot = true
}) {
  if (!data || data.length < 2) return null;
  const w = width, h = height, p = 4;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const dx = (w - p * 2) / (data.length - 1);
  const normY = v => {
    if (max === min) return h / 2;
    const t = (v - min) / (max - min);
    return (h - p) - t * (h - p * 2);
  };
  const points = data.map((v, i) => [p + i * dx, normY(v)]);
  const d = points.map(([x, y], i) => `${i ? "L" : "M"}${x},${y}`).join(" ");
  const area = `M${points[0][0]},${h - p} ` + d + ` L${points.at(-1)[0]},${h - p} Z`;
  const [lastX, lastY] = points.at(-1);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-[48px]">
      {showArea && <path d={area} fill={fill} />}
      <path d={d} fill="none" stroke={stroke} strokeWidth={strokeWidth} strokeLinejoin="round" strokeLinecap="round" />
      {showDot && <circle cx={lastX} cy={lastY} r="2.5" fill={stroke} />}
    </svg>
  );
}