import React from "react";

// values: array of 12 numbers (Jan-Dec)
export default function Heatmap({ values = [], width = 400, height = 40 }) {
  const max = Math.max(1, ...values);
  const cellWidth = width / 12;
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ height: `${height}px` }}>
        {values.map((value, i) => {
          const intensity = max > 0 ? value / max : 0;
          const opacity = Math.max(0.1, intensity);
          const color = `rgba(99, 102, 241, ${opacity})`;
          
          return (
            <g key={i}>
              <rect
                x={i * cellWidth}
                y={4}
                width={cellWidth - 2}
                height={height - 12}
                fill={color}
                rx="2"
              />
              <text
                x={i * cellWidth + cellWidth / 2}
                y={height - 2}
                fontSize="8"
                fill="#9CA3AF"
                textAnchor="middle"
              >
                {months[i]}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}