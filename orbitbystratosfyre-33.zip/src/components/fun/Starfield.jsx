import { useEffect, useMemo } from "react";

export default function Starfield({ show = false, onDone = () => {} }) {
  const stars = useMemo(() => {
    const arr = [];
    const N = 150; // Increased number of stars
    for (let i = 0; i < N; i++) {
      arr.push({
        top: Math.random() * 100,
        left: Math.random() * 100,
        twinkle: (2 + Math.random() * 3).toFixed(2) + 's', // Longer twinkle duration
        size: Math.random() < 0.15 ? 3 : Math.random() < 0.3 ? 2.5 : 2
      });
    }
    return arr;
  }, []);

  useEffect(() => {
    if (!show) return;
    // Increased duration to 12 seconds to match CSS animation
    const t = setTimeout(onDone, 12000);
    return () => clearTimeout(t);
  }, [show, onDone]);

  if (!show) return null;
  
  return (
    <div className="starfield">
      {stars.map((s, i) => (
        <span
          key={i}
          className="star"
          style={{ 
            top: s.top + '%', 
            left: s.left + '%', 
            width: s.size + 'px', 
            height: s.size + 'px', 
            '--twinkle': s.twinkle 
          }}
        />
      ))}
    </div>
  );
}