import { useEffect, useState } from "react";
import { isCosmicActive, disableCosmic, applyCosmic } from "@/components/utils/theme/cosmic";

export default function CosmicBadge() {
  const [on, setOn] = useState(false);
  useEffect(() => { setOn(isCosmicActive()); }, []);
  useEffect(() => {
    const t = setInterval(() => setOn(isCosmicActive()), 60000);
    return () => clearInterval(t);
  }, []);
  if (!on) return null;
  return (
    <div
      className="pointer-events-auto"
      style={{
        position: 'absolute', right: 14, bottom: 8, zIndex: 55,
        background: 'rgba(0,0,0,.55)', backdropFilter: 'blur(4px)',
        color: 'white', padding: '4px 10px', borderRadius: 10, fontSize: 12
      }}
    >
      Cosmic Mode · <button
        onClick={() => { disableCosmic(); applyCosmic(); setOn(false); }}
        style={{ textDecoration:'underline', marginLeft: 6 }}
      >Disable</button>
    </div>
  );
}