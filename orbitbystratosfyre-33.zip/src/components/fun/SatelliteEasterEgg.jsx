import { useCallback, useEffect, useState } from "react";
import Starfield from "./Starfield";
import { fireConfetti } from "@/components/utils/fun/confetti";
import { enableCosmic, disableCosmic, isCosmicActive, applyCosmic } from "@/components/utils/theme/cosmic";

export default function SatelliteEasterEgg() {
  const [party, setParty] = useState(false);
  const [caption, setCaption] = useState("");
  const [active, setActive] = useState(false);

  useEffect(() => {
    const speed = 22 + Math.round(Math.random() * 6);
    document.documentElement.style.setProperty('--satellite-speed', `${speed}s`);
    setActive(isCosmicActive());
  }, []);

  const onClick = useCallback(() => {
    const nowActive = isCosmicActive();
    if (nowActive) {
      disableCosmic();
      setActive(false);
      setCaption("Cosmic Mode disabled. Back to normal space.");
    } else {
      enableCosmic(24);
      setActive(true);
      setCaption("🌌 Cosmic Mode activated for 24 hours!");
    }
    
    // Force immediate visual update
    applyCosmic();
    
    setParty(true);
    try { 
      fireConfetti({ count: 140, duration: 2600 }); 
    } catch (e) {
      console.log("Confetti failed", e);
    }
  }, []);

  return (
    <>
      <div className="satellite-track">
        <button
          aria-label="Toggle Cosmic Mode - Click the satellite!"
          className="satellite-btn"
          onClick={onClick}
          title={active ? "Disable Cosmic Mode" : "Enable Cosmic Mode"}
          style={active ? { 
            filter: "drop-shadow(0 0 12px rgba(139,92,246,.9)) brightness(1.2)",
            transform: 'scale(1.05)'
          } : {}}
        >
          <SatelliteSVG />
        </button>
      </div>

      {party && (
        <div
          className="pointer-events-none fixed right-4 top-20 z-50 px-3 py-2 rounded-lg text-xs font-medium text-white"
          style={{
            background: active ? 'rgba(139,92,246,0.9)' : 'rgba(0,0,0,.8)', 
            backdropFilter: 'blur(6px)',
            border: '1px solid rgba(255,255,255,0.3)',
            animation: 'fade-in-out 4s ease-out forwards'
          }}
        >
          {caption}
        </div>
      )}

      <Starfield show={party} onDone={() => setParty(false)} />
    </>
  );
}

function SatelliteSVG() {
  return (
    <svg className="satellite-icon w-8 h-8" viewBox="0 0 64 64" fill="none">
      {/* Main body */}
      <rect x="26" y="26" width="12" height="12" rx="2" fill="#818cf8" stroke="#6366f1" strokeWidth="0.5" />
      <rect x="28" y="28" width="8" height="8" rx="1.6" fill="#6366f1" />
      
      {/* Solar panels with subtle animation */}
      <g className="satellite-spark">
        <rect x="6" y="28" width="18" height="8" rx="2" fill="#0ea5e9" stroke="#0284c7" strokeWidth="0.5" />
        <rect x="40" y="28" width="18" height="8" rx="2" fill="#0ea5e9" stroke="#0284c7" strokeWidth="0.5" />
      </g>
      
      {/* Connection struts */}
      <rect x="24" y="31" width="4" height="2" rx="1" fill="#e5e7eb" />
      <rect x="36" y="31" width="4" height="2" rx="1" fill="#e5e7eb" />
      
      {/* Communication dish */}
      <circle cx="32" cy="22" r="4" fill="#e5e7eb" stroke="#d1d5db" strokeWidth="0.5" />
      <rect x="31" y="22" width="2" height="4" fill="#e5e7eb" />
      
      {/* Sparkle effects */}
      <circle cx="14" cy="20" r="1.2" fill="#fff" opacity=".9" />
      <circle cx="52" cy="16" r="1.2" fill="#fff" opacity=".9" />
      <circle cx="32" cy="12" r="0.8" fill="#fbbf24" opacity=".8" />
    </svg>
  );
}