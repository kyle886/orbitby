import React from 'react';

export function VirtualList({ rows, rowHeight = 44, height = 440, width = '100%', render }) {
  if (!rows || rows.length === 0) {
    return <div style={{ height }} className="flex items-center justify-center text-gray-500">No items to display.</div>;
  }

  return (
    <div 
      style={{ 
        height, 
        width, 
        overflowY: 'auto',
        border: '1px solid rgba(255,255,255,0.1)',
        borderRadius: '8px'
      }}
      className="bg-gray-800/30"
    >
      {rows.map((row, index) => (
        <div 
          key={index}
          style={{ minHeight: rowHeight }}
          className="border-b border-gray-700/50 last:border-b-0"
        >
          {render(row, index)}
        </div>
      ))}
    </div>
  );
}