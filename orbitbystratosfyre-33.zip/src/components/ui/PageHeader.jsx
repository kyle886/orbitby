import React from "react";
// Removed SatelliteEasterEgg and CosmicBadge imports

export default function PageHeader({ title, description, actions, className = "" }) {
  return (
    <div className={`relative mb-8 ${className}`}>
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-2">
        <div className="flex-1">
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">{title}</h1>
          {description && (
            <p className="text-gray-300 text-sm md:text-base">{description}</p>
          )}
        </div>
        {actions && (
          <div className="flex items-center gap-3 flex-shrink-0">
            {actions}
          </div>
        )}
      </div>
      
      {/* Easter Egg Components removed from here */}
    </div>
  );
}