import React, { createContext, useContext, useState, useEffect } from 'react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

const ViewAsContext = createContext();

export function ViewAsProvider({ children }) {
  const [role, setRole] = useState(() => localStorage.getItem('viewAs') || 'Broker');
  
  useEffect(() => {
    localStorage.setItem('viewAs', role);
  }, [role]);

  return (
    <ViewAsContext.Provider value={{ role, setRole }}>
      {children}
    </ViewAsContext.Provider>
  );
}

export function useViewAs() {
  const context = useContext(ViewAsContext);
  if (!context) {
    throw new Error('useViewAs must be used within a ViewAsProvider');
  }
  return context;
}

export function ViewAsToggle() {
  const { role, setRole } = useViewAs();
  const isTenantView = role === 'Tenant';

  return (
    <div className="flex items-center gap-2 text-sm text-gray-300">
      <Label htmlFor="view-as-toggle">Tenant View</Label>
      <Switch
        id="view-as-toggle"
        checked={isTenantView}
        onCheckedChange={(checked) => setRole(checked ? 'Tenant' : 'Broker')}
      />
      <span className={isTenantView ? "text-white font-medium" : "text-gray-400"}>
        {isTenantView ? 'On' : 'Off'}
      </span>
    </div>
  );
}