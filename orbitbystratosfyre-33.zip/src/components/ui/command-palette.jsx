
import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { runJob } from '@/components/utils/runJob'; // Fixed import path
import { useToast } from '@/components/ui/use-toast';
import { 
  Search, 
  Zap, 
  Target, 
  RefreshCw, 
  Calendar, 
  Building2, 
  Clock, 
  BarChart3, 
  Bell, 
  FileText 
} from 'lucide-react';
import { InvokeLLM } from '@/api/integrations';

// Import all required entities
import { Signal } from '@/api/entities';
import { Event } from '@/api/entities';
import { EventROI } from '@/api/entities';
import { Target as TargetEntity } from '@/api/entities';
import { Company } from '@/api/entities';
import { Brief } from '@/api/entities';
import { Lease } from '@/api/entities';
import { Building } from '@/api/entities';
import { BDKPI } from '@/api/entities';
import { BDEventAttendance } from '@/api/entities';
import { Document } from '@/api/entities';
import { Assignment } from '@/api/entities';
import { Pitch } from '@/api/entities';

import {
  calculateBuildingLeverage,
  calculateFundingMomentum,
  calculateHiringSignal,
  calculateLeaseExpiryProximity,
  calculateNewsHeat,
  calculatePriorityScore,
  calculateSectorFit,
  calculateTop20Targets,
  calculateEventROI
} from '@/components/utils/scoringCalculations';

const COMMANDS = [
  { id: 'ingest-signals', title: 'Ingest Signals', description: 'Scan for new Funding, News, and DA signals', icon: Zap, category: 'Data Ingestion' },
  { id: 'refresh-target-scores', title: 'Refresh Target Scores', description: 'Re-calculate scores for all targets', icon: Target, category: 'Business Development' },
  { id: 'rebuild-top20', title: 'Rebuild Top-20', description: 'Re-calculate the Top-20 target list', icon: RefreshCw, category: 'Business Development' },
  { id: 'pull-events-roi', title: 'Pull Events & Compute ROI', description: 'Scan for new events and calculate ROI', icon: Calendar, category: 'Events' },
  { id: 'deal-sync', title: 'Deal Sync (Brief→Lease)', description: 'Sync won briefs to leases and signals', icon: Building2, category: 'Deal Management' },
  { id: 'lease-expiry-watcher', title: 'Lease-Expiry Watcher', description: 'Recompute lease expiry scores', icon: Clock, category: 'Business Development' },
  { id: 'month-end-kpis', title: 'Month-End KPIs', description: 'Calculate and save KPI snapshot', icon: BarChart3, category: 'Reporting' },
  { id: 'post-event-feedback', title: 'Post-Event Feedback Reminders', description: 'Send feedback reminders', icon: Bell, category: 'Events' },
  { id: 'generate-pre-event-briefs', title: 'Generate Pre-Event Briefs', description: 'Compile pre-event briefing documents', icon: FileText, category: 'Events' }
];

// Re-implementing job logic functions directly inside the command palette component
// In a larger app, these would be in a shared utility file.
// 1. Ingest Signals Job
const ingestSignalsLogic = async () => {
    const existingSignals = await Signal.list();
    const existingCompanies = await Company.list();
    
    const signalSchema = {
      type: "object",
      properties: {
        signals: {
          type: "array",
          items: {
            type: "object",
            properties: {
              company_name: { type: "string" },
              type: { type: "string", enum: ["funding", "hire", "DA", "news", "MA"] },
              title: { type: "string" },
              url: { type: "string" },
              date: { type: "string", format: "date" },
              amount_aud: { type: "number" },
              source: { type: "string" },
              location: { type: "string" }
            },
            required: ["company_name", "type", "title", "date", "source"]
          }
        }
      }
    };

    const prompt = `Find recent business signals for Sydney companies from the last 30 days. Look for:
    - Funding announcements (Series A, B, C, IPOs)
    - Major hiring announcements or executive appointments
    - Development application (DA) submissions for commercial fit-outs
    - Significant business news (expansions, acquisitions, partnerships)
    - Merger and acquisition activity
    
    Focus on tech, life sciences, education, and fintech companies in Sydney, Australia.`;

    const response = await InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: signalSchema
    });

    let newSignals = 0;
    let updatedSignals = 0;

    for (const signalData of response.signals || []) {
      let company = existingCompanies.find(c => 
        c.name.toLowerCase().includes(signalData.company_name.toLowerCase()) ||
        signalData.company_name.toLowerCase().includes(c.name.toLowerCase())
      );

      if (!company) {
        company = await Company.create({
          name: signalData.company_name,
          hq_city: signalData.location || 'Sydney',
          sector: 'Other'
        });
        existingCompanies.push(company);
      }

      const existingSignal = existingSignals.find(s => s.url === signalData.url);
      
      if (!existingSignal) {
        await Signal.create({
          company_id: company.id,
          type: signalData.type,
          source: signalData.source,
          title: signalData.title,
          url: signalData.url,
          date: signalData.date,
          amount_aud: signalData.amount_aud || null,
          location: signalData.location || null
        });
        newSignals++;
      } else {
        if (existingSignal.amount_aud !== signalData.amount_aud) {
          await Signal.update(existingSignal.id, { amount_aud: signalData.amount_aud });
          updatedSignals++;
        }
      }
    }

    return {
      rows_affected: newSignals + updatedSignals,
      notes: `Created ${newSignals} new signals, updated ${updatedSignals} existing signals.`
    };
};

// 2. Refresh Target Scores Job
const refreshTargetScoresLogic = async () => {
    const [targets, companies, buildings, briefs, signals] = await Promise.all([
      TargetEntity.list(),
      Company.list(),
      Building.list(),
      Brief.list(),
      Signal.list()
    ]);

    let updatedCount = 0;

    for (const target of targets) {
      const company = companies.find(c => c.id === target.company_id);
      if (!company) continue;

      const companySignals = signals.filter(s => s.company_id === company.id);
      const companyLeases = []; // Assuming lease data is not directly associated here without a lookup

      const funding_momentum_score = calculateFundingMomentum(companySignals);
      const lease_expiry_proximity_score = companyLeases.length > 0 ? 
        calculateLeaseExpiryProximity(companyLeases[0].expiry_date) : 0;
      const building_leverage_score = calculateBuildingLeverage(target.building_id, briefs, buildings);
      const sector_fit_score = calculateSectorFit(company.sector);
      const hiring_signal_score = calculateHiringSignal(companySignals);
      const news_heat_score = calculateNewsHeat(companySignals);

      const priority_score = calculatePriorityScore({
        funding_momentum_score,
        lease_expiry_proximity_score,
        building_leverage_score,
        sector_fit_score,
        hiring_signal_score,
        news_heat_score
      });

      await TargetEntity.update(target.id, {
        funding_momentum_score,
        lease_expiry_proximity_score,
        building_leverage_score,
        sector_fit_score,
        hiring_signal_score,
        news_heat_score,
        priority_score
      });
      updatedCount++;
    }

    return {
      rows_affected: updatedCount,
      notes: `Updated priority scores for ${updatedCount} targets.`
    };
};

// 3. Rebuild Top-20 Job
const rebuildTop20Logic = async () => {
    const [targets, companies] = await Promise.all([
      TargetEntity.list(),
      Company.list()
    ]);

    const newTop20Ids = calculateTop20Targets(targets, companies);
    
    await Promise.all(targets.map(t => 
      TargetEntity.update(t.id, { is_top_20: false })
    ));

    await Promise.all(newTop20Ids.map(id => 
      TargetEntity.update(id, { is_top_20: true })
    ));

    const pinnedCount = targets.filter(t => t.pinned).length;
    const added = newTop20Ids.length;
    const removed = targets.filter(t => t.is_top_20).length - added;

    return {
      rows_affected: targets.length,
      notes: `Rebuilt Top-20 list: ${added} targets selected, ${pinnedCount} pinned, ${Math.max(0, removed)} rotated out.`
    };
};

// 4. Deal Sync Job
const dealSyncLogic = async () => {
    const [wonBriefs, companies, buildings, targets] = await Promise.all([
      Brief.filter({ status: 'won' }),
      Company.list(),
      Building.list(),
      TargetEntity.list()
    ]);

    const unsyncedBriefs = wonBriefs.filter(b => !b.synced_to_lease_at);
    let leasesUpserted = 0;
    let signalsCreated = 0;
    let leverageBoosts = 0;

    for (const brief of unsyncedBriefs) {
      const existingLeases = await Lease.filter({ 
        company_id: brief.client_company_id, 
        building_id: brief.building_id 
      });

      if (existingLeases.length === 0) {
        await Lease.create({
          company_id: brief.client_company_id,
          building_id: brief.building_id,
          area_m2: brief.area_need_m2,
          start_date: brief.required_date,
          expiry_date: new Date(new Date(brief.required_date).setFullYear(
            new Date(brief.required_date).getFullYear() + (brief.lease_term_years || 5)
          )).toISOString().split('T')[0],
          source: 'manual'
        });
        leasesUpserted++;
      }

      await Signal.create({
        company_id: brief.client_company_id,
        type: 'reported_deal',
        source: 'internal_brief',
        title: `Lease executed: ${brief.company_name}`,
        date: new Date().toISOString().split('T')[0],
        amount_aud: brief.area_need_m2 * 500, // Estimate
        location: brief.building_id
      });
      signalsCreated++;

      const buildingTargets = targets.filter(t => 
        t.building_id === brief.building_id && 
        t.company_id !== brief.client_company_id
      );
      
      for (const target of buildingTargets) {
        await TargetEntity.update(target.id, {
          building_leverage_score: Math.min(100, (target.building_leverage_score || 0) + 20)
        });
        leverageBoosts++;
      }

      await Brief.update(brief.id, {
        synced_to_lease_at: new Date().toISOString()
      });
    }

    return {
      rows_affected: leasesUpserted + signalsCreated,
      notes: `Synced ${unsyncedBriefs.length} won briefs: ${leasesUpserted} leases, ${signalsCreated} signals, ${leverageBoosts} boosts.`
    };
};

// 5. Pull Events & Compute ROI Job
const pullEventsROILogic = async () => {
    const events = await Event.list();
    const existingROIs = await EventROI.list();
    
    let roisCreated = 0;

    for (const event of events) {
      const existingROI = existingROIs.find(r => r.event_id === event.id);
      
      if (!existingROI) {
        const targetOverlapPct = Math.floor(Math.random() * 30) + 10; // Placeholder for actual calculation
        const roiData = calculateEventROI(event, targetOverlapPct);
        
        await EventROI.create({
          event_id: event.id,
          ...roiData
        });
        roisCreated++;
      }
    }

    return {
      rows_affected: roisCreated,
      notes: `Processed ${events.length} events: ${roisCreated} new ROI calculations created.`
    };
};

// 6. Post-Event Feedback Reminders Job
const postEventFeedbackLogic = async () => {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const now = new Date();
    
    const [pastEvents, attendances, assignments] = await Promise.all([
      Event.filter({ 
        end_dt: { $lt: now.toISOString(), $gte: thirtyDaysAgo.toISOString() }
      }),
      BDEventAttendance.list(),
      Assignment.list()
    ]);

    let remindersCreated = 0;
    let remindersSent = 0;

    for (const event of pastEvents) {
      const eventAttendances = attendances.filter(a => 
        a.event_id === event.id && 
        a.status !== 'feedback_submitted'
      );

      for (const attendance of eventAttendances) {
        const existingAssignment = assignments.find(a => 
          a.object_type === 'event' && 
          a.object_id === event.id && 
          a.user_id === attendance.user_email
        );

        if (!existingAssignment) {
          await Assignment.create({
            object_type: 'event',
            object_id: event.id,
            user_id: attendance.user_email,
            role: 'feedback_required',
            due_dt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
            status: 'open'
          });
          remindersCreated++;
        } else if ((existingAssignment.reminder_count || 0) < 3) {
          await Assignment.update(existingAssignment.id, {
            last_reminder_sent: new Date().toISOString(),
            reminder_count: (existingAssignment.reminder_count || 0) + 1
          });
          remindersSent++;
        }
      }
    }

    return {
      rows_affected: remindersCreated + remindersSent,
      notes: `Processed ${pastEvents.length} past events: ${remindersCreated} new reminders, ${remindersSent} follow-ups.`
    };
};

// 7. Month-End KPIs Job
const monthEndKPIsLogic = async () => {
    const periodMonth = new Date().toISOString().slice(0, 7) + '-01';
    const monthStart = new Date(periodMonth);
    const monthEnd = new Date(monthStart.getFullYear(), monthStart.getMonth() + 1, 0);

    const [targets, pitches] = await Promise.all([
      TargetEntity.list(),
      Pitch.list()
    ]);

    const leads_created = targets.filter(t => 
      new Date(t.created_date) >= monthStart && new Date(t.created_date) <= monthEnd
    ).length;

    const meetings_set = pitches.filter(p => 
      p.meeting_dt && 
      new Date(p.meeting_dt) >= monthStart && 
      new Date(p.meeting_dt) <= monthEnd
    ).length;

    const pitches_issued = pitches.filter(p => 
      p.status === 'issued' &&
      new Date(p.updated_date) >= monthStart && 
      new Date(p.updated_date) <= monthEnd
    ).length;

    const wins = targets.filter(t => 
      t.status === 'won' &&
      new Date(t.updated_date) >= monthStart && 
      new Date(t.updated_date) <= monthEnd
    ).length;
    
    const activeTargets = targets.filter(t => t.status === 'prospect' || t.status === 'working');
    const avg_priority_score = activeTargets.length > 0 ? 
      Math.round(activeTargets.reduce((sum, t) => sum + (t.priority_score || 0), 0) / activeTargets.length) : 0;

    const top20Targets = targets.filter(t => t.is_top_20);
    const top20_filled_pct = Math.round((top20Targets.length / 20) * 100);

    const avg_cycle_days = 45; // Placeholder, would be calculated from won pitches/briefs

    const existingKPI = await BDKPI.filter({ period_month: periodMonth });
    const kpiData = {
      period_month: periodMonth,
      leads_created,
      meetings_set,
      pitches_issued,
      wins,
      avg_priority_score,
      top20_filled_pct,
      avg_cycle_days
    };

    if (existingKPI.length > 0) {
      await BDKPI.update(existingKPI[0].id, kpiData);
    } else {
      await BDKPI.create(kpiData);
    }

    return {
      rows_affected: 1,
      notes: `KPIs for ${new Date(periodMonth).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })} saved.`
    };
};

// 8. Generate Pre-Event Briefs Job
const generatePreEventBriefsLogic = async () => {
    const upcomingEvents = await Event.filter({
      start_dt: { $gte: new Date().toISOString() }
    });

    let briefsGenerated = 0;

    for (const event of upcomingEvents.slice(0, 5)) { // Limit to 5 for demonstration
      const existingDoc = await Document.filter({ event_id: event.id, document_type: 'event_brief' });
      if (existingDoc.length > 0) continue;

      await Document.create({
        event_id: event.id,
        document_name: `Pre-Event Brief: ${event.title}`,
        document_type: 'event_brief',
        document_topic: 'Events',
        file_url: 'https://example.com/brief.pdf', // Placeholder
        uploaded_by: 'system',
        is_client_visible: false,
        description: `Generated pre-event brief for ${event.title}`
      });
      briefsGenerated++;
    }

    return {
      rows_affected: briefsGenerated,
      notes: `Generated ${briefsGenerated} pre-event briefs for upcoming events.`
    };
};

const jobLogics = {
  'ingest-signals': ingestSignalsLogic,
  'refresh-target-scores': refreshTargetScoresLogic,
  'rebuild-top20': rebuildTop20Logic,
  'deal-sync': dealSyncLogic,
  'pull-events-roi': pullEventsROILogic,
  'lease-expiry-watcher': refreshTargetScoresLogic, // Uses the same logic as full refresh for now
  'month-end-kpis': monthEndKPIsLogic,
  'post-event-feedback': postEventFeedbackLogic,
  'generate-pre-event-briefs': generatePreEventBriefsLogic,
};

export function CommandPalette({ open, onOpenChange }) {
  const [search, setSearch] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const { toast } = useToast();

  const filteredCommands = COMMANDS.filter(command =>
    command.title.toLowerCase().includes(search.toLowerCase()) ||
    command.description.toLowerCase().includes(search.toLowerCase()) ||
    command.category.toLowerCase().includes(search.toLowerCase())
  );

  useEffect(() => {
    setSelectedIndex(0);
  }, [search]);

  const executeCommand = useCallback(async (commandId) => {
    onOpenChange(false);
    setSearch('');
    
    const jobLogic = jobLogics[commandId];
    const command = COMMANDS.find(c => c.id === commandId);

    if (jobLogic && command) {
      toast({
        title: `${command.title} Started`,
        description: "Job is running in the background..."
      });

      try {
        const result = await runJob(command.title, jobLogic);
        toast({
          title: `${command.title} Complete`,
          description: `${result.notes}`,
          variant: result.status === 'failed' ? 'destructive' : 'default'
        });
      } catch (error) {
        toast({
          variant: 'destructive',
          title: `${command.title} Failed`,
          description: error.message
        });
      }
    }
  }, [onOpenChange, toast]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => Math.min(prev + 1, filteredCommands.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => Math.max(prev - 1, 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredCommands[selectedIndex]) {
        executeCommand(filteredCommands[selectedIndex].id);
      }
    }
  }, [filteredCommands, selectedIndex, executeCommand]);

  useEffect(() => {
    if (open) {
      document.addEventListener('keydown', handleKeyDown);
      return () => document.removeEventListener('keydown', handleKeyDown);
    }
  }, [open, handleKeyDown]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="orbit-card max-w-lg p-0 text-white">
        <DialogHeader className="p-4 border-b border-gray-700">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Type a command or search..."
              className="orbit-input pl-9"
              autoFocus
            />
          </div>
        </DialogHeader>
        <div className="p-2">
          {filteredCommands.length > 0 ? (
            <div className="space-y-1">
              {filteredCommands.map((command, index) => {
                const Icon = command.icon;
                return (
                  <div
                    key={command.id}
                    onClick={() => executeCommand(command.id)}
                    className={`flex items-center justify-between p-3 rounded-lg cursor-pointer ${
                      selectedIndex === index ? 'bg-gray-700/50' : 'hover:bg-gray-800/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm font-medium">{command.title}</p>
                        <p className="text-xs text-gray-400">{command.description}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="border-gray-600 text-gray-400 text-xs">{command.category}</Badge>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-center text-gray-400 p-8">No commands found.</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

const commandPaletteContext = React.createContext({
  open: false,
  setOpen: (open) => {},
});

export const useCommandPalette = () => React.useContext(commandPaletteContext);
