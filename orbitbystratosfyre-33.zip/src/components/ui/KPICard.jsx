import React from "react";
import { Card, CardContent } from "@/components/ui/card";

export default function KPICard({ title, value, delta = 0, spark = null, footnote = null }) {
  const up = delta > 0;
  const down = delta < 0;
  return (
    <Card className="shadow-elevated overflow-hidden">
      <CardContent className="p-3">
        <div className="flex items-start justify-between">
          <div className="text-xs text-gray-400">{title}</div>
          <div className={`px-1.5 py-0.5 rounded-md text-[11px] ${up ? "bg-emerald-900/30 text-emerald-300" : down ? "bg-rose-900/30 text-rose-300" : "bg-white/5 text-gray-300"}`}>
            {up ? "▲" : down ? "▼" : "•"} {Math.abs(delta)}%
          </div>
        </div>
        <div className="mt-1 text-lg font-semibold">{fmt(value)}</div>
        <div className="-mx-1 mt-1">{spark}</div>
        {footnote && <div className="mt-1 text-[11px] text-gray-500">{footnote}</div>}
      </CardContent>
    </Card>
  );
}

function fmt(v){
  try {
    if (typeof v === "number") return v.toLocaleString("en-AU");
    return String(v ?? "—");
  } catch { return String(v ?? "—"); }
}