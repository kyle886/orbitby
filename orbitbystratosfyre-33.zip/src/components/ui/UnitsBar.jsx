import React from 'react';
import { useUnits } from '@/components/utils/units';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export const UnitsBar = () => {
  const { preferences, setPreferences, loading } = useUnits();

  if (loading) return null;

  return (
    <div className="surface p-2 mb-2">
      <div className="flex items-center justify-between gap-2 text-sm">
        <div className="flex items-center gap-4">
          <span className="text-xs text-gray-400 font-medium ml-2">Display Units:</span>
          <div>
            <Select
              value={preferences.region}
              onValueChange={(value) => setPreferences({ ...preferences, region: value })}
            >
              <SelectTrigger className="border-0 bg-transparent h-8 text-white focus:ring-0 ring-focus">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="AU">AU</SelectItem>
                <SelectItem value="US">US</SelectItem>
                <SelectItem value="UK">UK</SelectItem>
                <SelectItem value="EU">EU</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <span className="text-xs text-gray-400 font-medium">Currency</span>
          <Select
            value={preferences.currency}
            onValueChange={(value) => setPreferences({ ...preferences, currency: value })}
          >
            <SelectTrigger className="border-0 bg-transparent h-8 text-white focus:ring-0 ring-focus">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="AUD">AUD</SelectItem>
              <SelectItem value="USD">USD</SelectItem>
              <SelectItem value="GBP">GBP</SelectItem>
              <SelectItem value="EUR">EUR</SelectItem>
            </SelectContent>
          </Select>

          <span className="text-xs text-gray-400 font-medium">Area</span>
          <Select
            value={preferences.area_unit}
            onValueChange={(value) => setPreferences({ ...preferences, area_unit: value })}
          >
            <SelectTrigger className="border-0 bg-transparent h-8 text-white focus:ring-0 ring-focus">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="m2">sqm</SelectItem>
              <SelectItem value="ft2">sqft</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
};