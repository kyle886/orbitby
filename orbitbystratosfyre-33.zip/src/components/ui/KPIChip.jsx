import React from "react";
export default function KPIChip({ label, value, trend = null }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-xl border border-white/10 bg-white/5">
      <div className="text-xs text-gray-300">{label}</div>
      <div className="text-sm font-semibold text-white">{value}</div>
      {trend && (
        <span className={`text-[11px] font-medium ${trend > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
          {trend > 0 ? '▲' : '▼'} {Math.abs(trend)}%
        </span>
      )}
    </div>
  );
}